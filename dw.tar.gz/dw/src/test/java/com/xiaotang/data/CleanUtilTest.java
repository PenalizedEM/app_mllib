package com.xiaotang.data;

import com.xiaotang.data.cfg.UIParameterOption;
import com.xiaotang.data.util.CleanUtil;
import com.xiaotang.data.util.ETLUtil;

import java.util.HashMap;

/**
 * Clean unit test
 * Created by vent on 6/17/16.
 */
public class CleanUtilTest {


            public static void main(String[] args)
            {
                HashMap<String,String>  testMAP = new HashMap<String,String>();
                testMAP.put(UIParameterOption.U_ACTIVE,"1");
                testMAP.put(UIParameterOption.U_FRESH,"1");
                testMAP.put(UIParameterOption.U_TIME_STAMP_F,"2016-06-08 06:46:46");
                testMAP.put(UIParameterOption.ES_U_UID,"111aa");
                testMAP.put(UIParameterOption.ES_U_UID, CleanUtil.cleanFiled(CleanUtil.numberPat, testMAP.get(UIParameterOption.ES_U_UID)));
                System.out.println("uid: "+testMAP.get(UIParameterOption.ES_U_UID));



            }

}
