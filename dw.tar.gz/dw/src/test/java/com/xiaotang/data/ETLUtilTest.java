package com.xiaotang.data;

import com.xiaotang.data.cfg.FieldOrderSchema;
import com.xiaotang.data.cfg.UIParameterOption;
import com.xiaotang.data.util.ETLUtil;

import java.util.HashMap;

/**
 * ETLUtil unit test
 * Created by vent on 6/17/16.
 */
public class ETLUtilTest {


            public static void main(String[] args)
            {
                HashMap<String,String>  testMAP = new HashMap<String,String>();
                testMAP.put(UIParameterOption.U_ACTIVE,"1");
                testMAP.put(UIParameterOption.U_FRESH,"1");
                //testMAP.put(UIParameterOption.U_TIME_STAMP_F,"2016-06-01 06:46:46");
                testMAP.put(UIParameterOption.U_TIME_STAMP,"2016-06-08 06:46:46");
                HashMap<String,String>  uiMAP = new HashMap<String,String>();
                uiMAP.put(UIParameterOption.U_ACTIVE,"1");
                uiMAP.put(UIParameterOption.U_FRESH,"1");
                uiMAP.put(UIParameterOption.U_TIME_STAMP_F,"2016-06-01 06:46:46");
                uiMAP.put(UIParameterOption.U_TIME_STAMP,"2016-06-01 11:46:46");
                System.out.println(uiMAP.get(UIParameterOption.U_TIME_STAMP));
                ETLUtil.updateActive(testMAP);
                //ETLUtil.updateFresh(testMAP, "2016-06-16");
                ETLUtil.updateUI(testMAP,uiMAP, FieldOrderSchema.Update_User_Info);
                System.out.println(testMAP.get(UIParameterOption.U_ACTIVE));
                //System.out.println(testMAP.get(UIParameterOption.U_FRESH));
                System.out.println(uiMAP.get(UIParameterOption.U_TIME_STAMP));
            }

}
