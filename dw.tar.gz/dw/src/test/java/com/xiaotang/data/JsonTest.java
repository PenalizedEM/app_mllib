package com.xiaotang.data;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import com.xiaotang.data.cfg.ESParameterOption;
import com.xiaotang.data.cfg.UIParameterOption;
import com.xiaotang.data.util.CleanUtil;
import com.xiaotang.data.util.ETLUtil;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.lang.reflect.Type;
import java.util.*;

/**
 * A test class for gson
 * Created by vent on 6/1/16.
 */
public class JsonTest {
    public void getJsonRight()
    {

    }
    public static void main(String[] args)
    {
        //String gsonString = "{\"@timestamp\":\"2016-03-26T00:00:00.000Z\",\"host\":\"10.10.222.184\",\"clientip\":\"10.10.251.83\",\"size\":\"62\",\"responsetime\":\"0.045\",\"backtime\":\"0.045\",\"http_host\":\"aa.tangdou.com\",\"xff\":\"123.234.166.49\",\"referer\":\"-\",\"agent\":\"Dalvik/1.6.0 (Linux; U; Android 4.4.4; HM NOTE 1S MIUI/V6.6.2.0.KHKCNCF)\",\"status\":\"200\",\"@version\":\"1\",\"path\":\"/data2/wwwlogs/access.log\",\"type\":\"rs\",\"method\":\"POST\",\"verb\":\"HTTP/1.1\",\"url_path\":\"POST /api.php\",\"u_mod\":\"top\",\"u_ac\":\"video_play_speed\",\"u_vid\":\"7853965\",\"u_rate\":57,\"u_client\":\"2\",\"u_uuid\":\"53242cf29e0e0c78d8ed728ce49b6c57\",\"u_device\":\"HM+NOTE+1S-Android:4.4.4\",\"u_channel\":\"xiaomi\",\"u_ver\":\"v2\",\"u_package\":\"com.bokecc.dance\",\"u_version\":\"4.1.7\",\"u_lon\":\"120.334244\",\"u_lat\":\"36.081884\",\"u_city\":\"青岛市\",\"u_province\":\"山东省\",\"u_xinge\":\"2bc858a2424f2a894ebeb71d85bab0b0a2dd984a\",\"u_div\":\"4.1.7\",\"u_dic\":\"xiaomi\",\"u_diu\":\"868190024646390\",\"u_diu2\":\"f48b32f8fc86\",\"u_diu3\":\"0326f626a22a45ec8f144105da075623\",\"u_startid\":\"7372579\",\"u_setpid\":\"4\",\"u_width\":\"720\",\"u_height\":\"1280\",\"u_nettype\":\"WIFI\",\"u_netop\":\"中国联通\",\"u_SDKVersion\":\"4.4.4\",\"u_model\":\"HM+NOTE+1S\",\"u_device_s\":\"gucci\",\"u_manufacture\":\"Xiaomi\",\"u_time\":\"1458950403387\",\"u_hash\":\"6213c8900fb4372f2281f2972794e3f1\"}";
        String gsonString ="{\n" +
                "    \"@timestamp\": \"2016-06-08T06:46:46.000Z\",\n" +
                "    \"host\": \"10.10.47.46\",\n" +
                "    \"clientip\": \"10.10.251.104\",\n" +
                "    \"size\": \"31\",\n" +
                "    \"responsetime\": \"0.007\",\n" +
                "    \"backtime\": \"0.002\",\n" +
                "    \"http_host\": \"aa.tangdou.com\",\n" +
                "    \"xff\": \"202.189.0.2\",\n" +
                "    \"referer\": \"-\",\n" +
                "    \"agent\": \"Dalvik/2.1.0 (Linux; U; Android 5.0.2; Redmi Note 2 MIUI/V7.2.3.0.LHMCNDA)\",\n" +
                "    \"status\": \"200\",\n" +
                "    \"@version\": \"1\",\n" +
                "    \"path\": \"/data2/wwwlogs/access.log\",\n" +
                "    \"type\": \"rs\",\n" +
                "    \"method\": \"POST\",\n" +
                "    \"verb\": \"HTTP/1.1\",\n" +
                "    \"url_path\": \"POST /api.php\",\n" +
                "    \"u_mod\": \"emptylog\",\n" +
                "    \"u_ac\": \"search_onclick\",\n" +
                "    \"u_position\": \"10\",\n" +
                "    \"u_page\": \"1\",\n" +
                "    \"u_vid\": \"7970260\",\n" +
                "    \"u_key\": \"幸福因为有你\",\n" +
                "    \"u_source\": \"vtag_teach\",\n" +
                "    \"u_type\": \"2\",\n" +
                "    \"u_client_module\": \"tag\",\n" +
                "    \"u_client\": \"2\",\n" +
                "    \"u_uuid\": \"76f98322c88b6ffbf1ec0cdda3f2dd4d\",\n" +
                "    \"u_device\": \"Redmi+Note+2-Android:5.0.2\",\n" +
                "    \"u_channel\": \"gf\",\n" +
                "    \"u_ver\": \"v2\",\n" +
                "    \"u_package\": \"com.bokecc.dance\",\n" +
                "    \"u_version\": \"4.5.6.6\",\n" +
                "    \"u_token\": \"ef3f8e3626293bdcf4fb7f01fed37948\",\n" +
                "    \"u_uid\": \"245896\",\n" +
                "    \"u_lon\": \"116.354889\",\n" +
                "    \"u_lat\": \"39.988468\",\n" +
                "    \"u_city\": \"北京市\",\n" +
                "    \"u_province\": \"北京市\",\n" +
                "    \"u_xinge\": \"e3eea7ce314d5866483f8af93e622bc0bf60ed16\",\n" +
                "    \"u_div\": \"4.5.6.6\",\n" +
                "    \"u_dic\": \"gf\",\n" +
                "    \"u_diu\": \"869043026602292\",\n" +
                "    \"u_diu2\": \"fc64bac4e3b2\",\n" +
                "    \"u_diu3\": \"992016dfb5a24855af9cb8077ab5b72a\",\n" +
                "    \"u_startid\": \"13789600\",\n" +
                "    \"u_stepid\": \"314\",\n" +
                "    \"u_width\": \"1080\",\n" +
                "    \"u_height\": \"1920\",\n" +
                "    \"u_nettype\": \"WIFI\",\n" +
                "    \"u_netop\": \"联通\",\n" +
                "    \"u_sdkversion\": \"5.0.2\",\n" +
                "    \"u_model\": \"Redmi+Note+2\",\n" +
                "    \"u_device_s\": \"hermes\",\n" +
                "    \"u_manufacture\": \"Xiaomi\",\n" +
                "    \"u_time\": \"1465368430127\",\n" +
                "    \"u_来了\": \"1465368430127\",\n" +
                "    \"u_hash\": \"6260436223538ccf0b57a9cffd8746e2\"\n" +
                "  }";
        JsonParser parser = new JsonParser();
        JsonObject jsonObject = parser.parse(gsonString).getAsJsonObject();


        DateTime dataDate = new DateTime(jsonObject.get("@timestamp").getAsJsonPrimitive().getAsString());
        //System.out.println(dataDate.toString());
        //ETLUtil.safeCheck(gsonString,"u_time");
        //System.out.println(new DateTime(ETLUtil.safeCheck(gsonString, ESParameterOption.TIME_STAMP)).toString());
        //System.out.println(new DateTime(ETLUtil.safeCheck(gsonString, ESParameterOption.TIME_STAMP)).toString(ETLUtil.hiveTimeStampFormat));
        //System.out.println(new DateTime(ETLUtil.safeCheck(gsonString, ESParameterOption.TIME_STAMP)).getMillis());
       // System.out.println(new LocalDateTime(ETLUtil.safeCheck(gsonString, ESParameterOption.TIME_STAMP)));
        //System.out.println(new DateTime(ETLUtil.safeCheck(gsonString, ESParameterOption.TIME_STAMP)).toString());
       // System.out.println(ETLUtil.limitSafeCheck(gsonString, ESParameterOption.ES_U_CLIENT_MODULE));
        TreeMap<Long,HashMap<String,String>> uiTm= new TreeMap<Long,HashMap<String,String>>();
       // System.out.println(uiTm.size());
        //List<Video> videos = gson.fromJson(json, new TypeToken<List<Video>>(){}.getType());
        JsonParser tParser = new JsonParser();
        JsonObject tjsonObject = parser.parse(gsonString).getAsJsonObject();
        Set<Map.Entry<String, JsonElement>> entries = tjsonObject.entrySet();//will return members of your object
        List<String> hrList = new ArrayList();
       // entries.removeAll();
        for (Map.Entry<String, JsonElement> entry: entries) {
            //System.out.println(entry.getKey());

            //System.out.println(entry.getKey());

            //System.out.println(CleanUtil.isClean(CleanUtil.enPat, entry.getKey()));

               if(!CleanUtil.isClean(CleanUtil.enPat,entry.getKey()))
                {
                    System.out.println(entry.getKey());
                    hrList.add(entry.getKey());
                   // System.out.println(CleanUtil.isClean(CleanUtil.diuPat, entry.getKey()));
                }
            //
        }
        for(String h2r : hrList)
        {
            tjsonObject.remove(h2r);
        }
        System.out.println("MAP1: "+entries.size());
        entries.removeAll(hrList);
        System.out.println("MAP2: "+entries.size());
        System.out.println("MAP3: "+entries.contains("u_来了"));
        System.out.println("json: "+tjsonObject.has("u_来了"));
        Gson gson = new Gson();
        Type stringStringMap = new TypeToken<Map<String, String>>(){}.getType();
        Map<String,String> map = gson.fromJson(gsonString, stringStringMap);
       // System.out.println("MAP: "+map.size());


        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        System.out.println(formatter.parseDateTime("2016-06-08 06:46:46").getMillis()) ;
        System.out.println(formatter.parseDateTime("2016-06-08 06:46:46")) ;
        System.out.println("Day Difference : "
                + Days.daysBetween(formatter.parseDateTime("2016-06-08 06:46:46").withTimeAtStartOfDay(), new DateTime("2016-06-18").withTimeAtStartOfDay()).getDays());
    }
}
