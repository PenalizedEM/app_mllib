use edw;
CREATE EXTERNAL TABLE IF NOT EXISTS edw.user_dvlog(
    u_timestamp STRING COMMENT '东八区时间',
  u_host STRING COMMENT '服务器内网ip',
  u_xff STRING COMMENT '客户端ip',
  u_status STRING COMMENT 'http状态',
  u_size STRING COMMENT 'http返回大小',
  u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
  u_dic STRING COMMENT '客户端渠道代码',
  u_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
  u_diu2 STRING COMMENT '广告ID,android--mac, ios--IDFA',
  u_diu3 STRING COMMENT 'GUID,android--guid, ios--guid',
  u_uid STRING COMMENT '注册用户id',
  u_time STRING COMMENT '客户端时间戳',
  u_mod STRING COMMENT '服务端接口模块',
  u_ac STRING COMMENT '服务端具体接口',
  u_client STRING COMMENT '客户端类型',
  u_ver STRING COMMENT '服务端版本',
  u_uuid STRING COMMENT '用户设备号(md5)',
  u_hash STRING COMMENT '加密验证串',
  u_xinge STRING COMMENT '信鸽token',
  u_token STRING COMMENT '用户单点登录token',
  u_agent STRING COMMENT '客户端agent',
  u_method STRING COMMENT 'http方法',
  u_client_module STRING COMMENT '用户曝光模块',
  u_source STRING COMMENT '用户曝光页面',
  u_vid STRING COMMENT '视频的id',
  u_width STRING COMMENT '屏幕尺寸——宽',
  u_height STRING COMMENT '屏幕尺寸——高',
  u_lon STRING COMMENT '用户位置——经度',
  u_lat STRING COMMENT '用户位置——纬度',
  u_province STRING COMMENT '用户省份',
  u_city STRING COMMENT '用户城市',
  u_netop STRING COMMENT '网络运营商',
  u_nettype STRING COMMENT '网络类型',
  u_sdkversion STRING COMMENT 'android 系统版本号',
  u_model STRING COMMENT 'ios:固件版本, android:手机模型',
  u_device STRING COMMENT 'ios:设备型号, android:设备',
  u_manufacture STRING COMMENT '厂商',
  u_rsource STRING COMMENT '推荐队列',
  u_rank STRING COMMENT '推荐结果排序位置',
  u_rmodelid STRING COMMENT '推荐模型ID',
  u_ruuid STRING COMMENT '推荐曝光唯一标识ID',
  u_strategyid STRING COMMENT '推荐策略ID'
)
COMMENT '基础数据层——曝光日志'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/edw/user_dvlog';


ALTER TABLE edw.user_dvlog ADD IF NOT EXISTS
PARTITION (dt='2017-09-01') LOCATION '/dw/edw/user_dvlog/2017-09-01/';