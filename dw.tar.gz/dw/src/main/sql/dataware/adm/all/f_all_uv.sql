use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_all_uv(
    d_client int COMMENT '客户端类型',
    d_abtag string COMMENT 'abtag',
    m_dau int COMMENT '日活',
    m_vu int COMMENT '播放视频的用户数',
    m_vvrate float COMMENT '播放视频的用户比例'
)
COMMENT '数据集市层——事实表——大盘各tag日活跃用户数,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_all_uv';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_all_uv PARTITION(dt='${datebuf}')
select
  d_client,
--  case when (d_abtag>=0 and d_abtag<=99) then '0_99'
--  when d_abtag in ('A','B') then d_abtag
--  else 'other'
--  end as d_abtag,
  '' as d_abtag,
  count(distinct d_diu) m_dau,
  count(distinct if((m_litevv + m_vv)>0,d_diu,null)) m_vu,
  round( count(distinct if((m_litevv + m_vv)>0,d_diu,null))/count(distinct d_diu)*100,1) m_vvrate
from adm.f_user_act
where dt='${datebuf}'
group by
  d_client
--  case when (d_abtag>=0 and d_abtag<=99) then '0_99'
--  when d_abtag in ('A','B') then d_abtag
--  else 'other'
--  end
;