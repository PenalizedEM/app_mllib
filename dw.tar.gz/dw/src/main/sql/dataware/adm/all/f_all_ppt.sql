use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_all_ppt(
    d_client int COMMENT '客户端类型',
    m_pt int COMMENT '播放时长',
    m_vu int COMMENT '播放人数',
    m_ppt float COMMENT '人均播放时长'
)
COMMENT '数据集市层——事实表——大盘人均播放时长(注:播放时长仅限安卓535,IOS517及以上版本参与统计),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_all_ppt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;
-- 在算大盘人均时长时候,需要注意,播放人数只取和播放时长对应的版本,低于此版本的的播放不计入统计。and if(d_client=2, d_div>='5.3.5', d_div>='5.1.7')
-- 在计算具体AB实验的人均时长时候,可以忽略这个细节,因为有ABtag的版本都大于播放时长改版的版本。

insert OVERWRITE table adm.f_all_ppt PARTITION(dt='${datebuf}')
select
  a.d_client,
  m_pt,
  m_vu,
  round(m_pt/m_vu,1) m_ppt
from
(
  select
    d_client,
    sum(m_pt) m_pt
  from adm.f_video_pt
  where dt='${datebuf}'
  group by
    d_client
) a
join
(
  select
    d_client,
    count(distinct d_diu) m_vu
  from adm.f_video_vv
  where dt='${datebuf}'
  and if(d_client=2, d_div>='5.3.5', d_div>='5.1.7')
  group by
    d_client
) b
on(a.d_client=b.d_client )
;