use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_all_vv(
    d_terminal string COMMENT '终端类型, M站, APP',
    d_client string COMMENT '客户单类型: AND-安卓,IOS-苹果',
    d_vtype string COMMENT '视频类型: 小视频,大视频',
    m_vv int COMMENT '播放次数'
)
COMMENT '数据集市层——事实表——大盘视频播放量,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_all_vv';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_all_vv PARTITION(dt='${datebuf}')
select
d_terminal,
d_client,
if(type='10','小视频','大视频') d_vtype,
sum(m_vv) m_vv
from
(
select 'M站' d_terminal, '-' d_client , d_vid, sum(m_vv) m_vv  from adm.f_video_vv_m where dt='${datebuf}' group by d_vid
union all
select 'APP' d_terminal, if(d_client=1,'IOS',if(d_client=2,'AND','-')) d_client, d_vid, sum(m_vv) m_vv from adm.f_video_vv where dt='${datebuf}' group by if(d_client=1,'IOS',if(d_client=2,'AND','-')), d_vid
) a
join dw.video b
on(a.d_vid=b.vid)
group by
d_terminal,
d_client,
if(type='10','小视频','大视频')
;