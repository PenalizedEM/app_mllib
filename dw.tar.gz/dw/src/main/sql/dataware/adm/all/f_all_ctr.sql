use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_all_ctr(
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_client int COMMENT '客户端类型',
    m_vv bigint COMMENT '点击次数',
    m_dv int COMMENT '曝光次数',
    m_ctr float COMMENT '点击率'
)
COMMENT '数据集市层——事实表——大盘各模块点击率,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_all_ctr';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_all_ctr PARTITION(dt='${datebuf}')
select
  a.d_source,
  a.d_module,
  a.d_client,
  m_vv,
  m_dv,
  round(m_vv/m_dv*100,1) m_ctr
from
(
select
        d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end as d_module,
						d_client,
        sum(m_dv) m_dv
from adm.f_video_cmdv
where dt='${datebuf}'
group by d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end,
						d_client
) a
join
(
select
        d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end as d_module,
						d_client,
        sum(m_vv) m_vv
from adm. f_video_vv
where dt='${datebuf}'
group by d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end,
						d_client
) b
on(a.d_client=b.d_client and a.d_module=b.d_module and a.d_source=b.d_source  )
;