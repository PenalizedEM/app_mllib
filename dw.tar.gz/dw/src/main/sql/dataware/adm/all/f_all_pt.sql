use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_all_pt(
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_client int COMMENT '客户端类型',
    m_pt bigint COMMENT '播放时长',
    m_vu int COMMENT '播放人数',
    m_ppt float COMMENT '人均播放时长'
)
COMMENT '数据集市层——事实表——大盘各模块播放时长,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_all_pt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_all_pt PARTITION(dt='${datebuf}')
select
  a.d_source,
  a.d_module,
  a.d_client,
  m_pt,
  m_vu,
  round(m_pt/m_vu,1) m_ppt
from
(
select
        d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end as d_module,
						d_client,
        sum(m_pt) m_pt
from adm. f_video_pt
where dt='${datebuf}'
group by d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end,
						d_client
) a
join
(
select
        d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end as d_module,
						d_client,
    count(distinct d_diu) m_vu
from adm. f_video_vv
where dt='${datebuf}'
group by d_source,
	    case when d_module like '%框搜%' then '框搜'
       when d_module like '%猜你喜欢%' then '猜你喜欢'
       when d_module like '%视频%' then '空间视频'
       when d_module like '%每日精选%' then '每日精选'
       when d_module like '%分类搜%' then '分类搜'
       when d_module like '%糖豆广场%' then '糖豆广场'
       when d_module like '%舞曲搜%' then '舞曲搜'
       when d_module like '%我的关注%' then '我的关注'
       when d_module like '%关注流%' then '关注流'
       when d_module like '%热门%' then '热门'
       when d_module like '%附近搜%' then '附近搜'
       when d_module like '%糖豆生活%' then '糖豆生活'
       when d_module like '%最新更新%' then '最新更新'
       when d_module like '%相关推荐%' then '相关推荐'
       when d_module like '%喜欢%' then '空间喜欢'
       when d_module like '%H5跳转%' then 'H5跳转'
       when d_module like '%首页banner页%' then '首页banner页'
       when d_module like '%标签搜%' then '标签搜'
       when d_module like '%同城舞友%' then '同城舞友'
       when d_module like '%banner%' then 'banner'
       when d_module like '%广场舞名师教你%分钟轻松入门%' then '广场舞名师教你+5+分钟轻松入门'
       when d_module like '%简单又优美的舞蹈视频推荐%' then '简单又优美的舞蹈视频推荐'
       when d_module like '%为你量身定做的精品广场舞课堂%' then '为你量身定做的精品广场舞课堂'
       else '其他'
       end,
						d_client
) b
on( a.d_client=b.d_client and a.d_module=b.d_module and a.d_source=b.d_source  )
;