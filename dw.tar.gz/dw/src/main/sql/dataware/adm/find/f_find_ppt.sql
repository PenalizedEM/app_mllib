use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_find_ppt(
    d_abtag string COMMENT 'AB测试标示, A:有发现改版实验的, B无发现改版实验的',
    d_client int COMMENT '客户端类型',
    m_pt int COMMENT '播放时长',
    m_vu int COMMENT '播放人数',
    m_ppt float COMMENT '人均播放时长'
)
COMMENT '数据集市层——新版发现事实表-不同实验版本的人均播放时长(注:新版AB实验仅限安卓5.9.6及以上版本参与统计),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_find_ppt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_find_ppt PARTITION(dt='${datebuf}')
select
  a.d_abtag,
  a.d_client,
  m_pt,
  m_vu,
  round(m_pt/m_vu,1) m_ppt
from
(
    select
      case when d_abtag>=0 and d_abtag<=89 then 'A'
        when d_abtag>=90 and d_abtag<=99 then 'B'
        else 'others'
      end as d_abtag,
      d_client,
      sum(m_pt) m_pt
    from adm.f_video_pt
    where dt='${datebuf}'
    and d_client=2
    and d_div>='5.9.6'
    group by
      case when d_abtag>=0 and d_abtag<=89 then 'A'
        when d_abtag>=90 and d_abtag<=99 then 'B'
        else 'others'
      end ,
      d_client
) a
join
(
    select
      case when d_abtag>=0 and d_abtag<=89 then 'A'
        when d_abtag>=90 and d_abtag<=99 then 'B'
        else 'others'
      end as d_abtag,
      d_client,
      count(distinct d_diu) m_vu
    from adm.f_video_vv
    where dt='${datebuf}'
    and d_client=2
    and d_div>='5.9.6'
    group by
      case when d_abtag>=0 and d_abtag<=89 then 'A'
        when d_abtag>=90 and d_abtag<=99 then 'B'
        else 'others'
      end,
      d_client
) b
on(a.d_abtag=b.d_abtag and a.d_client=b.d_client )
;