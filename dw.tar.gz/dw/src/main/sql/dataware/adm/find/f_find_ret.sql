
use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_find_ret(
    d_abtag STRING COMMENT 'ABTag',
    m_dnu int COMMENT '新增用户数',
    m_ret int COMMENT '留存用户数',
    m_retrate float COMMENT '第n日留存率'
)
COMMENT '数据集市层——新版发现事实表-新旧版激活用户第n日留存,(注:新版AB实验仅限安卓5.9.6及以上版本参与统计)字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING, retdays STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_find_ret';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_find_ret PARTITION(dt='${datebuf}',retdays='${n}')
select a.d_abtag,
       count(distinct a.d_diu) new,
       count(distinct b.d_diu) ret,
       round(count(distinct b.d_diu)/count(distinct a.d_diu)*100,2) m_retrate
from
  ( select d_diu,
        case when dt>='2017-07-04'and d_abtag>=0 and d_abtag<=89 then 'A'
          when dt>='2017-07-04'and d_abtag>=90 and d_abtag<=99 then 'B'
          when  dt<'2017-07-04'and d_abtag>=0 and d_abtag<=19 then 'A'
          when  dt<'2017-07-04'and d_abtag>=20 and d_abtag<=99 then 'B'
          else 'others'
        end as d_abtag
   from f_user_act
   where dt='${datebuf}'
     and m_isnew>0
     and d_client=2
     and d_div>='5.9.6'
   group by d_diu,
        case when dt>='2017-07-04'and d_abtag>=0 and d_abtag<=89 then 'A'
          when dt>='2017-07-04'and d_abtag>=90 and d_abtag<=99 then 'B'
          when  dt<'2017-07-04'and d_abtag>=0 and d_abtag<=19 then 'A'
          when  dt<'2017-07-04'and d_abtag>=20 and d_abtag<=99 then 'B'
          else 'others'
        end
  )a
left outer join
  ( select d_diu
   from f_user_act
   where dt=date_add('${datebuf}', ${n} )
   group by d_diu )b on(a.d_diu=b.d_diu)
group by a.d_abtag ;

dfs -touchz /dw/adm/f_find_ret/dt=${datebuf}/retdays=${n}/_SUCCESS ;
