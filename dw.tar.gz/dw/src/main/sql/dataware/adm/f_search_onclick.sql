use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_search_onclick(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_examid STRING COMMENT 'AB实验ID',
    d_bucketid STRING COMMENT '分桶ID',
    d_abtag STRING COMMENT 'ABTag',
    d_gtag STRING COMMENT 'gTag',
    d_page int COMMENT '页码',
    d_position int COMMENT '位置',
    d_vid bigint COMMENT '视频的id',
    d_key STRING COMMENT '搜索关键词',
    d_type STRING COMMENT '搜索排序类型',
    m_cnt int COMMENT '视频播放次数'
)
COMMENT '数据集市层——事实表——搜索结果页点击播放'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_search_onclick';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
set hive.input.format=org.apache.hadoop.hive.ql.io.CombineHiveInputFor;
-- set mapreduce.map.memory.mb=2048;
set hive.exec.reducers.max=10;
insert OVERWRITE table adm.f_search_onclick PARTITION(dt='${datebuf}')
select
       if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))                                                           d_hour
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))                                                       d_minute
       ,if(u_div is null or u_div='','-',u_div)                                                                        d_div
       ,if(u_dic is null or u_dic='','-',u_dic)                                                                        d_dic
       ,if(u_uid is null or u_uid='',-1,u_uid)                                                                         d_uid
       ,if(u_client is null or u_client='',-1,u_client)                                                                d_client
       ,if(u_city is null or u_city='','-',u_city)                                                                     d_city
       ,if(u_source is null or u_source='','-',u_source)                                                               d_source
       ,if(u_client_module is null or u_client_module='','-',u_client_module)                                          d_module
       ,if(get_json_object(u_bigger_json,'$.u_examid') is null,'-',get_json_object(u_bigger_json,'$.u_examid'))        d_examid
       ,if(get_json_object(u_bigger_json,'$.u_bucketid') is null,'-',get_json_object(u_bigger_json,'$.u_bucketid'))    d_bucketid
       ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))          d_abtag
       ,if(get_json_object(u_bigger_json,'$.u_gtag') is null,'-',get_json_object(u_bigger_json,'$.u_gtag'))            d_gtag
       ,if(u_page is null or u_page='',-1,u_page)                                                                      d_page
       ,if(u_position is null or u_position='',-1,u_position)                                                          d_position
       ,if(u_vid is null or u_vid='',-1,u_vid)                                                                         d_vid
       ,if(u_key is null or u_key='','-',u_key)                                                                        d_key
       ,if(u_type is null or u_type='','-',u_type)                                                                     d_type
       ,count(1)                                                                                                       m_cnt
from edw.user_elog
where dt='${datebuf}'
and u_ac='search_onclick'

group by
       if(u_diu is null or u_diu='','-',u_diu)
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))
       ,if(u_div is null or u_div='','-',u_div)
       ,if(u_dic is null or u_dic='','-',u_dic)
       ,if(u_uid is null or u_uid='',-1,u_uid)
       ,if(u_client is null or u_client='',-1,u_client)
       ,if(u_city is null or u_city='','-',u_city)
       ,if(u_source is null or u_source='','-',u_source)
       ,if(u_client_module is null or u_client_module='','-',u_client_module)
       ,if(get_json_object(u_bigger_json,'$.u_examid') is null,'-',get_json_object(u_bigger_json,'$.u_examid'))
       ,if(get_json_object(u_bigger_json,'$.u_bucketid') is null,'-',get_json_object(u_bigger_json,'$.u_bucketid'))
       ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))
       ,if(get_json_object(u_bigger_json,'$.u_gtag') is null,'-',get_json_object(u_bigger_json,'$.u_gtag'))
       ,if(u_page is null or u_page='',-1,u_page)
       ,if(u_position is null or u_position='',-1,u_position)
       ,if(u_vid is null or u_vid='',-1,u_vid)
       ,if(u_key is null or u_key='','-',u_key)                                                                     
       ,if(u_type is null or u_type='','-',u_type)                                                                    
;
