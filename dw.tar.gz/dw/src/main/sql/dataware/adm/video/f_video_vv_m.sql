use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_vv_m(
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    u_cdn_source STRING COMMENT 'CDN',
    d_vid bigint COMMENT '视频的id',
    m_vv int COMMENT 'M站视频播放次数'
)
COMMENT '数据集市层——事实表——M站视频播放次数,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_video_vv_m';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_video_vv_m PARTITION(dt='${datebuf}')
select
        if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))                                                           d_hour
        ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))                                                       d_minute
        ,if(u_cdn_source is null or u_cdn_source='','-',u_cdn_source)
        ,if(u_vid is null or u_vid='',-1,u_vid)                                                                         d_vid
        ,count(1)                                                                                                       m_vv
from edw.user_ilog
where dt='${datebuf}'
and concat(u_mod,'-',u_ac)='top-hits_pc'
group by
        if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))
        ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))
        ,if(u_cdn_source is null or u_cdn_source='','-',u_cdn_source)
        ,if(u_vid is null or u_vid='',-1,u_vid)
;

dfs -touchz /dw/adm/f_video_vv_m/dt=${datebuf}/_SUCCESS ;
