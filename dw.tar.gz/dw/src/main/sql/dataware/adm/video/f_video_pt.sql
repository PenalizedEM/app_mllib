use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_pt(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_examid STRING COMMENT 'AB实验ID',
    d_bucketid STRING COMMENT '分桶ID',
    d_abtag STRING COMMENT 'ABTag',
    d_gtag STRING COMMENT 'gTag',
    d_vid bigint COMMENT '视频的id',
    m_pp bigint COMMENT '视频最大播放进度',
    m_pt bigint COMMENT '视频播放时长'
)
COMMENT '数据集市层——事实表——视频播放时长与进度(playtime),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_video_pt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

set mapreduce.map.memory.mb=2048;

-- f_video_pt总时长	mid_video_cmpt总时长	5月8日
-- 1415128864	1414602846	526018	去掉版本渠道
-- 1415119249	1414602846	516403	去掉城市
-- 1414602846	1414602846	0	去掉uid
-- 山寨机diu 一天内同一视频 会有多个 版本、城市、uid、渠道
-- 对于取非sum聚合的计算,上面的维度都需要单独计算。只有sum聚合才可以任意组合以上维度

-- 最后,对于城市、渠道、uid取 max 值 保证一个diu只有唯一一个相应的维度

insert OVERWRITE table adm.f_video_pt PARTITION(dt='${datebuf}')
select
  d_diu
  ,max(if(d_div is null or d_div='','-',d_div))                                                                        d_div
  ,max(if(d_dic is null or d_dic='','-',d_dic))                                                                        d_dic
  ,max(if(d_uid is null or d_uid='',-1,d_uid))                                                                         d_uid
  ,max(if(d_client is null or d_client='',-1,d_client))                                                                d_client
  ,max(if(d_city is null or d_city='','-',d_city))                                                                     d_city
  ,d_source
  ,d_module
  ,d_examid
  ,d_bucketid
  ,d_abtag
  ,d_gtag
  ,d_vid
  ,max(if(m_pp is null,0,m_pp))                                                                                        m_pp
  ,sum(if(m_pt>7200,7200,m_pt))                                                                                        m_pt   -- handle outlier
from
(
  select
         if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
         ,if(u_source is null or u_source='','-',u_source)                                                               d_source
         ,if(u_client_module is null or u_client_module='','-',u_client_module)                                          d_module
         ,if(get_json_object(u_bigger_json,'$.u_examid') is null,'-',get_json_object(u_bigger_json,'$.u_examid'))        d_examid
         ,if(get_json_object(u_bigger_json,'$.u_bucketid') is null,'-',get_json_object(u_bigger_json,'$.u_bucketid'))    d_bucketid
         ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))          d_abtag
         ,if(get_json_object(u_bigger_json,'$.u_gtag') is null,'-',get_json_object(u_bigger_json,'$.u_gtag'))            d_gtag
         ,if(get_json_object(u_bigger_json,'$.u_playid') is null,'-',get_json_object(u_bigger_json,'$.u_playid'))        d_playid
         ,if(u_vid is null or u_vid='',-1,u_vid)                                                                         d_vid
         ,max(u_client)                                                                                                  d_client
         ,max(u_div)                                                                                                     d_div
         ,max(u_dic)                                                                                                     d_dic
         ,max(u_uid)                                                                                                     d_uid
         ,max(u_city)                                                                                                    d_city
         ,max(if(u_percent>100,100,u_percent))                                                                           m_pp
         ,max(if(get_json_object(u_bigger_json,'$.u_playtime') is null,0,get_json_object(u_bigger_json,'$.u_playtime'))) m_pt
  from edw.user_elog
  where dt='${datebuf}'
  and if(u_client=2, u_div>='5.3.5', u_div>='5.1.7')
  and concat(u_mod,'-',u_ac)='emptylog-video_play_speed'
  group by
         if(u_diu is null or u_diu='','-',u_diu)
         ,if(u_source is null or u_source='','-',u_source)
         ,if(u_client_module is null or u_client_module='','-',u_client_module)
         ,if(get_json_object(u_bigger_json,'$.u_examid') is null,'-',get_json_object(u_bigger_json,'$.u_examid'))
         ,if(get_json_object(u_bigger_json,'$.u_bucketid') is null,'-',get_json_object(u_bigger_json,'$.u_bucketid'))
         ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))
         ,if(get_json_object(u_bigger_json,'$.u_gtag') is null,'-',get_json_object(u_bigger_json,'$.u_gtag'))
         ,if(get_json_object(u_bigger_json,'$.u_playid') is null,'-',get_json_object(u_bigger_json,'$.u_playid'))
         ,if(u_vid is null or u_vid='',-1,u_vid)
) a
group by
   d_diu
  ,d_client
  ,d_source
  ,d_module
  ,d_examid
  ,d_bucketid
  ,d_abtag
  ,d_gtag
  ,d_vid
;

dfs -touchz /dw/adm/f_video_pt/dt=${datebuf}/_SUCCESS ;
