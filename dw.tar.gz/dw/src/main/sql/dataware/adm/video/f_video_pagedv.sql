use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_pagedv(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_examid STRING COMMENT 'AB实验ID',
    d_bucketid STRING COMMENT '分桶ID',
    d_abtag STRING COMMENT 'ABTag',
    d_gtag STRING COMMENT 'gTag',
    m_dv int COMMENT '页面内模块展现次数'
)
COMMENT '数据集市层——事实表——页面内模块曝光次数,与模块曝光表cmdv的区别在于,如果一次曝光涉及多个模块,在cmdv表中,每个模块都会有一条记录,在pagedv中只有一条记录, pagedv用来统计页面的曝光和点击率,cmdv用来统计模块的点击率。字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_video_pagedv';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_video_pagedv PARTITION(dt='${datebuf}')

  select
         if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
         ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))                                                           d_hour
         ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))                                                       d_minute
         ,if(u_div is null or u_div='','-',u_div)                                                                        d_div
         ,if(u_dic is null or u_dic='','-',u_dic)                                                                        d_dic
         ,if(u_uid is null or u_uid='',-1,u_uid)                                                                         d_uid
         ,if(u_client is null or u_client='',-1,u_client)                                                                d_client
         ,if(u_city is null or u_city='','-',u_city)                                                                     d_city
         ,if(u_source is null or u_source='','-',u_source)                                                               d_source
         ,if(u_client_module is null or u_client_module='','-',u_client_module)                                          d_module
         ,if(get_json_object(u_bigger_json,'$.u_examid') is null,'-',get_json_object(u_bigger_json,'$.u_examid'))        d_examid
         ,if(get_json_object(u_bigger_json,'$.u_bucketid') is null,'-',get_json_object(u_bigger_json,'$.u_bucketid'))    d_bucketid
         ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))          d_abtag
         ,if(get_json_object(u_bigger_json,'$.u_gtag') is null,'-',get_json_object(u_bigger_json,'$.u_gtag'))            d_gtag
         ,count(1)                                                                                                       m_dv
  from edw.user_elog
  where dt='${datebuf}'
  and concat(u_mod,'-',u_ac)='emptylog-video_display'
  group by
         if(u_diu is null or u_diu='','-',u_diu)
         ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))
         ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))
         ,if(u_div is null or u_div='','-',u_div)
         ,if(u_dic is null or u_dic='','-',u_dic)
         ,if(u_uid is null or u_uid='',-1,u_uid)
         ,if(u_client is null or u_client='',-1,u_client)
         ,if(u_city is null or u_city='','-',u_city)
         ,if(u_source is null or u_source='','-',u_source)
         ,if(u_client_module is null or u_client_module='','-',u_client_module)
         ,if(get_json_object(u_bigger_json,'$.u_examid') is null,'-',get_json_object(u_bigger_json,'$.u_examid'))
         ,if(get_json_object(u_bigger_json,'$.u_bucketid') is null,'-',get_json_object(u_bigger_json,'$.u_bucketid'))
         ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))
         ,if(get_json_object(u_bigger_json,'$.u_gtag') is null,'-',get_json_object(u_bigger_json,'$.u_gtag'))
;

dfs -touchz /dw/adm/f_video_pagedv/dt=${datebuf}/_SUCCESS ;
