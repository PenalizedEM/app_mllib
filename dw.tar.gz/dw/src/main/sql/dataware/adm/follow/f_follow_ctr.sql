use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_follow_ctr(
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_client int COMMENT '客户端类型',
    d_abtag STRING COMMENT 'ABTag',
    m_vv int COMMENT '点击次数',
    m_dv int COMMENT '展示次数',
    m_ctr float COMMENT '点击率'
)
COMMENT '数据集市层——事实表——关注模块点击率,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_follow_ctr';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

 set hive.auto.convert.join = false;
insert OVERWRITE table adm.f_follow_ctr PARTITION(dt='${datebuf}')
select
  a.d_source,
  a.d_module,
  a.d_client,
  a.d_abtag,
  m_vv,
  m_dv,
  round(m_vv/m_dv,2) m_ctr
from
(
  select
    d_source,
    d_module,
    d_client,
    d_abtag,
    sum(m_dv) m_dv
  from adm.f_follow_cmdv
  where dt='${datebuf}'
    and d_abtag in ('A','B')
  group by
    d_source,
    d_module,
    d_client,
    d_abtag
  having m_dv>1000
) a
join
(
  select
    d_source,
    d_module,
    d_client,
    d_abtag,
    sum(m_vv) m_vv
  from adm.f_follow_vv
  where dt='${datebuf}'
    and d_abtag in ('A','B')
  group by
    d_source,
    d_module,
    d_client,
    d_abtag
  having m_vv>1000
) b
on(a.d_source=b.d_source and a.d_module=b.d_module and a.d_client=b.d_client and a.d_abtag=b.d_abtag)
;