
use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_follow_regrate(
    d_abtag STRING COMMENT 'ABTag',
    m_reg int COMMENT '新注册用户量',
    m_dau int COMMENT '日活',
    m_regrate float COMMENT '注册比'
)
COMMENT '数据集市层——事实表——关注实验注册用户量,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_follow_regrate';


set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;
insert OVERWRITE table adm.f_follow_regrate PARTITION(dt='${datebuf}')
select
  d_abtag
  ,count(distinct id) m_reg
  ,count(distinct d_diu) m_dau
  ,round(count(distinct id)/count(distinct d_diu)*100,2) m_regrate
from
(
  select
    d_diu,
    case when (d_abtag>=0 and d_abtag<=48) then 'A'
            when (d_abtag>50 and d_abtag<=99) then 'B'
            else 'other'
          end as d_abtag
    ,max(d_uid) d_uid
  from
    adm.f_user_act
  where
    dt='${datebuf}'
  group by
    d_diu,
    case when (d_abtag>=0 and d_abtag<=48) then 'A'
        when (d_abtag>50 and d_abtag<=99) then 'B'
        else 'other'
      end
) a
left outer join
(
  select id from dw.user where to_date(regtime)='${datebuf}'
) b
on(a.d_uid=b.id)
group by
  d_abtag
