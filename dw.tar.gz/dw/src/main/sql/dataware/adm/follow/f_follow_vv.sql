
use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_follow_vv(
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_client int COMMENT '客户端类型',
    d_div STRING COMMENT '客户端版本号',
    d_abtag STRING COMMENT 'ABTag',
    m_vv int COMMENT '模块展现次数'
)
COMMENT '数据集市层——事实表——关注页面点击(viewvideo),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_follow_vv';


set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;
insert OVERWRITE table adm.f_follow_vv PARTITION(dt='${datebuf}')
select
		if(d_abtag>50 and d_abtag<=99, '首页' ,d_source) d_source,
        case when d_module like '%我的关注%' then '我的关注'
        	when d_module like '%关注流%' and (d_abtag>50 and d_abtag<=99) then '我的关注'
        	else d_module
        	end as d_module,
		d_client,
				d_div,
        case when (d_abtag>=0 and d_abtag<=48) then 'A'
        	when (d_abtag>50 and d_abtag<=99) then 'B'
        	else 'other'
        end as d_abtag,
        sum(m_vv) m_vv
from adm. f_video_vv
where dt='${datebuf}'
  and d_module like '%关注%'
group by if(d_abtag>50 and d_abtag<=99, '首页' ,d_source),
        case when d_module like '%我的关注%' then '我的关注'
        	when d_module like '%关注流%' and (d_abtag>50 and d_abtag<=99) then '我的关注'
        	else d_module
        	end,
		d_client,
				d_div,
        case when (d_abtag>=0 and d_abtag<=48) then 'A'
        	when (d_abtag>50 and d_abtag<=99) then 'B'
        	else 'other'
        end
;
