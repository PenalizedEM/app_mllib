
use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_follow_followrate(
    d_abtag STRING COMMENT 'ABTag',
    m_dau int COMMENT '日活',
    m_follow_uv int COMMENT '有关注行为的用户数',
    m_follow int COMMENT '关注次数',
    m_regrate float COMMENT '关注率=有关注行为的用户数/日活'
)
COMMENT '数据集市层——事实表——关注实验关注率,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_follow_followrate';


set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;
insert OVERWRITE table adm.f_follow_followrate PARTITION(dt='${datebuf}')
select
  case when (d_abtag>=0 and d_abtag<=48) then 'A'
          when (d_abtag>50 and d_abtag<=99) then 'B'
          else 'other'
        end as d_abtag
  ,count(distinct d_diu) m_dau
  ,count(distinct if(m_follow>0,d_diu,null)) m_follow_uv
  ,sum(m_follow) m_follow
  ,round(count(distinct if(m_follow>0,d_diu,null))/count(distinct d_diu)*100,2) m_regrate
from
  adm.f_user_act
where
  dt='${datebuf}'
group by
  case when (d_abtag>=0 and d_abtag<=48) then 'A'
      when (d_abtag>50 and d_abtag<=99) then 'B'
      else 'other'
    end
