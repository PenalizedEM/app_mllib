use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_follow_ppt(
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_client int COMMENT '客户端类型',
    d_abtag STRING COMMENT 'ABTag',
    m_pt int COMMENT '播放时长',
    m_vu int COMMENT '播放人数',
    m_ppt float COMMENT '人均播放时长'
)
COMMENT '数据集市层——事实表——关注模块人均播放时长,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_follow_ppt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_follow_ppt PARTITION(dt='${datebuf}')
select
  a.d_source,
  a.d_module,
  a.d_client,
  a.d_abtag,
  m_pt,
  m_vu,
  round(m_pt/m_vu,1) m_ppt
from
(
  select
    d_source,
    d_module,
    d_client,
    d_abtag,
    sum(m_pt) m_pt
  from adm.f_follow_pt
  where dt='${datebuf}'
    and d_abtag in ('A','B')
  group by
    d_source,
    d_module,
    d_client,
    d_abtag
  having m_pt>1000
) a
join
(
  select
    d_source,
    d_module,
    d_client,
    d_abtag,
    m_vu
  from adm.f_follow_vu
  where dt='${datebuf}'
    and d_abtag in ('A','B')
    and m_vu>100
) b
on(a.d_source=b.d_source and a.d_module=b.d_module and a.d_client=b.d_client and a.d_abtag=b.d_abtag)
;