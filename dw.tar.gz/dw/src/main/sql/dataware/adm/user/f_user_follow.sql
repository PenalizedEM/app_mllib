use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_user_follow(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    d_ac STRING COMMENT '接口',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_reuid STRING COMMENT '关注用户的id',
    m_cnt int COMMENT '次数'
)
COMMENT '数据集市层——事实表——用户关注与取消关注操作,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_user_follow';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_user_follow PARTITION(dt='${datebuf}')
select
       if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))                                                           d_hour
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))                                                       d_minute
       ,if(u_ac is null or u_ac='', '-',u_ac)                                                                          d_ac
       ,if(u_div is null or u_div='','-',u_div)                                                                        d_div
       ,if(u_dic is null or u_dic='','-',u_dic)                                                                        d_dic
       ,if(u_uid is null or u_uid='',-1,u_uid)                                                                         d_uid
       ,if(u_client is null or u_client='',-1,u_client)                                                                d_client
       ,if(u_city is null or u_city='','-',u_city)                                                                     d_city
       ,if(get_json_object(u_bigger_json,'$.u_reuid') is null,'-',get_json_object(u_bigger_json,'$.u_reuid'))          d_reuid
       ,count(1)                                                                                                       m_cnt
from edw.user_ilog
where dt='${datebuf}'
and u_mod='user'
and u_ac in ('follow_user','unfollow_user')
group by
       if(u_diu is null or u_diu='','-',u_diu)
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))
       ,if(u_ac is null or u_ac='', '-',u_ac)
       ,if(u_div is null or u_div='','-',u_div)
       ,if(u_dic is null or u_dic='','-',u_dic)
       ,if(u_uid is null or u_uid='',-1,u_uid)
       ,if(u_client is null or u_client='',-1,u_client)
       ,if(u_city is null or u_city='','-',u_city)
       ,if(get_json_object(u_bigger_json,'$.u_reuid') is null,'-',get_json_object(u_bigger_json,'$.u_reuid'))
;

dfs -touchz /dw/adm/f_user_follow/dt=${datebuf}/_SUCCESS ;
