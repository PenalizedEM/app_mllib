use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_recy_ppt(
    d_abtag string COMMENT 'AB测试标示, A:有推荐实验的, B无推荐实验的, NA:新版中有推荐实验的, NB新版无推荐实验的',
    d_client int COMMENT '客户端类型',
    m_pt int COMMENT '播放时长',
    m_vu int COMMENT '播放人数',
    m_ppt float COMMENT '人均播放时长'
)
COMMENT '数据集市层——推荐事实表——不同实验版本的人均播放时长(注:播放时长仅限安卓535,IOS517及以上版本参与统计),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_recy_ppt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_recy_ppt PARTITION(dt='${datebuf}')
select
  a.d_abtag,
  a.d_client,
  m_pt,
  m_vu,
  round(m_pt/m_vu,1) m_ppt
from
(
  select
    d_abtag,
    d_client,
    sum(m_pt) m_pt
  from
  (
    select
      d_diu,
      case when d_abtag>=0 and d_abtag<=19 then 'NA'
        when d_abtag>=80 and d_abtag<=99 then 'NB'
        when d_abtag in ('A','B') then d_abtag
        else 'others'
      end as d_abtag,
      d_client,
      sum(m_pt) m_pt
    from adm.f_video_pt
    where dt='${datebuf}'
    group by
      d_diu,
      case when d_abtag>=0 and d_abtag<=19 then 'NA'
        when d_abtag>=80 and d_abtag<=99 then 'NB'
        when d_abtag in ('A','B') then d_abtag
        else 'others'
      end ,
      d_client
  )  a
  left outer join
  (
    select
      d_diu
    from adm.f_video_pt
    where dt='${datebuf}'
    and d_abtag='B'
    and d_module like '%相关推荐%'
    group by
      d_diu
  ) b
  on (a.d_diu=b.d_diu)
  where b.d_diu is null
  group by
    d_abtag,
    d_client
) a
join
(
  select
    d_abtag,
    d_client,
     count(distinct a.d_diu) m_vu
  from
  (
    select
      d_diu,
      case when d_abtag>=0 and d_abtag<=19 then 'NA'
        when d_abtag>=80 and d_abtag<=99 then 'NB'
        when d_abtag in ('A','B') then d_abtag
        else 'others'
      end as d_abtag,
      d_client
    from adm.f_video_vv
    where dt='${datebuf}'
    group by
      d_diu,
      case when d_abtag>=0 and d_abtag<=19 then 'NA'
        when d_abtag>=80 and d_abtag<=99 then 'NB'
        when d_abtag in ('A','B') then d_abtag
        else 'others'
      end,
      d_client
  )  a
  left outer join
  (
    select
      d_diu
    from adm.f_video_vv
    where dt='${datebuf}'
    and d_abtag='B'
    and d_module like '%相关推荐%'
    group by
      d_diu
  ) b
  on (a.d_diu=b.d_diu)
  where b.d_diu is null
  group by
    d_abtag,
    d_client
) b
on(a.d_abtag=b.d_abtag and a.d_client=b.d_client )
;