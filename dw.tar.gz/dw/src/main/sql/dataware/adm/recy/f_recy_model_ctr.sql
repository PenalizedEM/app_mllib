use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_recy_model_ctr(
    d_module string COMMENT '推荐流或关注流模块',
    d_rsource string COMMENT 'modelId',
    m_vv int COMMENT '总播放次数',
    m_dv int COMMENT '总展现次数',
    m_ctr float COMMENT '平均点击率'
)
COMMENT '数据集市层——推荐流中model的点击率,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_recy_model_ctr';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_recy_model_ctr PARTITION(dt='${datebuf}')
select
d_module,
d_rsource,
sum(m_vv) m_vv,
sum(m_dv) m_dv,
avg(m_ctr) m_ctr
from
(
    select
      a.d_module,
      a.d_rsource,
      m_vv,
      m_dv,
      round(m_vv/m_dv*100,1) m_ctr
    from
    (
      select
        if(d_module in ('推荐流','推荐'),'推荐流','相关推荐') d_module,
        d_rsource,
        sum(m_vv) m_vv
      from adm.f_video_model_vv
      where dt='${datebuf}'
      and d_div>='6.0.0'
      and d_client ='2'
      and  d_module in ('推荐流','推荐','相关推荐')
      group by
        if(d_module in ('推荐流','推荐'),'推荐流','相关推荐'),
        d_rsource
    ) a
    join
    (
      select
        if(d_module in ('推荐流','推荐'),'推荐流','相关推荐') d_module,
        d_rsource,
        sum(m_dv) m_dv
      from adm.f_video_model_dv
      where dt='${datebuf}'
      and d_div>='6.0.0'
      and d_client ='2'
      and  d_module in ('推荐流','推荐','相关推荐')
      group by
        if(d_module in ('推荐流','推荐'),'推荐流','相关推荐'),
        d_rsource
    ) b
    on(a.d_module=b.d_module and a.d_rsource=b.d_rsource )
) d
group by
d_module,
d_rsource
;
dfs -touchz /dw/adm/f_recy_model_ctr/dt=${datebuf}/_SUCCESS ;