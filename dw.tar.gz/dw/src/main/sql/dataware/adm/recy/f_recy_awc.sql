use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_recy_awc(
    d_client int COMMENT '客户端类型',
    d_module string COMMENT '推荐流或关注流模块',
    m_vv int COMMENT '播放次数',
    m_dv int COMMENT '展现次数',
    m_ctr float COMMENT '点击率',
    m_dau int COMMENT '相应的日活',
    m_awc float COMMENT '人均播放视频个数'
)
COMMENT '数据集市层——feed流人均播放视频个数(注:仅限安卓和IOS 596及以上版本参与统计),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_recy_awc';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_recy_awc PARTITION(dt='${datebuf}')
select
  a.d_client,
  a.d_module,
  m_vv,
  m_dv,
  round(m_vv/m_dv*100,1) m_ctr,
  m_dau,
  round(m_vv/m_dau,1) m_awc
from
(
  select
    d_client,
    if(d_module in ('推荐流','推荐'),'推荐流','关注流') d_module,
    sum(m_vv) m_vv
  from adm.f_video_vv
  where dt='${datebuf}'
  and d_div>='5.9.6'
  and  d_module in ('推荐流','推荐','关注','关注流')
  group by
    d_client,
    if(d_module in ('推荐流','推荐'),'推荐流','关注流')
) a
join
(
  select
    d_client,
    if(d_module in ('推荐流','推荐'),'推荐流','关注流') d_module,
    sum(m_dv) m_dv
  from adm.f_video_cmdv
  where dt='${datebuf}'
  and d_div>='5.9.6'
  and  d_module in ('推荐流','推荐','关注','关注流')
  group by
    d_client,
    if(d_module in ('推荐流','推荐'),'推荐流','关注流')
) b
on(a.d_module=b.d_module and a.d_client=b.d_client )
join
(
    select
      d_client,
      count(distinct d_diu) m_dau
    from adm.f_user_act
    where dt='${datebuf}'
    and d_div>='5.9.6'
    group by
      d_client
) c
on(a.d_client=c.d_client)
;