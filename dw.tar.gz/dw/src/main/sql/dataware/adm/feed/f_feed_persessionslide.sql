use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_feed_persessionslide(
    sessionId STRING COMMENT 'session、diu组合字段',
    m_cnt Int COMMENT '滑动次数'
)
COMMENT '数据集市层——feed流每个session&diu滑动页面的次数(注:仅限安卓和IOS 596及以上版本参与统计),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_feed_persessionslide';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
set mapreduce.map.memory.mb=2048;

insert OVERWRITE table adm.f_feed_persessionslide PARTITION(dt='${datebuf}')
select concat(u_diu,'_',u_startid),count(1) 
from edw.user_elog 
where dt='${datebuf}' and concat(u_mod,'-',u_ac)='emptylog-video_display' and u_client_module in ('推荐流','推荐') and u_div>='5.9.6' 
group by u_diu,u_startid
;