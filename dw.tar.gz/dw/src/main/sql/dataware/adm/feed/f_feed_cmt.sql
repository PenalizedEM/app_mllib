use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_feed_cmt(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    createtime STRING COMMENT '视频上传时间',
    d_vid bigint COMMENT '视频的id',
    timesub int COMMENT '时间差:dt-createtime',
    d_type STRING,
    m_cnt bigint COMMENT '评论次数'
)
COMMENT '数据集市层——事实表——平均滑动几次观看一个视频,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_feed_cmt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_feed_cmt PARTITION(dt='${datebuf}')
	
select a.d_diu,b.cretime,a.d_vid, datediff('${datebuf}',cretime) timesub,b.d_type,a.m_cnt
from
	(
	select  d_diu,d_vid,dt,sum(m_cnt) m_cnt
	from adm.f_video_cmt
	where dt='${datebuf}'  and d_div>='5.9.6'
	group by d_diu,d_vid,dt
	)a
join 
	(select vid ,if(to_date(createtime) is null, -1 ,to_date(createtime)) cretime,if(type=10,'lite','normal') d_type from dw.video
	)b
on a.d_vid=b.vid;