use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_feed_awc(
    d_type STRING,
    m_vv int COMMENT '播放次数',
    m_dau int COMMENT '相应的日活',
    m_awc float COMMENT '人均播放视频个数'
)
COMMENT '数据集市层——feed流人均播放视频个数(注:仅限安卓和IOS 596及以上版本参与统计),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_feed_awc';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_feed_awc PARTITION(dt='${datebuf}')
select
  a.d_type,
  m_vv,
  m_dau,
  round(m_vv/m_dau,1) m_awc
from
(
  select
    d_type,
    sum(m_vv) m_vv
  from adm.f_feed_time_vv
  where dt='${datebuf}'
  group by
    d_type
) a
join
(
	select d_type,count(distinct d_diu) m_dau
	from
	    (
	      select
		     d_vid,
		     d_diu
	     from adm.f_video_vv
	     where dt='${datebuf}' and d_module in ('推荐流','推荐') and d_div>='5.9.6'
	    )c
    join
	   (select vid ,if(type=10,'lite','normal') d_type from dw.video
	    )d
 	on c.d_vid=d.vid
 	group by d_type
) b
on(a.d_type=b.d_type)
;