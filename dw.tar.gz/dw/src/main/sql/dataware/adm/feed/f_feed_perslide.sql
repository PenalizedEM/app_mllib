use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_feed_perslide(
    sum_dv BigInt COMMENT '总滑动次数',
    m_uv int COMMENT '相应的uv',
    per_slide double COMMENT '人均观看页数'
)
COMMENT '数据集市层——事实表——视频评论次数,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_feed_perslide';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_feed_perslide PARTITION(dt='${datebuf}')
	
select a.sum_dv,b.m_uv,round(sum_dv/m_uv,3) from
	(
		select dt,sum(m_dv) sum_dv 
		from f_video_dv 
		where dt = '${datebuf}' and d_module in ('推荐流','推荐') and d_div>='5.9.6' group by dt
	)a 
join 
	(
		select dt,count(distinct d_diu) m_uv 
		from f_video_vv 
		where dt = '${datebuf}' and d_module in ('推荐流','推荐') and d_div>='5.9.6' group by dt
	)b
on a.dt=b.dt