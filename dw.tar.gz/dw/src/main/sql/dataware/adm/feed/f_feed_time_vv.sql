use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_feed_time_vv(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_module STRING COMMENT '推荐流或关注流模块',
    createtime STRING COMMENT '视频上传时间',
    d_vid bigint COMMENT '视频的id',
    timesub int COMMENT '时间差:dt-createtime',
    d_type STRING,
    m_vv int COMMENT '视频播放次数'
)
COMMENT '数据集市层——事实表——用户播放视频(videoviewtimes),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_feed_time_vv';


set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;
insert OVERWRITE table adm.f_feed_time_vv PARTITION(dt='${datebuf}')
select a.d_diu,
	   if(a.d_module in ('推荐流','推荐'),'推荐流','关注流') d_module,
	   b.cretime,a.d_vid, datediff('${datebuf}',cretime) timesub,
	   b.d_type,
	   a.m_vv 
from
	 (select d_diu,d_module,d_vid,dt,sum(m_vv) m_vv 
	  from adm.f_video_vv where dt='${datebuf}' and d_module in ('推荐流','推荐','关注','关注流') and d_div>='5.9.6'
	  group by d_diu,d_module,d_vid,dt
	  )a 
 join
	 (select vid ,if(to_date(createtime) is null, -1 ,to_date(createtime)) cretime,if(type=10,'lite','normal') d_type 
	  from dw.video
	 )b
on a.d_vid=b.vid;

dfs -touchz /dw/adm/f_feed_time_vv/dt=${datebuf}/_SUCCESS;
