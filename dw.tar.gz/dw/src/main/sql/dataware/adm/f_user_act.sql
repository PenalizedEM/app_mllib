use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_user_act(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_abtag STRING COMMENT 'ABTag',
    m_isnew int COMMENT '是否为当日新增用户—— 0 否, >0 是',
    m_vv int COMMENT '观看普通视频个数—— 0 无观看, >0 有观看',
    m_litevv int COMMENT '观看小视频个数—— 0 无观看, >0 有观看',
    m_down int COMMENT '下载了视频/舞曲的次数—— 0 无下载, >0 有下载',
    m_fav int COMMENT '收藏视频的个数—— 0 无, >0 有',
    m_flower int COMMENT '给视频送花的数量—— 0 无, >0 有',
    m_follow int COMMENT '关注用户的个数—— 0 无, >0 有',
    m_share int COMMENT '分享视频的次数—— 0 无, >0 有',
    m_localup int COMMENT '从本地上传视频的次数—— 0 无, >0 有',
    m_showup int COMMENT '上传秀舞视频的次数—— 0 无, >0 有',
    m_liteucnt int COMMENT '上传小视频的次数—— 0 无, >0 有',
    m_cnt int COMMENT '调用有效服务接口的次数'
)
COMMENT '数据集市层——事实表——活跃用户,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_user_act';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

set mapreduce.map.memory.mb=2048;

insert OVERWRITE table adm.f_user_act PARTITION(dt='${datebuf}')
select
  d_diu
  ,d_div
  ,d_dic
  ,d_uid
  ,d_client
  ,d_city
  ,d_abtag
  ,sum(if(c.u_diu is null,0,1)) m_isnew
  ,sum(if(type is null, 0, if(type=10, 0, 1))) m_vv
  ,sum(if(type is null, 0, if(type=10, 1, 0))) m_litevv
  ,sum(d_down) m_down
  ,sum(d_fav) m_fav
  ,sum(d_flower) m_flower
  ,sum(d_follow) m_follow
  ,sum(d_share) m_share
  ,sum(d_localup) m_localup
  ,sum(d_showup) m_showup
  ,sum(d_liteup) m_liteup
  ,sum(m_cnt) m_cnt
from
(
  select
         if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
         ,if(u_div is null or u_div='','-',u_div)                                                                        d_div
         ,if(u_dic is null or u_dic='','-',u_dic)                                                                        d_dic
         ,if(u_uid is null or u_uid='',-1,u_uid)                                                                         d_uid
         ,if(u_client is null or u_client='',-1,u_client)                                                                d_client
         ,if(u_city is null or u_city='','-',u_city)                                                                     d_city
         ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))          d_abtag
         ,if(concat(u_mod,'-',u_ac)='top-hits',u_vid,0)                                                                  d_vid
         ,sum(if(concat(u_mod,'-',u_ac)='video-count_video',1,0))                                                        d_down
         ,sum(if(concat(u_mod,'-',u_ac)='user-fav',1,0)  )                                                               d_fav
         ,sum(if(concat(u_mod,'-',u_ac)='flower-send',get_json_object(u_bigger_json,'$.u_num'),0) )                      d_flower
         ,sum(if(concat(u_mod,'-',u_ac)='user-follow_user',1,0)    )                                                     d_follow
         ,sum(if(concat(u_mod,'-',u_ac)='user-share',1,0)  )                                                             d_share
         ,sum(if(concat(u_mod,'-',u_ac)='video_upload-add' and get_json_object(u_bigger_json,'$.u_type')=9, 1 , 0 ))     d_localup
         ,sum(if(concat(u_mod,'-',u_ac)='video_upload-add' and get_json_object(u_bigger_json,'$.u_type')<>9, 1 , 0 )  )  d_showup
         ,sum(if(concat(u_mod,'-',u_ac)='litevideo-add_video',1,0))                                                      d_liteup
         ,count(1) m_cnt
  from edw.user_ilog
  where dt='${datebuf}'
  group by
         if(u_diu is null or u_diu='','-',u_diu)
         ,if(u_div is null or u_div='','-',u_div)
         ,if(u_dic is null or u_dic='','-',u_dic)
         ,if(u_uid is null or u_uid='',-1,u_uid)
         ,if(u_client is null or u_client='',-1,u_client)
         ,if(u_city is null or u_city='','-',u_city)
         ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))
         ,if(concat(u_mod,'-',u_ac)='top-hits',u_vid,0)
) a
left outer join dw.video b
on (a.d_vid=b.vid)
left outer join
( select u_diu from dw.uibigger where dt='${datebuf}' and to_date(u_timestamp_f)='${datebuf}' ) c
on (a.d_diu=c.u_diu)
group by
  d_diu
  ,d_div
  ,d_dic
  ,d_uid
  ,d_client
  ,d_city
  ,d_abtag
  ,if(c.u_diu is null,0,1)
;

dfs -touchz /dw/adm/f_user_act/dt=${datebuf}/_SUCCESS ;

