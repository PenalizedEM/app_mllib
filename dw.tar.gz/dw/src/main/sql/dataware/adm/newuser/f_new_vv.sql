use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_new_vv(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_source STRING COMMENT '客户端页面',
    d_module STRING COMMENT '客户端模块',
    d_examid STRING COMMENT 'AB实验ID',
    d_bucketid STRING COMMENT '分桶ID',
    d_abtag STRING COMMENT 'ABTag',
    d_gtag STRING COMMENT 'gTag',
    d_page int COMMENT '页码',
    d_position int COMMENT '位置',
    d_vid bigint COMMENT '视频的id',
    m_vv int COMMENT '视频播放次数'
)
COMMENT '数据集市层——事实表——新激活用户播放视频(newuser videoviewtimes),字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_new_vv';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_new_vv PARTITION(dt='${datebuf}')
select  a.d_diu,
	    d_hour,
	    d_minute,
	    d_div,
	    d_dic,
	    d_uid ,
	    d_client,
	    d_city ,
	    d_source,
	    d_module ,
	    d_examid ,
	    d_bucketid ,
	    d_abtag ,
	    d_gtag ,
	    d_page,
	    d_position ,
	    d_vid ,
	    m_vv 
        from
            (
                select *
                from adm.f_video_vv 
                where dt='${datebuf}' 
            ) a
        join 
            (
                select distinct d_diu 
                from adm.f_user_act 
                where dt='${datebuf}'
                and m_isnew>0
            )b 
        on (a.d_diu=b.d_diu)
;

dfs -touchz /dw/adm/f_new_vv/dt=${datebuf}/_SUCCESS ;