use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_grow_abppt(
    d_abtag STRING COMMENT 'ABTag',
    m_pt int COMMENT '播放时长',
    m_vu int COMMENT '播放人数',
    m_ppt float COMMENT '人均播放时长'
)
COMMENT '数据集市层——事实表——激活用户新增实验AB版的APP大盘人均播放时长,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_grow_abppt';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

set mapreduce.map.memory.mb=2048;

insert OVERWRITE table adm.f_grow_abppt PARTITION(dt='${datebuf}')

select
  a.abtag,
  m_pt,
  m_vu,
  round(m_pt/m_vu,2) m_ppt

  from
    (select
           case
               when ( (d_abtag>=0 and d_abtag<=24 ) or (d_abtag>=75 and d_abtag<=99) ) then 'A'
                 when (d_abtag>=25 and d_abtag<=74) then 'B'
               else 'other' end as abtag,
            sum(m_pt) m_pt 
    from f_new_pt
    where dt='${datebuf}'
    and d_client=2 and d_div>='5.9.3'
    group by
           case
               when ( (d_abtag>=0 and d_abtag<=24 ) or (d_abtag>=75 and d_abtag<=99) ) then 'A'
                 when (d_abtag>=25 and d_abtag<=74) then 'B'
               else 'other' end
    ) a
    join
    (select
           case
               when ( (d_abtag>=0 and d_abtag<=24 ) or (d_abtag>=75 and d_abtag<=99) ) then 'A'
                 when (d_abtag>=25 and d_abtag<=74) then 'B'
               else 'other' end as abtag,
           
            count(distinct d_diu) m_vu
    from adm.f_new_vv
    where dt='${datebuf}'
    and d_client=2 and d_div>='5.9.3'
    group by
           case
               when ( (d_abtag>=0 and d_abtag<=24 ) or (d_abtag>=75 and d_abtag<=99) ) then 'A'
                 when (d_abtag>=25 and d_abtag<=74) then 'B'
               else 'other' end
    )b
    on(a.abtag=b.abtag);
    dfs -touchz /dw/adm/f_grow_abppt/dt=${datebuf}/_SUCCESS ;
