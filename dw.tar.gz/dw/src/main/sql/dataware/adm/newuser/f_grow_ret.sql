use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_grow_ret(
    d_abtag STRING COMMENT 'ABTag',
    m_dnu int COMMENT '新增用户数',
    m_ret int COMMENT '留存用户数',
    m_retrate float COMMENT '第n日留存率'
)
COMMENT '数据集市层——事实表——激活用户新增实验模块第n日留存,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING, retdays STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_grow_ret';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=2048;

insert OVERWRITE table adm.f_grow_ret PARTITION(dt='${datebuf}',retdays='${n}')
select a.abtag,
       count(distinct a.d_diu) newGrow,
       count(distinct b.d_diu) ret,
       round(count(distinct b.d_diu)/count(distinct a.d_diu)*100,2) m_retrate
from
  ( select d_diu,
           case
               when ( (d_abtag>=0 and d_abtag<=24 ) or (d_abtag>=75 and d_abtag<=99) ) then 'A'
                 when (d_abtag>=25 and d_abtag<=74) then 'B'
               else 'other'
           end as abtag
   from f_user_act
   where dt='${datebuf}'
     and m_isnew>0
     and d_client=2
     and d_div>='5.9.3'
   group by d_diu,
            case
               when ( (d_abtag>=0 and d_abtag<=24 ) or (d_abtag>=75 and d_abtag<=99) ) then 'A'
                 when (d_abtag>=25 and d_abtag<=74) then 'B'
               else 'other'
            end)a
left outer join
  ( select d_diu
   from f_user_act
   where dt=date_add('${datebuf}', ${n} )
   group by d_diu )b on(a.d_diu=b.d_diu)
group by a.abtag ;
   
dfs -touchz /dw/adm/f_grow_ret/dt=${datebuf}/retdays=${n}/_SUCCESS ;