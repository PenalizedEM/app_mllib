use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_lite_vv_like_dv(
	d_vid STRING COMMENT '视频id',
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV,观看视频的设备标识',
    create_uid STRING COMMENT '发布视频的uid',
    createtime STRING COMMENT '发布视频的时间',
    m_vv int COMMENT '视频被播放次数',
    like_cnt STRING COMMENT '视频被喜欢次数',
	m_dv STRING COMMENT '视频曝光数'
    
)
COMMENT '数据集市层——事实表——小视频播放-喜欢-曝光表,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_lite_vv_like_dv';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_lite_vv_like_dv PARTITION(dt='${datebuf}')
select a.d_vid,a.d_diu,b.create_uid,b.createtime,a.m_vv,if(c.m_cnt is null,0,c.m_cnt) like_cnt,d.m_dv from
	(select d_diu,d_vid, sum(m_vv) m_vv from adm.f_video_vv where dt='${datebuf}' group by d_diu,d_vid ) a 
join (select vid,uid create_uid,to_date(createtime) createtime from dw.video where type=10)b
on (a.d_vid=b.vid)    
left join
	( select d_diu,d_vid,sum(m_cnt) m_cnt from adm.f_video_like where dt='${datebuf}' group by d_diu,d_vid ) c 
on (a.d_vid=c.d_vid)
left join
	(select d_vid,sum(m_dv) m_dv from adm.f_video_dv where dt='${datebuf}' group by d_vid)d
on (a.d_vid=d.d_vid)
;
dfs -touchz /dw/adm/f_lite_vv_like_dv/dt=${datebuf}/_SUCCESS;