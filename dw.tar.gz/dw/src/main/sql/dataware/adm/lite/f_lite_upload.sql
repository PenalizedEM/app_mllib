use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_lite_upload(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_mp3id STRING COMMENT '音乐id',
    d_width int COMMENT '宽',
    d_height int COMMENT '高',
    d_themeid STRING COMMENT '特效id',
    d_abtag STRING COMMENT 'ABTag',
    d_videourl STRING COMMENT 'cc视频id',
    d_siteid STRING COMMENT 'siteid',
    m_vv int COMMENT '上传次数'
)
COMMENT '数据集市层——事实表——用户上传小视频,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_lite_upload';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_lite_upload PARTITION(dt='${datebuf}')
select
       if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))                                                           d_hour
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))                                                       d_minute
       ,if(u_div is null or u_div='','-',u_div)                                                                        d_div
       ,if(u_dic is null or u_dic='','-',u_dic)                                                                        d_dic
       ,if(u_uid is null or u_uid='',-1,u_uid)                                                                         d_uid
       ,if(u_client is null or u_client='',-1,u_client)                                                                d_client
       ,if(u_city is null or u_city='','-',u_city)                                                                     d_city
       ,if(get_json_object(u_bigger_json,'$.u_mp3id') is null,'-',get_json_object(u_bigger_json,'$.u_mp3id'))          d_mp3id
       ,if(get_json_object(u_bigger_json,'$.u_p_width') is null,'-',get_json_object(u_bigger_json,'$.u_p_width'))      d_width
       ,if(get_json_object(u_bigger_json,'$.u_p_height') is null,'-',get_json_object(u_bigger_json,'$.u_p_height'))    d_height
       ,if(get_json_object(u_bigger_json,'$.u_themeid') is null,'-',get_json_object(u_bigger_json,'$.u_themeid'))      d_themeid
       ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))          d_abtag
       ,if(get_json_object(u_bigger_json,'$.u_videourl') is null,'-',get_json_object(u_bigger_json,'$.u_videourl'))    d_videourl
       ,if(get_json_object(u_bigger_json,'$.u_siteid') is null,'-',get_json_object(u_bigger_json,'$.u_siteid'))        d_siteid
       ,count(1)                                                                                                       m_vv
from edw.user_ilog
where dt='${datebuf}'
and concat(u_mod,'-',u_ac)='litevideo-add_video'
group by
       if(u_diu is null or u_diu='','-',u_diu)
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))
       ,if(u_div is null or u_div='','-',u_div)
       ,if(u_dic is null or u_dic='','-',u_dic)
       ,if(u_uid is null or u_uid='',-1,u_uid)
       ,if(u_client is null or u_client='',-1,u_client)
       ,if(u_city is null or u_city='','-',u_city)
       ,if(get_json_object(u_bigger_json,'$.u_mp3id') is null,'-',get_json_object(u_bigger_json,'$.u_mp3id'))
       ,if(get_json_object(u_bigger_json,'$.u_p_width') is null,'-',get_json_object(u_bigger_json,'$.u_p_width'))
       ,if(get_json_object(u_bigger_json,'$.u_p_height') is null,'-',get_json_object(u_bigger_json,'$.u_p_height'))
       ,if(get_json_object(u_bigger_json,'$.u_themeid') is null,'-',get_json_object(u_bigger_json,'$.u_themeid'))
       ,if(get_json_object(u_bigger_json,'$.u_abtag') is null,'-',get_json_object(u_bigger_json,'$.u_abtag'))
       ,if(get_json_object(u_bigger_json,'$.u_videourl') is null,'-',get_json_object(u_bigger_json,'$.u_videourl'))
       ,if(get_json_object(u_bigger_json,'$.u_siteid') is null,'-',get_json_object(u_bigger_json,'$.u_siteid'))
;

dfs -touchz /dw/adm/f_lite_upload/dt=${datebuf}/_SUCCESS ;
