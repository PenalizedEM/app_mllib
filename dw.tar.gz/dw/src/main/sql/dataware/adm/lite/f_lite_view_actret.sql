use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_lite_view_actret(
    m_dnu int COMMENT '新增用户数',
    m_ret int COMMENT '留存用户数',
    m_retrate float COMMENT '次日留存率'
)
COMMENT '数据集市层——事实表——小视频上传功能新用户留存,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING, retdays STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_lite_view_actret';


set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;
insert OVERWRITE table adm.f_lite_view_actret PARTITION(dt='${datebuf}',retdays='${n}')
select
  count(distinct a.d_diu) m_dnu
  ,count(distinct b.d_diu) m_ret
  ,round(count(distinct b.d_diu)/count(distinct a.d_diu)*100,2) m_retrate
from
(
  select
    d_diu
  from
    adm.f_user_act
  where
    dt='${datebuf}' and  m_litevv>0
  group by
    d_diu
) a
left outer join
(
  select d_diu from adm.f_user_act where dt=date_add('${datebuf}',${n}) and  m_litevv>0  group by d_diu
) b
on(a.d_diu=b.d_diu)