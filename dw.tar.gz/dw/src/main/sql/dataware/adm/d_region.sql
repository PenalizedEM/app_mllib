use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.d_region(
    cityid STRING COMMENT '城市代码',
    city STRING COMMENT '城市名',
    clid STRING COMMENT '城市级别id',
    ctiylevel STRING COMMENT '城市级别',
    provid STRING COMMENT '省份id',
    province STRING COMMENT '省份',
    regionid STRING COMMENT '区域id',
    region STRING COMMENT '区域'
)
COMMENT '数据集市层——维度表——地域位置维度表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/d_region';


