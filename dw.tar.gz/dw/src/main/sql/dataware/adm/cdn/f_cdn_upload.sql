use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_cdn_upload(
    d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
    d_hour int COMMENT '时间-小时',
    d_minute int COMMENT '时间-分钟',
    d_ac STRING COMMENT '接口',
    d_div STRING COMMENT '客户端版本号',
    d_dic STRING COMMENT '客户端渠道代码',
    d_uid int COMMENT '注册用户id',
    d_client int COMMENT '客户端类型',
    d_city STRING COMMENT '城市',
    d_videourl STRING COMMENT 'CDN源的视频id',
    d_mp3id STRING COMMENT '音乐id',
    d_video_type STRING COMMENT '视频类型:秀舞/小视频',
    d_fsize bigint COMMENT '视频文件大小单位byte',
    d_cdn_source STRING COMMENT 'CDN源',
    d_rate int COMMENT '上传进度百分比',
    d_upload_start_time bigint COMMENT '开始上传时间-毫秒时间戳',
    d_upload_fail_time bigint COMMENT '上传失败时间-毫秒时间戳',
    d_upload_stop_time bigint COMMENT '上传结束时间-毫秒时间戳',
    d_content STRING COMMENT '错误原因（如 Eoorcode:Network_ERROR）',
    m_cnt int COMMENT '次数'
)
COMMENT '数据集市层——事实表——用户上传视频成功或失败记录,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/dw/adm/f_cdn_upload';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=2048;
insert OVERWRITE table adm.f_cdn_upload PARTITION(dt='${datebuf}')
select
       if(u_diu is null or u_diu='','-',u_diu)                                                                         d_diu
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))                                                           d_hour
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))                                                       d_minute
       ,if(u_ac is null or u_ac='', '-',u_ac)                                                                          d_ac
       ,if(u_div is null or u_div='','-',u_div)                                                                        d_div
       ,if(u_dic is null or u_dic='','-',u_dic)                                                                        d_dic
       ,if(u_uid is null or u_uid='',-1,u_uid)                                                                         d_uid
       ,if(u_client is null or u_client='',-1,u_client)                                                                d_client
       ,if(u_city is null or u_city='','-',u_city)                                                                     d_city
       ,if(get_json_object(u_bigger_json,'$.u_videourl') is null,'-',get_json_object(u_bigger_json,'$.u_videourl'))    d_videourl
       ,if(get_json_object(u_bigger_json,'$.u_mp3id') is null,'-',get_json_object(u_bigger_json,'$.u_mp3id'))          d_mp3id
       ,if(get_json_object(u_bigger_json,'$.u_video_type') is null,'-',get_json_object(u_bigger_json,'$.u_video_type')) d_video_type
--       ,if(get_json_object(u_bigger_json,'$.u_fsize') is null,-1,get_json_object(u_bigger_json,'$.u_fsize'))           d_fsize
       ,if(u_div>='6.0.0', if(get_json_object(u_bigger_json,'$.u_fsize') is null,'-',get_json_object(u_bigger_json,'$.u_fsize')) , if(u_size is null or u_size='',-1,u_size) )                                                                        d_fsize
       ,if(u_cdn_source is null or u_cdn_source='','-',u_cdn_source)                                                   d_cdn_source
       ,if(u_rate is null or u_rate='',-1,u_rate)                                                                      d_rate
       ,if(get_json_object(u_bigger_json,'$.u_upload_start_time') is null,-1,get_json_object(u_bigger_json,'$.u_upload_start_time'))    d_upload_start_time
       ,if(get_json_object(u_bigger_json,'$.u_upload_fail_time') is null,-1,get_json_object(u_bigger_json,'$.u_upload_fail_time'))    d_upload_fail_time
       ,if(get_json_object(u_bigger_json,'$.u_upload_stop_time') is null,-1,get_json_object(u_bigger_json,'$.u_upload_stop_time'))    d_upload_stop_time
       ,if(get_json_object(u_bigger_json,'$.u_content') is null,'-',get_json_object(u_bigger_json,'$.u_content'))      d_content
       ,count(1)                                                                                                       m_cnt
from edw.user_elog
where dt='${datebuf}'
and u_ac in ('upload_error','cdn_upload_speed')
group by
       if(u_diu is null or u_diu='','-',u_diu)
       ,if(hour(u_timestamp) is null, -1 ,hour(u_timestamp))
       ,if(minute(u_timestamp) is null, -1 ,minute(u_timestamp))
       ,if(u_ac is null or u_ac='', '-',u_ac)
       ,if(u_div is null or u_div='','-',u_div)
       ,if(u_dic is null or u_dic='','-',u_dic)
       ,if(u_uid is null or u_uid='',-1,u_uid)
       ,if(u_client is null or u_client='',-1,u_client)
       ,if(u_city is null or u_city='','-',u_city)
       ,if(get_json_object(u_bigger_json,'$.u_videourl') is null,'-',get_json_object(u_bigger_json,'$.u_videourl'))
       ,if(get_json_object(u_bigger_json,'$.u_mp3id') is null,'-',get_json_object(u_bigger_json,'$.u_mp3id'))
       ,if(get_json_object(u_bigger_json,'$.u_video_type') is null,'-',get_json_object(u_bigger_json,'$.u_video_type'))
--       ,if(get_json_object(u_bigger_json,'$.u_fsize') is null,-1,get_json_object(u_bigger_json,'$.u_fsize'))
       ,if(u_div>='6.0.0', if(get_json_object(u_bigger_json,'$.u_fsize') is null,'-',get_json_object(u_bigger_json,'$.u_fsize')) , if(u_size is null or u_size='',-1,u_size) )
       ,if(u_cdn_source is null or u_cdn_source='','-',u_cdn_source)
       ,if(u_rate is null or u_rate='',-1,u_rate)
       ,if(get_json_object(u_bigger_json,'$.u_upload_start_time') is null,-1,get_json_object(u_bigger_json,'$.u_upload_start_time'))
       ,if(get_json_object(u_bigger_json,'$.u_upload_fail_time') is null,-1,get_json_object(u_bigger_json,'$.u_upload_fail_time'))
       ,if(get_json_object(u_bigger_json,'$.u_upload_stop_time') is null,-1,get_json_object(u_bigger_json,'$.u_upload_stop_time'))
       ,if(get_json_object(u_bigger_json,'$.u_content') is null,'-',get_json_object(u_bigger_json,'$.u_content'))
;

dfs -touchz /dw/adm/f_cdn_upload/dt=${datebuf}/_SUCCESS ;
