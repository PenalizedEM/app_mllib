
use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_cdn_uperror(
    d_cdn_source STRING COMMENT 'cdn源',
    d_client string COMMENT '客户端版本',
    d_video_type STRING COMMENT '视频类型:秀舞/小视频',
    m_uperror bigint COMMENT '上传错误次数',
    m_up bigint COMMENT '总上传次数',
    m_uperate float COMMENT '上传错误率'
)
COMMENT '数据集市层——用户上传错误率,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_cdn_uperror';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_cdn_uperror PARTITION(dt='${datebuf}')
select if(d_cdn_source=0,'cc',d_cdn_source) d_cdn_source,
    if(d_client=2 and d_div>='6.0.1','AND>=601',if(d_client=1 and d_div>='6.0.0','ios>=600',if(d_client=2 and d_div<'6.0.1','AND<601','others'))) d_client,
    d_video_type,
    sum(if(d_ac='upload_error',1,0)) m_uperror,
    sum(m_cnt) m_up,
    sum(if(d_ac='upload_error',1,0))/sum(m_cnt) m_uperate
from adm.f_cdn_upload
where dt='${datebuf}'
group by
    if(d_cdn_source=0,'cc',d_cdn_source),
    if(d_client=2 and d_div>='6.0.1','AND>=601',if(d_client=1 and d_div>='6.0.0','ios>=600',if(d_client=2 and d_div<'6.0.1','AND<601','others'))),
    d_video_type;

dfs -touchz /dw/adm/f_cdn_uperror/dt=${datebuf}/_SUCCESS ;
