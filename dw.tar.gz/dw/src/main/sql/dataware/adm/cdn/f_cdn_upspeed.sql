
use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_cdn_upspeed(
    d_cdn_source STRING COMMENT 'cdn源',
    d_client int COMMENT '客户端类型',
    d_video_type STRING COMMENT '视频类型:秀舞/小视频',
    d_uptime bigint COMMENT '上传耗时单位秒',
    d_fsize float COMMENT '上传文件大小单位kb',
    m_avg_speed float COMMENT '平均上传速度单位kb/s',
    m_mid_speed  float  COMMENT '上传速度中位数单位kb/s'
)
COMMENT '数据集市层——用户上传视频速度,字符型字段默认值为-,数值型默认为-1'
PARTITIONED BY(dt STRING )
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_cdn_upspeed';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- set mapreduce.map.memory.mb=1024;

insert OVERWRITE table adm.f_cdn_upspeed PARTITION(dt='${datebuf}')
select d_cdn_source,
       d_client,
       d_video_type,
       sum(d_uptime) d_uptime,
       sum(d_fsize) d_fsize,
       avg(up_speed) m_avg_speed,
       percentile(cast(up_speed as bigint),0.5) m_mid_speed
from
  ( select d_cdn_source,
        d_client,
        d_video_type,
        (d_upload_stop_time-d_upload_start_time)/1000 d_uptime,
        d_fsize/1024 d_fsize,
        (d_fsize/1024)/((d_upload_stop_time-d_upload_start_time)/1000) up_speed
   from f_cdn_upload
   where dt='${datebuf}'
    and d_upload_stop_time>0
    and d_ac='cdn_upload_speed'
  )a
group by
    d_cdn_source,
    d_client,
    d_video_type;

dfs -touchz /dw/adm/f_cdn_upspeed/dt=${datebuf}/_SUCCESS ;
