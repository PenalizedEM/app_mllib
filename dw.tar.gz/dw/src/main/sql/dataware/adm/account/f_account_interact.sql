-- 用户互动用户事实表

use adm;
CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_account_interact(
    d_datebuf string COMMENT '业务日期',
    d_uid string COMMENT '注册用户id',
    d_reuid string COMMENT '互动用户id',
    d_type string COMMENT '互动类型: fav：收藏/喜欢 comment:评论/回复',
    m_cnt int COMMENT '互动次数'
)
COMMENT '数据集市层——注册用户事实表——注册用户互动次数'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/dw/adm/f_account_interact';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;


insert OVERWRITE table adm.f_account_interact PARTITION(dt='${datebuf}')
select
	'${datebuf}',
	a.uid,
	if(reuid is null, b.uid, reuid) reuid,
	interaction,
	sum(cnt) cnt
from
(
	select
	u_uid uid,
	get_json_object(u_bigger_json,'$.u_reuid') reuid,
	u_vid vid,
	if(concat(u_mod,'-',u_ac) in ('user-fav','flower-good'),'fav','comment') interaction,
	count(1) cnt
	from edw.user_ilog
	where dt='${datebuf}'
	and concat(u_mod,'-',u_ac) in ('user-fav','message-video_comment_add','message-video_comment_reply','flower-good')
	and u_uid<>'' and u_uid is not null
	group by
	u_uid ,
	get_json_object(u_bigger_json,'$.u_reuid'),
	u_vid,
	if(concat(u_mod,'-',u_ac) in ('user-fav','flower-good'),'fav','comment')
) a
join
(select vid, uid from dw.video where uid<>0) b
on(a.vid=b.vid)
group by
	a.uid,
	if(reuid is null, b.uid, reuid),
	interaction
;
