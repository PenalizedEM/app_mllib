use ods;
CREATE EXTERNAL TABLE IF NOT EXISTS rawlog (
content STRING  COMMENT 'rawlog'
)
COMMENT'rawlog'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/flume/';

alter table ods.rawlog add if not exists partition(dt='${datebuf}',hour='${hour}') location '/flume/${fdate}/${hour}';

-- set hive.exec.compress.output=true;
-- set mapred.output.compress=true;
-- set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
-- set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

-- INSERT OVERWRITE table ods.rawlog PARTITION(dt='${datebuf}', hour='${hour}')
-- SELECT content FROM ods.rawlog WHERE dt='${datebuf}' and hour='${hour}';