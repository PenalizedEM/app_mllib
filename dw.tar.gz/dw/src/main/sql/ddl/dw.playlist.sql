use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS playlist
(
id int COMMENT'专辑ID主键自增',
master_uid int COMMENT'达人UID',
title string COMMENT'专辑名称',
charclass string COMMENT'专辑首字母',
uid int COMMENT'专辑作者ID',
uname string COMMENT'专辑作者用户名',
type int COMMENT'舞曲1舞队2',
keyword string COMMENT'关键字',
pid int COMMENT'PC专辑ID',
top int COMMENT'权重',
info string COMMENT'关键词全文索引',
pic string COMMENT'',
groupid int COMMENT'达人级别1达人2超级达人',
video_num int COMMENT'专辑视频数量',
userid int COMMENT'移动端达人UID',
username string COMMENT'移动端达人昵称',
is_prompt int COMMENT'是否搜索提示0提示1不提示',
level int COMMENT'达人等级'
)
COMMENT'专辑字典表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/playlist/';
