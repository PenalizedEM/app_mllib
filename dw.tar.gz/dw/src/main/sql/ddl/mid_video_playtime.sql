drop TABLE da.mid_video_playtime;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_playtime(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    dic STRING COMMENT '渠道',
    province STRING COMMENT '省份',
    city  STRING COMMENT '城市',
    client  STRING COMMENT '平台',
    m_vp int COMMENT '播放最大进度',
    m_vst bigint  COMMENT '播放总时长',
    tag STRING COMMENT 'A/B等测试版本标识'
)
COMMENT '中间层-视频播放'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_playtime/';


drop TABLE da.mid_video_cmpt;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_cmpt(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    cm  STRING COMMENT 'app模块',
    m_vp int COMMENT '播放最大进度',
    m_vst bigint  COMMENT '播放总时长'
)
COMMENT '中间层-模块视频播放时长'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_cmpt/';


diu, vid, dic, province, city, client,max(vp) vp, sum(vst) vst
