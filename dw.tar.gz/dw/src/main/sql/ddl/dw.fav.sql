
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS fav (
id int COMMENT '主键自增',
uid int COMMENT '用户ID',
vid bigint  COMMENT '视频ID',
time STRING COMMENT '收藏时间'
)
COMMENT'用户收藏视频表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/fav/';

import --connect jdbc:mysql://10.10.34.125:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table fav --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/fav/ -m 1

