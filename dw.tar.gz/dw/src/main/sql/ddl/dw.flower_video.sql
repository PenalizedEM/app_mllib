use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS flower_video (
id int COMMENT '主键自增',
uid int  COMMENT '送花用户id',
vid bigint  COMMENT '送花视频id',
num int   COMMENT '送花朵数',
cancel int  COMMENT '取消空间喜欢'
)
COMMENT'视频送花表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/flower_video/';