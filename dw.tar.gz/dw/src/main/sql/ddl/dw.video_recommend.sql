use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS video_recommend (
id int COMMENT '主键自增',
vid bigint  COMMENT '视频id',
type int COMMENT '1 每日精选 2最新发布/糖豆广场 3 本周热门 4最多分享 5原创 6达人秀 7入门舞蹈 8舞艺深造 9kk成人组 10 kk儿童组 11汤臣倍健 12中国队长 13活动相关 14糖豆生活',
uptime string   COMMENT '更新时间'
)
COMMENT'专辑视频关联表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/video_recommend/';

