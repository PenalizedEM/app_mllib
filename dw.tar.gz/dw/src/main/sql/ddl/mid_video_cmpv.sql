drop TABLE da.mid_video_cmpv;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_cmpv(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    cm STRING COMMENT '模块',
    m_pv bigint COMMENT '播放次数',
    tag STRING COMMENT 'A/B等测试版本标识'
)
COMMENT '中间层-视频模块播放'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_cmpv/';

alter table da.mid_video_cmpv change COLUMN m_pv bigint COMMENT '播放次数'