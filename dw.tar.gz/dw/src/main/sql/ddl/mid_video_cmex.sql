drop TABLE da.mid_video_cmex;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_cmex(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    cm STRING COMMENT '模块',
    m_pv bigint COMMENT '曝光次数',
    tag STRING COMMENT 'A/B等测试版本标识'
)
COMMENT '中间层-模块曝光'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_cmex/';