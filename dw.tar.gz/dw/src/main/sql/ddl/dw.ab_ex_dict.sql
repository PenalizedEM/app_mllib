use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS ab_ex_dict (
ex_id int COMMENT '实验位id',
bu_id int COMMENT '分桶策略id',
name STRING  COMMENT '分桶策略名称',
abtag int  COMMENT '分桶id'
)
COMMENT'AB测试平台实验与流量分配关系字典'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\t'
STORED AS TEXTFILE
LOCATION '/olap/db/ab_ex_dict/';

hadoop jar abtest.jar com.xiaotang.data.abtest.ABTag2Experiment