use dw;

CREATE EXTERNAL TABLE IF NOT EXISTS ab_name (
id int COMMENT '实验位id',
name STRING  COMMENT '位置名称',
ios_version STRING COMMENT '版本号',
android_version STRING  COMMENT '版本号',
source STRING   COMMENT '展示页',
client STRING  COMMENT '平台:0ios, 1android',
client_module STRING  COMMENT '展示模块',
describe STRING COMMENT '位置描述',
offset STRING COMMENT '默认返回条数',
config STRING COMMENT '位置分流策略配置',
add_time STRING COMMENT '添加时间'
)
COMMENT'AB测试平台实验描述'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/ab_name/';

import --connect jdbc:mysql://10.10.150.36:3306/tduser?tinyInt1isBit=false --username tangdou --password tangdouapp#123 --table cfg_position --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/ab_name/ -m 1

