ALTER TABLE dw.uibigger ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/dw/uibigger/${datebuf}'
