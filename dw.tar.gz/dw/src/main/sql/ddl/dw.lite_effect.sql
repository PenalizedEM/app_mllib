use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS lite_effect (
id int COMMENT '特效ID',
title STRING  COMMENT '标题',
pic STRING  COMMENT '图片地址',
theme_url STRING   COMMENT '特效地址',
addtime STRING  COMMENT '添加时间',
uptime STRING  COMMENT '修改时间',
admin_uid int  COMMENT '管理员',
position int  COMMENT '0',
type int  COMMENT '分类',
client int  COMMENT '客户端 1 ios 2 android',
compose_type int  COMMENT '合成方式 1叠加 2融合',
loop_type int  COMMENT '循环方式 1单播 2循环',
start_version STRING  COMMENT '最低版本'
)
COMMENT'小视频特效'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/lite_effect/';

import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username tangdou --password tangdouapp#123 --table lite_video_effect --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/lite_effect/ -m 1

-- CREATE TABLE `lite_video_effect` (
--  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '特效ID',
--  `title` varchar(50) NOT NULL COMMENT '标题',
--  `pic` varchar(100) NOT NULL COMMENT '图片地址 ',
--  `theme_url` varchar(100) NOT NULL COMMENT '特效地址',
--  `addtime` datetime NOT NULL COMMENT '添加时间 ',
--  `uptime` datetime NOT NULL COMMENT '修改时间',
--  `admin_uid` int(10) NOT NULL COMMENT '管理员',
--  `position` int(10) DEFAULT '0',
--  `type` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分类 ',
--  `client` tinyint(2) NOT NULL DEFAULT '2' COMMENT '客户端 1 ios 2 android',
--  `compose_type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '合成方式 1叠加 2融合',
--  `loop_type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '循环方式 1单播 2循环',
--  `start_version` varchar(20) NOT NULL COMMENT '最低版本',
--  PRIMARY KEY (`id`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COMMENT='小视频特效'