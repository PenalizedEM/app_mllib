
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS follow_user
(
id int COMMENT '主键自增',
uid int COMMENT '观注用户',
reuid int COMMENT '被观注用户',
time string COMMENT '观注时间'
)
COMMENT'用户关注字典表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/follow_user/';
