use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS playlist_recommend
(
id int COMMENT'ID主键自增',
type int COMMENT'1热门舞曲 2 最新舞曲 3 热门舞队 4搜索排行 5推荐舞曲  6推荐达人',
pid int COMMENT'专辑ID',
keyword string COMMENT'关键词（舞曲or舞队）',
position int COMMENT'位置',
pic string COMMENT'图片'
)
COMMENT'推荐专辑字典表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/playlist_recommend/';
