use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS user (
id int COMMENT '主键自增',
name STRING  COMMENT '昵称',
avatar STRING  COMMENT '头像',
client tinyint   COMMENT '设备：1、ios，2、android',
regtime STRING  COMMENT '注册时间',
regip STRING  COMMENT '注册ip',
loginip STRING  COMMENT '最后登录IP',
version STRING  COMMENT '该用户使用的版本号',
type tinyint   COMMENT '账号类型：1微信，2QQ，3手机',
account STRING  COMMENT '账号唯一标识：微信Openid，QQid，手机号',
pwd STRING  COMMENT '手机用户密码',
token STRING  COMMENT '验证串',
mobile STRING,
zone int COMMENT '国家号',
sign int  COMMENT '签到次数',
signdate STRING  COMMENT '最后签到日期',
iskill tinyint  COMMENT '用户是否被封禁',
groupid int  COMMENT '0普通用户组，1达人组',
uuid STRING ,
channel STRING ,
province STRING  COMMENT '省份',
city STRING  COMMENT '城市',
lon STRING  COMMENT '经度',
lat STRING  COMMENT '纬度',
signature STRING  COMMENT '个性签名',
level tinyint  COMMENT '级别',
xinge STRING  COMMENT '信鸽token',
device STRING  COMMENT '机型',
dance_role tinyint  COMMENT '我的角色 1领队 2队员 3未入队 0未选择',
dance_level tinyint  COMMENT '舞蹈水平 1初级 2熟练',
age_range tinyint  COMMENT '我的年龄 1小于30岁 2 30-55岁 3 大于55岁',
last_upSTRING STRING  COMMENT '最后一次更新信息时间',
birthdate int  COMMENT '用户录入生日',
diu STRING  COMMENT '用户设备号',
diu2 STRING  COMMENT '广告ID',
diu3 STRING  COMMENT 'GUID',
gender tinyint  COMMENT '性别',
idcard int  COMMENT '身份证号码',
category_id STRING COMMENT '兴趣大分类id，多个用逗号分割',
space_pic STRING  COMMENT '空间背景'
)
COMMENT'用户字典表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/user/';

