use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS room
(
id int COMMENT'直播间id',
uid int COMMENT'直播人UID',
name string COMMENT'直播人昵称',
bgpic string COMMENT'直播间头像图片default.jpg',
start_t string COMMENT'',
live_status int COMMENT'1:直播  0:离开 -1:关闭',
open_time int COMMENT'',
is_del int COMMENT'0 自动 1删除',
weight int COMMENT'权重',
redisid int COMMENT'',
source string COMMENT'ucloud'
)
COMMENT'直播间信息'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/room/';


-- CREATE TABLE `room` (
--  `id` int(8) unsigned NOT NULL AUTO_INCREMENT,
--  `uid` int(8) NOT NULL,
--  `name` varchar(50) CHARACTER SET utf8mb4 NOT NULL,
--  `bgpic` varchar(100) NOT NULL DEFAULT 'default.jpg',
--  `start_t` varchar(50) NOT NULL,
--  `live_status` tinyint(3) NOT NULL COMMENT '1:直播  0:离开 -1:关闭',
--  `open_time` int(10) unsigned NOT NULL,
--  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 自动 1删除',
--  `weight` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
--  `redisid` smallint(5) unsigned NOT NULL DEFAULT '0',
--  `source` varchar(30) NOT NULL DEFAULT 'ucloud',
--  PRIMARY KEY (`id`),
--  UNIQUE KEY `userid` (`uid`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=379 DEFAULT CHARSET=utf8

