use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS mp3 (
id int COMMENT '主键自增',
name STRING  COMMENT '舞曲名子',
team STRING  COMMENT '舞队名子',
mp3url STRING   COMMENT '设备：1、ios，2、android',
addtime STRING  COMMENT '添加时间',
userid int  COMMENT '用户UID'
)
COMMENT'mp3'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/mp3/';

import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table mp3 --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/mp3/ -m 1