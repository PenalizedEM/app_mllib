drop TABLE da.mid_video_cmpt;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_cmpt(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    cm STRING COMMENT '模块',
    m_vp bigint COMMENT '播放完整度',
    m_vst bigint COMMENT '播放总时长',
    tag STRING COMMENT 'A/B等测试版本标识'
)
COMMENT '中间层-模块视频播放时长'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_cmpt/';
