drop TABLE da.mid_video_pv;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_pv(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    dic STRING COMMENT '渠道',
    province STRING COMMENT '省份',
    city  STRING COMMENT '城市',
    client  STRING COMMENT '平台',
    m_pv bigint COMMENT '播放次数',
    tag STRING COMMENT 'A/B等测试版本标识'
)
COMMENT '中间层-视频播放'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_pv/';


drop TABLE da.mid_video_cmpv;
CREATE EXTERNAL TABLE IF NOT EXISTS da.mid_video_cmpv(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    cm  STRING COMMENT 'app模块',
    m_pv bigint COMMENT '播放次数'
)
COMMENT '中间层-视频模块播放'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/mid_video_cmpv/';
