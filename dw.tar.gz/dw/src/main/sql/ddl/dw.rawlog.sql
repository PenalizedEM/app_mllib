use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS rawlog (
content STRING  COMMENT 'rawlog'
)
COMMENT'rawlog'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/test/logstatsh/';

alter table dw.rawlog add if not exists partition(dt='2016-09-21') location '/olap/test/logstatsh/2016-09-21';
