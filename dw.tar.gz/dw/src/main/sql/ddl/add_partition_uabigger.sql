ALTER TABLE dw.uabigger ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/dw/uabigger/${datebuf}'
