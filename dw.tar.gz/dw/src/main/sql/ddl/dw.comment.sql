use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS comment(
  id int COMMENT 'ID自增',
  uid int  COMMENT '评论用户ID',
  content string COMMENT '评论的内容',
  time string COMMENT '评论的时间',
  vid bigint COMMENT '内容ID',
  reply string COMMENT '回复内容(已弃用)',
  retime string COMMENT '回复时间',
  up int COMMENT '置顶',
  reuid int COMMENT '回复id',
  hot int COMMENT '热度',
  praise INT COMMENT '总赞数',
  upid int COMMENT '评论id',
  recontent string COMMENT '引用内容',
  is_ad int COMMENT '是否广告 1 是 0 否'
)
COMMENT '评论字典表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/db/comment/';
