use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS video(
    id int COMMENT '视频ID自增',
    title string COMMENT '视频标题',
    pic string COMMENT '图片',
    ald_pic string,
    hits_total int  COMMENT '总播放量',
	hits_week	int	COMMENT '周播放量',
	hits_month	int	COMMENT '月播放量',
	good_total	int	COMMENT '总点赞',
	good_week	int	COMMENT '周点赞',
	good_month	int	COMMENT '月点赞',
	recommend	int	COMMENT '推荐星级',
	definition	int	COMMENT '清晰度',
	coderate	string	COMMENT '码率',
	videourl	string	COMMENT '视频地址',
	duration	int	COMMENT '时长',
	speed	int	COMMENT '速度:1慢 2中 3快',
	degree	int	COMMENT '难度: 1简单 2适中 3稍难',
	teach	int	COMMENT '1教学 2表演',
	beach	int	COMMENT '步数：1-16步 2-32步 3-64步',
	best	int	COMMENT '优质视频',
	type	int	COMMENT '视频类型 1：CC上传  11：56上传  7：CC复制  8:秀舞',
	vid	bigint	COMMENT 'PC端视频ID', -- 注意vid可能超过int
	search	string	COMMENT '标题全文索引',
	siteid	string	COMMENT '',
	sitekey	string	COMMENT '',
	is_special	int	COMMENT '',
	createtime	string	COMMENT '创建时间',
	uptime	string	COMMENT '更新时间',
	share	int	COMMENT '分享次数',
	mp3url	string	COMMENT 'mp3',
	user_hits	int	COMMENT '播放人数',
	user_share	int	COMMENT '分享人数',
	pc_uid	int	COMMENT '',
	uid	int	COMMENT '移动端用户id',
	status	int	COMMENT '0正常 1处理中 2审核中 5删除',
	tag	string	COMMENT '',
	parent_category	int	COMMENT '大分类',
	child_category	int	COMMENT '小分类',
	genre	int	COMMENT '曲风',
	hobby	int	COMMENT '学舞兴趣推荐',
	sync	int	COMMENT '是否同步到云',
	comment_total	int	COMMENT '评论数量',
	active_id int  COMMENT '活动id',
  active_status int COMMENT '0 正常 1审核中 2未通过',
  short_title string COMMENT '引导语',
	province	string	COMMENT '上传作者所在省份',
	city	string	COMMENT '上传作者所在城市'
)
COMMENT '视频字典表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/db/video/';

