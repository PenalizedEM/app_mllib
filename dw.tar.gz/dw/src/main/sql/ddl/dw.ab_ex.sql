use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS ab_ex (
id int COMMENT '实验位id',
no int COMMENT '策略编码',
name STRING  COMMENT '实验位名称',
code STRING COMMENT '实验位代码',
position_id STRING  COMMENT '位置id',
location_id STRING   COMMENT '地区',
category_id STRING  COMMENT '分类',
client STRING  COMMENT '平台:0ios, 1android',
flow int  COMMENT '流量占比, 0 ~ 99',
sort int  COMMENT '排序',
class_name STRING COMMENT '类文件名',
directory STRING COMMENT '物理路径',
describe STRING COMMENT '描述',
config STRING COMMENT '策略相关配置',
modify_time STRING COMMENT '修改时间',
add_time STRING COMMENT '添加时间'
)
COMMENT'AB测试平台实验配置表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/ab_ex/';

import --connect jdbc:mysql://10.10.150.36:3306/tduser?tinyInt1isBit=false --username tangdou --password tangdouapp#123 --table cfg_strategy --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/ab_ex/ -m 1
