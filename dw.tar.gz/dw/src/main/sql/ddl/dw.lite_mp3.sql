use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS lite_mp3 (
id int COMMENT '主键自增',
name STRING  COMMENT '标题',
tag STRING  COMMENT 'TAG',
mp3url STRING   COMMENT 'mp3地址',
addtime STRING  COMMENT '添加时间',
position int  COMMENT '权重',
admin_uid int  COMMENT '管理员UID',
start_time int  COMMENT '开始时间',
end_time int  COMMENT '结束时间',
effect_ios int  COMMENT 'IOS特效',
effect_android int  COMMENT 'Android特效'
)
COMMENT'小视频mp3'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/lite_mp3/';

import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username tangdou --password tangdouapp#123 --table lite_video_mp3 --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/lite_mp3/ -m 1

-- CREATE TABLE `lite_video_mp3` (
--  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
--  `name` varchar(100) NOT NULL COMMENT '标题',
--  `tag` varchar(100) NOT NULL COMMENT 'TAG',
--  `mp3url` varchar(100) NOT NULL COMMENT '音乐地址',
--  `addtime` datetime NOT NULL,
--  `position` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '权重',
--  `admin_uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员UID',
--  `start_time` smallint(4) NOT NULL DEFAULT '0' COMMENT '开始时间',
--  `end_time` smallint(4) NOT NULL DEFAULT '0' COMMENT '结束时间',
--  `effect_ios` tinyint(2) NOT NULL DEFAULT '0' COMMENT 'IOS特效',
--  `effect_android` tinyint(2) NOT NULL DEFAULT '0' COMMENT 'Android特效',
--  PRIMARY KEY (`id`),
--  KEY `position` (`position`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=391 DEFAULT CHARSET=utf8 COMMENT='小视频mp3'