-- da.user_full

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS user_full
(
id string COMMENT 'userid',
keyword string COMMENT '专辑/空间关键词',
name string COMMENT '用户昵称',
avatar string COMMENT '用户头像',
update_time string COMMENT '最近更新时间',
fan int COMMENT '粉丝个数',
level int COMMENT '级别',
lon double COMMENT '经度',
lat double COMMENT '纬度'
)
COMMENT'用户表-搜索用'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/da/user_full/';

insert overwrite table da.user_full
select
n.id,
m.keyword,
n.name,
avatar,
update_time,
nvl(q.fans_cnt,0) fan,
level,
lon,
lat
from
(SELECT id,name,avatar,if(regtime>if(last_upstring is null or last_upstring='null','0000-00-00 00:00:00.0',last_upstring),regtime,last_upstring) update_time,level,lon,lat FROM dw.user) n
left outer join
(SELECT userid,keyword FROM dw.playlist WHERE type=2 and userid<>0 group by userid, keyword) m
on n.id=m.userid
left outer join
(select reuid,count(1) fans_cnt from dw.follow_user group by reuid) q
on n.id=q.reuid
;

-- -- mysql
-- CREATE TABLE `user_full` (
--   `id` int(10) NOT NULL  COMMENT 'userid',
--   `keyword` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '专辑/空间关键词',
--   `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户昵称',
--   `avatar` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户头像',
--   `update_time` datetime DEFAULT NULL COMMENT '最近更新时间',
--   `fan` int(11) DEFAULT NULL COMMENT '粉丝个数',
--   `level` int(5) DEFAULT NULL COMMENT '级别',
--   PRIMARY KEY (`id`)
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
--
--
-- sqoop export --connect jdbc:mysql://10.10.243.51:3306/search --username root --password tangdouapp#123 --table user_full --update-key id --update-mode allowinsert --export-dir /olap/da/user_full/ --input-fields-terminated-by \001 --input-null-string \\\\N --input-null-non-string \\\\N  -m 10
