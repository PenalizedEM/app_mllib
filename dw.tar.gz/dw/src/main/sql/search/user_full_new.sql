-- da.user_full

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS user_full_new
(
id string COMMENT 'userid',
keyword string COMMENT '专辑/空间关键词',
name string COMMENT '用户昵称',
avatar string COMMENT '用户头像',
update_time string COMMENT '最近更新时间',
latest_time string COMMENT '最新时间',
fan int COMMENT '粉丝个数',
level int COMMENT '级别',
lon double COMMENT '经度',
lat double COMMENT '纬度'
)
COMMENT'用户表-搜索用'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/da/user_full_new/';

insert overwrite table da.user_full_new 
select  id,
		keyword,
		name,
		avatar,
		update_time,
        u_timestamp latest_time,
		fan,
		level,
		lon,
		lat
		
from 
	(
		select
			n.id,
			m.keyword,
			n.name,
			avatar,
			update_time,
			nvl(q.fans_cnt,0) fan,
			level,
			lon,
			lat,
			if(r.u_timestamp is null,'1970-01-01 00:00:00.0',r.u_timestamp) u_timestamp,
			count(*)
		from
			(
				SELECT  id,
						name,
						avatar,
						if(regtime>if(last_upstring is null or last_upstring='null','0000-00-00 00:00:00.0',last_upstring), regtime, last_upstring)  update_time,
						level,
						lon,
						lat 
				FROM 
				dw.user
			) n
		left outer join
			(SELECT userid,keyword FROM dw.playlist WHERE type=2 and userid<>0 group by userid, keyword) m
		on n.id=m.userid
		left outer join
			(select reuid,count(1) fans_cnt from dw.follow_user group by reuid) q
		on n.id=q.reuid   
		left join 
			(select u_uid,max(u_timestamp) u_timestamp from dw.uibigger where dt='${datebuf}' and u_timestamp>date_sub('${datebuf}',30)  and u_uid<>'' and u_uid <> '-1' group by u_uid) r
		on n.id=r.u_uid
		group by n.id,
			m.keyword,
			n.name,
			avatar,
			update_time,
			nvl(q.fans_cnt,0) ,
			level,
			lon,
			lat,
			if(r.u_timestamp is null,'1970-01-01 00:00:00.0',r.u_timestamp)
	) a
; 