
-- da.search_sug

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS search_sug
(
keyword string COMMENT '专辑/空间关键词',
type string COMMENT '1舞曲，0搜索词',
pv int COMMENT 'pv'
)
COMMENT'视频提示-搜索用'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/da/search_sug/';

insert overwrite table da.search_sug
select
if(m.d_keyword is NULL,n.keyword,m.d_keyword) key ,
nvl(type,0) song ,
nvl(m.m_pv,0) pv
from
(select
d_keyword,m_pv
from da.search_top_keywords
where
dt='${datebuf}'
and m_pv>100
and d_keyword rlike '^[\\w-一()（）《》，,：:。·\\s\\.\\u4E00-\\u9FA5]{1,49}$'
)m
full outer join
(
select
keyword,type
from dw.playlist
where type=1
and is_prompt=0
and keyword<>'' and keyword is not null
and keyword rlike '^[\\w-一()（）《》，,：:。·\\s\\.\\u4E00-\\u9FA5]{1,49}$'
group by
keyword,type
) n
on m.d_keyword = n.keyword
;

-- -- mysql
-- CREATE TABLE `search_sug` (
--  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID主键自增',
--  `keyword` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '专辑/空间关键词',
--  `type` int(11) DEFAULT NULL COMMENT '1舞曲,0关键词',
--  `pv` int(11) DEFAULT NULL COMMENT 'pv',
--  PRIMARY KEY (`id`),
--  UNIQUE KEY `keyword` (`keyword`)
-- ) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4

--


-- export --connect jdbc:mysql://10.10.243.51:3306/search --username root --password tangdouapp#123 --table search_sug --columns keyword,type,pv --update-key keyword --update-mode allowinsert --export-dir /olap/da/search_sug/ --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N  -m 1

