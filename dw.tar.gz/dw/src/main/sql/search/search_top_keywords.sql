use da;
CREATE EXTERNAL TABLE IF NOT EXISTS search_top_keywords(
d_datebufer STRING  COMMENT '最新一次出现的业务日期',
d_keyword  STRING  COMMENT '搜索关键词',
m_pv  int  COMMENT '累计搜索次数'
)
COMMENT '搜索-框搜—关键词'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/search_top_keywords/';

-- 初始化，top埋点从6月1日开始
-- set hivevar:datebuf=2016-06-01;
--
-- INSERT OVERWRITE table da.search_top_keywords partition(dt='${datebuf}')
-- select
-- dt,
-- u_key,
-- count(1) pv
-- from dw.user_action
-- where dt='${datebuf}'
-- and concat(u_mod,'-',u_ac)='emptylog-search_onclick'
-- and u_client_module='top'
-- group by
-- dt,
-- u_key
-- order by pv desc ;


-- 每日更新
-- set hivevar:datebuf_before=2016-06-01;
-- set hivevar:datebuf=2016-06-02;

INSERT OVERWRITE table da.search_top_keywords partition(dt='${datebuf}') 
select 
if(b.dt is null, a.dt,b.dt) d_datebuf,
if(a.d_keyword is null, b.u_key, a.d_keyword) d_keyword,
case when a.m_pv is null and b.pv is not null then b.pv 
when a.m_pv is not null and b.pv is null then a.m_pv 
when a.m_pv is not null and b.pv is not null then a.m_pv+b.pv
else 0 
end as m_pv
from 
(
select * from da.search_top_keywords where dt='${datebuf_before}' 
) a  
full outer join 
(
select 
dt,
u_key, 
count(1) pv 
from dw.uabigger
where dt='${datebuf}' 
and concat(u_mod,'-',u_ac)='emptylog-search_onclick' 
and u_client_module='top' 
group by 
dt,
u_key 
) b 
on(a.d_keyword=b.u_key)
order by m_pv desc 
;
