
use da;
-- drop table dm_ac_feature_a;
CREATE EXTERNAL TABLE IF NOT EXISTS da.dm_ac_feature_a(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    is_reg  INT COMMENT '激活后是否注册：0未注册，1注册',
    avatar   INT COMMENT '激活后是否设置头像：0否，1是',
    type INT COMMENT '激活后登录账号类型：1微信，2qq，3手机，0未注册',
    signature    INT COMMENT '激活后是否设置个性签名：0否，1是',
    space_pic    INT COMMENT '激活后是否设置背景空间：0否，1是',
    follow_ucnt   INT COMMENT '激活后关注用户的个数' ,
    manufacture STRING  COMMENT '激活时的厂商',
    device  STRING  COMMENT '激活时的ios:设备型号',
    os_version    STRING  COMMENT '操作系统版本号',
    dic_f   STRING  COMMENT '激活时的客户端渠道代码',
    div_f  STRING  COMMENT '激活时的客户端版本',
    hour_f INT COMMENT '激活的时间——小时',
    resolution  STRING  COMMENT '屏幕分辨率：高*宽',
    u_client    STRING  COMMENT '客户端类型',
    u_nettype   STRING  COMMENT '网络类型',
    u_province  STRING  COMMENT '用户省份',
    u_city  STRING  COMMENT '用户城市',
    u_netop STRING  COMMENT '网络运营商',
    u_agent STRING  COMMENT '客户端agent',
    u_xff   STRING  COMMENT '客户端ip',
    search_cnt INT COMMENT '搜索次数',
    sug_cnt INT COMMENT '搜索提示次数',
    homepage_cnt INT COMMENT '首页打开次数',
    hp_hot_cnt INT COMMENT '首页-热门打开次数',
    hp_dancemusic_cnt INT COMMENT '首页-舞曲打开次数',
    hp_talent_cnt INT COMMENT '首页-达人打开次数',
    hp_category_cnt INT COMMENT '首页-分类打开次数',
    hp_new_cnt INT COMMENT '首页-最新打开次数',
    hp_follow_cnt INT COMMENT '首页-我的关注模块点击次数',
    hp_greatest_cnt INT COMMENT '首页-每日精选模块点击次数',
    hp_live_cnt INT COMMENT '首页-糖豆生活模块点击次数',
    hp_stage_cnt INT COMMENT '首页-糖粉舞台模块点击次数',
    hp_more_cnt INT COMMENT '首页-加载更多点击次数',
    feaddback_cnt INT COMMENT '糖小豆反馈次数',
    showdance_cnt INT COMMENT '秀舞打开次数',
    upload_cnt INT COMMENT '上传视频次数',
    serv_cnt INT COMMENT '接口调用次数',
    serv_unique_cnt INT COMMENT '接口调用个数',
    max_stepid  INT COMMENT '激活当日最大步数'
)
COMMENT '新增设备激活当日的特征——A'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/dm_ac_feature_a/';

insert overwrite table  dm_ac_feature_a partition(dt='${datebuf}')
select
    u_diu,
    is_reg,
    avatar,
    type,
    signature,
    space_pic,
    follow_ucnt,
    manufacture,
    if(u_client=1,split(device,'/')[0],split(device,'-Android:')[0]) device ,
    if(u_client=1,split(device,'/')[1],split(device,'-Android:')[1]) os_version,
    dic_f,
    div_f,
    hour_f,
    max(concat(if(height>width,height,width),'*',if(height>width,width,height))) resolution,
    max(u_client) u_client,
    max(u_nettype) u_nettype,
    max(if(province='',u_province,province)) u_province,
    max(if(city='',u_city,city)) u_city,
    max(if(netop='',u_netop,netop)) u_netop,
    max(u_agent) u_agent,
    max(u_xff) u_xff,
    sum(if(concat(u_mod,'-',u_ac) in ('search-all_video','search-radar'),1,0)) search_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('search-suggest','search-suggest_overall'),1,0)) sug_cnt ,
    sum(if(concat(u_mod,'-',u_ac)='video-index'
        or (concat(u_mod,'-',u_ac)='emptylog-user_role' and u_old_activity='首页' )
         ,1,0)) homepage_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('search-teach_library'),1,0)) hp_hot_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('top-music_recommend_index'),1,0)) hp_dancemusic_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('top-team_recommend_index'),1,0)) hp_talent_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('top-tag'),1,0)) hp_category_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('video-new_list'),1,0)) hp_new_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('emptylog-user_role') and u_action in ('我的关注'),1,0)) hp_follow_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('emptylog-user_role') and u_action in ('每日精选'),1,0)) hp_greatest_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('emptylog-user_role') and u_action in ('糖豆生活'),1,0)) hp_live_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('emptylog-user_role') and u_action in ('糖豆广场','糖粉舞台'),1,0)) hp_stage_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('emptylog-user_role') and u_action in ('加载更多内容'),1,0)) hp_more_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('message-txdfeed_add'),1,0)) feaddback_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('video_upload-mp3_rank'),1,0 )) showdance_cnt ,
    sum(if(concat(u_mod,'-',u_ac) in ('video_upload-add'),1,0 )) upload_cnt ,
    count(concat(u_mod,'-',u_ac)) serv_cnt,
    count(distinct concat(u_mod,'-',u_ac)) serv_unique_cnt,
    max(u_stepid) max_stepid
from
    da.dm_ac_action
where
    dt='${datebuf}'
    and concat(u_mod,'-',u_ac) not in
    (
    'main-start',
    'top-count_plush',
    'emptylog-push_arrival'
    )
group by
    u_diu,
    is_reg,
    avatar,
    type,
    signature,
    space_pic,
    follow_ucnt,
    manufacture,
    if(u_client=1,split(device,'/')[0],split(device,'-Android:')[0])  ,
    if(u_client=1,split(device,'/')[1],split(device,'-Android:')[1]),
    dic_f,
    div_f,
    hour_f
;