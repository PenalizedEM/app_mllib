use da;
-- ALTER TABLE anticheating_newuabigger RENAME TO dm_ac_action;
set mapreduce.map.memory.mb=2048;
CREATE EXTERNAL TABLE IF NOT EXISTS da.dm_ac_action(
    u_timestamp TIMESTAMP   COMMENT '东八区时间',
    u_xff   STRING  COMMENT '客户端ip',
    u_status    STRING  COMMENT 'http状态',
    u_div   STRING  COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
    u_dic   STRING  COMMENT '客户端渠道代码',
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_diu2  STRING  COMMENT '广告ID,android--mac,ios--IDFA',
    u_diu3  STRING  COMMENT 'GUID,android--guid,ios--guid',
    u_uid   STRING  COMMENT '注册用户id',
    u_startid   STRING  COMMENT '启动标识号(距离2016年1月1号0点0分0秒这时刻有多少秒）',
    u_stepid    INT COMMENT '客户端的操作步骤',
    u_time  STRING  COMMENT '客户端时间戳',
    u_mod   STRING  COMMENT '服务端接口模块',
    u_ac    STRING  COMMENT '服务端具体接口',
    u_client    STRING  COMMENT '客户端类型',
    u_agent STRING  COMMENT '客户端agent',
    u_method    STRING  COMMENT 'http方法',
    u_new_activity  STRING  COMMENT '跳转到页面名称(当前页)',
    u_old_activity  STRING  COMMENT '跳转过来页面名称',
    u_key   STRING  COMMENT '搜索关键词',
    u_client_module STRING  COMMENT '用户客户端搜索模块',
    u_source    STRING  COMMENT '用户搜索调用的接口',
    u_page  INT COMMENT '用户点击第几页的搜索结果',
    u_position  INT COMMENT '用户点击第几条的搜索结果',
    u_vid   STRING  COMMENT '视频的id',
    u_type  STRING  COMMENT '搜索排序类型',
    u_percent   INT COMMENT '页面停留时间/视频播放时间',
    u_rate  INT COMMENT '视频播放进度（百分比)',
    u_user_role STRING  COMMENT '用户在舞队内的角色',
    u_isnew_user    STRING  COMMENT '当天注册为新用户',
    u_isdownload    STRING  COMMENT '是否点击了播放页的下载按钮',
    u_isonline  STRING  COMMENT '是否在线播放',
    u_buffertime    FLOAT   COMMENT '进入播放页到视频开始播放的时间',
    u_action    STRING  COMMENT '操作播放器行为',
    u_ishigh    STRING  COMMENT '是否高清视频',
    u_cdn_source    STRING  COMMENT 'cdn名称',
    u_download_start    TIMESTAMP   COMMENT '下载开始',
    u_download_stop TIMESTAMP   COMMENT '下载结束',
    u_fail_cdn_source   STRING  COMMENT '失败cdn源',
    u_new_cdn_source    STRING  COMMENT '切换cdn源',
    u_lon   STRING  COMMENT '用户位置——经度',
    u_lat   STRING  COMMENT '用户位置——纬度',
    u_province  STRING  COMMENT '用户省份',
    u_city  STRING  COMMENT '用户城市',
    u_netop STRING  COMMENT '网络运营商',
    u_nettype   STRING  COMMENT '网络类型',
    u_sdkversion    STRING  COMMENT 'android系统版本号',
    u_model STRING  COMMENT 'ios:固件版本',
    uid STRING  COMMENT '新增设备的注册用户id',
    province    STRING  COMMENT '激活时的省份',
    city    STRING  COMMENT '激活时的城市',
    netop   STRING  COMMENT '激活时的网络运营商',
    manufacture STRING  COMMENT '激活时的厂商',
    device  STRING  COMMENT '激活时的ios:设备型号',
    width   INT COMMENT '激活时的屏幕尺寸——宽',
    height  INT COMMENT '激活时的屏幕尺寸——高',
    dic_f   STRING  COMMENT '激活时的客户端渠道代码',
    hour_f INT COMMENT '激活的时间——小时',
    div_f  STRING  COMMENT '激活时的客户端版本',
    is_reg  INT COMMENT '激活后是否注册：0未注册，1注册',
    avatar   INT COMMENT '激活后是否设置头像：0否，1是',
    type INT COMMENT '激活后登录账号类型：1微信，2qq，3手机，0未注册',
    signature    INT COMMENT '激活后是否设置个性签名：0否，1是',
    space_pic    INT COMMENT '激活后是否设置背景空间：0否，1是',
    follow_ucnt   INT COMMENT '激活后关注用户的个数'
)
COMMENT '新增设备激活当日的所有日志行为'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/dm_ac_action/';


insert overwrite table dm_ac_action partition(dt='${datebuf}')
select
    u_timestamp,
    u_xff,
    u_status,
    u_div,
    u_dic,
    u_diu,
    u_diu2,
    u_diu3,
    u_uid,
    u_startid,
    u_stepid,
    u_time,
    u_mod,
    u_ac,
    u_client,
    u_agent,
    u_method,
    u_new_activity,
    u_old_activity,
    u_key,
    u_client_module,
    u_source,
    u_page,
    u_position,
    u_vid,
    u_type,
    u_percent,
    u_rate,
    u_user_role,
    u_isnew_user,
    u_isdownload,
    u_isonline,
    u_buffertime,
    u_action,
    u_ishigh,
    u_cdn_source,
    u_download_start,
    u_download_stop,
    u_fail_cdn_source,
    u_new_cdn_source,
    u_lon,
    u_lat,
    u_province,
    u_city,
    u_netop,
    u_nettype,
    u_sdkversion,
    u_model,
    if(c.uid is null or c.uid='', 0, c.uid) uid,
    province,
    city,
    netop,
    manufacture,
    device,
    width,
    height,
    dic_f,
    hour_f,
    div_f ,
    if(d.id is null,0,1) is_reg,
    if(d.avatar is null, 0, avatar) avatar,
    if(d.type is null, 0, type) type,
    if(d.signature is null, 0, signature) signature ,
    if(d.space_pic is null, 0, space_pic) space_pic,
    if(e.follow_ucnt is null, 0, follow_ucnt) follow_ucnt

from
    (
        select
            a.*,
            b.*
        from
            (
                select
                    *
                from
                    dw.uabigger
                where
                    dt='${datebuf}'
            ) a
        join
            (
                select
                    u_diu diu,
                    u_uid uid,
                    u_province province,
                    u_city city,
                    u_netop netop ,
                    u_manufacture manufacture,
                    u_device device,
                    u_width width,
                    u_height height,
                    u_dic_f dic_f,
                    hour(u_timestamp_f)  hour_f,
                    u_div_f div_f
                from
                    dw.uibigger
                where
                    dt='${datebuf}'
                    and to_date(u_timestamp_f)='${datebuf}'
            ) b
        on
            (a.u_diu=b.diu)
    ) c
left outer join
    (
        select
            id,
            if(avatar is null or avatar='',0,1) avatar ,
            type,
            if(signature is null or signature='',0,1) signature,
            if(space_pic is null or signature='',0,1) space_pic
        from dw.user
    )  d
on
    (c.uid=d.id)
left outer join
    (
        select
            uid,
            count(1) follow_ucnt
        from
            dw.follow_user
        where
            to_date(time)='${datebuf}'
        group by
            uid
    ) e
on
    (c.uid=e.uid)
;
