use da;
CREATE EXTERNAL TABLE IF NOT EXISTS da.dm_ac_feature_b(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vcnt INT COMMENT '观看视频的个数',
    vv INT COMMENT '观看次数',
    vp INT COMMENT '播放进度',
    vst INT COMMENT '观看时长',
    vc INT COMMENT '评论次数',
    vsf INT COMMENT '送花次数',
    vf INT COMMENT '收藏次数',
    vs INT COMMENT '分享次数',
    vd INT COMMENT '下载次数'
)
COMMENT '新增设备激活当日的特征——B'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/dm_ac_feature_b/';

insert overwrite table dm_ac_feature_b partition (dt='${datebuf}')
select
diu,
count(1) vcnt,
sum(vv) vv,
percentile(cast(vp as bigint),0.5) vp ,
percentile(cast(vst as bigint),0.5) vst,
sum(vc) vc,
sum(vsf) vsf,
sum(vf) vf,
sum(vs) vs,
sum(vd) vd
from
(
select
diu,
vid,
uid v_uid,
title,
vv,
vp,
round(vst/100*duration,1) vst,
vc,
vsf,
vf,
vs,
vd
from
(
select
u_diu diu,
u_vid vid,
title,
duration,
uid,
sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) vv ,
max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed' ,u_percent,0)) vp, -- progress
sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed' and u_action='exit',u_percent,0)) vst,
sum(if(concat(u_mod,'-',u_ac)='message-video_comment_add',1,0)) vc ,
sum(if(concat(u_mod,'-',u_ac)='flower-send',1,0)) vsf ,
sum(if(concat(u_mod,'-',u_ac)='user-fav',1,0)) vf ,
sum(if(concat(u_mod,'-',u_ac)='user-share',1,0)) vs ,
sum(if(concat(u_mod,'-',u_ac)='video-count_video',1,0)) vd
from
(
select
/* +mapjoin(b) */
*
from dw.uabigger
where dt='${datebuf}'
and concat(u_mod,'-',u_ac) in
(
'emptylog-video_play_speed', -- 播放时间
'top-hits', -- 播放次数
'flower-send', -- 送花
'user-share', -- 分享
'user-fav', -- 收藏
'video-count_video', -- 下载
'message-video_comment_add' -- 评论
)
) a
join
(
select
vid, title, duration, createtime ,uid
from dw.video
) b
on (a.u_vid=b.vid)
group by
u_diu ,
u_vid ,
title,
duration,
uid
) c
) d
group by
diu;