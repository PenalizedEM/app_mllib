use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS push_user_info(
u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_xinge STRING  COMMENT '信鸽token',
u_fresh INT COMMENT '用户新鲜度(当天减去激活天数)',
u_active  INT COMMENT '用户累计活跃天数', 
u_timestamp STRING COMMENT '最近一次活跃时间'
)
COMMENT '糖豆用户推送设备表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE 
LOCATION '/olap/dw/push_user_info/';

insert overwrite table dw.push_user_info partition (dt='${datebuf}') 
select 
u_diu, 
u_xinge,
u_fresh,
u_active, 
u_timestamp
from dw.uibigger
where dt='${datebuf}'
;

