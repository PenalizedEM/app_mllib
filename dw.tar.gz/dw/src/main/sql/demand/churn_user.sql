use da;

CREATE EXTERNAL TABLE IF NOT EXISTS churn_user_daily(
datebuf STRING  COMMENT '业务日期',
new_uv STRING  COMMENT '新增设备数',
new_churn_uv  STRING  COMMENT '新增流失数',
new_churn_rate  double  COMMENT '新增流失率',
act_uv STRING  COMMENT '活跃设备数',
act_churn_uv  STRING  COMMENT '活跃流失数',
act_churn_rate  double  COMMENT '活跃流失率'
)
COMMENT '每日流失用户'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/churn_user_daily/';

-- 每日新增&活跃流失用户
-- 新增流失：从激活日后30天内未活跃
-- 活跃流失：从活跃日后30天内为活跃


insert overwrite table churn_user_daily partition(dt='${datebuf}')
select
a.dt,
a.new_uv,
b.new_churn_uv,
b.new_churn_uv/a.new_uv new_churn_rate,
a.act_uv,
b.act_churn_uv,
b.act_churn_uv/a.act_uv act_churn_rate
from
(
select
dt,
sum(if(isnew_flag, uv, 0)) new_uv,
sum(if(isact_flag, uv, 0)) act_uv
from
(
select dt,
       if ((u_fresh=0 and u_active=1 ), true, false) isnew_flag ,
       if (( to_date(u_timestamp)='${datebuf}' ), true, false ) isact_flag ,
       count(distinct u_diu)  uv
from dw.uibigger
where dt='${datebuf}'
group by dt ,
       if ((u_fresh=0 and u_active=1 ), true, false )  ,
       if (( to_date(u_timestamp)='${datebuf}' ), true, false )
) a
group by
dt
) a
join
(
select
sum(if(isnew_churn_flag, uv, 0)) new_churn_uv,
sum(if(isact_churn_flag, uv, 0)) act_churn_uv
from
(
select dt,
       if (( u_fresh=30 and u_active=1 ), true, false) isnew_churn_flag ,
       if (( to_date(u_timestamp)='${datebuf}' ), true, false ) isact_churn_flag ,
       count(distinct u_diu)  uv
from dw.uibigger
where dt='${churn_datebuf}'
group by dt ,
       if ((u_fresh=30 and u_active=1 ), true, false )  ,
       if (( to_date(u_timestamp)='${datebuf}' ), true, false )
) a
) b
;

