-- 首播时间分布
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_quantile(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_min  float  COMMENT '最小值',
m_first_quartile  float  COMMENT '四分一分位数',
m_median  float  COMMENT '中位数',
m_lower_quartile  float  COMMENT '四分之三分位数',
m_avg float COMMENT '均值',
m_max float COMMENT '最大值',
m_var float COMMENT '方差',
m_ninety float COMMENT '90分位数',
m_ninetyfive float COMMENT '95分位数',
m_ninetynine float COMMENT '99分位数'
)
COMMENT '视频播放质量——首播时间分布'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_quantile/';

-- 以下注释不能放文件头，否则在hue中执行会因为hivejob名过长而直接跳过，返回执行成功。

-- hive脚本变量替换的方式一：hiveconf
-- set datebuf='2016-07-01';
-- select ${hiveconf:datebuf} from da.vpq_switch limit 1;
-- select * from da.vpq_switch where dt>=${hiveconf:datebuf};

-- hive脚本变量替换的方式二：hivevar
-- 用于创建success文件指定路径的时间变量
-- set hivevar:datebuf_dir=2016-07-01;


-- 安卓>=V4.6.8 top-hits(APP内视频播放量)接口添加u_cdn_source

-- 安卓>=V4.8.2 emptylog-video_buffer接口 (由于卡顿p可能远大于播放pv,统计播放卡顿比(uv))

-- 2017-02-07起,统一只统计安卓v5.3.5以及以上版本

insert overwrite table da.vpq_quantile partition (dt='${datebuf}')
select
dt,
u_cdn_source,
min(u_buffertime)/1000 min_bt,
percentile(cast(u_buffertime as bigint),0.25)/1000 quater_bt,
percentile(cast(u_buffertime as bigint),0.5)/1000 median_bt,
percentile(cast(u_buffertime as bigint),0.75)/1000 threequater_bt,
avg(cast(u_buffertime as bigint))/1000 avg_bt,
max(cast(u_buffertime as bigint))/1000 max_bt,
variance(cast(u_buffertime as bigint))/1000 var_bt,
percentile(cast(u_buffertime as bigint),0.90)/1000 threequater_bt,
percentile(cast(u_buffertime as bigint),0.95)/1000 threequater_bt,
percentile(cast(u_buffertime as bigint),0.99)/1000 threequater_bt
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_buffertime is not null and u_buffertime>0
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.5.7'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source
;

-- 首播时间区间分布
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_interval(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_0to5s  int  COMMENT '0~5秒',
m_5to10s  int  COMMENT '5~10秒',
m_10to15s  int  COMMENT '10~15秒',
m_15to20s  int  COMMENT '15~20秒',
m_20to30s int COMMENT '20~30秒',
m_30to40s int COMMENT '30~40秒',
m_40to50s int COMMENT '40~50秒',
m_50to80s int COMMENT '50~80秒',
m_80to100s int COMMENT '80~100秒',
m_100to200s int COMMENT '100~200秒',
m_gt200s int COMMENT '200秒',
m_pv int COMMENT '总播放次数'
)
COMMENT '视频播放质量——首播时间区间分布'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_interval/';

insert overwrite table vpq_interval partition (dt='${datebuf}')
select
dt,
u_cdn_source,
sum(if(u_buffertime<5000,pv,0)) as 0to5s,
sum(if(u_buffertime>=5000 and u_buffertime<10000,pv,0)) as 5to10s,
sum(if(u_buffertime>=10000 and u_buffertime<15000,pv,0)) as 10to15s,
sum(if(u_buffertime>=15000 and u_buffertime<20000,pv,0)) as 15to20s,
sum(if(u_buffertime>=20000 and u_buffertime<30000,pv,0)) as 20to30s,
sum(if(u_buffertime>=30000 and u_buffertime<40000,pv,0)) as 30to40s,
sum(if(u_buffertime>=40000 and u_buffertime<50000,pv,0)) as 40to50s,
sum(if(u_buffertime>=50000 and u_buffertime<80000,pv,0)) as 50to80s,
sum(if(u_buffertime>=80000 and u_buffertime<100000,pv,0)) as 80to100s,
sum(if(u_buffertime>=100000 and u_buffertime<200000,pv,0)) as 100to200s,
sum(if(u_buffertime>=200000,pv,0)) as gt200s,
sum(pv) pv
from
(
select
dt, u_cdn_source,cast(u_buffertime as bigint) u_buffertime, count(1) pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_buffertime is not null and u_buffertime>0
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.5.7'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source,cast(u_buffertime as bigint) 
) a
group by
dt,
u_cdn_source
;


-- 播放错误率
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_errate(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_error_uv  int  COMMENT '播放错误人数',
m_error_pv  int  COMMENT '播放次数',
m_play_uv  int  COMMENT '总播放人数',
m_play_pv  int  COMMENT '总播放次数',
m_errate_uv float COMMENT '播放错误率（uv）',
m_errate_pv float COMMENT '播放错误率（pv）'
)
COMMENT '视频播放质量——播放错误率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_errate/';

insert overwrite table da.vpq_errate partition (dt='${datebuf}')
select
c.dt,
c.u_cdn_source,
error_uv,
error_pv,
play_uv,
play_pv,
error_uv/play_uv errate_uv,
error_pv/play_pv errate_pv
from
(
select
dt,
u_cdn_source,
count(1) error_uv,
sum(pv) error_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='play_error'
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.5.7'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source , u_diu
) a
group by
dt,
u_cdn_source
) c
join
(
select
dt,
u_cdn_source,
count(1) play_uv,
sum(pv) play_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.5.7'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source , u_diu
) b
group by
dt,
u_cdn_source
) d
on (c.dt=d.dt and c.u_cdn_source=d.u_cdn_source)
;


-- 安卓>=V4.6.8 top-hits(APP内视频播放量)接口添加u_cdn_source

-- 安卓>=V4.8.2 emptylog-video_buffer接口 (由于卡顿p可能远大于播放pv,统计播放卡顿比(uv))

-- 视频播放卡顿率
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_lagrate(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_lag_uv  int  COMMENT '播放卡顿人数',
m_lag_pv  int  COMMENT '播放卡顿次数',
m_play_uv  int  COMMENT '总播放人数',
m_play_pv  int  COMMENT '总播放次数',
m_lagrate_uv float COMMENT '播放卡顿率（uv）',
m_lagrate_pv float COMMENT '播放卡顿率（pv）'
)
COMMENT '视频播放质量——播放卡顿率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_lagrate/';

-- 视频播放卡顿率
insert overwrite table da.vpq_lagrate partition (dt='${datebuf}')
select
c.dt,
c.u_cdn_source,
lag_uv,
lag_pv,
play_uv,
play_pv,
lag_uv/play_uv lagrate_uv,
lag_pv/play_pv lagrate_pv
from
(
select
dt,
u_cdn_source,
count(1) lag_uv,
sum(pv) lag_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_buffer'
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.8.2'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source , u_diu
) a
group by
dt,
u_cdn_source
) c
join
(
select
dt,
u_cdn_source,
count(1) play_uv,
sum(pv) play_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
-- and u_mod='top'and u_ac='hits'
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.8.2'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source , u_diu
) b
group by
dt,
u_cdn_source
) d
on (c.dt=d.dt and c.u_cdn_source=d.u_cdn_source)
;

-- 视频播放失败切换CDN源统计

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_switch(
d_datebufer STRING  COMMENT '业务日期',
d_fail_cdn_source  STRING  COMMENT '播放失败的CDN源',
 m_switch_uv  int  COMMENT '切换cdn源人数',
 m_switch_pv  int  COMMENT '切换cdn源次数',
 m_play_uv  int  COMMENT '总播放人数',
 m_play_pv  int  COMMENT '总播放次数',
 m_swrate_uv float COMMENT '切换率（uv）',
 m_swrate_pv float COMMENT '切换率（pv）'
)
COMMENT '视频播放质量——播放失败切源统计'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_switch/';

insert overwrite table da.vpq_switch partition (dt='${datebuf}')
select
c.dt,
c.u_fail_cdn_source,
switch_uv,
switch_pv,
play_uv,
play_pv,
switch_uv/play_uv switchrate_uv,
switch_pv/play_pv switchrate_pv
from
(
select
dt,
u_fail_cdn_source,
count(distinct u_diu) switch_uv,
count(1) switch_pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='cdn_switch'
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.5.7'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt,
u_fail_cdn_source
) c
right outer join
(
select
dt,
u_cdn_source,
count(1) play_uv,
sum(pv) play_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.uabigger
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_div<>'' and u_div is not null
-- and substr(u_div,0,5)>='4.5.7'
and substr(u_div,0,5)>='5.3.5'
and u_client=2
group by
dt, u_cdn_source , u_diu
) b
group by
dt,
u_cdn_source
) d
on (c.dt=d.dt and c.u_fail_cdn_source=d.u_cdn_source)
where c.u_fail_cdn_source is not null
;

dfs -touchz /olap/da/vpq_switch/dt=${datebuf}/_SUCCESS;
