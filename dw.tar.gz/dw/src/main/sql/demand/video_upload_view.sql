-- UGC/PGC每日上传视频量

-- 业务日上传的 达人的视频 PGC / 非达人的视频 UGC
drop table if exists da.temp_demand_video;
create table da.temp_demand_video as
select
/* +mapjoin(b) */
to_date(createtime) datebuf,
if(b.userid is null,'ugc','pgc') upload_type,
if(type=8,'mobile','pc') upload_client,
a.*
from
( select * from dw.video where to_date(createtime)='${datebuf}')  a
left outer join
(
SELECT distinct b.userid
from
(select pid FROM dw.playlist_recommend where type=3 group by pid )a
join
(select pid, userid from dw.playlist where userid<>0 group by pid, userid) b
on a.pid=b.pid
) b
on (a.uid = b.userid)
;

-- 每日PGC/UGC上传视频量
-- 视频上传量
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS video_upload_cnt(
d_datebufer STRING  COMMENT '业务日期',
d_upload_type  STRING  COMMENT 'ugc/pgc',
d_upload_client  STRING  COMMENT 'pc/mobile',
m_vid_cnt  int  COMMENT '上传量'
)
COMMENT '每日视频上传量'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/video_upload_cnt/';

insert overwrite table video_upload_cnt partition (dt='${datebuf}')
select
datebuf d_datebuf,
upload_type d_upload_type,
upload_client d_upload_client,
count(distinct vid) m_vid_cnt
from da.temp_demand_video
group by
datebuf,
upload_type,
upload_client
;


-- 截止业务日期UGC/PGC累计上传的视频在当日的播放量
-- 截止业务日上传的 达人的视频 PGC / 非达人的视频 UGC
drop table if exists da.temp_demand_video_all;
create table da.temp_demand_video_all as
select
/* +mapjoin(b) */
to_date(createtime) datebuf,
if(b.userid is null,'ugc','pgc') upload_type,
if(type=8,'mobile','pc') upload_client,
a.*
from
( select * from dw.video where to_date(createtime)<='${datebuf}')  a
left outer join
(
SELECT distinct b.userid
from
(select pid FROM dw.playlist_recommend where type=3 group by pid )a
join
(select pid, userid from dw.playlist where userid<>0 group by pid, userid) b
on a.pid=b.pid
) b
on (a.uid = b.userid)
;

-- 上传视频播放量
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS video_upload_vv(
d_datebufer STRING  COMMENT '业务日期',
d_upload_type  STRING  COMMENT 'ugc/pgc',
d_upload_client  STRING  COMMENT 'pc/mobile',
m_pv  int  COMMENT '截止业务日上传的视频在业务日当日的播放量'
)
COMMENT '截止业务日上传的视频在业务日当日的播放量'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/video_upload_vv/';

insert overwrite table video_upload_vv partition (dt='${datebuf}')
select
/* +mapjoin(b) */
dt,
upload_type,
upload_client,
sum(pv) pv
from
(
select
dt,
u_vid,
count(1) pv
from
dw.uabigger
where
dt='${datebuf}'
and u_mod='top' and u_ac='hits'
group by
dt,
u_vid
)  a
join
( select upload_type, upload_client, vid  from da.temp_demand_video_all   ) c
on (a.u_vid=c.vid)
group by
dt,
upload_type,
upload_client
;



