
CREATE EXTERNAL TABLE IF NOT EXISTS da.first_upload_users(
datebuf_f STRING  COMMENT '首次上传视频日期',
client  int  COMMENT '客户端类型',
diu  STRING  COMMENT 'diu',
datebuf STRING  COMMENT '最近次上传视频日期' 
)
COMMENT '用户首次使用秀舞工具上传视频的时间'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/first_upload_users/';

-- -- 初始化
-- insert overwrite table da.first_upload_users partition(dt='2016-08-31')
-- select
-- '2016-08-31' datebuf_f,
-- u_client,
-- u_diu,
-- '2016-08-31'
-- from dw.user_action
-- where dt='2016-08-31'
-- and concat(u_mod,'-',u_ac) in
-- ('video_upload-add')
-- and u_client is not null and u_client<>''
-- and u_diu is not null and u_diu<>''
-- group by
-- u_client,
-- u_diu ;

insert overwrite table da.first_upload_users partition(dt='${datebuf}')
select 
if(a.datebuf_f is null,b.datebuf,a.datebuf_f ) datebuf_f,
if(a.client is null,b.u_client,a.client ) client,
if(a.diu is null,b.u_diu,a.diu ) diu,
if(b.datebuf is null,a.datebuf,b.datebuf ) datebuf 
from 
(select * from da.first_upload_users where dt='${before_datebuf}') a 
full outer join 
(
select 
dt datebuf,
u_client, 
u_diu
from dw.uabigger
where dt='${datebuf}'
and concat(u_mod,'-',u_ac) in 
('video_upload-add') 
and u_client is not null and u_client<>''
and u_diu is not null and u_diu<>'' 
group by 
dt,
u_client, 
u_diu 
) b 
on(a.diu=b.u_diu);

dfs -touchz /olap/da/first_upload_users/dt=${datebuf}/_SUCCESS;
