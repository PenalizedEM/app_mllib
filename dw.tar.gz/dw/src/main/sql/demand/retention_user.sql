-- 次日新增留存

use da;

CREATE EXTERNAL TABLE IF NOT EXISTS retention_user_daily(
datebuf STRING  COMMENT '业务日期',
new_uv STRING  COMMENT '新增设备数',
new_retention_uv  STRING  COMMENT '次日活跃数',
new_retention_rate  double  COMMENT '次日留存率'
)
COMMENT '每日留存率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/retention_user_daily/';




insert overwrite table retention_user_daily partition(dt='${datebuf}')
select
'${datebuf}',
new_uv,
new_retention_uv,
new_retention_uv/a.new_uv new_retention_rate
from
(
select
'${datebuf}',
sum(if(isnew_flag, uv, 0)) new_uv,
sum(if(isretention_flag, uv, 0)) new_retention_uv
from
(
select '${datebuf}',
       if (( to_date(u_timestamp_f)='${datebuf}' ), true, false) isnew_flag ,
       if (( to_date(u_timestamp_f)='${datebuf}' and to_date(u_timestamp)='${retention_datebuf}' ), true, false ) isretention_flag ,
       count(distinct u_diu)  uv
from dw.uibigger
where dt='${retention_datebuf}'
group by '${datebuf}' ,
       if (( to_date(u_timestamp_f)='${datebuf}' ), true, false)  ,
		if (( to_date(u_timestamp_f)='${datebuf}' and to_date(u_timestamp)='${retention_datebuf}' ), true, false )
) a
group by
'${datebuf}'
) a
;

dfs -touchz /olap/da/retention_user_daily/dt=${datebuf}/_SUCCESS;
