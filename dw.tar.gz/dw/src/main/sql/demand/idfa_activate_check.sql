-- 抽取idfa与激活时间,供渠道接口调用实时结算

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS idfa_activate_check(
idfa STRING  COMMENT 'idfa',
createtime STRING  COMMENT '激活时间-unix时间戳'
)
COMMENT 'idfa激活校对'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/idfa_activate_check/';

-- 初始化2016-09-21

-- insert overwrite table da.idfa_activate_check partition(dt='2016-09-21')
-- select idfa,createtime from dw.cpa_idfa;

insert overwrite table da.idfa_activate_check partition(dt='${datebuf}')
select
if(a.idfa is null,b.u_diu2,a.idfa) idfa,
if(a.createtime is null, b.createtime,a.createtime) createtime
from
(
select * from da.idfa_activate_check where dt='${before_datebuf}'
) a
full outer join
(
select
u_diu2,                                 -- IDFA
min(unix_timestamp(u_timestamp_f)) createtime     -- 首次激活时间
from dw.uibigger
where dt='${datebuf}'
and u_diu2<>'' and u_diu2 is not null   -- 去除空值
and u_client=1                          -- IOS
group BY
u_diu2
) b
on(a.idfa=b.u_diu2)                                -- IDFA去重
;

-- insert overwrite table da.idfa_activate_check
-- select
-- u_diu2,                                 -- IDFA
-- min(unix_timestamp(u_timestamp_f))      -- 首次激活时间
-- from dw.user_info
-- where dt='${datebuf}'
-- and u_diu2<>'' and u_diu2 is not null   -- 去除空值
-- and u_client=1                          -- IOS
-- group BY
-- u_diu2                                  -- IDFA去重
-- ;

-- export
-- export --connect jdbc:mysql://10.10.243.51:3306/cpa --username root --password tangdouapp#123 --table cpa_idfa  --columns idfa,createtime --update-key idfa --update-mode allowinsert --export-dir /olap/da/idfa_activate_check --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N  -m 2