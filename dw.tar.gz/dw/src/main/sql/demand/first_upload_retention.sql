
CREATE EXTERNAL TABLE IF NOT EXISTS da.first_upload_retention(
datebuf STRING  COMMENT '首次上传视频日期',
client int  COMMENT '客户端类型',
first_uv  int  COMMENT '首次上传视频的用户数',
first_retention_uv  int  COMMENT '首次上传的用户中7天内再次上传视频的用户数',
first_retention_rate float  COMMENT '上传视频用户周留存率'
)
COMMENT '首次上传的用户中7天内再次上传视频的用户留存率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/first_upload_retention/';


insert overwrite table da.first_upload_retention partition(dt='${seven_days_ago}')
select
'${seven_days_ago}',
client,
first_uv,
first_retention_uv,
first_retention_uv/first_uv first_retention_rate
from
(
select
'${seven_days_ago}',
client,
sum(if(isfirst_flag, uv, 0)) first_uv,
sum(if(isretention_flag, uv, 0)) first_retention_uv
from
(
select
'${seven_days_ago}',
client,
if ( datebuf_f='${seven_days_ago}', true, false) isfirst_flag ,
if ( datebuf_f='${seven_days_ago}' and datediff(datebuf, datebuf_f)>=1 and datediff(datebuf, datebuf_f)<=7 , true, false ) isretention_flag ,
count(distinct diu)  uv
from
da.first_upload_users
where dt='${datebuf}'
and datebuf_f='${seven_days_ago}'
group by
client,
if ( datebuf_f='${seven_days_ago}', true, false)  ,
if ( datebuf_f='${seven_days_ago}' and datediff(datebuf, datebuf_f)>=1 and datediff(datebuf, datebuf_f)<=7 , true, false )
) a
group by
client
) b
