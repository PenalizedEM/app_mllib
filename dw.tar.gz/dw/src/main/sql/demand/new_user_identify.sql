
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS newuser_identify(
u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_timestamp_f STRING COMMENT '激活时间'
)
COMMENT '用于客户单识别新增用户'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/newuser_identify/';

insert overwrite table da.newuser_identify
select
u_diu,
u_timestamp_f
from dw.uibigger
where dt='${datebuf}'
;




CREATE TABLE `newuser_identify` (
 `diu` varchar(128) NOT NULL,
 `createtime` TIMESTAMP COMMENT '激活时间',
 PRIMARY KEY (`diu`),
 index diu (`diu`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8


export --connect jdbc:mysql://10.10.243.51:3306/2016hd --username root --password tangdouapp#123 --table newuser_identify  --columns diu,createtime --update-key diu --update-mode allowinsert --export-dir /olap/da/newuser_identify --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N  -m 2
