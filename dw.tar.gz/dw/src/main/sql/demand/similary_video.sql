use adm;
-- CREATE TABLE  da.similar_video like da.recy_icf_similarity_topn;

insert overwrite table da.similar_video partition(dt='${datebuf}')
select
vid_1,
vid_2,
similarity,
rank
from
( select * from da.recy_icf_similarity_topn where dt='${datebuf}' ) a
join
(select vid from dw.video where status=0 and type<>10) b
on(a.vid_2=b.vid);

dfs -touchz /user/hive/warehouse/da.db/similar_video/dt=${datebuf}/_SUCCESS;


-- export --connect jdbc:mysql://10.10.243.51:3306/2016hd?tinyInt1isBit=false --username root --password tangdouapp#123 --table similar_video --columns vid_1,vid_2,similarity,rank  --export-dir /user/hive/warehouse/da.db/similar_video/dt=${datebuf} --update-key vid_1,rank --update-mode allowinsert  --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 5