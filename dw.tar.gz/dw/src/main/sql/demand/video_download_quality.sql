-- 视频下载错误率
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS vdq_cdn_errate(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_error_uv  int  COMMENT '下载错误人数',
m_error_pv  int  COMMENT '下载错误次数',
m_down_uv  int  COMMENT '总下载人数',
m_down_pv  int  COMMENT '总下载次数',
m_errate_uv float COMMENT '下载错误率（uv）'
)
COMMENT '视频下载质量——不同cdn下载错误率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vdq_cdn_errate/';

-- 以下注释不能放文件头，否则在hue中执行会因为hivejob名过长而直接跳过，返回执行成功。
-- 视频错误下载评估接口 在安卓v4.6.2以上版本有（2016-06-29）
-- 下载失败由于有重试机制，pv量会爆多于下载次数
-- 视频下载评估接口添加cdn源埋点——在安卓v4.7.1以上版本有（2016-07-14）
-- 2017-02-07日,所有安卓版本统一改成只统计V5.3.5以及以上版本

-- -- 安卓v4.7.1以上版本各CDN源视频下载错误率
-- 安卓v5.3.5以上版本各CDN源视频下载错误率
insert overwrite table da.vdq_cdn_errate partition (dt='${datebuf}')
select
dt,
u_cdn_source,
download_fail_uv,
download_fail_pv,
download_uv,
download_pv,
download_fail_uv/if(download_uv=0,1,download_uv)
from
(
select
dt,
u_cdn_source,
sum(if(ac='emptylog-download_fail',1,0)) download_fail_uv,
sum(if(ac='emptylog-download_fail',pv,0)) download_fail_pv,
sum(if(ac='emptylog-download_onclick',1,0)) download_uv,
sum(if(ac='emptylog-download_onclick',pv,0)) download_pv
from
(
select
dt,
u_cdn_source,
concat(u_mod,'-',u_ac) ac,
u_diu,
count(1) pv
from dw.uabigger
where dt='${datebuf}'
-- and u_cdn_source in ('cc','ucloud','upyun') -- 过滤异常cdn source
and concat(u_mod,'-',u_ac) in ('emptylog-download_fail','emptylog-download_onclick')
and u_div is not null and u_div<>''
and u_client=2
-- and substr(u_div,0,5)>='4.7.1'
and substr(u_div,0,5)>='5.3.5'
group by
dt,
u_cdn_source,
concat(u_mod,'-',u_ac),
u_diu
) a
group by
dt,
u_cdn_source
) b ;

-- 视频下载错误率
CREATE EXTERNAL TABLE IF NOT EXISTS vdq_errate(
d_datebufer STRING  COMMENT '业务日期',
m_error_uv  int  COMMENT '下载错误人数',
m_error_pv  int  COMMENT '下载错误次数',
m_down_uv  int  COMMENT '总下载人数',
m_down_pv  int  COMMENT '总下载次数',
m_errate_uv float COMMENT '下载错误率（uv）'
)
COMMENT '视频下载质量——整体下载错误率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vdq_errate/';

-- -- 安卓v4.6.2以上版本视频下载错误率
-- 安卓v5.3.5以上版本视频下载错误率
insert overwrite table da.vdq_errate partition (dt='${datebuf}')
select
dt,
download_fail_uv,
download_fail_pv,
download_uv,
download_pv,
download_fail_uv/download_uv
from
(
select
dt,
sum(if(ac='emptylog-download_fail',1,0)) download_fail_uv,
sum(if(ac='emptylog-download_fail',pv,0)) download_fail_pv,
sum(if(ac='video-count_video',1,0)) download_uv,
sum(if(ac='video-count_video',pv,0)) download_pv
from
(
select
dt,
concat(u_mod,'-',u_ac) ac,
u_diu,
count(1) pv
from dw.uabigger
where dt='${datebuf}'
and concat(u_mod,'-',u_ac) in ('emptylog-download_fail','video-count_video')
and u_div is not null and u_div<>''
and u_client=2
-- and substr(u_div,0,5)>='4.6.2'
and substr(u_div,0,5)>='5.3.5'
group by
dt,
concat(u_mod,'-',u_ac),
u_diu
) a
group by
dt
) b ;

