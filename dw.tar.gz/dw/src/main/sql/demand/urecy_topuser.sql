

CREATE TABLE `urecy_topuser` (
 `uid`  int(10) COMMENT '用户id',
 `type` varchar(50) DEFAULT NULL COMMENT '用户类型',
 `rank` int(11) DEFAULT NULL COMMENT '推荐用户排序',
 PRIMARY KEY (`uid`),
 UNIQUE KEY `uid` (`uid`)
) ENGINE=InnoDB   DEFAULT CHARSET=utf8mb4


export --connect jdbc:mysql://10.10.34.125:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table urecy_topuser --columns uid,type,rank  --export-dir /olap/da/urecy_topuser/dt=${datebuf} --update-key uid --update-mode allowinsert  --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 1
