

-- 每日视频播放次数、下载次数、收藏次数、点赞次数、评论次数、转发次数
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS video_statistics(
d_datebufer STRING  COMMENT '业务日期',
m_online_play  int  COMMENT '播放次数',
m_download  int  COMMENT '下载次数',
m_like  int  COMMENT '收藏次数',
m_praise  int  COMMENT '点赞次数',
m_comment  int  COMMENT '评论次数',
m_share  int  COMMENT '分享次数'

)

COMMENT '每日视频各种统计量'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/video_statistics/';

insert overwrite table video_statistics partition(dt='${datebuf}')
select dt,
sum(if(concat(u_mod,'|',u_ac) in ('top|hits','top|hits_pc'),1,0)) m_online_play,
sum(if(concat(u_mod,'|',u_ac)='video|count_video',1,0)) m_download,
sum(if(concat(u_mod,'|',u_ac)='user|fav',1,0)) m_like,
sum(if(concat(u_mod,'|',u_ac)='message|video_praise',1,0)) m_praise,
sum(if(concat(u_mod,'|',u_ac) in ('message|video_comment_add','message|video_comment_reply'),1,0)) m_comment,
sum(if(concat(u_mod,'|',u_ac)='user|share',1,0)) m_share
from dw.uabigger where dt>='${datebuf}' group by dt;


