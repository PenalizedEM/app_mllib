----用户session轨迹
insert overwrite table dw.user_core_track partition (dt='${datebuf}')
select
  u_diu d_diu,
  u_startid d_session,
  u_stepid d_step,
  u_time d_time,
  u_new_activity d_event
from
  dw.user_action
 where
  dt='${datebuf}' and u_mod='emptylog' and
  u_ac in ('user_role','video_play_speed') and u_startid <>1 and
  u_diu rlike '^[\\w-]{5,75}?$';

dfs -touchz /olap/dw/uct/dt=${datebuf}/_SUCCESS;
