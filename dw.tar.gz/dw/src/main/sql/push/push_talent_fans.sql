use da;

-- 三级及以上达人的粉丝设备列表

drop table if exists push_talent_fans ;
create table push_talent_fans as
select
	reuid,
	id,
	client,
	version,
	xinge,
	signdate
from
(
	select
		reuid, uid
	from dw.follow_user
	group by
		reuid, uid
) a
join
(
	select
		xinge,
		client,
		version,
		id,
		signdate
	from dw.user
	where xinge<>''
) b
on (a.uid=b.id)
join
(
	select
		uid
	from dw.room
	group by
		uid
) c
on (a.reuid=c.uid)
;

-- import --connect jdbc:mysql://10.10.7.237:3306/tdlive?tinyInt1isBit=false --username root --password tangdouapp#123 --table room --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/room/ -m 1


-- --update-key
-- keyword
-- --update-mode
-- allowinsert

-- sqoop export --connect jdbc:mysql://10.10.243.51:3306/2016hd --username root --password tangdouapp#123 --table push_list --columns t_uid,uid,client,version,xinge,signdate --export-dir /user/hive/warehouse/da.db/push_talent_fans --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 1
