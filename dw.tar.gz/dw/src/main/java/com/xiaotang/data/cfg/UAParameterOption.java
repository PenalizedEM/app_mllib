package com.xiaotang.data.cfg;

/**
 * ES parameter Option
 * Created by vent on 6/3/16.
 */
public interface UAParameterOption extends ESParameterOption {

    String U_TIME_STAMP = "u_timestamp";
    String U_BACK_TIME = "u_backtime";
    String U_RSP_TIME = "u_responsetime";
    String U_HOST = "u_host";
    String U_XFF = "u_xff";
    String U_STATUS = "u_status";
    String U_SIZE = "u_size";
}
