package com.xiaotang.data.job;

import com.xiaotang.data.mapper.ES2HDFSMapper;
import com.xiaotang.data.reducer.ES2HDFSReducer;
import com.xiaotang.data.util.HdfsUtil;
import com.xiaotang.data.util.TimeUtil;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.fs.Path;
import org.elasticsearch.hadoop.mr.EsInputFormat;

import java.net.URI;

/**
 * Read Log file from es cluster.
 * The Driver Code.
 * Created by vent on 5/19/16.
 */
public class ES2HDFSJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {

        //ToolRunner.
        int exitCode = ToolRunner.run(new ES2HDFSJob(), args);

        System.exit(exitCode);

    }

     public int run(String[] arg0) throws Exception {



         Configuration conf = new Configuration();
         String esNode = "10.19.114.162:9200";
         String cliInDate = TimeUtil.pasrseCLITime(arg0,conf);
        // String esIndex = TimeUtil.transESInPath(arg0,conf)+"/rs";
         String esIndex = "logstash-"+cliInDate.replace("-",".")+"/rs";
         conf.set("es.nodes", esNode);
         conf.set("es.resource", esIndex);
         conf.set("es.output.json", "true");
        /* DistributedCache.createSymlink(conf);
         DistributedCache.addFileToClassPath(new Path("/user/hadoop/3pjar/elasticsearch-hadoop-mr-2.2.0-rc1.jar"),conf);*/
         Job job = Job.getInstance(conf,"ES Data Load Job : " + esIndex);

         job.setJarByClass(ES2HDFSJob.class);
         job.setMapperClass(ES2HDFSMapper.class);
         //job.setReducerClass(ES2HDFSReducer.class);

         HdfsUtil.setThirdPartyJar(job);
         //compress as gzip
         FileOutputFormat.setCompressOutput(job, true);
         FileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);

         job.setInputFormatClass(EsInputFormat.class);
         job.setMapOutputKeyClass(Text.class);
         job.setMapOutputValueClass(NullWritable.class);
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(NullWritable.class);
         //job.setOutputValueClass(MapWritable.class);
         //job.setMaxMapAttempts(12);
         job.setNumReduceTasks(100);

        // String outPathStr = "/user/hadoop/test/logstatsh/"+cliInDate;
         String outPathStr = "/raw/es/"+cliInDate;
         Path outputPath = new Path(outPathStr);
         HdfsUtil.delExistDir(outPathStr,conf);
         FileOutputFormat.setOutputPath(job, outputPath);
         //job.get
         //job.addFileToClassPath();
        return job.waitForCompletion(true) ? 0 : 1;



        }
    }
