package com.xiaotang.data.job;

import com.xiaotang.data.mapper.Raw2UAMapper;
import com.xiaotang.data.mapper.UA4UIStatMapper;
import com.xiaotang.data.mapper.UI4UIStatMapper;
import com.xiaotang.data.reducer.UIStatReducer;
import com.xiaotang.data.util.HdfsUtil;
import com.xiaotang.data.util.TimeUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.MultipleInputs;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * generate user device info from ua.Using multiple input
 * The Driver Code.
 * Created by vent on 6/13/16.
 */
public class UIStatJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {

        int exitCode = ToolRunner.run(new UIStatJob(), args);

        System.exit(exitCode);

    }

     public int run(String[] arg0) throws Exception {



         Configuration conf = new Configuration();
         String cliInDate = TimeUtil.pasrseCLITime(arg0,conf);
         conf.set("inDate",cliInDate);
         Job job = Job.getInstance(conf,"User Info Job : " + cliInDate );

         job.setJarByClass(UIStatJob.class);

         FileOutputFormat.setCompressOutput(job, true);
         FileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);

         //job.setMapperClass(Raw2UAMapper.class);
         //YesterDay UA
         String uaPathPrefix = "/olap/dw/ua/";
         String uaPathStr = TimeUtil.setNormalInPath(arg0,conf,uaPathPrefix,0);
         System.out.println("UA inPut path is: "+ uaPathStr);
         MultipleInputs.addInputPath(job,new Path(uaPathStr), TextInputFormat.class,UA4UIStatMapper.class);
         // The Day Before YesterDay UI
         String uiPathPrefix = "/olap/dw/ui/";
         String uiPathStr = TimeUtil.setNormalInPath(arg0, conf,uiPathPrefix,1);
         System.out.println("UI inPut path is: "+ uiPathStr);
         MultipleInputs.addInputPath(job,new Path(uiPathStr), TextInputFormat.class,UI4UIStatMapper.class);

         job.setOutputFormatClass(TextOutputFormat.class);

         job.setMapOutputKeyClass(Text.class);
         job.setMapOutputValueClass(Text.class);
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(NullWritable.class);
         job.setReducerClass(UIStatReducer.class);
         job.setNumReduceTasks(80);



         String outPathStr = "/olap/dw/ui/"+cliInDate;
         Path outputPath = new Path(outPathStr);
         HdfsUtil.delExistDir(outPathStr, conf);
         System.out.println("outPut path is: "+ outPathStr);
         FileOutputFormat.setOutputPath(job, outputPath);

         //job.addFileToClassPath();
        return job.waitForCompletion(true) ? 0 : 1;



        }
    }
