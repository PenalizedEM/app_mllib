package com.xiaotang.data.mapper;

import com.xiaotang.data.job.Temp_ES2HDFSJob;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.example.data.GroupFactory;
import org.apache.parquet.example.data.simple.SimpleGroupFactory;


/**
 * Read data from ES Mapper.Save as parquet and compress as gzip.
 * Created by vent on 10/10/16.
 */


public  class Temp_ES2HDFSMapper extends Mapper<Object, Object, Void, Group> {



    private GroupFactory groupFactory = new SimpleGroupFactory(Temp_ES2HDFSJob.SCHEMA);

    @Override
    protected void map(Object key, Object value, Context context)
            throws IOException, InterruptedException
    {
        Text doc = (Text) value;
       // System.out.println("This shit "+doc.toString());
        context.getCounter("UI flag ",  "= ").increment(1);
        Group group = groupFactory.newGroup()
                .append("line", doc.toString());
       // System.out.println("Test: "+group.toString());
        context.write(null, group);
    }
}


