package com.xiaotang.data.reducer;

import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * Read data from ES Reducer
 * Created by vent on 5/25/16.
 */
public class ES2HDFSReducer extends Reducer<NullWritable, Text, NullWritable, Text> {

    public void reduce(NullWritable key, Text values, Context context) throws IOException, InterruptedException
    {
        context.write(NullWritable.get(), values);
    }
}
