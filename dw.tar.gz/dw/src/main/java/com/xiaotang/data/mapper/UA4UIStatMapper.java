package com.xiaotang.data.mapper;


import com.google.common.base.Joiner;
import com.xiaotang.data.cfg.FieldOrderSchema;
import com.xiaotang.data.cfg.UAParameterOption;
import com.xiaotang.data.cfg.UIParameterOption;
import com.xiaotang.data.util.CleanUtil;
import com.xiaotang.data.util.ETLUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Generating UI from UA. Using Reducer Side Join.
 * Created by vent on 6/13/16.
 */
public class UA4UIStatMapper extends Mapper<Object, Object, Text, Text>
{
    String inDate ;
    //private HashMap<String, String> loadDicInfo2HM = new HashMap<String, String>();
   // private ArrayList<String> outAL = new ArrayList<String>() ;
    @Override
    protected void setup(Context context) throws IOException
    {
        Configuration conf = context.getConfiguration();
         inDate = conf.get("inDate");
    }
    @Override
    //TODO Clean up other fields
    protected void map(Object key, Object value, Context context) throws IOException, InterruptedException {
        //No POJO,Spilt String
        Text doc = (Text) value;
        Text diuKey = new Text();
        Text uiVal  = new Text();
        try {

            String[] uaStr = doc.toString().split(ETLUtil.hiveSpilt,ETLUtil.uaFieldLen);
            //System.out.println("uaStr size : "+uaStr.length);
            //System.out.println("ua string : "+uaStr[0]);
            //System.out.println("FieldOrderSchema  Length : "+FieldOrderSchema.USER_ACTION.length);
            //System.out.println("uaStr  Length : "+uaStr.length);
            HashMap<String,String> uaMap = ETLUtil.joinArrayAsMap(FieldOrderSchema.USER_ACTION, uaStr);
            //System.out.println("ua map size : "+uaMap.size());
           // System.out.println("diu : "+uaMap.get("u_diu"));
            //
            //String diu = CleanUtil.cleanDIU(uaMap.get(UIParameterOption.ES_U_DIU));
            //先不清洗
            if(uaMap.size()>0&&uaMap.containsKey(UIParameterOption.ES_U_DIU))
            {
                String modAC = uaMap.get(UAParameterOption.ES_U_MOD)+"-"+uaMap.get(UAParameterOption.ES_U_AC);
                if(!modAC.equals("main-start")&&!modAC.equals("top-count_plush")&&!modAC.equals("emptylog-push_arrival"))
                {
                    String diu = CleanUtil.cleanDIU(uaMap.get(UIParameterOption.ES_U_DIU));
                    diuKey.set(diu);
                    // System.out.println("diu : "+diu);
                    //  @||user_action data
                    uiVal.set(ETLUtil.uaFlag+ETLUtil.flagSplice+ETLUtil.extUIMapValue(uaMap, ETLUtil.hiveSpilt));
                }

            }
            context.write(diuKey,uiVal);
            context.getCounter("ua write",  "= ").increment(1);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}

