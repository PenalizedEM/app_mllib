package com.xiaotang.data.cfg;

/**
 * universal parameter of all table
 * Created by vent on 6/3/16.
 */
public interface ParameterOption {

    String TIME_STAMP = "@timestamp";

}
