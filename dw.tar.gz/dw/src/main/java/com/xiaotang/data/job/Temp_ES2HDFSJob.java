package com.xiaotang.data.job;

import com.xiaotang.data.mapper.ES2HDFSMapper;
import com.xiaotang.data.mapper.Temp_ES2HDFSMapper;
import com.xiaotang.data.util.HdfsUtil;
import com.xiaotang.data.util.TimeUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.parquet.example.data.Group;
import org.apache.parquet.example.data.GroupFactory;
import org.apache.parquet.example.data.simple.SimpleGroupFactory;
import org.apache.parquet.hadoop.example.ExampleOutputFormat;
import org.apache.parquet.schema.MessageType;
import org.apache.parquet.schema.MessageTypeParser;
import org.elasticsearch.hadoop.mr.EsInputFormat;

import java.io.IOException;

/**
 * Read Log file from es cluster.
 * The Driver Code.
 * Created by vent on 5/19/16.
 */
public class Temp_ES2HDFSJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {

        //ToolRunner.
        int exitCode = ToolRunner.run(new Temp_ES2HDFSJob(), args);

        System.exit(exitCode);

    }
    public static final MessageType SCHEMA = MessageTypeParser.parseMessageType(
            "message Line {\n" +
                    "  required binary line (UTF8);\n" +
                    "}");
/*
    public static class TempES2ParquetMapper extends Mapper<LongWritable, Text, Text, NullWritable> {


        @Override
        protected void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {

            context.write(value,NullWritable.get());
        }
    }
    public static class TempES2ParquetReducer extends Reducer<Text, NullWritable, Void, Group> {

        private GroupFactory groupFactory = new SimpleGroupFactory(Temp_ES2HDFSJob.SCHEMA);

        public void reduce(Text key, NullWritable value, Context context) throws IOException, InterruptedException
        {
            // System.out.println("This shit "+doc.toString());
            context.getCounter("Parquet Counter",  "= ").increment(1);
            Group group = groupFactory.newGroup()
                    .append("line", key.toString());
            // System.out.println("Test: "+group.toString());
            context.write(null, group);
        }
    }
*/
    public int run(String[] arg0) throws Exception {



         Configuration conf = new Configuration();
         String esNode = "10.19.177.156:9200";
        // String cliInDate = TimeUtil.pasrseCLITime(arg0,conf);
        // String esIndex = TimeUtil.transESInPath(arg0,conf)+"/rs";
         String esIndex = "dbvideo/videotype";
         conf.set("es.nodes", esNode);
         conf.set("es.resource", esIndex);
         conf.set("es.output.json", "true");
        /* DistributedCache.createSymlink(conf);
         DistributedCache.addFileToClassPath(new Path("/user/hadoop/3pjar/elasticsearch-hadoop-mr-2.2.0-rc1.jar"),conf);*/
         Job job = Job.getInstance(conf,"ES Data Load Job : " + esIndex);

         job.setJarByClass(Temp_ES2HDFSJob.class);
         job.setMapperClass(ES2HDFSMapper.class);
         //job.setReducerClass(TempES2ParquetReducer.class);

         HdfsUtil.setThirdPartyJar(job);

         FileOutputFormat.setCompressOutput(job, true);
         FileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);

         job.setInputFormatClass(EsInputFormat.class);
         job.setMapOutputKeyClass(Text.class);
         job.setMapOutputValueClass(NullWritable.class);
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(NullWritable.class);
/*         job.setOutputFormatClass(ExampleOutputFormat.class);
         ExampleOutputFormat.setSchema(job, SCHEMA);
         job.setMapOutputKeyClass(Void.class);
         job.setMapOutputValueClass(Group.class);
         job.setOutputKeyClass(Void.class);
         job.setOutputValueClass(Group.class);*/
         job.setNumReduceTasks(80);

         String outPathStr = "/temp/test/dbvideo/";
         Path outputPath = new Path(outPathStr);
         HdfsUtil.delExistDir(outPathStr,conf);
         FileOutputFormat.setOutputPath(job, outputPath);
         //job.get
         //job.addFileToClassPath();
        return job.waitForCompletion(true) ? 0 : 1;



        }
    }
