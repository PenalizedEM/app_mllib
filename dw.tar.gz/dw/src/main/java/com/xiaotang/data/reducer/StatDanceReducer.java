package com.xiaotang.data.reducer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

/**
 * Mapper side join to calculate differnt  type dance pv/uv.
 * Created by vent on 6/1/16.
 */
public class StatDanceReducer extends Reducer<Text, Text, Text, Text> {

    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
    {
        Text result = new Text();
        Set<Text> s =  new HashSet<Text>();
        int count = 0;
        for (Text val : values) {
            count ++;
            s.add(val);
        }
        String outStr = Integer.toString(count)+"||"+s.size();
        result.set(outStr);
        context.write(key, result);
    }
}
