package com.xiaotang.data.cfg;

/**
 * UI parameter Option
 * Created by vent on 6/13/16.
 */
public interface UIParameterOption extends ESParameterOption {

    String U_TIME_STAMP = "u_timestamp";
    String U_TIME_STAMP_F = "u_timestamp_f";
    String U_Tag = "u_tag";
    String U_ACTIVE = "u_active";
    String U_FRESH = "u_fresh";
    String U_DIV_F = "u_div_f";
    String U_DIC_F = "u_dic_f";
    String U_NETOP_F = "u_netop_f";
    String U_PROVINCE_F = "u_province_f";
    String U_CITY_F = "u_city_f";
    String U_TAG = "u_tag";
}
