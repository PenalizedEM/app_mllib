package com.xiaotang.data.mapper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.joda.time.LocalDateTime;

import java.io.IOException;

/** Mapping UTC timezone data to beijing timezone.
 * Created by vent on 5/30/16.
 */
public class UTC2LocalDateMapper extends Mapper<Object, Object, Text, NullWritable>  {
    String inDate ;
    @Override
    protected void setup(Context context)
    {
        Configuration conf = context.getConfiguration();
         inDate = conf.get("inDate");
    }
    @Override
    protected void map(Object key, Object value, Context context) throws IOException, InterruptedException {

        if(inDate != null && !inDate.isEmpty())
        {

            Text doc = (Text) value;
            JsonParser parser = new JsonParser();
            JsonObject jsonObject = parser.parse(doc.toString()).getAsJsonObject();
            DateTime dataDate = new DateTime(jsonObject.get("@timestamp").getAsJsonPrimitive().getAsString());
            DateTime cliDate = new  DateTime(inDate);

            if(dataDate.withTimeAtStartOfDay().isEqual(cliDate.withTimeAtStartOfDay()))
            {
                context.write(doc,NullWritable.get());
            }

        }

    }
}
