package com.xiaotang.data.reducer;

import com.xiaotang.data.cfg.FieldOrderSchema;
import com.xiaotang.data.cfg.UIParameterOption;
import com.xiaotang.data.util.CleanUtil;
import com.xiaotang.data.util.ETLUtil;
import com.xiaotang.data.util.TimeUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeMap;
import java.util.logging.FileHandler;

/**
 * Generating UI . Using Reducer Side Join.
 * Created by vent on 6/14/16.
 */
public class UIStatReducer extends Reducer<Text, Text, Text, NullWritable> {

    String inDate ;

    protected void setup(Context context) throws IOException
    {
        Configuration conf = context.getConfiguration();
        inDate = conf.get("inDate");
    }
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException
    {

        //System.out.println("inDate: "+inDate);
        Text  outKey = new Text();
        //UI Tree Map
        TreeMap<Long,HashMap<String,String>>  uiTm= new TreeMap<Long,HashMap<String,String>>();
        //UA Tree Map
        TreeMap<Long,HashMap<String,String>>  uaTm = new  TreeMap<Long,HashMap<String,String>> ();
        //填充预设集合
        for(Text val:values)
        {

            //拆分，判断来源
            String[] preObj =  val.toString().split(ETLUtil.flagSpilt,2);
            if(preObj.length==2)
            {
                String flag = preObj[0];

                //实际值，构建UI/UA
                String[] inArr = preObj[1].split(ETLUtil.hiveSpilt,ETLUtil.uiFieldLen);
                HashMap<String,String> inMap = ETLUtil.joinArrayAsMap(FieldOrderSchema.User_Info,inArr);
                inMap.put(UIParameterOption.ES_U_DIU, CleanUtil.cleanDIU(inMap.get(UIParameterOption.ES_U_DIU)));
                inMap.put(UIParameterOption.ES_U_DIU2, CleanUtil.cleanDIU(inMap.get(UIParameterOption.ES_U_DIU2)));
                inMap.put(UIParameterOption.ES_U_DIU3, CleanUtil.cleanDIU(inMap.get(UIParameterOption.ES_U_DIU3)));
                //清洗UID
                inMap.put(UIParameterOption.ES_U_UID,CleanUtil.cleanFiled(CleanUtil.numberPat,inMap.get(UIParameterOption.ES_U_UID)));
                //清洗高,宽
                inMap.put(UIParameterOption.ES_U_HEIGHT,CleanUtil.cleanFiled(CleanUtil.numberPat,inMap.get(UIParameterOption.ES_U_HEIGHT)));
                inMap.put(UIParameterOption.ES_U_WIDTH,CleanUtil.cleanFiled(CleanUtil.numberPat,inMap.get(UIParameterOption.ES_U_WIDTH)));

                //访问时间
                DateTimeFormatter formatter = DateTimeFormat.forPattern(ETLUtil.hiveTimeStampFormat);
                long elapseTime = formatter.parseDateTime(inMap.get(UIParameterOption.U_TIME_STAMP)).getMillis();
                //是否存在UI对象
                if(flag.equals(ETLUtil.uiFlag))
                {
                    uiTm.put(elapseTime, inMap);
                    //context.getCounter("UI flag ",  "= ").increment(1);
                }
                //是否存在UA对象
                else if(flag.equals(ETLUtil.uaFlag))
                {
                    uaTm.put(elapseTime, inMap);

                    // context.getCounter("UA flag",  "= ").increment(1);
                }
                else
                {
                    context.getCounter("withoutflg",  "= ").increment(1);
                }
            }
            else
            {
                //标识
                context.getCounter("spilt wrong",  "= ").increment(1);
                //System.out.println("val.toString() "+val.toString());
            }


        }
            //判断新增，活跃，沉默
            if(uaTm.size()==0)
            {
                //沉默用户
                if(uiTm.size() ==1)
                {
                    //输出
                    //ui旧记录
                    HashMap<String,String> onlyUIMap = uiTm.firstEntry().getValue();
                    //仅更新新鲜度
                    //System.out.print("BF Fresh : "+onlyUIMap.get(UIParameterOption.U_FRESH));
                    ETLUtil.updateFresh(onlyUIMap,inDate);
                    //System.out.print("AF Fresh : "+onlyUIMap.get(UIParameterOption.U_FRESH));
                    outKey.set(ETLUtil.extUIMapValue(onlyUIMap, ETLUtil.hiveSpilt));
                    context.getCounter("sil",  "= ").increment(1);
                }
            }
            else if (uaTm.size()>0)
            {
                //新增用户
                if(uiTm.size() ==0)
                {
                    //取出首次和末次UA对象
                    HashMap<String,String> fUaMap =uaTm.firstEntry().getValue();
                    HashMap<String,String> lUaMap = uaTm.lastEntry().getValue();
                    //将第一条日志的各种值填充到最后一条日志的各种 **_**_ f 字段中
                    lUaMap.put(UIParameterOption.U_DIV_F,fUaMap.get(UIParameterOption.ES_U_DIV));
                    lUaMap.put(UIParameterOption.U_DIC_F,fUaMap.get(UIParameterOption.ES_U_DIC));
                    lUaMap.put(UIParameterOption.U_TIME_STAMP_F,fUaMap.get(UIParameterOption.U_TIME_STAMP));
                    lUaMap.put(UIParameterOption.U_NETOP_F,fUaMap.get(UIParameterOption.ES_U_NETOP));
                    lUaMap.put(UIParameterOption.U_PROVINCE_F,fUaMap.get(UIParameterOption.ES_U_PROVINCE));
                    lUaMap.put(UIParameterOption.U_CITY_F,fUaMap.get(UIParameterOption.ES_U_CITY));
                    //新鲜度
                    //System.out.print("BF Fresh : "+lUaMap.get(UIParameterOption.U_FRESH));
                    ETLUtil.updateFresh(lUaMap, inDate);
                    //System.out.print("AF Fresh : "+lUaMap.get(UIParameterOption.U_FRESH));
                    //活跃度,新增用户直接设为1
                    //System.out.print("BF ACT : "+lUaMap.get(UIParameterOption.U_ACTIVE));
                    ETLUtil.updateActive(lUaMap);
                   // System.out.print("AF ACT : "+lUaMap.get(UIParameterOption.U_ACTIVE));
                    //lUaMap.put(UIParameterOption.U_ACTIVE,"1");
                    //输出
                    outKey.set(ETLUtil.extUIMapValue((lUaMap),ETLUtil.hiveSpilt));
                    context.getCounter("new",  "= ").increment(1);
                }
                //活跃用户
                else if(uiTm.size()==1)
                {
                    //context.getCounter("act  UA flag",  "= ").increment(1);
                    //ui旧记录
                    HashMap<String,String> onlyUIMap = uiTm.firstEntry().getValue();
                    //ua最新记录
                    HashMap<String,String> lUaMap = uaTm.lastEntry().getValue();

                    ETLUtil.updateUI(lUaMap,onlyUIMap,FieldOrderSchema.Update_User_Info);
                    //新鲜度
                    //System.out.print("BF Fresh : "+onlyUIMap.get(UIParameterOption.U_FRESH));
                    ETLUtil.updateFresh(onlyUIMap, inDate);
                   // System.out.print("AF Fresh : "+onlyUIMap.get(UIParameterOption.U_FRESH));
                    //活跃度 +1
                   // System.out.print("BF ACT : "+onlyUIMap.get(UIParameterOption.U_ACTIVE));
                    ETLUtil.updateActive(onlyUIMap);
                   // System.out.print("AF ACT : "+onlyUIMap.get(UIParameterOption.U_ACTIVE));

                    //输出
                    outKey.set(ETLUtil.extUIMapValue((onlyUIMap), ETLUtil.hiveSpilt));
                    context.getCounter("act",  "= ").increment(1);
                }
            }

        try {
            context.write(outKey, NullWritable.get());
            context.getCounter("tryall",  "= ").increment(1);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
}
