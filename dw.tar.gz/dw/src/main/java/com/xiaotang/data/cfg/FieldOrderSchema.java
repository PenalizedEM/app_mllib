package com.xiaotang.data.cfg;

/**
 * Created by vent on 6/8/16.
 */
public interface FieldOrderSchema {

        String[] USER_ACTION = {
            UAParameterOption.U_TIME_STAMP,UAParameterOption.U_BACK_TIME,UAParameterOption.U_RSP_TIME,UAParameterOption.U_HOST,
            UAParameterOption.U_XFF,UAParameterOption.U_STATUS,UAParameterOption.U_SIZE,UAParameterOption.ES_U_DIV,
            UAParameterOption.ES_U_DIC,UAParameterOption.ES_U_DIU,UAParameterOption.ES_U_DIU2,UAParameterOption.ES_U_DIU3,
            UAParameterOption.ES_U_UID,UAParameterOption.ES_START_ID,UAParameterOption.ES_STEP_ID,UAParameterOption.ES_U_TIME,
            UAParameterOption.ES_U_MOD,UAParameterOption.ES_U_AC,UAParameterOption.ES_U_CLIENT,UAParameterOption.ES_U_VER,
            UAParameterOption.ES_U_UUID,UAParameterOption.ES_U_HASH,UAParameterOption.ES_U_XINGE,
            UAParameterOption.ES_U_TOKEN,UAParameterOption.ES_U_AGENT,UAParameterOption.ES_U_METHOD,UAParameterOption.ES_U_NEW_ACTIVITY,
            UAParameterOption.ES_U_OLD_ACTIVITY,UAParameterOption.ES_U_KEY,UAParameterOption.ES_U_CLIENT_MODULE,UAParameterOption.ES_U_SOURCE,
            UAParameterOption.ES_U_PAGE,UAParameterOption.ES_U_POSITION,UAParameterOption.ES_U_VID,ESParameterOption.ES_U_TYPE,
            UAParameterOption.ES_U_PERCENT,UAParameterOption.ES_U_RATE,UAParameterOption.ES_U_USER_ROLE,UAParameterOption.ES_U_ISNEW_USER,
            UAParameterOption.ES_U_ISDOWNLOAD,UAParameterOption.ES_U_ISONLINE,UAParameterOption.ES_U_BUFFERTIME,UAParameterOption.ES_U_ACTION,
            UAParameterOption.ES_U_ISHIGH,UAParameterOption.ES_U_CDN_SOURCE,UAParameterOption.ES_U_DOWNLOAD_START,UAParameterOption.ES_U_DOWNLOAD_STOP,
            UAParameterOption.ES_U_FAIL_CDN_SOURCE,UAParameterOption.ES_U_NEW_CDN_SOURCE,UAParameterOption.ES_U_WIDTH,UAParameterOption.ES_U_HEIGHT,
            UAParameterOption.ES_U_LON,UAParameterOption.ES_U_LAT,UAParameterOption.ES_U_PROVINCE,UAParameterOption.ES_U_CITY,
            UAParameterOption.ES_U_NETOP,UAParameterOption.ES_U_NETTYPE, UAParameterOption.ES_U_SDK_VERSION,UAParameterOption.ES_U_MODEL,
            UAParameterOption.ES_U_DEVICE,UAParameterOption.ES_U_MANUFACTURE, UAParameterOption.ES_U_REVERSE0,UAParameterOption.ES_U_REVERSE1,
            UAParameterOption.ES_U_REVERSE2,UAParameterOption.ES_U_REVERSE3, UAParameterOption.ES_U_REVERSE4,UAParameterOption.ES_U_REVERSE5,
            UAParameterOption.ES_U_REVERSE6,UAParameterOption.ES_U_REVERSE7, UAParameterOption.ES_U_REVERSE8,UAParameterOption.ES_U_REVERSE9,UAParameterOption.ES_U_BIGGER_JSON
                                };
        String[] User_Info = {
                UIParameterOption.ES_U_DIU,UIParameterOption.ES_U_DIU2,UIParameterOption.ES_U_DIU3,UIParameterOption.ES_U_UID,
                UIParameterOption.ES_U_UUID,UIParameterOption.ES_U_HASH,UIParameterOption.ES_U_XINGE,UIParameterOption.ES_U_TOKEN,
                UIParameterOption.U_DIV_F,UIParameterOption.ES_U_DIV,UIParameterOption.U_DIC_F,UIParameterOption.ES_U_DIC,
                UIParameterOption.ES_U_CLIENT,UIParameterOption.U_TIME_STAMP_F,UIParameterOption.U_TIME_STAMP,
                UIParameterOption.U_NETOP_F,UIParameterOption.ES_U_NETOP,UIParameterOption.U_PROVINCE_F,UIParameterOption.ES_U_PROVINCE,
                UIParameterOption.U_CITY_F,UIParameterOption.ES_U_CITY,UIParameterOption.ES_U_MANUFACTURE,UIParameterOption.ES_U_MODEL,
                UIParameterOption.ES_U_DEVICE,UIParameterOption.ES_U_WIDTH,UIParameterOption.ES_U_HEIGHT,UIParameterOption.U_FRESH,
                UIParameterOption.U_ACTIVE,UIParameterOption.U_TAG,UIParameterOption.ES_U_BIGGER_JSON
                              };

        String[] Update_User_Info = {
                UIParameterOption.ES_U_DIU2,UIParameterOption.ES_U_UID,UIParameterOption.ES_U_UUID,UIParameterOption.ES_U_HASH,UIParameterOption.ES_U_XINGE,
                UIParameterOption.ES_U_TOKEN,UIParameterOption.U_TIME_STAMP,UIParameterOption.ES_U_DIC,UIParameterOption.ES_U_DIV,
                UIParameterOption.ES_U_NETOP,UIParameterOption.ES_U_NETTYPE,UIParameterOption.ES_U_PROVINCE,UIParameterOption.ES_U_CITY,
                UIParameterOption.ES_U_CLIENT,UIParameterOption.ES_U_MANUFACTURE,UIParameterOption.ES_U_MODEL,UIParameterOption.ES_U_DEVICE,
                UIParameterOption.ES_U_WIDTH,UIParameterOption.ES_U_HEIGHT,UIParameterOption.ES_U_DIU3

        };

}
