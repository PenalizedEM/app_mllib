package com.xiaotang.data.job;

import com.xiaotang.data.mapper.Raw2UAMapper;
import com.xiaotang.data.mapper.StatDanceTypeMapper;
import com.xiaotang.data.reducer.StatDanceReducer;
import com.xiaotang.data.util.HdfsUtil;
import com.xiaotang.data.util.TimeUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.compress.GzipCodec;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * Stat differ
 * The Driver Code.
 * Created by vent on 5/19/16.
 */
public class Raw2UAJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {

        int exitCode = ToolRunner.run(new Raw2UAJob(), args);

        System.exit(exitCode);

    }

     public int run(String[] arg0) throws Exception {



         Configuration conf = new Configuration();
        // String esNode = "10.10.247.210:9200";
         String cliInDate = TimeUtil.pasrseCLITime(arg0,conf);
        // String esIndex = TimeUtil.transESInPath(arg0,conf)+"/rs";
        // String esIndex = "logstash-"+cliInDate.replace("-",".")+"/rs";
        // conf.set("es.nodes", esNode);
       //  conf.set("es.resource", esIndex);
       //  conf.set("es.output.json", "true");
         conf.set("inDate",cliInDate);
        /* DistributedCache.createSymlink(conf);
         DistributedCache.addFileToClassPath(new Path("/user/hadoop/3pjar/elasticsearch-hadoop-mr-2.2.0-rc1.jar"),conf);*/
         Job job = Job.getInstance(conf,"User Action Job : " + cliInDate);

         job.setJarByClass(Raw2UAJob.class);
         job.setMapperClass(Raw2UAMapper.class);

         FileOutputFormat.setCompressOutput(job, true);
         FileOutputFormat.setOutputCompressorClass(job, GzipCodec.class);

         job.setInputFormatClass(TextInputFormat.class);
         job.setOutputFormatClass(TextOutputFormat.class);

         job.setMapOutputKeyClass(Text.class);
         job.setMapOutputValueClass(NullWritable.class);
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(NullWritable.class);
         //job.setOutputValueClass(MapWritable.class);
         //job.setMaxMapAttempts(12);
         job.setNumReduceTasks(120);
         //写入目录
         String inputPrefixPath = "/raw/es/";
         String inPathStr = TimeUtil.transHDFSPath(arg0,conf,inputPrefixPath);
         System.out.println("inPut path is: "+ inPathStr);
         FileInputFormat.addInputPaths(job,inPathStr);

         String outPathStr = "/olap/dw/ua/"+cliInDate;
         Path outputPath = new Path(outPathStr);
         HdfsUtil.delExistDir(outPathStr, conf);
         System.out.println("outPut path is: "+ outPathStr);
         FileOutputFormat.setOutputPath(job, outputPath);

         //job.addFileToClassPath();
        return job.waitForCompletion(true) ? 0 : 1;



        }
    }
