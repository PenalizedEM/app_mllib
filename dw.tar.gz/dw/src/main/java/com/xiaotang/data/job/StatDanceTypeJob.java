package com.xiaotang.data.job;

import com.xiaotang.data.mapper.StatDanceTypeMapper;
import com.xiaotang.data.mapper.UTC2LocalDateMapper;
import com.xiaotang.data.reducer.StatDanceReducer;
import com.xiaotang.data.util.HdfsUtil;
import com.xiaotang.data.util.TimeUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

/**
 * Stat differ
 * The Driver Code.
 * Created by vent on 5/19/16.
 */
public class StatDanceTypeJob extends Configured implements Tool {

    public static void main(String[] args) throws Exception {

        int exitCode = ToolRunner.run(new StatDanceTypeJob(), args);

        System.exit(exitCode);

    }

     public int run(String[] arg0) throws Exception {



         Configuration conf = new Configuration();
        // String esNode = "10.10.247.210:9200";
         String cliInDate = TimeUtil.pasrseCLITime(arg0,conf);
        // String esIndex = TimeUtil.transESInPath(arg0,conf)+"/rs";
        // String esIndex = "logstash-"+cliInDate.replace("-",".")+"/rs";
        // conf.set("es.nodes", esNode);
       //  conf.set("es.resource", esIndex);
       //  conf.set("es.output.json", "true");
         conf.set("inDate",cliInDate);
        /* DistributedCache.createSymlink(conf);
         DistributedCache.addFileToClassPath(new Path("/user/hadoop/3pjar/elasticsearch-hadoop-mr-2.2.0-rc1.jar"),conf);*/
         Job job = Job.getInstance(conf,"Reading Data from /user/hadoop/logstatsh/" + cliInDate);

         job.setJarByClass(StatDanceTypeJob.class);
         job.setMapperClass(StatDanceTypeMapper.class);
         job.setReducerClass(StatDanceReducer.class);
         String[] jarPaths = {"/user/hadoop/db/video.csv"};
         //lll
         HdfsUtil.setThirdPartyJar(jarPaths,job);


         job.setInputFormatClass(TextInputFormat.class);
         job.setOutputFormatClass(TextOutputFormat.class);

         job.setMapOutputKeyClass(Text.class);
         job.setMapOutputValueClass(Text.class);
         job.setOutputKeyClass(Text.class);
         job.setOutputValueClass(Text.class);
         //job.setOutputValueClass(MapWritable.class);
         //job.setMaxMapAttempts(12);
         job.setNumReduceTasks(1);

         String inputPrefixPath = "/raw/es/";
         String inPathStr = TimeUtil.transHDFSPath(arg0,conf,inputPrefixPath);
         System.out.println("inPut path is: "+ inPathStr);
         FileInputFormat.addInputPaths(job,inPathStr);

         String outPathStr = "/user/hadoop/pm/"+cliInDate;
         Path outputPath = new Path(outPathStr);
         HdfsUtil.delExistDir(outPathStr, conf);
         System.out.println("outPut path is: "+ outPathStr);
         FileOutputFormat.setOutputPath(job, outputPath);

         //job.addFileToClassPath();
        return job.waitForCompletion(true) ? 0 : 1;



        }
    }
