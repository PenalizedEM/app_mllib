package com.xiaotang.data.mapper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/** Read data from ES Mapper.
 * Created by vent on 5/19/16.
 */
public class ES2HDFSMapper extends Mapper<Object, Object, Text, NullWritable>  {
    @Override
    protected void map(Object key, Object value, Context context) throws IOException, InterruptedException
    {
        //Text docId = (Text) key;

        Text doc = (Text) value;
        /*JsonParser parser = new JsonParser();
        JsonObject jsonObject = parser.parse(doc.toString()).getAsJsonObject();
        jsonObject.getAsJsonPrimitive("@timestamp");*/
        context.write(doc,NullWritable.get());
    }
}
