package com.xiaotang.data.util;

import com.xiaotang.data.cfg.FieldOrderSchema;

import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Clean up the field of UI.
 * Created by vent on 6/14/16.
 */
public class CleanUtil {

    //通用渠道正则表达式
/*    private static final String dicPatStr = "^[\\w-]";

    private static final String divPatStr =  "^[ANDHIOSWIPBL]{4}+[0-9]{6}$";*/
    //imei规则
    private static final String diuPatStr = "^[\\w-]{5,75}?$";
    private static final String numberPatStr = "^[\\d]{1,30}$";
    private static final String enPatStr = "^[\\w-_@#]{3,75}?$";
/*    public static Pattern dicPat = null;
    public static Pattern ndivPat = null;
    public static Pattern odivPat = null;
    public static Pattern dipPat = null;*/
    public static Pattern diuPat = null;
    public static Pattern numberPat = null;
    public static Pattern enPat = null;
    static {
        //dicPat = Pattern.compile(dicPatStr);

       // odivPat = Pattern.compile(divPatStr);
        diuPat = Pattern.compile(diuPatStr);
        numberPat =  Pattern.compile(numberPatStr);
        enPat =  Pattern.compile(enPatStr);
    }

    public static String cleanDIU(String diu) {

        String cleanDiu="";
        if (isClean(diuPat,diu))
        {
            cleanDiu = diu;
        }

        return cleanDiu;
    }

    public static String cleanFiled(Pattern inPat, String filed) {

        String cleanFiled="";
        if (isClean(inPat,filed))
        {
            cleanFiled = filed;
        }

        return cleanFiled;
    }

    public static boolean  isClean(Pattern inPat,String inStr)
    {
        boolean isC =  false;
        Matcher cm =  inPat.matcher(inStr);
        if(cm.find())
        {
            isC = true;
        }
        return isC;
    }

}
