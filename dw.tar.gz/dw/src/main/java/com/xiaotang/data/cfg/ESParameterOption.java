package com.xiaotang.data.cfg;

/**
 * ES parameter Option
 * Created by vent on 6/3/16.
 */
public interface ESParameterOption extends ParameterOption {

    String ES_BACK_TIME = "backtime";
    String ES_RSP_TIME = "responsetime";
    String ES_HOST = "host";
    //String ES_CLI_IP = "clientip";
    String ES_XFF = "xff";
    String ES_STATUS = "status";
    String ES_SIZE = "size";

    //caution!! 旧版安卓写成了setpid
    String ES_U_DIV = "u_div";
    String ES_U_OLD_DIV = "u_version";

    String ES_U_DIC = "u_dic";
    String ES_U_DIU = "u_diu";
    String ES_U_DIU2 = "u_diu2";
    String ES_U_DIU3 = "u_diu3";
    String ES_U_UID = "u_uid";
    String ES_START_ID = "u_startid";

    //caution!! 旧版安卓写成了setpid
    String ES_STEP_ID = "u_stepid";
    String ES_OLD_STEP_ID = "u_setpid";

    String ES_U_TIME = "u_time";
    String ES_U_MOD = "u_mod";
    String ES_U_AC = "u_ac";
    String ES_U_CLIENT = "u_client";
    String ES_U_VER = "u_ver";
    String ES_U_UUID = "u_uuid";
    String ES_U_HASH = "u_hash";
    String ES_U_XINGE= "u_xinge";
    String ES_U_TOKEN = "u_token";
    String ES_U_AGENT = "agent";
    String ES_U_METHOD = "method";

    String ES_U_NEW_ACTIVITY = "u_new_activity";
    String ES_U_OLD_ACTIVITY = "u_old_activity";
    String ES_U_KEY = "u_key";
    String ES_U_CLIENT_MODULE = "u_client_module";
    String ES_U_SOURCE = "u_source";
    String ES_U_PAGE = "u_page";
    String ES_U_POSITION = "u_position";
    String ES_U_VID = "u_vid";

    //caution!! 有可能和其他参数冲突，需要在转换时限定接口
    String ES_U_TYPE = "u_type";
    String ES_U_PERCENT = "u_percent";
    String ES_U_RATE = "u_rate";
    String ES_U_USER_ROLE = "u_user_role";
    String ES_U_ISNEW_USER = "u_isnew_user";
    String ES_U_ISDOWNLOAD = "u_isdownload";
    String ES_U_ISONLINE = "u_isonline";
    String ES_U_BUFFERTIME = "u_buffertime";
    String ES_U_ACTION = "u_action";
    String ES_U_ISHIGH = "u_ishigh";
    String ES_U_CDN_SOURCE = "u_cdn_source";
    String ES_U_DOWNLOAD_START = "u_download_start";
    String ES_U_DOWNLOAD_STOP = "u_download_stop";
    String ES_U_FAIL_CDN_SOURCE= "u_fail_cdn_source";
    String ES_U_NEW_CDN_SOURCE = "u_new_cdn_source";
    String ES_U_WIDTH = "u_width";
    String ES_U_HEIGHT = "u_height";
    String ES_U_LON = "u_lon";
    String ES_U_LAT = "u_lat";
    String ES_U_PROVINCE = "u_province";
    String ES_U_CITY = "u_city";
    String ES_U_NETOP = "u_netop";
    String ES_U_NETTYPE = "u_nettype";

    //caution!! ES字段名是SDKVersion
    String ES_U_SDK_VERSION = "u_SDKVersion";

    String ES_U_MODEL = "u_model";
    String ES_U_DEVICE = "u_device";
    String ES_U_MANUFACTURE = "u_manufacture";
    String ES_U_REVERSE0 = "reverse0";
    String ES_U_REVERSE1 = "reverse1";
    String ES_U_REVERSE2 = "reverse2";
    String ES_U_REVERSE3 = "reverse3";
    String ES_U_REVERSE4 = "reverse4";
    String ES_U_REVERSE5 = "reverse5";
    String ES_U_REVERSE6 = "reverse6";
    String ES_U_REVERSE7 = "reverse7";
    String ES_U_REVERSE8 = "reverse8";
    String ES_U_REVERSE9 = "reverse9";
    String ES_U_BIGGER_JSON = "bigger_json";
}
