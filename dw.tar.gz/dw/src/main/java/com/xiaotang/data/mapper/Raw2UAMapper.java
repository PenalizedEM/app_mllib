package com.xiaotang.data.mapper;

import com.google.common.base.Joiner;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xiaotang.data.util.DistributeCachUtil;
import com.xiaotang.data.util.ETLUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.joda.time.DateTime;

import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * ETL raw log data to ua
 * Created by vent on 6/3/16.
 */
public class Raw2UAMapper extends Mapper<Object, Object, Text, NullWritable>
{
    String inDate ;
    private HashMap<String, String> loadDicInfo2HM = new HashMap<String, String>();
    private ArrayList<String> outAL = new ArrayList<String>() ;
    @Override
    protected void setup(Context context) throws IOException
    {
        Configuration conf = context.getConfiguration();
         inDate = conf.get("inDate");
    }
    @Override
    protected void map(Object key, Object value, Context context)
    {

        if(inDate != null && !inDate.isEmpty())
        {

            Text doc = (Text) value;
            Text k = new Text();
            JsonParser parser = new JsonParser();
            JsonObject jsonObject = parser.parse(doc.toString()).getAsJsonObject();
            DateTime dataDate = new DateTime(jsonObject.get("@timestamp").getAsJsonPrimitive().getAsString());
            DateTime cliDate = new DateTime(inDate);
            if (dataDate.withTimeAtStartOfDay().equals(cliDate.withTimeAtStartOfDay()))
            {
                outAL = ETLUtil.ETFromJson(doc.toString());
                //System.out.println("list size "+outAL.size());
                if(outAL.size()==ETLUtil.uaFieldLen)
                {
                    k.set(Joiner.on(ETLUtil.hiveSpilt).join(outAL));
                    try {
                        context.write(k, NullWritable.get());
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }

        }
        outAL.clear();
    }

}

