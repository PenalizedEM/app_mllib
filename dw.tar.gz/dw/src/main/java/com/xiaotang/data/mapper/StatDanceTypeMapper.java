package com.xiaotang.data.mapper;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xiaotang.data.util.DistributeCachUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.joda.time.DateTime;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;

/**
 * Mapper side join to calculate differnt  type dance pv/uv.
 * Created by vent on 6/1/16.
 */
public class StatDanceTypeMapper extends Mapper<Object, Object, Text, Text>  {
    String inDate ;
    private HashMap<String, String> loadDicInfo2HM = new HashMap<String, String>();
    @Override
    protected void setup(Context context) throws IOException {
        Configuration conf = context.getConfiguration();
         inDate = conf.get("inDate");
        URI[] localPaths =context.getCacheFiles();
       // System.out.println(localPaths[0].toString());
        loadDicInfo2HM = DistributeCachUtil.load2Map(localPaths,context);
        System.out.println(loadDicInfo2HM.size());
    }
    @Override
    protected void map(Object key, Object value, Context context){

        if(inDate != null && !inDate.isEmpty()) {

            Text doc = (Text) value;
            Text k = new Text();
            Text v = new Text();
            JsonParser parser = new JsonParser();
            JsonObject jsonObject = parser.parse(doc.toString()).getAsJsonObject();
            DateTime dataDate = new DateTime(jsonObject.get("@timestamp").getAsJsonPrimitive().getAsString());
            DateTime cliDate = new DateTime(inDate);
            if (jsonObject.has("u_vid")&&jsonObject.has("u_diu")&&jsonObject.has("u_mod")&&jsonObject.has("u_ac"))
            {

                String vid = jsonObject.get("u_vid").getAsJsonPrimitive().getAsString();
                String diu = jsonObject.get("u_diu").getAsJsonPrimitive().getAsString();
                String mod = jsonObject.get("u_mod").getAsJsonPrimitive().getAsString();
                String ac = jsonObject.get("u_ac").getAsJsonPrimitive().getAsString();
               // System.out.println("u_vid: "+vid);

                if (dataDate.withTimeAtStartOfDay().isEqual(cliDate.withTimeAtStartOfDay()) && mod.equals("video") && ac.equals("techinfo_new")
                        &&loadDicInfo2HM.containsKey(vid)
                )
                {
                       // System.out.println("u_vid: "+vid);
                        k.set(loadDicInfo2HM.get(vid));
                        System.out.println(loadDicInfo2HM.get(vid));
                        //k.set(vid);
                        v.set(diu);
                        try {
                            context.write(k, v);
                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                }

                }

            }
        }
    }

