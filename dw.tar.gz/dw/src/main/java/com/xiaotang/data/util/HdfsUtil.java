package com.xiaotang.data.util;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;
import java.net.URI;

/**
 * io operation on hdfs
 * Created by vent on 5/26/16.
 */
public class HdfsUtil {

    public static boolean delExistDir(String pathStr,Configuration conf) throws IOException
    {

        FileSystem fileSystem = FileSystem.get(URI.create(pathStr),conf);
        fileSystem.delete(new Path(pathStr), true);
        return  true;
    }

    public static void setThirdPartyJar(Job job)
    {

        String[] jarPaths = {"/user/hadoop/3pjar/elasticsearch-hadoop-mr-2.2.0.jar"};
        setThirdPartyJar(jarPaths,job);
    }

    public static void setThirdPartyJar(String[] JarPaths,Job job)
    {
        for (String jarPath : JarPaths)
        {
            job.addCacheFile(new Path(jarPath).toUri());
        }
    }

}
