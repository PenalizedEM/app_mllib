package com.xiaotang.data.util;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.util.GenericOptionsParser;
import org.joda.time.*;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.IOException;

/**
 * Handle Hadoop Command Client and time issue.
 * Created by vent on 5/26/16.
 */
public class TimeUtil {

    public static  final String cliDateFormat = "yyyy-MM-dd";
    /**
     * Parse hadoop client command
     * Only accept two arguments.
     * Make sure your date in command is format as "yyyy-MM-dd"!
     * @param args args from hadoop cli. To be check.
     * @param conf conf for job.
     * @throws IOException
     */
    public static String pasrseCLITime(String[] args,Configuration conf) throws IOException
    {
        //Date date = new Date();
        String fmStr = "yyyy-MM-dd";
        String dateString = "";
        String[] otherArgs = new GenericOptionsParser(conf, args).getRemainingArgs();
        if (0 != otherArgs.length && 1 != otherArgs.length)
        {
            printUsage();
            System.exit(-1);
        }
        else if (otherArgs.length == 0)
        {
            DateTimeFormatter dateFormat = DateTimeFormat
                    .forPattern(fmStr);
            DateTime today = new DateTime();
            dateString = today.minusDays(1).toString(dateFormat);
            //System.out.println("dateString: "+dateString);
            //conf.set("InputDate", today.minusDays(1).toString());
        }
        else {
              dateString = otherArgs[0];
             // System.out.println("1 dateString: "+dateString);
            //conf.set("InputDate", dateString);
        }
        return dateString;
    }

    private  static  void printUsage()
    {
        //System.out.println()
        System.out.println("ERROR! Only accept two arguments. Date argument like 2016-01-01 ");
    }

    /**
     * Consider Elastic Search store data using $timeiso618 format.
     * Should read yesterday and the day before yesterday input Path.
     * @param args  args from hadoop cli. To be check .
     * @param conf  conf for job
     * @return
     * @throws IOException
     */
    public  static String transHDFSPath(String[] args,Configuration conf,String prefixStr) throws IOException
    {

        String dateStr = pasrseCLITime(args, conf);
       // String prefixStr = "/user/hadoop/test/logstatsh/";
        String dbfyStr = new DateTime(dateStr).minusDays(1).toString("yyyy-MM-dd");
        //String yesStr = dateStr.replace("-",".");
        return prefixStr+dbfyStr+"/part*"+","+prefixStr+dateStr+"/part*";
    }

    /**
     *
     * Should read yesterday and the day before yesterday input Path.
     * @param args  args from hadoop cli. To be check .
     * @param conf  conf for job
     * @return
     * @throws IOException
     */
    public  static String setNormalInPath(String[] args,Configuration conf,String prefix,int day) throws IOException
    {

        String dateStr = pasrseCLITime(args, conf);

        String dateMinStr = new DateTime(dateStr).minusDays(day).toString(cliDateFormat);
        return prefix+dateMinStr+"/*";
    }

    /**
     * Consider Elastic Search store data using $timeiso618 format.
     * Should read yesterday and the day before yesterday index data.
     * @param args  args from hadoop cli. To be check .
     * @param conf  conf for job
     * @return
     * @throws IOException
     */
    public  static String transESInPath(String[] args,Configuration conf) throws IOException
    {

        String dateStr = pasrseCLITime(args, conf);

        String dbfyStr = new DateTime(dateStr).minusDays(1).toString("yyyy.MM.dd");
        String yesStr = dateStr.replace("-",".");
        return "logstash-"+dbfyStr+","+"logstash-"+yesStr;
    }

    public static void main(String[] sm) {
        DateTimeFormatter dateFormat = DateTimeFormat
                .forPattern("G,C,Y,x,w,e,E,Y,D,M,d,a,K,h,H,k,m,s,S,z,Z");
        DateTimeFormatter dateFormat1 = DateTimeFormat
                .forPattern("yyyy.MM.dd");
        String dob = "2002-01-15";
        LocalTime localTime = new LocalTime();
        LocalDate localDate = new LocalDate();
        DateTime dateTime = new DateTime();
        LocalDateTime localDateTime = new LocalDateTime();
        DateTimeZone dateTimeZone = DateTimeZone.getDefault();


        DateTime dataDate = new DateTime("2016-04-20T09:09:00.000Z");
        DateTime cliDate = new DateTime("2016-04-20");
        System.out.println(dataDate.withTimeAtStartOfDay().isEqual(cliDate.withTimeAtStartOfDay()));
 /*       if(cliDate.isEqual(dataDate))
        {
            System.out.println("is true");
        }
        else{
            System.out.println("not true");

        }*/
        System.out
                .println("dateFormatr : " + dateFormat.print(localDateTime));
        System.out.println("LocalTime : " + localTime.toString());
        System.out.println("localDate : " + localDate.toString());
        System.out.println("dateTime : " + dateTime.toString(dateFormat1));
        System.out.println("localDateTime : " + localDateTime.toString());
        System.out.println("DateTimeZone : " + dateTimeZone.toString());
        System.out.println("Year Difference : "
                + Years.yearsBetween(DateTime.parse(dob), dateTime).getYears());
        System.out.println("Month Difference : "
                + Months.monthsBetween(DateTime.parse(dob), dateTime)
                .getMonths());
        System.out.println("Day Difference : "
                + Days.daysBetween(DateTime.parse(dob), dateTime).getDays());
    }
}
