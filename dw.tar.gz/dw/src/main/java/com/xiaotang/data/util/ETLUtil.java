package com.xiaotang.data.util;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xiaotang.data.cfg.ESParameterOption;
import com.xiaotang.data.cfg.FieldOrderSchema;
import com.xiaotang.data.cfg.UIParameterOption;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

/**
 * ETL raw log data
 * Created by vent on 6/3/16.
 */
public class ETLUtil {

    public static final String hiveTimeStampFormat = "yyyy-MM-dd HH:mm:ss";
    public static final int uaFieldLen = 72;
    public static final int uiFieldLen = 30;
    public static final String emptylogMod = "emptylog";
    public static final String hiveSpilt = "\u0001";
    public static final String flagSplice = "||";
    public static final String flagSpilt = "\\|\\|";
    public static final String nothing = "";
    public static final String uaFlag = "@";
    public static final String uiFlag = "#";
    /**
     * get element from json safely.
     * @param jsonStr
     * @param keyElement
     * @return json element string
     */
    public  static String safeCheck(String jsonStr,String keyElement)
    {
        String safeStr = "";
        JsonParser parser = new JsonParser();
        JsonObject jsonObject = parser.parse(jsonStr).getAsJsonObject();
        if(jsonObject.has(keyElement))
        {
            try {
                safeStr = jsonObject.get(keyElement).getAsJsonPrimitive().getAsString();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return  safeStr;
    }

    /**
     * get elements from json safely.
     * @param jsonStr
     * @param keyElements
     * @return json element string list
     */
    public  static ArrayList<String> safeCheck(String jsonStr,String[] keyElements)
    {
        ArrayList<String> jsonAL = new ArrayList<>();
        for(String keyElement : keyElements)
        {
            jsonAL.add(safeCheck(jsonStr, keyElement));
        }
        return  jsonAL;
    }

    /**
     * limit term safe check
     * mostly for emptylog
     * @param jsonStr
     * @param keyElement
     * @param limitElement
     * @param limitTerm
     * @return
     */
    public  static String limitSafeCheck(String jsonStr,String keyElement,String limitElement,String limitTerm)
    {
        String safeStr = "";
        JsonParser parser = new JsonParser();
        JsonObject jsonObject = parser.parse(jsonStr).getAsJsonObject();
        if(jsonObject.has(keyElement) && jsonObject.has(limitElement)&&jsonObject.get(limitElement).isJsonPrimitive())
        {

            if(jsonObject.get(limitElement).getAsJsonPrimitive().getAsString().equals(limitTerm))
            {
                try {
                    safeStr = jsonObject.get(keyElement).getAsJsonPrimitive().getAsString();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

        }


        return  safeStr;
    }

    public  static String limitSafeCheck(String jsonStr,String keyElement)
    {
        String safeStr = limitSafeCheck(jsonStr,keyElement,ESParameterOption.ES_U_MOD,emptylogMod);
        return  safeStr;
    }
    /**
     * String second to ms.
     * @param msStr
     */
    public static String second2MS(String msStr)
    {
        float second = 0;
        try {
            second = Float.parseFloat(msStr) *1000;
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
        return  Float.toString(second);
    }

    /**
     * compact old and new div.
     * @param jsonStr
     * @return
     */
    private static String compatOLD(String jsonStr,String oldField,String newField)
    {

        String compatDiv = "";
        compatDiv =safeCheck(jsonStr,newField);
        if(compatDiv.equals(nothing))
        {
            compatDiv=  safeCheck(jsonStr,oldField);
        }
        return compatDiv;
    }

    /**
     * Mapping two array into a map
     * @param keyArray
     * @param valArray
     * @return
     */
    public static HashMap<String,String> joinArrayAsMap(String[] keyArray,String[] valArray){

        HashMap<String,String> map = new HashMap<String,String>();

        if(keyArray.length == valArray.length){
            for(int index = 0; index < keyArray.length; index++){
                map.put(keyArray[index], valArray[index]);

            }
        }
        return map;
    }

    /**
     * extract value set from map,return list
     * @param uaMap
     * @return
     */
    public static ArrayList<String> extUIMapValue(HashMap<String,String> uaMap) {

        ArrayList<String> al = new ArrayList<String>();
        if(uaMap.size()>0)
        {
            for(String uiObject: FieldOrderSchema.User_Info)
            {
                if(uaMap.containsKey(uiObject))
                {
                    al.add(uaMap.get(uiObject));
                }
                else
                {
                    al.add(nothing);
                }
            }
        }

        return al;
    }

    /**
     *extract ui(in order) value set from map,return string
     * @param uaMap
     * @return
     */
    public static String extUIMapValue(HashMap<String,String> uaMap,String split) {
        String logStr="" ;
        ArrayList<String> uaAL =  extUIMapValue(uaMap);
        if(uaAL.size()>0 && uaAL!=null) {
             logStr = Joiner.on(split).useForNull(nothing).join(uaAL);
        }

        return logStr ;
    }

    /**
     * update user info get/set field
     * @param uaMap
     * @param uiMap
     * @param Update_User_Info
     */
    public static void updateUI(HashMap<String, String> uaMap, HashMap<String, String> uiMap, String[] Update_User_Info){

        for(String field :Update_User_Info)
        {
            if(uaMap.containsKey(field)&&!uaMap.get(field).equals("")&&!uaMap.get(field).toLowerCase().equals("null"))
            {
                uiMap.put(field,uaMap.get(field));
            }
        }
    }

    /**
     * Update UI map fresh field
     * @param inMap
     * @param inDate
     */
    public static void updateFresh(HashMap<String,String> inMap,String inDate){

        DateTimeFormatter formatter = DateTimeFormat.forPattern(hiveTimeStampFormat);
        String logDate = inMap.get(UIParameterOption.U_TIME_STAMP_F);
        // 命令行时间 减去 日志 第一条时间

        String fresh = "-1";
        try {
            if(!logDate.equals(nothing))
            {
                int freshInt= Days.daysBetween(formatter.parseDateTime(logDate).withTimeAtStartOfDay(), new DateTime(inDate).withTimeAtStartOfDay()).getDays();
                fresh = Integer.toString(freshInt);
            }

         }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        inMap.put(UIParameterOption.U_FRESH,fresh);
    }

    /**
     * Update UI map active field
     * @param inMap
     */
    public static void updateActive(HashMap<String,String> inMap){

        String active = "1";
        try {
            if(!inMap.get(UIParameterOption.U_ACTIVE).equals(nothing))
            {
                active=inMap.get(UIParameterOption.U_ACTIVE);
                int activeInt = Integer.parseInt(active)+1;
                active= Integer.toString(activeInt);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        inMap.put(UIParameterOption.U_ACTIVE,active);
    }
    public void fullETL(String json)
    {
        JsonParser parser = new JsonParser();
        JsonObject jsonObject = parser.parse(json).getAsJsonObject();
        Set<Map.Entry<String, JsonElement>> entries = jsonObject.entrySet();//will return members of your object
        for (Map.Entry<String, JsonElement> entry: entries) {
            System.out.println(entry.getKey());

        }
    }
    /**
     * Long and main method for extract and transform raw json data to ua table.
     * ToDO Construct it more elegant.
     * @param jsonStr
     */
    public  static ArrayList<String> ETFromJson(String jsonStr)
    {
        ArrayList<String> uaAL = new ArrayList<>(uaFieldLen);
        //Transfer timestamp format for local  datetime and hive.
        uaAL.add(new DateTime(safeCheck(jsonStr, ESParameterOption.TIME_STAMP)).toString(hiveTimeStampFormat));
        //Transform to ms
        uaAL.add(second2MS(safeCheck(jsonStr, ESParameterOption.ES_BACK_TIME)));
        //Transform to ms
        uaAL.add(second2MS(safeCheck(jsonStr, ESParameterOption.ES_RSP_TIME)));
        //simple get server ip
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_HOST));
        //simple get client ip
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_XFF));
        //simple get http status code
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_STATUS));
        //simple get http respond size
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_SIZE));

        //there are version and div both,using div only.
        uaAL.add(compatOLD(jsonStr, ESParameterOption.ES_U_OLD_DIV,ESParameterOption.ES_U_DIV));

        //there are channel and dic both, using dic only.
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_DIC));
        //simple get diu
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_DIU));
        //simple get diu2
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_DIU2));
        //simple get diu3
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_DIU3));
        //simple get user id
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_UID));
        //simple get user start id
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_START_ID));

        //to compat step id and setp id.
        uaAL.add(compatOLD(jsonStr, ESParameterOption.ES_OLD_STEP_ID,ESParameterOption.ES_STEP_ID));

        //simple get client time
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_TIME));
        //simple get service module .
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_MOD));
        //simple get service interface
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_AC));
        //simple get client type
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_CLIENT));
        //simple get service version
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_VER));
        //simple get client device uuid
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_UUID));
        //simple get hash code
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_HASH));
        //simple get xinge code for push
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_XINGE));
        //simple get service token
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_TOKEN));
        //simple get agent
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_AGENT));
        //simple get http method code
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_METHOD));
        //simple get client current activity
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_NEW_ACTIVITY));
        //simple get client prior activity
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_OLD_ACTIVITY));
        //simple get search key
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_KEY));
        //simple get search client module
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_CLIENT_MODULE));
        //simple get search source
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_SOURCE));
        //simple get search result page
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_PAGE));
        //simple get search result position
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_POSITION));
        //simple get video id
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_VID));
        //simple get search order type.Could duplicate with other type.
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_TYPE));
        //simple get video play percent
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_PERCENT));
        //simple get video play rate.
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_RATE));
        //simple get client register role
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_USER_ROLE));
        //simple get is new user or not
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_ISNEW_USER));
        //check if user click download button or not
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_ISDOWNLOAD));
        //check if user watch video online or not
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_ISONLINE));
        // get video play buffer time
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_BUFFERTIME));
        //simple get video action
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_ACTION));
        //simple check if video is high resolution
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_ISHIGH));
        //simple get cdn source
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_CDN_SOURCE).toLowerCase());
        //simple get download video  starting time
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_DOWNLOAD_START));
        //simple get download video  stop time
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_DOWNLOAD_STOP));
        //simple get cdn failed source
        uaAL.add(limitSafeCheck(jsonStr, ESParameterOption.ES_U_FAIL_CDN_SOURCE).toLowerCase());
        //simple get cdn new source
        uaAL.add(limitSafeCheck(jsonStr,ESParameterOption.ES_U_NEW_CDN_SOURCE).toLowerCase());
        //simple get device width
        uaAL.add(safeCheck(jsonStr, ESParameterOption.ES_U_WIDTH));
        //simple get device height
        uaAL.add(safeCheck(jsonStr, ESParameterOption.ES_U_HEIGHT));
        //simple get device longitude
        uaAL.add(safeCheck(jsonStr, ESParameterOption.ES_U_LON));
        //simple get device latitude
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_LAT));
        //simple get province
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_PROVINCE));
        //simple get city
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_CITY));
        //simple get device net operator
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_NETOP));
        //simple get device net type
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_NETTYPE));
        //simple get device sdk version
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_SDK_VERSION));
        //simple get device model
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_MODEL));
        //simple get device
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_DEVICE));
        //simple get device manfacture
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_MANUFACTURE));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE0));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE1));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE2));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE3));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE4));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE5));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE6));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE7));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE8));
        //simple get reverse field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_REVERSE9));
        //simple get last bigger json field
        uaAL.add(safeCheck(jsonStr,ESParameterOption.ES_U_BIGGER_JSON));
        return uaAL;
    }


}
