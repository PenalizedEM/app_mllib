package com.xiaotang.data.mapper;

import com.google.common.base.Joiner;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.xiaotang.data.util.ETLUtil;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
import org.joda.time.DateTime;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Generating UI from old UI. Using Reducer Side Join.
 * Created by vent on 6/13/16.
 */
public class UI4UIStatMapper extends Mapper<Object, Object, Text, Text>
{
    String inDate ;

    @Override
    protected void setup(Context context) throws IOException
    {
        Configuration conf = context.getConfiguration();
         inDate = conf.get("inDate");
    }
    @Override
    protected void map(Object key, Object value, Context context) {
        Text doc = (Text) value;
        Text diuKey = new Text();
        Text uiVal = new Text();
        try {
            if(doc.toString()!=null&&!doc.toString().equals(""))
            {
                String[] uiStr = doc.toString().split(ETLUtil.hiveSpilt, ETLUtil.uiFieldLen);
                String diu = uiStr[0];
                diuKey.set(diu);
                //#||user_info
                uiVal.set(ETLUtil.uiFlag + ETLUtil.flagSplice + doc.toString());
                context.write(diuKey, uiVal);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}

