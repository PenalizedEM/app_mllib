package com.xiaotang.data.util;

import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashMap;

/**
 * For distribute cache
 * Created by vent on 6/1/16.
 */
public class DistributeCachUtil
{
    /**
     * load distributed cache 2 hashmap
     * only support key[0] value[1]
     * @param uri
     * @param context
     * @return hashmap with cache file
     * @throws IOException
     */
    public static HashMap<String,String> load2Map(URI[] uri,Mapper.Context context) throws IOException
    {
        int cacheStrLen = 2;
        String delimiters =";";
        HashMap<String,String> hm = new HashMap<String,String>();
        FileSystem fs = FileSystem.get(context.getConfiguration());
        for (URI p : uri) {
            Path path = new Path(p.toString());
            FSDataInputStream fsin = fs.open(path);
            DataInputStream in = new DataInputStream(fsin);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String str = null;
            while ((str = br.readLine()) != null)
            {
                if (!"".equals(str))
                {
                    String[] strArr = str.split(delimiters);
                    if(strArr.length==cacheStrLen&&!"".equals(strArr[0])&&strArr[0]!=null)
                    {
                        hm.put(strArr[0], strArr[1]);
                    }
                }
            }
            //Use br

            br.close();
            in.close();
            fsin.close();
        }
        return hm;
    }

    }
