/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_pv.py

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/cube_video_pvuv.py


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_playtime.py 2217-01-01


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_cmpv.py 2217-01-01


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_cmpt.py 2217-01-01


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/testraw2ua.py


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/raw2ua.py 2217-03-07


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/ua2ui.py 2217-04-08
