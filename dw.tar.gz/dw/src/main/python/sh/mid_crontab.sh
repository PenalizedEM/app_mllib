#!/bin/sh

source /etc/profile
export PATH=${PATH}
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
year=$year
month=$month
day=$day
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2018-01-01"
exit 0
fi
fi

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf

hadoop fs -test -e /olap/dw/uabigger/${datebuf}/_SUCCESS
f=$?
hadoop fs -test -z /olap/dw/uabigger/${datebuf}/p*
e=$?
echo ua_${datebuf}_success=$f
echo ua_${datebuf}_size=$e

if [ $f -ne 0 ] || [ $e -eq 0 ] ; then

echo " not success "
exit -1

else
########################################
echo "`date` [INFO] ----------- job begin ---------"
########################################

########################################
echo "`date` [INFO] ----------- 1、 mid_video_pv start ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_pv.py $datebuf
} >> midlog/mid_video_pv_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 1、 mid_video_pv end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 2、 mid_video_ex begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_ex.py $datebuf
} >> midlog/mid_video_ex_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 2、 mid_video_ex end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 3、 mid_video_playtime begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_playtime.py $datebuf
 } >> midlog/mid_video_playtime_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 3、 mid_video_playtime end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 4、 mid_video_cmpv start ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_cmpv.py $datebuf
} >> midlog/mid_video_cmpv_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 4、 mid_video_pv end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 5、 mid_video_cmpt start ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_cmpt.py $datebuf
} >> midlog/mid_video_cmpt_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 5、 mid_video_cmpt end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 6、 mid_video_cmex start ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_cmex.py $datebuf
} >> midlog/mid_video_cmex_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 6、 mid_video_cmex end ---------"
################################################################################

fi
