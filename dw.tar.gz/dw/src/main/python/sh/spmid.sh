#!/bin/bash
#riqizizeng
#set -X

#input arguments cannot be null
source /etc/profile
if [ -z "$1" ] || [ -z "$2" ] ;then
echo "parameter error! please input the parameter!
para format YYYY-MM-DD"
exit 0
else

datebeg=$1
dateend=$2
beg_s=`date -d "$datebeg" +%s`
end_s=`date -d "$dateend" +%s`

count=1

while [ "$beg_s" -le "$end_s" ]
do
year=`date -d @$beg_s +"%Y"`
month=`date -d @$beg_s +"%m"`
day=`date -d @$beg_s +"%d"`
datebuf="${year}-${month}-${day}"
echo $datebuf
bef_datebuf=`date -d "$datebuf -0 day" +"%Y-%m-%d"`
echo $bef_datebuf

echo $count 

hadoop fs -test -e /olap/dw/uabigger/${bef_datebuf}/_SUCCESS
f=$?
hadoop fs -test -z /olap/dw/uabigger/${bef_datebuf}/p*
e=$?
echo es_${bef_datebuf}_success=$f
echo es_${bef_datebuf}_size=$e
if [ $f -ne 0 ] || [ $e -eq 0 ] ; then

echo " not success "
exit -1

else

echo "beginspark job "
/home/hadoop/spark/bin/spark-submit  --master yarn --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/mid_video_ex.py  $datebuf

fi


# hive -e ""
# hive   --hivevar datebuf=${datebuf}  -f /home/hadoop/user/vent/sql/uvr.sql 

#& 

#if [ $(($count%3)) == 0 ]; then
#echo $count
#wait
#fi 

let count=count+1

beg_s=$((beg_s+86400))
done



fi
