drop TABLE da.cube_video_pvuv;
CREATE EXTERNAL TABLE IF NOT EXISTS da.cube_video_pvuv(
    vid  STRING COMMENT '视频id',
    dic STRING COMMENT '渠道',
    province STRING COMMENT '省份',
    city  STRING COMMENT '城市',
    client  STRING COMMENT '平台',
    m_pv bigint COMMENT '播放次数',
    m_uv bigint COMMENT '播放人数'
)
COMMENT 'cube层-视频播放'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/cube_video_pvuv/';
