#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 19
import dateutil.parser
import json
from datetime import date, timedelta
import datetime
from dateutil import tz
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row
import re
import sys
from collections import OrderedDict
#读入JSON到Dict
def readJson(line):
    global allLines,jleLines,jpeLines,uaList,uaIntList
    uaDict = dict((el,"") for el in uaList)
    try:
        data = json.loads(line)
        #处理Logstash codec错误的数据
        if data.get('tags',""):
            regex = re.compile(r'\\(?![/u"])')
            fixed = regex.sub(r"\\\\", data['message'])
            data = json.loads(fixed)
            jpeLines +=1
        #只处理正确编码日志
        #生成 request dictionary
        data.pop('path',None)
        data.pop('@version',None)
        reqStr=data.pop('request',None)
        uaDict = etlOther(data,uaDict)
        uaDict = etlRequest(reqStr,uaDict)
        allLines += 1
    except:
        jleLines +=1
    return uaDict

#解析、清洗、转换日志的非request部分
def etlOther(otherDict,uaDict):
    global opeLines
    try:
        otherDict['timestamp']=isoStr2utc8Str(otherDict.pop('@timestamp'))
        #相应时间转换成毫秒
        if  otherDict['backtime'] !='-':
            otherDict['backtime']= str(float(otherDict['backtime'])*1000)
            otherDict['responsetime']= str(float(otherDict['responsetime'])*1000)
        else:
            otherDict['backtime']= str(0.0)
        #遍历字典，更换新key,有更干净做法？
        for key in otherDict:
            newKey = "u_"+key.lower()
            uaDict[newKey]= otherDict[key]
        #清空旧字典
        otherDict.clear()
    except ValueError as ve:
        opeLines +=1
    except TypeError as te:
        opeLines +=1
    finally:
        return uaDict

#解析、清洗、转换日志的request部分
def etlRequest(reqItem,uaDict):
    global rpeLines
    bigjsonDict = dict()
    #1. request值先按照空格分割得到四部分: (http_method) (http_uri)?(http_para) (http_verb)
    #每条日志都应该匹配上并正确切分成4部分。
    #TODO : 加上else累计器
    try:
        pattern = re.compile('(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.[0-1])')
        mat =re.match(pattern,reqItem)
        if mat is not None and len(mat.groups())==4:
            uaDict['u_method'] = mat.group(1)
            uaDict['u_url'] = mat.group(2)
            uaDict['u_verb'] = mat.group(4)

            #2. 对实际参数做分割,强制转换为小写，加上前缀u_
            reqList = mat.group(3).split('&')
            for reqEle in reqList:
                #if len(reqEle.split('='))==2:
                kvList = reqEle.split('=',2)
                if len(kvList) < 2:
                    kvList.append("")
                uaEle = 'u_'+kvList[0].lower()
                #将u_channel,u_version,u_setpid使用lambda转换成预定义的filed名
                tf = lambda rf:{'u_channel': 'u_dic','u_version': 'u_div','u_setpid':'u_stepid'}.get(rf,rf)
                cleanEle = tf(uaEle)
                if cleanEle in uaDict:
                    uaDict[cleanEle]=kvList[1]
                else:
                    bigjsonDict[cleanEle]=kvList[1]
            uaDict['u_bigger_json']=json.dumps(bigjsonDict)
    except TypeError as te:
        rpeLines +=1
    finally:
        return uaDict

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat):
    if len(dateList) ==1:
        # yes = date.today() - timedelta(1)
        datePath = (date.today() - timedelta(1)).strftime(dateFormat)
        # print datePath
    elif len(dateList) ==2:
        datePath = datetime.datetime.strptime(dateList[1],'%Y-%m-%d').strftime(dateFormat)
        #print datePath
    return datePath

#将传入的ISO8601 时间字符串，转成成指定格式的Local时区字(UTC+8)符串
def isoStr2utc8Str(isoStr):
    utc= datetime.datetime.strptime(isoStr,'%Y-%m-%dT%H:%M:%S.%fZ')
    utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).replace(tzinfo=None)
    return utc8Time

#定义好UASchema
def conUASchema():
    global uaList
    uaDict = OrderedDict()
    for ua in uaList:
        uaDict[ua] = StructField(ua, StringType(), True)
    schema = StructType(list(uaDict.values()))
    return schema

#判断字段是否合法
def cleanFiled(patStr,cleanStr):
    global numberLines
    cleanPat = re.compile(patStr)
    try:
        if re.match(cleanPat,cleanStr):
            return True
    except TypeError as te:
        print te
        numberLines += 1
    else:
        return False

##显式转化成int型
def castFiled(uaDict):
    global uaIntList,timeLines
    if not uaDict['u_timestamp']:
        uaDict['u_timestamp'] = datetime.datetime.strptime('1984-1-1 00:00:00.198964','%Y-%m-%d %H:%M:%S.%f')
        timeLines += 1
    numberPat = '^-?[0-9]+$'
    for ua in uaIntList:
        if uaDict[ua] is not None and cleanFiled(numberPat,uaDict[ua]):
            try:
                uaDict[ua] = int(uaDict[ua])
            except ValueError:
                uaDict[ua] = int(-1024.0)
        else:
            uaDict[ua] = -1
    return uaDict

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%y-%m-%d")
    outDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = datetime.datetime.strptime(dateList[1],"%Y-%m-%d").strftime("%y-%m-%d")
        outDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour,outDay

#主入口
if __name__ == "__main__":

    reload(sys)
    sys.setdefaultencoding('utf-8')

    #处理输入输出目录的日期格式
    inDate = handleDateArgs(sys.argv)[0]
    print "inDate  ", inDate
    inHour = handleDateArgs(sys.argv)[1]
    print "inHour ", inHour
    outDate = handleDateArgs(sys.argv)[2]
    print "outDate ", outDate

    inPath = "hdfs://Ucluster/flume/" + inDate + "/" + inHour + "/"
    print "InPut HDFS Path: ",inPath
    outHour = inHour
    outPath = "hdfs://Ucluster/olap/dw/uamini/"+outDate+"/" + inHour + "/"
    print "OutPut HDFS Path: ",outPath
    uaList = ['u_timestamp','u_backtime','u_responsetime','u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_stepid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_page','u_position','u_vid','u_type','u_percent','u_rate','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_download_start','u_download_stop','u_fail_cdn_source','u_new_cdn_source','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
    uaIntList = ['u_size','u_stepid','u_page','u_position','u_percent','u_rate','u_width','u_height']
    uaTimeList = ['u_timestamp']
    #print conUASchema()
    # conf = SparkConf.setAppName("Raw2UAMini-" + outDate + ":" + inHour)
    conf = SparkConf()
    sc = SparkContext()
    #sc = SparkContext('yarn-cluster', 'Spark-Raw2UA:'+inDate)
    #print sc
    #sc = SparkContext('yarn-client', 'Spark-Raw2ua'+inDate, conf=conf)
    sqlContext = SQLContext(sc)
    linesRDD = sc.textFile(inPath)
    allLines = sc.accumulator(0)
    jleLines = sc.accumulator(0)
    #json parse error line count
    jpeLines = sc.accumulator(0)
    #request parse error line
    rpeLines = sc.accumulator(0)
    opeLines = sc.accumulator(0)
    timeLines = sc.accumulator(0)
    numberLines = sc.accumulator(0)
    uaRDD= linesRDD.map(lambda x : readJson(x))
    #print uaRDD.take(2)
    uaDF = sqlContext.createDataFrame(uaRDD,conUASchema())
    #uaDF.printSchema()
    uaDF.repartition(200).write.mode('overwrite').save(outPath, format="parquet")
    #uaDF.write.json('hdfs://Ucluster/olap/dw/uabigger/test.json')
    print "all line: ",allLines
    print "json load error line",jleLines
    print "json parse error line : ",jpeLines
    print "request parse error line: ",rpeLines
    print "other parse error line: ",opeLines
    print "timestamp empty line", timeLines
    print "number error line", numberLines
    sc.stop()
