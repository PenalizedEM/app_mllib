#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 31
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import Row,SparkSession
import re
import sys
from collections import OrderedDict

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#parse hive txt
#parse hive txt
def readHive(line):
    #uiList = ['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div_f','u_div','u_dic_f','u_dic','u_client','u_timestamp_f','u_timestamp','u_netop_f',
    #'u_netop','u_province_f','u_province','u_city_f','u_city','u_manufacture','u_model','u_device','u_width','u_height','u_fresh','u_active','u_tag','u_bigger_json']
    #print len(uaList)
    global uiList
    valList = line.split("\001")
    if len(valList)==30:
        uiDict = dict(zip(uiList, valList))
        #uiDict = OrderedDict(zip(uiList, valList))
        #uiDict = dict((el,) for el in uiList)
        uiDict['u_fresh'] = int(uiDict['u_fresh'])
        uiDict['u_active'] = int(uiDict['u_active'])
        return uiDict
    else:
        return ''
        #print len(valList)
        #print valList
def cleanFiled(patStr,cleanStr):
    #cleanPat = re.compile("^[\\w-]{5,75}?$")
    #cleanPat = re.compile("^[\\d]{1,30}$")
    cleanPat = re.compile(patStr)
    if re.match(cleanPat,cleanStr):
        return True

#抛弃非用户主动触发接口以及初步清洗UA的DIU
def cleanUA(x):
    global uaDateFormat
    modAC = x.u_mod+"-"+x.u_ac;
    filterArray = ['main-start','top-count_plush','emptylog-push_arrival','main-update','video-ab_start','emptylog-count_plush','top-isnew_diu','emptylog-video_display','video-gtag','top-test','top-abtest']
    uncleanArr = ['UNKNOWN','000000000000000','012345678912345','812345678912345','860485038523819','860623027196482','353919025680130','00000000','0','0123456789abcde','123456789012345','111111111111111',' ','Unknown']
    diuPat = '^[\\w-]{5,75}?$'
    try:
        if modAC not in filterArray and cleanFiled(diuPat,x.u_diu) and x['u_diu'] not in uncleanArr:
            datestr = time.strptime(x.u_timestamp,uaDateFormat)
            return x
    except ValueError as ve:
        pass

#抛弃非用户主动触发接口以及初步清洗UA的DIU
def cleanUI(x):
    diuPat = '^[\\w-]{5,75}?$'
    uncleanArr = ['UNKNOWN','000000000000000','012345678912345','812345678912345','860485038523819','860623027196482','353919025680130','00000000','0','0123456789abcde','123456789012345','111111111111111',' ','Unknown']
    if x != '' and x is not None and cleanFiled(diuPat,x['u_diu']) and x['u_diu'] not in uncleanArr:
        return x
#count dict don't had u_diu
def countDiu(x):
    global errUICounts,rigUICounts
    if len(x) !=30:
        errUICounts += 1
    else:
        rigUICounts += 1
    return len(x)

def mergeDict(x,y):
    try:
        x.update(y)
        maxKey = max(x.keys(), key=int)
        minKey = min(x.keys(), key=int)
        maxVal = x[maxKey]
        minVal = x[minKey]
        x.clear()
        y.clear()
        x[minKey] = minVal
        x[maxKey] = maxVal
        return x
    except Exception, e:
        raise e

def mergeList(x,y):
    x.append(y)
    return x
#生成以diu为key的pairRDD,diu作为join key。同时，返回以时间戳为key的value dict。(diu,{timestamp,logline})
def genPairRDD(x,dateFormat):
    dic = dict()
    logEcoph = 0
    if x.u_timestamp:
        logEcoph=int(time.mktime(time.strptime(x.u_timestamp,dateFormat)))*1000
    dic[logEcoph]=x
    return (x.u_diu,dic)

def genUI(x):
    maxKey = max(x.keys(), key=int)
    minKey = min(x.keys(), key=int)
    lUIArr=['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div','u_dic','u_client','u_timestamp','u_netop','u_province','u_city','u_manufacture','u_model','u_device','u_width','u_height']
    fUIArr=['u_div','u_dic','u_timestamp','u_netop','u_province','u_city']
    emArr=['u_tag','u_bigger_json']
    cleanDiuArr=['u_diu','u_diu2','u_diu3']
    cleanNumArr=['u_uid','u_width','u_height']
    nuiDict = dict()
    for i in lUIArr:
        nuiDict[i] = x[maxKey][i]
    for j in fUIArr:
        nuiDict[j+"_f"] = x[minKey][j]
    for l in emArr:
        nuiDict[l]=""
    nuiDict['u_fresh'] = 0
    nuiDict['u_active'] = 1
    nuiDict['u_width'] = nuiDict['u_width']
    nuiDict['u_height'] = nuiDict['u_height']
    return nuiDict
    #nuiDict[i]=oList[-1][1][i]
    #nuiDict[j+"_f"]=oList[0][1][j]
# for m in cleanDiuArr:
# 	nuiDict[m]=cleanFiled('diu',nuiDict[m])
# for n in cleanNumArr:
# 	nuiDict[n]=cleanFiled('num',nuiDict[n])
#fRow= OrderedDict(sorted(x.items(), key=lambda t: t[0])).items()[0][1]
#u_diu,u_diu2,u_diu3,u_uid,u_uuid,u_hash,u_xinge,u_token,u_div,u_dic,u_client,u_timestamp,u_netop,u_province,u_city,u_manufacture,u_model,u_device,u_width,u_height
#u_diu,u_div,u_dic,u_timestamp,u_netop,u_province,u_city
#firtDiu = firstEle.u_diu
#lastROW = OrderedDict(sorted(x.items(), key=lambda t: t[0])).items()[-1][1]
#uiDict = x[0].asDict()
def updateUI(x):
    global newLines,actLines,silLines,teCounts,uiList
    uiDict = dict((el,"") for el in uiList)
    if x[0] is not None and x[1] is not None:
        if x[0] == '' or x[1] == '':
            teCounts += 1
        else:
            uiDict = x[0].asDict()
            needUpArr = ['u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div','u_dic','u_client','u_timestamp','u_netop','u_province','u_city','u_manufacture','u_model','u_device','u_width','u_height']
            for i in needUpArr:
                if(x[1][i] !=''):
                    uiDict[i] = x[1][i]
            uiDict['u_fresh'] = x[0]['u_fresh'] + 1
            uiDict['u_active'] = x[0]['u_active'] + 1
            actLines += 1
    elif x[0] is not None and x[1] is None:
        uiDict = x[0].asDict()
        uiDict['u_fresh'] = x[0]['u_fresh'] + 1
        #uiDict['u_active'] = x[0]['u_active']
        silLines += 1
    elif x[0] is None and x[1] is not None:
        uiDict = x[1]
        newLines += 1
        actLines += 1
    return uiDict

#定义好UISchema
def conUISchema():
    global uiList,uiIntList
    uiDict = OrderedDict()
    for ui in uiList:
        if ui in uiIntList:
            uiDict[ui] = StructField(ui, IntegerType(), True)
        else :
            uiDict[ui] = StructField(ui, StringType(), True)
    schema = StructType(list(uiDict.values()))
    return schema


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    #处理输入输出目录的日期格式
    inUADate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print inUADate
    inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    print "inUAPath HDFS Path: ",inUAPath
    inUIDate=handleDatePath(sys.argv,'%Y-%m-%d',1)
    inUIPath = "hdfs://Ucluster/olap/dw/uibigger/"+inUIDate+"/"
    print "inUIPath HDFS Path: ",inUIPath
    outUIDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    outUIPath = "hdfs://Ucluster/olap/dw/uibigger/"+outUIDate+"/"
    print "outUIPath HDFS Path: ",outUIPath
    uiList = ['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div_f','u_div','u_dic_f','u_dic','u_client','u_timestamp_f','u_timestamp','u_netop_f',
              'u_netop','u_province_f','u_province','u_city_f','u_city','u_manufacture','u_model','u_device','u_width','u_height','u_fresh','u_active','u_tag','u_bigger_json']
    uiIntList = ['u_fresh','u_active']
    conf = SparkConf()
    #sc = SparkContext('yarn-client', 'Spark-UA2UI:'+inUADate, conf=conf)
    sc = SparkContext()
    newLines = sc.accumulator(0)
    actLines = sc.accumulator(0)
    silLines = sc.accumulator(0)
    teCounts = sc.accumulator(0)
    errUICounts = sc.accumulator(0)
    rigUICounts = sc.accumulator(0)
    sqlContext = SQLContext(sc)
    #hive = HiveContext(sc)
    uaDF = sqlContext.read.parquet(inUAPath)
    uaDF.createOrReplaceTempView("uatoday")
    uaSql = "SELECT b.u_diu, u_diu2, u_diu3, u_uid, u_uuid, u_hash, u_xinge, u_token, u_div_f, u_div, u_dic_f, u_dic, u_client, u_timestamp_f, u_timestamp, u_netop_f, u_netop, u_province_f, u_province, u_city_f, u_city, u_manufacture, u_model, u_device, u_width, u_height, 0 AS u_fresh, 1 AS u_active, '' AS u_tag, '' AS u_bigger_json FROM (SELECT u_diu, u_div AS u_div_f , u_dic AS u_dic_f, u_timestamp AS u_timestamp_f, u_netop AS u_netop_f , u_province AS u_province_f, u_city AS u_city_f FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY u_diu ORDER BY u_timestamp) rank FROM uatoday WHERE  u_diu NOT IN ('UNKNOWN', ' ', 'Unknown', '0', '0123456789abcde', '012345678912345', '123456789012345', '0', '000000', '00000000', '00000000000000', '000000000000000', '0000000000000000', '000000011234564', '111111111111111', '', 'UNKNOWN', 'Unknown', '+++++000000000', '+GSN:808DCF89', '000000000000026') AND concat(u_mod,'-',u_ac) NOT IN ('main-start', 'top-count_plush', 'emptylog-push_arrival', 'main-update', 'video-ab_start', 'emptylog-count_plush', 'top-isnew_diu','video-gtag','top-test','top-hits_pc','top-abtest'))a WHERE a.rank=1)b JOIN (SELECT u_diu, u_diu2, u_diu3, u_uid, u_uuid, u_hash, u_xinge, u_token, u_div, u_dic, u_client, u_timestamp, u_netop, u_province, u_city, u_manufacture, u_model, u_device, u_width, u_height FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY u_diu ORDER BY u_timestamp DESC) rank FROM uatoday WHERE  u_diu NOT IN ('UNKNOWN', ' ', 'Unknown', '0', '0123456789abcde', '012345678912345', '123456789012345', '0', '000000', '00000000', '00000000000000', '000000000000000', '0000000000000000', '000000011234564', '111111111111111', '', 'UNKNOWN', 'Unknown', '+++++000000000', '+GSN:808DCF89', '000000000000026') AND concat(u_mod,'-',u_ac) NOT IN ('main-start', 'top-count_plush', 'emptylog-push_arrival', 'main-update', 'video-ab_start', 'emptylog-count_plush', 'top-isnew_diu','video-gtag','top-test','top-hits_pc','top-abtest'))c WHERE c.rank=1)d ON (b.u_diu = d.u_diu)"
    uaPairDF = sqlContext.sql(uaSql).repartition(800)
    uaPairDF.printSchema()
    uaPair = uaPairDF.rdd.map(lambda x :(x['u_diu'],x))
    #print uaPair.take(1)
    # uacount = uaPair.count()
    # print "ua count: ",uacount
    #reading ui
    #uisql = "SELECT * from dw.uibigger where dt='"+inUIDate+"' "
    #hive.sql("SET spark.sql.shuffle.partitions=800")
    oldUIDF = sqlContext.read.parquet(inUIPath).repartition(800)
    uiPair = oldUIDF.rdd.filter(lambda x :cleanUI(x)).map(lambda x :(x['u_diu'],x))
    # uicount =  uiPair.count()
    # print "ui count: ",uicount
    # nuiPair = uiPair.fullOuterJoin(uaPair)
    # nuicount = nuiPair.count()
    # print "nui count: ",nuicount
    # print nuiPair.take(1)
    nuiPair = uiPair.fullOuterJoin(uaPair).mapValues(lambda x:updateUI(x)).values()
    uiDF = sqlContext.createDataFrame(nuiPair,conUISchema())
    uiDF.repartition(400).write.mode('overwrite').save(outUIPath, format="parquet")
    print "new user count : ",newLines
    print "act user count : ",actLines
    print "sil user count : ",silLines
    print "empty count : ",teCounts
    print "error ui counts",errUICounts
    print "right ui counts",rigUICounts
    #print "ui first",uiPair.first().u_diu
    sc.stop()
