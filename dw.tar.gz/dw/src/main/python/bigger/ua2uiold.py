#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 31
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
import re
import sys
from collections import OrderedDict

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#parse hive txt
#parse hive txt
def readHive(line):
    #uiList = ['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div_f','u_div','u_dic_f','u_dic','u_client','u_timestamp_f','u_timestamp','u_netop_f',
                #'u_netop','u_province_f','u_province','u_city_f','u_city','u_manufacture','u_model','u_device','u_width','u_height','u_fresh','u_active','u_tag','u_bigger_json']
    #print len(uaList)
    global uiList
    valList = line.split("\001")
    if len(valList)==30:
    	uiDict = dict(zip(uiList, valList))
        #uiDict = OrderedDict(zip(uiList, valList))
        #uiDict = dict((el,) for el in uiList)
    	uiDict['u_fresh'] = int(uiDict['u_fresh'])
    	uiDict['u_active'] = int(uiDict['u_active'])
        return uiDict
    else:
        return ''
    #print len(valList)
    #print valList
def cleanFiled(patStr,cleanStr):
    #cleanPat = re.compile("^[\\w-]{5,75}?$")
    #cleanPat = re.compile("^[\\d]{1,30}$")
    cleanPat = re.compile(patStr)
    if re.match(cleanPat,cleanStr):
        return True
    return False

#抛弃非用户主动触发接口以及初步清洗UA的DIU
def cleanUA(x):
    global uaDateFormat
    modAC = x.u_mod+"-"+x.u_ac;
    filterArray=['main-start','top-count_plush','emptylog-push_arrival','main-update','video-ab_start','emptylog-count_plush','top-hits_pc','top-hits_m']
    uncleandiu = ['UNKNOWN','0123456789abcde','012345678912345','123456789012345','00000000','000000000000000','111111111111111']
    diuPat = '^[\\w-]{5,75}?$'
    try:
        if modAC not in filterArray and cleanFiled(diuPat,x.u_diu) and x['u_diu'] not in uncleandiu and x['u_timestamp']!= '':
            datestr = time.strptime(x.u_timestamp,uaDateFormat)
            return x
    except ValueError as ve:
        pass

#抛弃非用户主动触发接口以及初步清洗UA的DIU
def cleanUI(x):
    diuPat = '^[\\w-]{5,75}?$'
    if x != '' and x is not None and cleanFiled(diuPat,x['u_diu']):
        return x
#count dict don't had u_diu
def countDiu(x):
    global errUICounts,rigUICounts
    if len(x) !=30:
        errUICounts += 1
    else:
        rigUICounts += 1
    return len(x)

def mergeDict(x,y):
    x.update(y)
    maxKey = max(x.keys(), key=int)
    minKey = min(x.keys(), key=int)
    maxVal = x[maxKey]
    minVal = x[minKey]
    x.clear()
    x[minKey] = minVal
    x[maxKey] = maxVal
    return x
    #AKey = max(x.keys)

def mergeList(x,y):
    x.append(y)
    return x
#生成以diu为key的pairRDD,diu作为join key。同时，返回以时间戳为key的value dict。(diu,{timestamp,logline})
def genPairRDD(x,dateFormat):
	dic = dict()
	logEcoph = 0
	if x.u_timestamp:
		logEcoph=int(time.mktime(time.strptime(x.u_timestamp,dateFormat)))*1000
	dic[logEcoph]=x
	return (x.u_diu,dic)

def genUI(x):
    maxKey = max(x.keys(), key=int)
    minKey = min(x.keys(), key=int)
    lUIArr=['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div','u_dic','u_client','u_timestamp','u_netop','u_province','u_city','u_manufacture','u_model','u_device','u_width','u_height']
    fUIArr=['u_div','u_dic','u_timestamp','u_netop','u_province','u_city']
    emArr=['u_tag','u_bigger_json']
    cleanDiuArr=['u_diu','u_diu2','u_diu3']
    cleanNumArr=['u_uid','u_width','u_height']
    nuiDict = dict()
    for i in lUIArr:
        nuiDict[i] = x[maxKey][i]
    for j in fUIArr:
        nuiDict[j+"_f"] = x[minKey][j]
    for l in emArr:
        nuiDict[l]=""
    nuiDict['u_fresh'] = 0
    nuiDict['u_active'] = 1
    nuiDict['u_width'] = nuiDict['u_width']
    nuiDict['u_height'] = nuiDict['u_height']
    return nuiDict
        #nuiDict[i]=oList[-1][1][i]
        #nuiDict[j+"_f"]=oList[0][1][j]
		# for m in cleanDiuArr:
		# 	nuiDict[m]=cleanFiled('diu',nuiDict[m])
		# for n in cleanNumArr:
		# 	nuiDict[n]=cleanFiled('num',nuiDict[n])
	#fRow= OrderedDict(sorted(x.items(), key=lambda t: t[0])).items()[0][1]
	#u_diu,u_diu2,u_diu3,u_uid,u_uuid,u_hash,u_xinge,u_token,u_div,u_dic,u_client,u_timestamp,u_netop,u_province,u_city,u_manufacture,u_model,u_device,u_width,u_height
	#u_diu,u_div,u_dic,u_timestamp,u_netop,u_province,u_city
	#firtDiu = firstEle.u_diu
	#lastROW = OrderedDict(sorted(x.items(), key=lambda t: t[0])).items()[-1][1]
    #uiDict = x[0].asDict()
def updateUI(x):
    global newLines,actLines,silLines,teCounts,uiList
    uiDict = dict((el,"") for el in uiList)
    if x[0] is not None and x[1] is not None:
        if x[0] == '' or x[1] == '':
            teCounts += 1
        else:
            uiDict = x[0].asDict()
            needUpArr = ['u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div','u_dic','u_client','u_timestamp','u_netop','u_province','u_city','u_manufacture','u_model','u_device','u_width','u_height']
            for i in needUpArr:
                if(x[1][i] !=''):
                    uiDict[i] = x[1][i]
            uiDict['u_fresh'] = x[0]['u_fresh'] + 1
            uiDict['u_active'] = x[0]['u_active'] + 1
            actLines += 1
    elif x[0] is not None and x[1] is None:
        uiDict = x[0].asDict()
        uiDict['u_fresh'] = x[0]['u_fresh'] + 1
        #uiDict['u_active'] = x[0]['u_active']
        silLines += 1
    elif x[0] is None and x[1] is not None:
        uiDict = x[1]
        newLines += 1
        actLines += 1
    return uiDict

#定义好UISchema
def conUISchema():
    global uiList,uiIntList
    uiDict = OrderedDict()
    for ui in uiList:
        if ui in uiIntList:
            uiDict[ui] = StructField(ui, IntegerType(), True)
        else :
            uiDict[ui] = StructField(ui, StringType(), True)
    schema = StructType(list(uiDict.values()))
    return schema


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    #处理输入输出目录的日期格式
    inUADate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    print "inUAPath HDFS Path: ",inUAPath
    inUIDate=handleDatePath(sys.argv,'%Y-%m-%d',1)
    inUIPath = "hdfs://Ucluster/olap/dw/uibigger/"+inUIDate+"/"
    print "inUIPath HDFS Path: ",inUIPath
    outUIDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    outUIPath = "hdfs://Ucluster/olap/dw/uibigger/"+outUIDate+"/"
    print "outUIPath HDFS Path: ",outUIPath
    uiList = ['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div_f','u_div','u_dic_f','u_dic','u_client','u_timestamp_f','u_timestamp','u_netop_f',
    			'u_netop','u_province_f','u_province','u_city_f','u_city','u_manufacture','u_model','u_device','u_width','u_height','u_fresh','u_active','u_tag','u_bigger_json']
    uiIntList = ['u_fresh','u_active']
    conf = SparkConf()
    #sc = SparkContext('yarn-client', 'Spark-UA2UI:'+inUADate, conf=conf)
    sc = SparkContext()
    newLines = sc.accumulator(0)
    actLines = sc.accumulator(0)
    silLines = sc.accumulator(0)
    teCounts = sc.accumulator(0)
    errUICounts = sc.accumulator(0)
    rigUICounts = sc.accumulator(0)
    sqlContext = SQLContext(sc)
    #直接读入PQ作为DataFrame
    uaDF = sqlContext.read.parquet(inUAPath)
    #print uaDF.filter("u_diu<>\'\'").rdd.first()
    uaDateFormat = '%Y-%m-%d %H:%M:%S.%f'
    #uaPair = uaDF.rdd.filter(lambda x :cleanUA(x)).map(lambda x :genPairRDD(x,uaDateFormat)).reduceByKey(lambda x,y:mergeDict(x,y),400).mapValues(lambda x:genUI(x))
    uaPair = uaDF.rdd.filter(lambda x :cleanUA(x)).map(lambda x :genPairRDD(x,uaDateFormat))
    print uaPair.take(2)
    print uaPair.count()
    #print "ua to ui",uaPair.first()
    #uaPairDF = sqlContext.createDataFrame(uaPair)
    #uaPairDF.printSchema()
    #linesRDD = sqlContext.read.parquet(inUIPath)
    #uiPair = linesRDD.rdd.filter(lambda x :cleanUI(x)).map(lambda x :(x['u_diu'],x))
    #print uiPair.keys()
    #print uiPair.values()
    #print uiPair['u_diu']
    #uiPair = linesRDD.map(lambda x : readHive(x)).filter(lambda x :cleanUI(x)).map(lambda x :(x.u_diu,x))
    #print "ui first",uiPair.first()
    #uiDF = sqlContext.createDataFrame(uiPair)
    #uiDF.printSchema()
    #nuiPair = uiPair.fullOuterJoin(uaPair).mapValues(lambda x:updateUI(x)).values()
    #print nuiPair.first()
    #nuiPair.write.mode('overwrite').save(outUIPath, format="parquet")
    #uiDF = sqlContext.createDataFrame(nuiPair.coalesce(200),conUISchema())
    # uiDF.show()
    # #uiDF.show(n=1)
    # uiDF.printSchema()
    #uiDF.repartition(200).write.mode('overwrite').save(outUIPath, format="parquet")
    print "new user count : ",newLines
    print "act user count : ",actLines
    print "sil user count : ",silLines
    print "empty count : ",teCounts
    print "error ui counts",errUICounts
    print "right ui counts",rigUICounts
    #print "ui first",uiPair.first().u_diu
    sc.stop()
    #print uaDF.rdd.filter(lambda x :cleanUA(x)).map(lambda x :(x.u_diu,[x])).reduceByKey(lambda x,y:mergeList(x,y),240).first()
    #print uaDF.filter("u_diu='862845021377812'").rdd.map(lambda x :(x.u_diu,[x])).reduceByKey(lambda x,y:mergeList(x,y)).first()
    #print uaPair.first()
	#print .map(lambda x :genPairRDD(x,uaDateFormat)).reduceByKey(lambda x,y:mergeDict(x,y)).mapValues(lambda x:genUI(x)).first()
	#uaPair = uaDF.rdd.map(lambda x :cleanUA(x)).map(lambda x :genPairRDD(x,uaDateFormat)).reduceByKey(lambda x,y:mergeDict(x,y)).mapValues(lambda x:genUI(x))
	#uaPair = uaDF.filter("u_diu<>\'\'").rdd.map(lambda x :genPairRDD(x,uaDateFormat)).reduceByKey(lambda x,y:mergeDict(x,y)).mapValues(lambda x:genUI(x))
	# print uaPair.count()
	# print uaPair.take(10)
	#print uaDF.filter("u_diu='869832027894464'").rdd.map(lambda x :genPairRDD(x,uaDateFormat)).reduceByKey(lambda x,y:mergeDict(x,y)).first()
    #print uaPair.take(10)
    #uaPair.saveAsTextFile("hdfs://Ucluster/temp/test/uafilter/2016-10-29/")
    #print uaDF.filter("u_diu<>\'\'").rdd.map(lambda x :genPairRDD(x)).reduceByKey(lambda x,y:mergeDict(x,y)).first()
	#print uaDF.filter("u_diu<>\'\'").first()
	#print uaDF.filter("u_diu='869832027894464'").rdd.map(lambda x :(x.u_diu,[x])).reduceByKey(lambda x,y:mergeDict(x,y)).first()
	#cRDD = cleanDF.rdd
	#cRDD.first()
	#uaDF.filter("u_diu<>\'\' ").rdd.take(10)
	#uaDF.registerTempTable("uabigger")
	#cleanDF = sqlContext.sql('SELECT * FROM uabigger where u_diu<>\'\'')
	#print cleanDF.rdd.first()
	# lDF = sqlContext.sql('SELECT u_diu,u_diu2,u_diu3,u_uid,u_uuid,u_hash,u_xinge,u_token,u_div,u_dic,u_client,u_timestamp,u_netop,u_province,u_city,u_manufacture,u_model,u_device,u_width,u_height FROM (SELECT *, row_number() OVER(PARTITION BY u_diu ORDER BY u_timestamp ) rank FROM (SELECT * FROM uabigger where u_diu <>\'\') cua) tmp WHERE rank =1 ')
	# fDF = sqlContext.sql('SELECT u_diu,u_div,u_dic,u_timestamp,u_netop,u_province,u_city FROM (SELECT *, row_number() OVER(PARTITION BY u_diu ORDER BY u_timestamp desc) rank FROM (SELECT * FROM uabigger where u_diu <>\'\' and u_province<>\'\' and u_city<>\'\'and u_div<>\'\' and u_dic<>\'\' and u_netop<>\'\') cua) tmp WHERE rank =1')
	# tDF = sqlContext.sql('SELECT u_diu,u_timestamp FROM (SELECT *, row_number() OVER(PARTITION BY u_diu ORDER BY u_timestamp desc) rank FROM (SELECT * FROM uabigger where u_diu <>\'\' and u_timestamp<>\'\' ) cua) tmp WHERE rank =1')
	# lDF.withColumn("x4", lit(0))
	#firstRe.filter("u_province<>\'\' AND u_city<>\'\' AND u_dic<>\'\'").show(n=120)
	#print "not drop"
	#allRe.na.drop('any').show(n=120)
	#print "drop"
	#allRe.dropDuplicates().show()
	#for each in allRe.collect():
		#print each
	#for each in lastRe.collect():
		#print each
	#uaDF.printSchema()
	#读入Text作为RDD
    #uiDateFormat = '%Y-%m-%d %H:%M:%S'
	#uiDF = sqlContext.createDataFrame(uiRDD)
	#print uiDF.rdd.map(lambda x :(x.u_diu,x)).first()
	#uiPair =  uiDF.rdd.map(lambda x :(x.u_diu,x))
	#uiSS = SparkSession.builder.config("spark.sql.warehouse.dir", '/user/hive/warehouse').enableHiveSupport().getOrCreate()
	#uiSS.sql("show databases").show()
	#uiDF = uiSS.sql("select * from da.temp_user_info limit 10")
	#uiDF.printSchema()
	# uiDF.registerTempTable("testui")
	# findFriend = sqlContext.sql("SELECT u_diu,u_diu2 FROM testui limit 10")
	# ff_diu = findFriend.rdd.map(lambda p: p.u_diu).collect()
	# for diu in ff_diu:
	# 	print(diu)
    #print uaRDD.first()
	#linesRDD = sc.textFile(inPath)
	#uaSchema.printSchema()
	#uaSchema.registerTempTable("testuabigger")
	#findFriend = sqlContext.sql("SELECT u_diu,u_client FROM testuabigger")
	#ff_diu = findFriend.rdd.map(lambda p: p.u_diu).collect()
	#for diu in ff_diu:
		#print(diu)
	#print uaRDD.first()
