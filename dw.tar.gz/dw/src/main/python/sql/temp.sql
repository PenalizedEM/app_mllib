select diu, vid, cm, max(if(vp is null,0,vp)) vp, sum(if(vst>7200,7200,vst)) vst, tag from (select u_diu diu, u_vid vid, u_client_module cm, get_json_object(u_bigger_json,'$.u_playid') playid, get_json_object(u_bigger_json,'$.u_abtag') tag, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed',if(u_percent>100,100,u_percent),0)) vp, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'and get_json_object(u_bigger_json,'$.u_playtime') is not null,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst from dw.uabigger where dt='"+inDate+"'and if(u_client=2, u_div>='5.3.5', u_div>='5.1.7') and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed') group by u_diu , u_vid , u_client_module, get_json_object(u_bigger_json,'$.u_playid'), get_json_object(u_bigger_json,'$.u_abtag') )k group by diu, vid, cm, tag

INSERT overwrite table da.mid_video_cmpt PARTITION (dt='"+inDate+"')    SELECT diu, vid, cm, max(if(vp IS NULL,0,vp)) vp, sum(vst) vst FROM (SELECT u_diu diu, u_vid vid, u_client_module cm, get_json_object(u_bigger_json,'$.u_playid') playid, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed',if(u_percent>100,100,u_percent),0)) vp, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'AND get_json_object(u_bigger_json,'$.u_playtime') IS NOT NULL,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst FROM dw.uabigger WHERE dt='"+inDate+"'AND if(u_client=2, u_div>='5.3.5', u_div>='5.1.7') AND concat(u_mod,'-',u_ac) IN ('emptylog-video_play_speed') AND u_diu NOT IN ('0123456789abcde', '012345678912345', '123456789012345', '0', '000000', '00000000', '00000000000000', '000000000000000', '0000000000000000', '000000011234564', '111111111111111', '', 'UNKNOWN', 'Unknown', '+++++000000000', '+GSN:808DCF89', '000000000000026') GROUP BY u_diu , u_vid , u_dic , u_province, u_city, u_client, get_json_object(u_bigger_json,'$.u_playid'))k GROUP BY diu, vid, cm UNION ALL SELECT diu, a.vid vid, cm, if(vp IS NULL,0,vp) vp, round(vst/100*duration,3)vst FROM (SELECT u_diu diu, u_vid vid, u_client_module cm, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'AND u_action IN ('exit','complete'),if(u_percent>100,100,u_percent),0)) vp, sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'AND u_action IN ('exit','complete'),if(u_percent>100,100,u_percent),0)) vst FROM dw.uabigger WHERE dt='"+inDate+"'AND if(u_client=2, u_div<'5.3.5', u_div<'5.1.7') AND u_vid <> ''AND u_diu NOT IN ('0123456789abcde', '012345678912345', '123456789012345', '0', '000000', '00000000', '00000000000000', '000000000000000', '0000000000000000', '000000011234564', '111111111111111', '', 'UNKNOWN', 'Unknown', '+++++000000000', '+GSN:808DCF89', '000000000000026') AND concat(u_mod,'-',u_ac) IN ('emptylog-video_play_speed') GROUP BY u_diu , u_vid , u_dic , u_province, u_city, u_client)a JOIN (SELECT vid, duration FROM dw.video) b ON (a.vid=b.vid)

SELECT dt,
       uid,
       m_pv,
       m_ex,
       m_vst,
       m_uv,
       round(sum(m_pv)/sum(m_ex)*100,2)ctr,
       round(sum(m_vst)/sum(m_uv),0)avgtime
FROM (
        (SELECT uid,
                vid
         FROM dw.video
         WHERE parent_category IN ('65',
                                   '55',
                                   '54',
                                   '53',
                                   '47')
           )a
      JOIN
        (SELECT dt,
                vid,
                m_ex,
                m_pv,
                m_vst,
                m_uv
         FROM da.mid_video_all
         WHERE dt='${datebuf}' GROUP BY dt,vid)b on(a.vid = b.vid))
GROUP BY dt,
         uid,
         m_pv,
         m_ex,
         m_vst,
         m_uv
