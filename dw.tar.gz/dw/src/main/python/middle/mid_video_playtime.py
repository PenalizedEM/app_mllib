#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 22 2017

"""
中间层-用户视频播放时长
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
	print sys.argv
	reload(sys)
	sys.setdefaultencoding('utf-8')
	inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	print "inDate  ",inDate
	spark = SparkSession.builder.master('yarn-client').appName('mid_video_playtime:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
	inSql = "INSERT overwrite table da.mid_video_playtime PARTITION (dt='"+inDate+"')    SELECT diu, vid, dic, province, city, client, max(if(vp IS NULL,0,vp)) vp, sum(vst) vst FROM (SELECT u_diu diu, u_vid vid, u_dic dic, u_province province, u_city city, u_client client, get_json_object(u_bigger_json,'$.u_playid') playid, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed',if(u_percent>100,100,u_percent),0)) vp, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'AND get_json_object(u_bigger_json,'$.u_playtime') IS NOT NULL,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst FROM dw.uabigger WHERE dt='"+inDate+"'AND if(u_client=2, u_div>='5.3.5', u_div>='5.1.7') AND concat(u_mod,'-',u_ac) IN ('emptylog-video_play_speed') AND u_diu NOT IN ('0123456789abcde', '012345678912345', '123456789012345', '0', '000000', '00000000', '00000000000000', '000000000000000', '0000000000000000', '000000011234564', '111111111111111', '', 'UNKNOWN', 'Unknown', '+++++000000000', '+GSN:808DCF89', '000000000000026') GROUP BY u_diu , u_vid , u_dic , u_province, u_city, u_client, get_json_object(u_bigger_json,'$.u_playid'))k GROUP BY diu, vid, dic, province, city, client"
	spark.sql(inSql)
	#spark.sql("dfs -touchz /olap/da/recy_als_out_pop/dt=${inDate}/_SUCCESS")
	# popDF.printSchema()
	# popDF.show()
	#popDF.repartition(20).write.mode('overwrite').save(outPath, format="text")
	#addPartSql = "ALTER TABLE da.recy_als_out_pop ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_als_out_pop/"+inDate+"/'"
	#print addPartSql
	#spark.sql(addPartSql)
	spark.stop()
	# print uvmDF.count()
