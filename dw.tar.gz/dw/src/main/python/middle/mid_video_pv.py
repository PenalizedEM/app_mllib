#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 22 2017

"""
中间层-用户视频播放
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
	print sys.argv
	reload(sys)
	sys.setdefaultencoding('utf-8')
	inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	print "inDate  ",inDate
	spark = SparkSession.builder.master('yarn-client').appName('mid_video_pv:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
	inSql = "INSERT overwrite table da.mid_video_pv PARTITION (dt='"+inDate+"') SELECT u_diu as diu, u_vid as vid ,u_dic as dic ,u_province as province,u_city as city,u_client as client,count(1) as m_pv from dw.uabigger where dt='"+inDate+"'  and u_vid !='' and concat(u_mod,'|',u_ac) in ('top|hits','top|hits_pc') group by u_diu,u_vid,u_dic,u_province,u_city,u_client"
	spark.sql(inSql)
	#spark.sql("dfs -touchz /olap/da/recy_als_out_pop/dt=${inDate}/_SUCCESS")
	# popDF.printSchema()
	# popDF.show()
	#popDF.repartition(20).write.mode('overwrite').save(outPath, format="text")
	#addPartSql = "ALTER TABLE da.recy_als_out_pop ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_als_out_pop/"+inDate+"/'"
	#print addPartSql
	#spark.sql(addPartSql)
	spark.stop()
	# print uvmDF.count()
