#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 22 2017

"""
用户模块视频播放时长
用于评估app各个模块效率
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
	print sys.argv
	reload(sys)
	sys.setdefaultencoding('utf-8')
	inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	print "inDate  ",inDate
	spark = SparkSession.builder.master('yarn-client').appName('mid_video_cmpt:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
	inSql = "insert overwrite table da.mid_video_cmpt PARTITION (dt='"+inDate+"') select diu, vid, cm, max(if(vp is null,0,vp)) vp, sum(if(vst>7200,7200,vst)) vst, tag from (select u_diu diu, u_vid vid, u_client_module cm, get_json_object(u_bigger_json,'$.u_playid') playid, get_json_object(u_bigger_json,'$.u_abtag') tag, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed',if(u_percent>100,100,u_percent),0)) vp, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'and get_json_object(u_bigger_json,'$.u_playtime') is not null,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst from dw.uabigger where dt='"+inDate+"'and if(u_client=2, u_div>='5.3.5', u_div>='5.1.7') and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed') group by u_diu , u_vid , u_client_module, get_json_object(u_bigger_json,'$.u_playid'), get_json_object(u_bigger_json,'$.u_abtag') )k group by diu, vid, cm, tag"
	spark.sql(inSql)
	#spark.sql("dfs -touchz /olap/da/recy_als_out_pop/dt=${inDate}/_SUCCESS")
	# popDF.printSchema()
	# popDF.show()
	#popDF.repartition(20).write.mode('overwrite').save(outPath, format="text")
	#addPartSql = "ALTER TABLE da.recy_als_out_pop ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_als_out_pop/"+inDate+"/'"
	#print addPartSql
	#spark.sql(addPartSql)
	spark.stop()
	# print uvmDF.count()
