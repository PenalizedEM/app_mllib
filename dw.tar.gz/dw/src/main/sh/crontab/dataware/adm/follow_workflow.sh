#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################

##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
#onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
#echo "onedayago:$onedayago"
##########################################################################################

function runjob(){
    datebuf=$1
    module=$2
    sql_job_name=$3
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sql_job_name}  ${datebuf} job begin**************************"
    {
        sh ./sql_job.sh ${datebuf} ${module} ${sql_job_name}
    } > ./${module}/log/${sql_job_name}.txt 2>&1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sql_job_name}  ${datebuf} job end  **************************"
}

echo "`date "+%Y-%m-%d %T"` workflow begin ..."

{
    runjob  ${datebuf}  follow f_follow_cmdv       &
    runjob  ${datebuf}  follow f_follow_pt         &
    runjob  ${datebuf}  follow f_follow_vv         &
    runjob  ${datebuf}  follow f_follow_ret        &
    runjob  ${datebuf}  follow f_follow_regrate    &
    runjob  ${datebuf}  follow f_follow_followrate  &
}

wait

{
    runjob  ${datebuf}  follow f_follow_vu  &
    runjob  ${datebuf}  follow f_follow_ctr  &
}

wait

{
    runjob  ${datebuf}  follow f_follow_ppt
}
wait 


echo "`date "+%Y-%m-%d %T"` workflow end ..."