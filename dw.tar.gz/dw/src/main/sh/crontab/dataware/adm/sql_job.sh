#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################

##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1
module=$2
sqlfile_name=$3
otherpara=$4

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
#onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
#echo "onedayago:$onedayago"
##########################################################################################


echo "`date "+%Y-%m-%d %T"` begin ..."

#每次5分钟重试一次,重试3次
for((i=1;i<=3;i++))
do

    $hive --hivevar datebuf=${datebuf} --hivevar n=${otherpara} -f ./${module}/sql/${sqlfile_name}.sql
    f=$?

    if [ $f -ne 0 ] ; then
        echo  "`date "+%Y-%m-%d %T"` The  ${i} times job run failed! ..."
        sleep $((60*5))
    else
        echo "`date "+%Y-%m-%d %T"` The  ${i} times job run success! ..."
        break
    fi
done

echo "`date "+%Y-%m-%d %T"` end ..."