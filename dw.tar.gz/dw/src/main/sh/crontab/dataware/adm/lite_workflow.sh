#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
echo "onedayago:${onedayago}"
twodayago=`date -d" -2 day $datebuf" +"%Y-%m-%d"`
echo "twodayago:$twodayago"
threedayago=`date -d" -3 day $datebuf" +"%Y-%m-%d"`
echo "threedayago:$threedayago"
fourdayago=`date -d" -4 day $datebuf" +"%Y-%m-%d"`
echo "fourdayago:$fourdayago"
fivedayago=`date -d" -5 day $datebuf" +"%Y-%m-%d"`
echo "fivedayago:$fivedayago"
sixdayago=`date -d" -6 day $datebuf" +"%Y-%m-%d"`
echo "sixdayago:$sixdayago"
sevendayago=`date -d" -7 day $datebuf" +"%Y-%m-%d"`
echo "sevendayago:$sevendayago"
##########################################################################################

function runjob(){
    datebuf=$1
    module=$2
    sql_job_name=$3
    x=$4
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sql_job_name} ${x} ${datebuf} job begin**************************"
    {
        sh ./sql_job.sh ${datebuf} ${module} ${sql_job_name} ${x}
    } > ./${module}/log/${sql_job_name}${x}.txt 2>&1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sql_job_name} ${x} ${datebuf} job end  **************************"
}

echo "`date "+%Y-%m-%d %T"` workflow begin ..."

{
    runjob  ${datebuf} lite f_lite_upload
}

wait

{
    runjob  ${onedayago} lite f_lite_upload_ret 1 &
    runjob  ${twodayago} lite f_lite_upload_ret 2 &
    runjob  ${threedayago} lite f_lite_upload_ret 3 &
    runjob  ${fourdayago} lite f_lite_upload_ret 4 &
    runjob  ${fivedayago} lite f_lite_upload_ret 5 &
    runjob  ${sixdayago} lite f_lite_upload_ret 6 &
    runjob  ${sevendayago} lite f_lite_upload_ret 7 &
}

wait

{
    runjob  ${onedayago} lite f_lite_upload_actret 1 &
    runjob  ${twodayago} lite f_lite_upload_actret 2 &
    runjob  ${threedayago} lite f_lite_upload_actret 3 &
    runjob  ${fourdayago} lite f_lite_upload_actret 4 &
    runjob  ${fivedayago} lite f_lite_upload_actret 5 &
    runjob  ${sixdayago} lite f_lite_upload_actret 6 &
    runjob  ${sevendayago} lite f_lite_upload_actret 7 &
}

wait

{
    runjob  ${onedayago} lite f_lite_upload_firstret 1 &
    runjob  ${threedayago} lite f_lite_upload_firstret 3 &
    runjob  ${sevendayago} lite f_lite_upload_firstret 7 &
    runjob  ${sevendayago} lite f_lite_upload_firstretabs 7 &
}

wait

echo "`date "+%Y-%m-%d %T"` workflow end ..."