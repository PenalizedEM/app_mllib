#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 26

"""
Calculate app impress of all module
"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    #inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    #print "inUAPath HDFS Path: ",inUAPath
    # UVA输出目录的日期格式
    outDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    outPath = "hdfs://Ucluster/olap/da/recy_evaluate_video_clickrate/"+outDate+"/"
    spark = SparkSession.builder.master('yarn-client').appName('Recy_evaluator_impression_all:'+outDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()


    impressSQL = "SELECT vid,sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display',1,0))disnum,sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0))clinum,count(distinct(if(concat(u_mod,'-',u_ac)='emptylog-video_display',u_diu,null)))diper,count(distinct(if(concat(u_mod,'-',u_ac)='top-hits',u_diu,null)))cliper from  (select u_diu,u_mod,u_ac,u_vid from  dw.uabigger where dt='"+outDate+"')a  LATERAL VIEW explode(split(u_vid,','))b AS vid group by vid"
    
    #candySQL = "SELECT u_source,u_client_module,count(nvid) as cnt from  (select u_diu,u_source,u_client_module,u_vid from  dw.uabigger where dt='"+outDate+"' and concat(u_mod,'-',u_ac)='emptylog-video_display' )a  LATERAL VIEW explode(split(u_vid,','))b AS nvid group by u_source,u_client_module"
    # modelipSQL = "SELECT  u_source,u_client_module,sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display',1,0))diplay,sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0))cilck from dw.uabigger where dt<='2016-12-26' and dt>='2016-12-20' group by u_source,u_client_module ORDER BY diplay DESC"
    # modelipDF = spark.sql(modelipSQL)
    # modelipDF.show(n=30)
    impressDF = spark.sql(impressSQL)
    # #impressDF.createOrReplaceTempView("canvideo")
    # impressDF.printSchema()
    # impressDF.show()
    # print impressDF.count()
    impressDF.repartition(50).write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
