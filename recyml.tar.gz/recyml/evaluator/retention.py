#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 27

"""
Calculate app retention of recy
"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    #inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    #print "inUAPath HDFS Path: ",inUAPath
    # UVA输出目录的日期格式
    outDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    outPath = "hdfs://Ucluster/olap/da/recy_evaluate_video_clickrate/"+outDate+"/"
    spark = SparkSession.builder.master('yarn-client').appName('Recy_evaluator_retention:'+outDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    clickrate = "SELECT  u_source,u_client_module,get_json_object(u_bigger_json,'$.u_abtag')tag,sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display',1,0))diplay,sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0))cilck from dw.uabigger where dt='"+outDate+"' and u_div>='5.5.2' group by u_source,u_client_module,get_json_object(u_bigger_json,'$.u_abtag') ORDER BY diplay DESC"
    clickDF = spark.sql(clickrate)
    clickDF.show(n=60)
    modelipSQL = "SELECT  u_client_module,get_json_object(u_bigger_json,'$.u_abtag')tag,count(distinct u_diu)cnd,count(1)cnt,sum(get_json_object(u_bigger_json,'$.u_playtime'))play from dw.uabigger where dt='"+outDate+"' and u_div>='5.5.2' and u_ac='video_play_speed' and u_mod='emptylog'  group by u_client_module,get_json_object(u_bigger_json,'$.u_abtag') ORDER BY play DESC"
    #modelipSQL = "SELECT  get_json_object(u_bigger_json,'$.u_abtag')tag,count(distinct u_diu)cnd,count(1)cnt,sum(get_json_object(u_bigger_json,'$.u_playtime'))play from dw.uabigger where dt='2016-12-27' and u_div='5.5.2' and u_ac='video_play_speed' and u_mod='emptylog'  group by get_json_object(u_bigger_json,'$.u_abtag')"
    modelipDF = spark.sql(modelipSQL)
    modelipDF.show(n=60)
    #impressDF = spark.sql(impressSQL)
    # #impressDF.createOrReplaceTempView("canvideo")
    # impressDF.printSchema()
    # impressDF.show()
    # print impressDF.count()
    #impressDF.repartition(50).write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
