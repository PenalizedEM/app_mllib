#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    actDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print inDate
    print actDate

    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_eval:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    # Dir = "hdfs://Ucluster/olap/da/recy_icf_recommend_pre/"+inDate+"/"
    # Sql = "select sum(rt) rt, sum(r) r, sum(h) h from (select a.diu, count(distinct(if(a.vid=b.vid,a.vid,null))) rt , count(distinct(if(a.vid is not null,a.vid,null))) r , count(distinct(if(b.vid is not null,b.vid,null))) h from (select diu, vid from da.recy_icf_recommend where dt='2016-12-31'and rank<=10) a full outer join (select diu, vid from da.recy_cf_eval_sample where type='test') b on (a.diu=b.diu) group by a.diu) b where h>0"
    Sql = "select sum(rt) rt, sum(r) r, sum(h) h from (select a.diu, count(distinct(if(a.vid=b.vid,a.vid,null))) rt , count(distinct(if(a.vid is not null,a.vid,null))) r , count(distinct(if(b.vid is not null,b.vid,null))) h from (select diu, vid from da.recy_icf_recommend where dt='2016-12-31'and rank<=10) a full outer join (select u_diu diu, u_vid vid from da.recy_als_data_uvr where dt='2017-01-02'and from_unixtime(f_timestamp,'yyyy-MM-dd')>'2016-12-31') b on (a.diu=b.diu) group by a.diu) b where h>0"

    print Sql
    df = spark.sql(Sql)
    df.printSchema()
    df.show()
    # print df.count()
    # df.repartition(300).write.mode('overwrite').save(recPreDir, format="parquet")

    # addPartSql = "ALTER TABLE da.recy_icf_recommend_pre ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_icf_recommend_pre/"+inDate+"/'"
    # print addPartSql
    # spark.sql(addPartSql)

    spark.stop()

#/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/wenlong/spark/recy_icf_eval.py 2016-12-15

