#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by yinfeng

"""
cold start according to four features.

"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

##取table表中最大分区的时间
def max_dt(table,spark):
    recdf = spark.sql("show partitions "+table)
    res = recdf.rdd.map(lambda v: v.result).collect()
    max_time = max(res)
    return max_time[-10:]


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate = handleDatePath(sys.argv, '%Y-%m-%d', 0)
    befDate = handleDatePath(sys.argv, '%Y-%m-%d', 2)
    print inDate
    print befDate


    #四个维度类别下的视频
    spark = SparkSession.builder.appName('recy_cold_four_topk:' + inDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    max_time = max_dt("da.user_profile", spark)
    #max_time = "2017-04-30"
    print(max_time)
    #用户画像特征选择
    user_sql = "INSERT overwrite TABLE da.recy_cold_user partition (dt='"+inDate+"') SELECT u_diu diu,u_region region,u_act_status act,cc,cc_2 FROM da.user_profile WHERE dt = '"+max_time+"' "
    print user_sql
    spark.sql(user_sql)
    coldfk_sql = "insert overwrite table da.recy_cold_four_topk_pre partition (dt='"+inDate+"') select region, act, cc, cc_2, vid, pv, row_number() over(partition by region,act,cc,cc_2 order by pv desc) as rank from (select region, act, cc, cc_2, vid, count(distinct diu)pv from (select a.*, b.vid from (select * from da.recy_cold_user where dt='"+inDate+"')a join (select d_diu diu, d_vid vid from adm.f_video_vv where dt<='"+inDate+"'and dt>='"+befDate+"'group by d_diu , d_vid )b on (a.diu=b.diu))c group by region, act, cc, cc_2, vid)c where pv >=50"
    print coldfk_sql
    spark.sql(coldfk_sql)
    filter_sql = "INSERT overwrite TABLE da.recy_cold_four_topk partition (dt='"+inDate+"') SELECT a.* FROM (SELECT region, act, cc, cc_2, vid, pv, rank FROM da.recy_cold_four_topk_pre WHERE dt='"+inDate+"')a LEFT OUTER JOIN (SELECT vid FROM (SELECT vid FROM dw.video WHERE (status <> 0 OR uid=0 OR TYPE=9 OR (CASE WHEN TYPE='10' THEN datediff('"+inDate+"',to_date(createtime))>1 end) OR (parent_category IN ('65', '55', '54', '53', '47') AND uid NOT IN ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188'))) UNION ALL SELECT vid FROM dw.video_recommend WHERE TYPE=1) b GROUP BY vid)c ON a.vid = c.vid WHERE c.vid IS NULL"
    print filter_sql
    spark.sql(filter_sql)

    #AND cc NOT IN ('48','49','50','51','52','56','57','59','66','67','68','69','70','73','76','77','78','79') AND cc_2 NOT IN ('48','49','50','51','52','56','57','59','66','67','68','69','70','73','76','77','78','79') 
    
    #sql1 = "INSERT overwrite TABLE da.recy_cold_four_topk partition (dt='"+inDate+"') SELECT * FROM (SELECT a.region region, b.act act, c.cc cc1, c.cc_2 cc_2, d.vid vid, e.hits_total hits_total, row_number() over(partition BY a.region,b.act,c.cc,c.cc_2 ORDER BY e.hits_total DESC) AS rank FROM (SELECT u_diu diu, u_region region FROM da.user_profile_device_location WHERE dt = '"+inDate+"') a JOIN (SELECT u_diu diu, CASE WHEN u_act_status<-5 THEN -5 WHEN u_act_status<=5 AND u_act_status>=-5 THEN u_act_status WHEN u_act_status>5 THEN 5 END AS act FROM da.user_profile_device_act WHERE dt = '"+max_time+"') b ON a.diu = b.diu JOIN (SELECT diu, cc, cc_2 FROM da.user_profile_interest_vcat WHERE dt = '"+inDate+"')c ON a.diu=c.diu JOIN (SELECT diu, vid FROM da.mid_video_cmpv WHERE dt <= '"+inDate+"'AND dt >= date_sub('"+inDate+"',30) GROUP BY diu, vid)d ON a.diu = d.diu JOIN (SELECT vid, hits_total FROM dw.video WHERE child_category NOT IN ('48','49','50','51','52','56','57','59','66','67','68','69','70','73','76','77','78','79') AND status = 0 AND hits_total >=3000 )e ON d.vid= e.vid GROUP BY a.region, b.act, c.cc, c.cc_2, d.vid, e.hits_total) g WHERE rank<=150"
    # print sql1
    # recdf = spark.sql(sql1)
    # spark.stop()

    # #用户所属的四个维度类别
    # spark = SparkSession.builder.appName('recy_cold_user:' + inDate).config(
    #     'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    # user_sql = "INSERT overwrite TABLE da.recy_cold_user partition (dt='"+inDate+"') SELECT c.diu diu, f.region region, g.act, c.cc, c.cc_2 FROM (SELECT if(b.diu IS NOT NULL,b.diu,a.diu) diu, if(b.diu IS NOT NULL,b.cc,a.cc) cc, if(b.diu IS NOT NULL,b.cc_2,a.cc_2) cc_2 FROM (SELECT diu, cc, cc_2 FROM da.recy_cold_user WHERE dt = date_sub('"+inDate+"',1) AND cc NOT IN ('48','49','50','51','52','56','57','59','66','67','68','69','70','73','76','77','78','79')) a FULL OUTER JOIN (SELECT diu, cc, cc_2 FROM da.user_profile_interest_vcat WHERE dt = '"+inDate+"'AND cc NOT IN ('48','49','50','51','52','56','57','59','66','67','68','69','70','73','76','77','78','79')) b ON a.diu = b.diu) c JOIN (SELECT if(e.diu IS NOT NULL,e.diu,d.diu) diu, if(e.diu IS NOT NULL,e.region,d.region) region FROM (SELECT diu, region FROM da.recy_cold_user WHERE dt = date_sub('"+inDate+"',1)) d FULL OUTER JOIN (SELECT u_diu diu, u_region region FROM da.user_profile_device_location WHERE dt = '"+inDate+"') e ON d.diu = e.diu) f ON c.diu = f.diu JOIN (SELECT u_diu diu, CASE WHEN u_act_status<-5 THEN -5 WHEN u_act_status<=5 AND u_act_status>=-5 THEN u_act_status WHEN u_act_status>5 THEN 5 END AS act FROM da.user_profile_device_act WHERE dt = '"+max_time+"') g ON c.diu = g.diu"
    # print user_sql
    # recdf = spark.sql(user_sql)
    spark.stop()


