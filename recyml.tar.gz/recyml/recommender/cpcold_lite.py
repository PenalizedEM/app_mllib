#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 8

"""
CP cold start.
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer
import random
from pyspark.sql.functions import lit,rand,explode

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

def moreVid(vidList):
    try:
        kEle = 10
        if(len(vidList)>kEle):
            #vidbig = ','.join(str(x) for x in random.sample(vidList, kEle))
            vidbig = map(str,random.sample(vidList, kEle))
            return vidbig
    except Exception as e:
        pass

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    coldDate=handleDatePath(sys.argv,'%Y-%m-%d',30)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_lite_video_cpcold:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=1000")
    #random.uniform(0, 1)
    #插入一条新CP的新视频
    #vidSql = "SELECT vid from (select a.uid,a.vid,a.createtime, ROW_NUMBER() over (partition by uid order by createtime desc)rn from (SELECT uid,vid,createtime  FROM dw.video WHERE parent_category IN ('65', '55', '54', '53', '47') and to_date(createtime)>='"+coldDate+"' and to_date(createtime)<='"+inDate+"' and hits_total<=3 group by uid,vid,createtime)a join (select id,regtime from dw.user where to_date(regtime)>='"+coldDate+"' and to_date(regtime) <= '"+inDate+"' )b on(a.uid = b.id) group by a.uid,a.vid,a.createtime)b where b.rn=1 limit 1000"
    vidSql = "SELECT vid FROM (SELECT a.uid, a.vid, a.createtime, ROW_NUMBER() over (partition BY uid ORDER BY createtime DESC)rn FROM (SELECT uid, vid, createtime FROM dw.video WHERE TYPE=10 AND status=0 AND to_date(createtime)='"+inDate+"'GROUP BY uid, vid, createtime ORDER BY createtime DESC)a JOIN (SELECT id, regtime FROM dw.user WHERE to_date(regtime)>='"+coldDate+"'AND to_date(regtime)<='"+inDate+"')b on(a.uid = b.id) GROUP BY a.uid, a.vid, a.createtime)b WHERE b.rn<=15 LIMIT 1000"
    vidList = spark.sql(vidSql).rdd.map(lambda x :(x['vid'])).collect()
    #print len(vidList)
    print moreVid(vidList)
    #取出所有用户，随机赋值新视频K条
    finalSQL = " SELECT diu from da.recy_final_out_topk where dt='"+inDate+"' group by diu"
    finalDF = spark.sql(finalSQL)
    cpRDD = finalDF.rdd.map(lambda x :(x['diu'],moreVid(vidList)))
    #print cpRDD.take(50)
    cpDF = spark.createDataFrame(cpRDD,['diu','vid']).withColumn("vid", explode("vid"))
    cpDF.createOrReplaceTempView("cpfinal")
    #cpDF.show()
    cpDF.printSchema()
    spark.sql("SET spark.sql.shuffle.partitions=100")
    # #合并新CP和Matching阶段数据
    tTopKSQL = "INSERT OVERWRITE TABLE da.recy_lite_video_cpcold partition(dt='"+inDate+"') SELECT diu , a.vid AS vid, title, pic, short_title, hits_total, comment_total, createtime FROM (SELECT diu, vid FROM cpfinal)a JOIN (SELECT vid, title, pic, short_title, hits_total, comment_total, createtime FROM dw.video)b ON (a.vid = b.vid)"
    tTopkDF = spark.sql(tTopKSQL)



    # ffSQL = "SELECT a.* from (select * from  onefinal )a left outer join (select diu ,vid  from da.recy_final_out_topk where dt>='"+filterDate+"' and dt<'"+inDate+"' group by diu,vid)b  on (a.diu=b.diu and a.vid=b.vid) where b.diu is null"
    # ffDF = spark.sql(ffSQL)
    # #print fTopkDF.count()
    # # topk.printSchema()
    # # topk.show()
    # # print "count ",topk.count()
    # topkPath = "hdfs://Ucluster/olap/da/recy_final_out_topk/"+inDate+"/"
    # ffDF.repartition(500).write.mode('overwrite').save(topkPath, format="parquet")
    spark.stop()
