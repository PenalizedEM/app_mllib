#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 21 2017

"""
Export data to redis

"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_final_out_topk_redis:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=400")

    #拼接转化导入redis
    topkSql="INSERT OVERWRITE TABLE da.recy_final_out_topk_redis partition(dt='"+inDate+"') SELECT diu,vid,rn from (SELECT diu,vid,pp, ROW_NUMBER() over (partition by diu order by pp desc)rn FROM da.recy_ltr_predict WHERE  dt='"+inDate+"' AND pp>=0.15)a"

    # #拼接转化导入redis
    #    topkSql="INSERT OVERWRITE TABLE da.recy_final_out_topk_redis partition(dt='"+inDate+"') SELECT diu,vid,rn from (SELECT diu,vid,prediction, ROW_NUMBER() over (partition by diu order by createtime desc)rn FROM da.recy_final_out_topk WHERE diu != '000000000000000' AND dt='"+inDate+"' AND prediction>0 )a"
    #topkSql =  "select a.u_diu as diu,a.u_vid as vid,round(if(prediction>5,5,prediction),1) prediction,b.title,b.pic,b.short_title,b.hits_total,b.comment_total from (select u_diu,u_vid,prediction from da.recy_als_prediction where dt='"+inDate+"' and prediction >= 3.5)a join (select vid,title,pic,short_title,hits_total,comment_total from dw.video)b on (a.u_vid = b.vid) "
    topk = spark.sql(topkSql)
    spark.stop()
