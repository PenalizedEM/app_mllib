#!/usr/bin/python
# -*- coding: UTF-8 -*-
# created  by vent @ Dec 8
# edited by vent @ Apr 12
"""
Recommend top k videos to user.

"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer
import random
from pyspark.sql.functions import lit

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    filterDate = handleDatePath(sys.argv,'%Y-%m-%d',3)
    createDate= handleDatePath(sys.argv,'%Y-%m-%d',365)

    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_final_out_topk:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=1200")
    #融合两种算法模型输出结果，限制每个作者最多三条，取排名前500
    # topkSql="select diu , vid, prediction, title, pic, short_title, hits_total, comment_total, createtime from ( select * , ROW_NUMBER() over (partition by diu order by prediction desc) rank from (select a.*, ROW_NUMBER() over (partition by diu,uid order by prediction desc) rn from (select * from da.recy_als_out_topk where dt='"+inDate+"' union all select * from da.recy_icf_out_topk where dt='"+inDate+"') a join dw.video b on (a.vid = b.vid) ) b where rn<=4 ) c where rank<=500"
    topkSql = "select diu , vid, prediction, '' title, '' pic, '' short_title, 0 as hits_total, 0 as comment_total, '' createtime from (select * , ROW_NUMBER() over (partition by diu order by prediction desc) rank from (select a.*, ROW_NUMBER() over (partition by diu,uid order by prediction desc) rn from (select diu, vid, max(prediction) prediction from (select diu, vid, prediction from da.recy_als_out_topk where dt='" + inDate + "'union all select diu, vid, prediction from da.recy_icf_out_topk where dt='" + inDate + "'union all select diu, vid, prediction from da.recy_siucf_recommend union all select diu, vid, prediction from da.recy_ucf_out_topk) aa group by diu, vid) a join (select vid, uid from dw.video where !(status <> 0 or uid=0 or type=9 or (parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188'))) and to_date(createtime)>='"+createDate+"') b on(a.vid=b.vid)) b where rn<=6) c where rank<=400"
    topk = spark.sql(topkSql)
    #topk.printSchema()
    #print topk.count()
    topk.createOrReplaceTempView("onefinal")

    #################################################################
    ##### 20170611 注释掉cp的融合 小视频cp刷入redis 暂时在服务端融合
    #################################################################
    # # #合并冷启动和算法推荐阶段数据
    # spark.sql("SET spark.sql.shuffle.partitions=1200")
    # tTopKSQL = "SELECT  diu , vid, max(prediction)prediction, title, pic, short_title, hits_total, comment_total, createtime from (SELECT diu , vid, prediction, title, pic, short_title, hits_total, comment_total, createtime from da.recy_als_out_cpcold where dt='"+inDate+"' union all select diu , vid, prediction, title, pic, short_title, hits_total, comment_total, createtime from onefinal ) group by  diu , vid, title, pic, short_title, hits_total, comment_total, createtime"
    # tTopkDF = spark.sql(tTopKSQL)
    # #print tTopkDF.count()
    # tTopkDF.createOrReplaceTempView("tfinal")


    #################################################################
    ##### 20170611 注释生活类视频的强制分发
    #################################################################
    # # 根据用户近30天最常看/喜欢的生活类视频类别,给用户强插入3条其喜欢生活类别下的前一天的热门视频,分值取3~5随机
    # liveHotSql = "select   diu, child_category, vid, uv, rank, cast(3+rand()*2 as float) rating from (select diu, cc from da.user_profile_interest_vcat where dt='"+inDate+"'and pc in ('65', '55', '54', '53', '47') ) a join (select * from (select b.vid, child_category, uv, ROW_NUMBER() OVER (PARTITION by child_category order by uv desc) rank from ( select vid, child_category, uv from da.recy_cat_uv01d where dt='"+inDate+"') b join (   select vid from dw.video where child_category not in ('0', '3') and parent_category in ('65',  '55', '54', '53', '47') ) c on (b.vid=c.vid) ) d where rank<=3 )  e on(a.cc=e.child_category)"
    # print liveHotSql
    # topk = spark.sql(liveHotSql)
    # topk.createOrReplaceTempView("livehot")
    # # 过滤插入的3条生活热门视频中,用户看过的
    # liveHotFilterSql = "select c.diu, c.vid, rating prediction , title, pic , short_title, hits_total, comment_total, createtime from (select a.* from livehot a left outer join da.recy_cf_rating_online b on (a.diu=b.diu  and a.vid=b.vid) where b.diu is null ) c join (select * from dw.video where status=0) e on(c.vid=e.vid)"
    # print liveHotFilterSql
    # topk = spark.sql(liveHotFilterSql)
    # topk.createOrReplaceTempView("livehotfilter")

    # #最后过滤过去N天推荐过的视频 融合插入的3条生活热门视频
    # spark.sql("SET spark.sql.shuffle.partitions=1200")
    # ffSQL = "select diu, vid, max(prediction) prediction, title, pic, short_title, hits_total, comment_total, createtime from (select a.* from (select * from tfinal)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='"+filterDate+"'and dt<'"+inDate+"'group by diu, vid)b on (a.diu=b.diu and a.vid=b.vid) where b.diu is null union all select * from livehotfilter ) a group by diu, vid, title, pic, short_title, hits_total, comment_total, createtime"

    spark.sql("SET spark.sql.shuffle.partitions=1200")
    # ffSQL = "select a.* from (select * from onefinal)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='"+filterDate+"'and dt<'"+inDate+"'group by diu, vid)b on (a.diu=b.diu and a.vid=b.vid) where b.diu is null"
    ffSQL = "select e.* from (select c.* from (select a.* from (select * from onefinal)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='" + filterDate + "'and dt<'" + inDate + "'group by diu, vid)b on (a.diu=b.diu and a.vid=b.vid) where b.diu is null) c left outer join da.recy_cf_rating_online d on (c.diu=d.diu and c.vid=d.vid) where d.diu is null ) e left outer join (SELECT vid FROM dw.video_recommend WHERE type=1 ) f on(e.vid=f.vid) where f.vid is null"
    print ffSQL
    ffDF = spark.sql(ffSQL)
    ffDF.printSchema()
    topkPath = "hdfs://Ucluster/olap/da/recy_final_out_topk/"+inDate+"/"
    ffDF.repartition(600).write.mode('overwrite').save(topkPath, format="parquet")
    spark.stop()
