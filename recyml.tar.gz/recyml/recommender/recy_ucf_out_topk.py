#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
big and lite video similarity

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)


    ################# similarity topn compute
    spark = SparkSession.builder.master('yarn-client').appName('recy_ucf_out_topk:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    dropTabSqlBig = "drop table if exists da.recy_ucf_out_topk "
    print dropTabSqlBig
    spark.sql(dropTabSqlBig)
    simMidSqlBig = "create table da.recy_ucf_out_topk as select diu_1 diu, vid, rating*similarity prediction from (select diu_1, diu_2, similarity from da.recy_ucf_similarity_topn where rank<=30 ) a join (select diu, vid, rating from (select diu, vid ,rating, ROW_NUMBER() OVER (PARTITION by diu order by rating, uv desc) rank from da.recy_ucf_rating ) b where rank<=10 ) b on(a.diu_2=b.diu)"
    print simMidSqlBig
    spark.sql(simMidSqlBig)
