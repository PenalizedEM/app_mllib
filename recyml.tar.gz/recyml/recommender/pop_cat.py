#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 10 2017

"""
 按类别划分热门视频
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
	print sys.argv
	reload(sys)
	sys.setdefaultencoding('utf-8')
	inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	oDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	sDate=handleDatePath(sys.argv,'%Y-%m-%d',7)
	tDate=handleDatePath(sys.argv,'%Y-%m-%d',30)
	print "popDate  ",inDate
	print "1Day  ",oDate
	print "7Days  ",sDate
	print "30Days  ",tDate
	spark = SparkSession.builder.master('yarn-client').appName('pop_cat:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
	#POP(item) = ( w1*num_7(item) + w2*num_30(item) + w3*num_90(item) ) / ( sign(num_7(item)) + sign(num_30(item)) + sign(num_90(item)) )
	#其中，w1 = 1/7, w2 = 1/30, w3 = 90为权重系数，可以调整；当x>0时，sign(x)=1；否则sign(x)=0。
	#根据我们的情况改为7days,30days,90days
	#先生成一个简单模型，后续加入用户画像模型
	#outPath = "hdfs://Ucluster/olap/da/recy_als_out_pop/"+inDate+"/"
	w1 = 1
	w2 = 1/7
	w3 = 1/30
	mdSql = "from (select * from dw.uabigger where dt>='"+tDate+"' and  dt<='"+inDate+"')a insert overwrite table da.recy_uv01d PARTITION (dt='"+inDate+"') select u_vid,count(distinct u_diu)uv where dt>='"+oDate+"' and  dt<='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' group by u_vid order by uv desc limit 5000 insert overwrite table da.recy_uv07d PARTITION (dt='"+inDate+"') select u_vid,count(distinct u_diu)uv where dt>='"+sDate+"' and  dt<='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' group by u_vid order by uv desc limit 5000 insert overwrite table da.recy_uv30d PARTITION (dt='"+inDate+"') select u_vid,count(distinct u_diu)uv where dt>='"+tDate+"' and  dt<='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' group by u_vid order by uv desc limit 5000"
	mdDF = spark.sql(mdSql)
	popSql = "insert overwrite table da.recy_als_out_pop PARTITION (dt='"+inDate+"') select j.vid,j.pop,j.datebuf,k.title,k.pic,k.short_title,k.hits_total,k.comment_total,k.createtime from (select vid,(pop/(sign01d+sign07d+sign30d))pop,'"+inDate+"'datebuf from (select vid,(1*uv01d+1/7*uv07d+1/30*uv30d)pop,if(uv01d>0,1,0)sign01d,if(uv07d>0,1,0)sign07d,if(uv30d>0,1,0)sign30d from (select if(c.vid is null,d.vid,c.vid)vid,if(c.uv01d is null,0,c.uv01d)uv01d,if(c.uv07d is null,0,c.uv07d)uv07d,if(d.uv is null,0,d.uv)uv30d from (select if(a.vid is null,b.vid,a.vid)vid,if(a.uv is null,0,a.uv)uv01d,if(b.uv is null,0,b.uv)uv07d from  (select * from da.recy_uv01d where dt='"+inDate+"')a full outer join (select * from da.recy_uv07d where dt='"+inDate+"')b on(a.vid=b.vid))c full outer join (select * from da.recy_uv30d where dt='"+inDate+"')d on (c.vid = d.vid))e)f order by pop desc limit 300)j join (select vid,title,pic,short_title,hits_total,comment_total,createtime from dw.video where  status=0 )k on (j.vid = k.vid)"
	popDF = spark.sql(popSql)
	#spark.sql("dfs -touchz /olap/da/recy_als_out_pop/dt=${inDate}/_SUCCESS")
	# popDF.printSchema()
	# popDF.show()
	#popDF.repartition(20).write.mode('overwrite').save(outPath, format="text")
	#addPartSql = "ALTER TABLE da.recy_als_out_pop ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_als_out_pop/"+inDate+"/'"
	#print addPartSql
	#spark.sql(addPartSql)
	spark.stop()
	# print uvmDF.count()
