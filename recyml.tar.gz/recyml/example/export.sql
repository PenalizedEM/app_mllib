export --connect jdbc:mysql://10.10.243.51:3306/2016hd?tinyInt1isBit=false --username root --password tangdouapp#123 --table push_list --columns t_uid,uid,client,version,xinge,signdate --export-dir /user/hive/warehouse/da.db/push_talent_fans --staging-table push_list_stage --clear-staging-table --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 1 




export --connect jdbc:mysql://10.10.34.125:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table recycold --columns vid,pop,datebuf,title,pic,short_title,hits_total,comment_total,createtime --export-dir /olap/da/recy_als_out_pop/dt=${datebuf}/ --staging-table recycoldstage --clear-staging-table --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 1 


CREATE TABLE `recycold` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID主键自增',
  `vid`   varchar(50)  COMMENT '视频id',
   `pop`  double COMMENT '流行程度',
    `datebuf`  varchar(20) COMMENT '日期',
    `title`   varchar(250) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT  '视频标题',
    `pic` varchar(150) COMMENT '视频标图',
    `short_title` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT  '推荐语',
    `hits_total` INT COMMENT '播放次数',
    `comment_total` INT COMMENT '评论次数',
    `createtime` varchar(30) COMMENT '创建时间',
 	PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4
