#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.feature import VectorAssembler,StringIndexer,OneHotEncoder
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
from pyspark.mllib.util import MLUtils
from pyspark.ml.linalg import Vector as MLVector, Vectors as MLVectors
from pyspark.mllib.linalg import Vector as MLLibVector, Vectors as MLLibVectors
from pyspark.mllib.regression import  LabeledPoint
import subprocess

#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#删除HDFS上指定特征目录
def delOldDir(path):
    args_list = ['hadoop', 'fs', '-rmr', path]
    #用HDFS命令去判断
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
    proc.communicate()
    print proc.returncode
    ##返回0代表已经删除

##取table表中最大分区的时间
def max_dt(table,spark):
    recdf = spark.sql("show partitions "+table)
    res = recdf.rdd.map(lambda v: v.result).collect()
    max_time = max(res)
    return max_time[-10:]

#特征转换
def vecTrans(rawList,noList,df):
    vecList = list()
    vecList.extend(noList)
    for raw in rawList:
        vec = raw+"_vec"
        encode = OneHotEncoder(inputCol=raw, outputCol=vec)
        df = encode.transform(df)
        vecList.append(vec) 
    assembler = VectorAssembler(inputCols=vecList, outputCol="features")
    output = assembler.transform(df)
    return output
#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    exDate = handleDatePath(sys.argv,'%Y-%m-%d',30)
    print inDate
    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-rank-features:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=400")
    #item特征
    itemSQL = "SELECT c.*, hash(c.vid)f_vid, CASE WHEN d.flower_uv IS NULL OR d.flower_uv <=0 THEN 0 WHEN d.flower_uv =1 THEN 1 WHEN d.flower_uv >1 AND d.flower_uv <= 5 THEN 2 WHEN d.flower_uv > 5 AND d.flower_uv<= 10 THEN 3 WHEN d.flower_uv > 10 AND d.flower_uv <=20 THEN 4 WHEN d.flower_uv > 20 AND d.flower_uv <= 40 THEN 5 WHEN d.flower_uv >40 AND d.flower_uv <= 80 THEN 6 WHEN d.flower_uv >80 AND d.flower_uv <=150 THEN 7 ELSE 8 END AS floweruv_level FROM (SELECT a.*, if(b.fav_count_level IS NULL,0,b.fav_count_level)fav_count_level FROM (SELECT vid, CASE WHEN hits_total IS NULL THEN 0 WHEN hits_total >=0 AND hits_total <=50 THEN 1 WHEN hits_total >50 AND hits_total <=100 THEN 2 WHEN hits_total > 100 AND hits_total <= 500 THEN 3 WHEN hits_total > 500 AND hits_total <= 40000 THEN 4 ELSE 5 END AS hits_level, CASE WHEN comment_total IS NULL THEN 0 WHEN comment_total >=0 AND comment_total <=5 THEN 1 WHEN comment_total >5 AND comment_total <=10 THEN 2 WHEN comment_total > 10 AND comment_total <= 60 THEN 3 WHEN comment_total > 60 AND comment_total <= 300 THEN 4 ELSE 5 END AS comment_level, CASE WHEN SHARE IS NULL THEN 0 WHEN SHARE >=0 AND SHARE <=5 THEN 1 WHEN SHARE >5 AND SHARE <=10 THEN 2 WHEN SHARE > 10 AND SHARE <= 20 THEN 3 WHEN SHARE > 20 AND SHARE <= 50 THEN 4 ELSE 5 END AS share_level, CASE WHEN duration IS NULL THEN 0 WHEN duration >=0 AND duration <=90 THEN 1 WHEN duration >90 AND duration <=300 THEN 2 ELSE 3 END AS duration_level, if(cast(cast(coderate AS int)/256 AS int) IS NULL,0,cast(cast(coderate AS int)/256 AS int))coderate, if(definition IS NULL,0,definition)definition, if(uid IS NULL,0,uid)uid, if(type IS NULL,0,type)type, if(child_category IS NULL,0,child_category)child_category, if(degree IS NULL,0,degree)degree, if(genre IS NULL,0,genre)genre, if(parent_category IS NULL,0,parent_category)parent_category FROM dw.video)a LEFT OUTER JOIN (SELECT vid, CASE WHEN fav_count IS NULL OR fav_count<1 THEN 0 WHEN fav_count =1 THEN 1 WHEN fav_count >1 AND fav_count<=10 THEN 2 WHEN fav_count>10 AND fav_count<= 20 THEN 3 WHEN fav_count>20 AND fav_count<=50 THEN 4 WHEN fav_count>50 AND fav_count<=100 THEN 5 WHEN fav_count>100 AND fav_count<=500 THEN 6 ELSE 7 END AS fav_count_level FROM (SELECT vid, count(1)fav_count FROM dw.fav GROUP BY vid)k)b on(a.vid = b.vid))c LEFT OUTER JOIN (SELECT vid, count(1)flower_uv FROM dw.flower_video GROUP BY vid)d on(c.vid = d.vid)"
    itemDF = spark.sql(itemSQL)
    itemDF.printSchema()
    itemDF.show()
    itemDF.createOrReplaceTempView("item")
    
    # #用户特征
    #避免用户画像任务失败，使用最大分区
    table = "da.user_profile"
    maxPar = max_dt(table,spark)
    userSQL = "SELECT u_diu AS diu, hash(u_diu)f_diu, if(u_act_status IS NULL,0,u_act_status)u_act_status,if(u_actperiod IS NULL,0,u_actperiod)u_actperiod, if(u_citylevel IS NULL,0,u_citylevel)u_citylevel, if(u_wvdur_range IS NULL,0,u_wvdur_range)u_wvdur_range, if(u_wvcnts_range IS NULL,0,u_wvcnts_range)u_wvcnts_range, if(cc IS NULL,0,cc)u_cc, if(cc_2 IS NULL,0,cc_2)u_cc2, if(u_osv IS NULL,0,u_osv)u_osv, if(cast(u_client AS int) IS NULL,0,cast(u_client AS int))u_client, CASE WHEN u_fresh IS NULL THEN 0 WHEN u_fresh>=0 AND u_fresh<=7 THEN 1 WHEN u_fresh >7 AND u_fresh <=30 THEN 2 WHEN u_fresh>30 AND u_fresh<=90 THEN 3 WHEN u_fresh >90 AND u_fresh<=180 THEN 4 WHEN u_fresh>180 AND u_fresh<=360 THEN 5 ELSE 6 END AS u_fresh_level, CASE WHEN u_active IS NULL THEN 0 WHEN u_active=1 THEN 1 WHEN u_active>1 AND u_active<=7 THEN 2 WHEN u_active>7 AND u_active<=14 THEN 3 WHEN u_active>14 AND u_active<=30 THEN 4 WHEN u_active>30 AND u_active<=90 THEN 5 WHEN u_active>90 AND u_active<=180 THEN 6 ELSE 7 END AS u_active_level FROM da.user_profile WHERE dt='"+maxPar+"'"
    userDF = spark.sql(userSQL)
    userDF.printSchema()
    userDF.show()
    userDF.createOrReplaceTempView("user")

    #曝光点击生成label数据
    exclickSQL = "SELECT a.diu, cast(a.vid as int)vid ,if(a.m_pv IS NULL,0,a.m_pv)ex,if(b.m_pv IS NULL,0,1)label from (SELECT diu,vid,m_pv from da.mid_video_ex where  dt<='"+inDate+"' AND dt>='"+exDate+"' )a left outer  join (SELECT diu,vid,m_pv from da.mid_video_cmpv where  dt<='"+inDate+"' AND dt>='"+exDate+"' )b on(a.diu = b.diu and a.vid = b.vid) group by a.diu,a.vid,a.m_pv,b.m_pv"
    exclickDF = spark.sql(exclickSQL)
    exclickDF.createOrReplaceTempView("exclick")
    exclickDF.printSchema()
    exclickDF.show()

    #关联
    joinSQL = "SELECT c.*,d.f_diu,d.u_act_status,d.u_actperiod,d.u_citylevel,d.u_wvdur_range,d.u_wvcnts_range,d.u_cc,d.u_cc2,d.u_osv,d.u_client,d.u_fresh_level,d.u_active_level  from (SELECT a.diu,a.label,b.* from (SELECT diu, vid, label FROM exclick)a JOIN (SELECT *  FROM item)b ON (a.vid = b.vid))c join (SELECT * from user)d on (c.diu = d.diu)"
    joinDF = spark.sql(joinSQL)
    joinDF.printSchema()
    joinDF.show()
    outPath = "hdfs://Ucluster/test/ltrfeature/" + inDate + "/"
    joinDF.write.mode('overwrite').save(outPath, format="parquet")
    # joinDF.createOrReplaceTempView("ltrfe")
    # #分层采样
    # rateSql =  "SELECT diu,vid,f_vid,f_diu,itfeatures,usfeatures,label FROM (SELECT *, count(*) over (partition BY hash(diu)) AS st_count, rank() over (partition BY hash(diu) ORDER BY rand()) AS rank1 FROM ltrfe WHERE label = 0)a WHERE rank1 <= 0.05 * st_count UNION ALL SELECT diu,vid,f_vid,f_diu,itfeatures,usfeatures,label FROM FROM ltrfe WHERE label = 1"
    # ltrData = spark.sql(rateSql)
    spark.stop()



    