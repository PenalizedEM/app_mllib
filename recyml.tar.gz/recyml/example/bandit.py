import numpy as np
import pymc
def naive(estimated_beta_params,number_to_explore=100):  
   totals = estimated_beta_params.sum(1) # totals  
   if np.any(totals < number_to_explore): # if have been explored less than specified  
       least_explored = np.argmin(totals) # return the one least explored  
       return least_explored  
   else: # return the best mean forever  
       successes = estimated_beta_params[:,0] # successes  
       estimated_means = successes/totals # the current means  
       best_mean = np.argmax(estimated_means) # the best mean  
       return best_mean

#def thompsion():

if __name__ == "__main__":
	pc = np.argmax(pymc.rbeta(1 + successes, 1 + totals - successes))  
	choice = numpy.argmax(pymc.rbeta(1 + self.wins, 1 + self.trials - self.wins))
	print pc