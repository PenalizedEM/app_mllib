#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Jan 19 2017
"""
循环排序
"""

#主入口
if __name__ == "__main__":
	#tp是存储diu和最后一次的页码数
	tp = ('800001111','1')
	## 推荐接口调用
	if recyCall:
		tp[1] += 1
		tp[1] = resetPage(tp[1])
	#首页接口调用
	else mainStart:
		tp[1] += 2
		tp[1] = resetPage(tp[1])

# 页码大于9将重置
def resetPage(pages):
	if pages > 9 :
		pages = pages - 10


