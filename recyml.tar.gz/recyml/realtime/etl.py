#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Jan 23 2017


"""
Raw data real time etl. only apply to some mod/ac
"""
import sys
import json
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
import re
import dateutil.parser
from datetime import datetime,date, timedelta
from dateutil import tz
#读入JSON到Dict
def readJson(line):
    global allLines,jleLines,jpeLines,uaList,uaIntList
    uaDict = dict((el,"") for el in uaList)
    try:
        data = json.loads(line)
        #处理Logstash codec错误的数据
        if data.get('tags',""):
            regex = re.compile(r'\\(?![/u"])')
            fixed = regex.sub(r"\\\\", data['message'])
            data = json.loads(fixed)
            jpeLines +=1
        #只处理正确编码日志
        #生成 request dictionary
        #else:
        data.pop('path',None)
        data.pop('@version',None)
        reqStr=data.pop('request',None)
        uaDict = etlOther(data,uaDict)
        uaDict = etlRequest(reqStr,uaDict)
        allLines += 1
    except:
        jleLines +=1
    return uaDict
    #return data


#解析、清洗、转换日志的非request部分
def etlOther(otherDict,uaDict):
    #cleanOtherDict = dict()
    #将ISO8601时间转换成本地时间
    global opeLines
    try:
        otherDict['timestamp']=isoStr2utc8Str(otherDict.pop('@timestamp'))
        #print otherDict['timestamp']
        #相应时间转换成毫秒
        if  otherDict['backtime'] !='-':
            otherDict['backtime']= str(float(otherDict['backtime'])*1000)
            otherDict['responsetime']= str(float(otherDict['responsetime'])*1000)
        else:
            otherDict['backtime']= str(0.0)
        #遍历字典，更换新key,有更干净做法？
        for key in otherDict:
            newKey = "u_"+key.lower()
            uaDict[newKey]= otherDict[key]
        #清空旧字典
        otherDict.clear()
        #print cleanOtherDict
    except ValueError as ve:
        #print "\skipping otherDict ve:", json.dumps(otherDict['backtime'])
        opeLines +=1
    except TypeError as te:
        #print te
        #print "\skipping uaDict te: ", uaDict
        opeLines +=1
    finally:
        return uaDict

#解析、清洗、转换日志的request部分
def etlRequest(reqItem,uaDict):
    #reqDict = dict()
    global rpeLines
    bigjsonDict = dict()
    #1. request值先按照空格分割得到四部分: (http_method) (http_uri)?(http_para) (http_verb)
    #每条日志都应该匹配上并正确切分成4部分。
    try:
        pattern = re.compile('(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.1)')
        mat =re.match(pattern,reqItem)
        if mat is not None and len(mat.groups())==4:
            uaDict['u_method'] = mat.group(1)
            uaDict['u_url'] = mat.group(2)
            uaDict['u_verb'] = mat.group(4)
            #for mustUa in flatList:
            #uaDict[mustUa] = ""
            #2. 对实际参数做分割,强制转换为小写，加上前缀u_
            reqList = mat.group(3).split('&')
            for reqEle in reqList:
                #if len(reqEle.split('='))==2:
                kvList = reqEle.split('=',2)
                if len(kvList) < 2:
                    kvList.append("")
                uaEle = 'u_'+kvList[0].lower()
                #将u_channel,u_version,u_setpid使用lambda转换成预定义的filed名
                tf = lambda rf:{'u_channel': 'u_dic','u_version': 'u_div','u_setpid':'u_stepid'}.get(rf,rf)
                cleanEle = tf(uaEle)
                if cleanEle in uaDict:
                    uaDict[cleanEle]=kvList[1]
                else:
                    bigjsonDict[cleanEle]=kvList[1]
            uaDict['u_bigger_json']=json.dumps(bigjsonDict)
    except TypeError as te:
        #print "\skipping te:", mat.group(1)
        rpeLines +=1
    finally:
        return uaDict


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat):
    if len(dateList) ==1:
        # yes = date.today() - timedelta(1)
        datePath = (date.today() - timedelta(1)).strftime(dateFormat)
        # print datePath
    elif len(dateList) ==2:
        datePath = datetime.strptime(dateList[1],'%Y-%m-%d').strftime(dateFormat)
        #print datePath
    return datePath

#将传入的ISO8601 时间字符串，转成成指定格式的Local时区字(UTC+8)符串
def isoStr2utc8Str(isoStr):
    #取出timestamp，解析转成iso8601 navie datetime
    utc= datetime.strptime(isoStr,'%Y-%m-%dT%H:%M:%S.%fZ')
    #utc navie datetime设置时区，再换成本地时区，最后解析成字符串。时区可以硬编码。
    utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).replace(tzinfo=None)
    return utc8Time





if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    uaList = ['u_timestamp','u_backtime','u_responsetime','u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_stepid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_page','u_position','u_vid','u_type','u_percent','u_rate','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_download_start','u_download_stop','u_fail_cdn_source','u_new_cdn_source','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
    sc = SparkContext(appName="real_time_etl")
    allLines = sc.accumulator(0)
    jleLines = sc.accumulator(0)
    #json parse error line count
    jpeLines = sc.accumulator(0)
    #request parse error line
    rpeLines = sc.accumulator(0)
    opeLines = sc.accumulator(0)
    timeLines = sc.accumulator(0)
    numberLines = sc.accumulator(0)
    #两秒
    ssc = StreamingContext(sc, 5)
    brokers = "ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092"
    topic = "logstash"
    kvs = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers})
    lines = kvs.map(lambda x : readJson(x[1]))
    lines.pprint()
    print "all line: ",allLines
    print "json load error line",jleLines
    print "json parse error line : ",jpeLines
    print "request parse error line: ",rpeLines
    print "other parse error line: ",opeLines
    print "timestamp empty line", timeLines
    print "number error line", numberLines
    ssc.start()
    ssc.awaitTermination()

