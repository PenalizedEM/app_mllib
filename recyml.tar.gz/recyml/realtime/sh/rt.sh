/data/rtlog
nohup /home/hadoop/spark/bin/spark-submit  --master yarn --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.1.0 --py-files /home/hadoop/user/rt/dateutil.zip,/home/hadoop/user/rt/six.py,/home/hadoop/user/rt/redis.zip --num-executors 10 --executor-cores 7 --executor-memory 6g /home/hadoop/user/rt/litetl.py  &


/data/wslog
nohup /home/hadoop/spark/bin/spark-submit  --master yarn --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.1.0 --py-files /home/hadoop/user/rt/dateutil.zip,/home/hadoop/user/rt/six.py,/home/hadoop/user/rt/redis.zip --num-executors 2 --executor-cores 7 --executor-memory 4g /home/hadoop/user/rt/watchset.py &