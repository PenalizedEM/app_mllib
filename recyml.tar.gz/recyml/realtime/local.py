#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ APr 14 2017


"""
python redis io
"""
import sys
import json
import re
import subprocess

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat):
    if len(dateList) ==1:
        # yes = date.today() - timedelta(1)
        datePath = (date.today() - timedelta(1)).strftime(dateFormat)
        # print datePath
    elif len(dateList) ==2:
        datePath = datetime.strptime(dateList[1],'%Y-%m-%d').strftime(dateFormat)
        #print datePath
    return datePath


def run_cmd():
    yesday = '/olap/da/recy_als_model/2017-04-18/_SUCCESS'
    args_list = ['hadoop', 'fs', '-test', '-f', yesday]
    print('Running system command: {0}'.format(' '.join(args_list)))
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
    proc.communicate()
    print proc.returncode
    return proc.returncode
 


if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    code = run_cmd()
    if code:
        print 'file not exist'
    # sc = SparkContext(appName="redis io")
    # #两秒
    # ssc = StreamingContext(sc, 5)
    # brokers = "ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092"
    # topic = "logstash"
    # kvs = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers})
    # lines = kvs.map(lambda x: x[1])
    # lines.pprint()
    # print "all line: ",allLines
    # print "json load error line",jleLines
    # print "json parse error line : ",jpeLines
    # print "request parse error line: ",rpeLines
    # print "other parse error line: ",opeLines
    # print "timestamp empty line", timeLines
    # print "number error line", numberLines
    # ssc.start()
    # ssc.awaitTermination()

