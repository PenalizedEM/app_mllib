#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Apr 14 2017


"""
Raw data real time etl. only apply to some mod/ac
"""
import sys
import json
from pyspark import SparkContext
from pyspark.streaming import StreamingContext
from pyspark.streaming.kafka import KafkaUtils
import re
import dateutil.parser
from datetime import datetime,date, timedelta
from dateutil import tz
import redis
import ast
import subprocess
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.sql import Row, SparkSession
import random

#读入JSON到Dict
def readJson(line):
    global allLines,jleLines,jpeLines,uaList,uaIntList
    uaDict = dict((el,"") for el in uaList)
    try:
        data = json.loads(line)
        #处理Logstash codec错误的数据
        if data.get('tags',""):
            regex = re.compile(r'\\(?![/u"])')
            fixed = regex.sub(r"\\\\", data['message'])
            data = json.loads(fixed)
            jpeLines +=1
        #只处理正确编码日志
        #生成 request dictionary
        #else:
        data.pop('path',None)
        data.pop('@version',None)
        reqStr=data.pop('request',None)
        uaDict = etlOther(data,uaDict)
        #print uaDict['timestamp']
        uaDict = etlRequest(reqStr,uaDict)
        #someMod = ['emptylog-video_play_speed','emptylog-cdn_download_speed']
        #uaDict = filterSomeMod(someMod,uaDict)
        uaDict = filterSomeMod(uaDict)
        #uaDict = getImfromRedis(uaDict)
        allLines += 1
    except:
        jleLines +=1
    return uaDict
    #return data


#解析、清洗、转换日志的非request部分
def etlOther(otherDict,uaDict):
    #cleanOtherDict = dict()
    #将ISO8601时间转换成本地时间
    global opeLines
    try:
        otherDict['timestamp']=isoStr2utc8Str(otherDict.pop('@timestamp'))
        print otherDict['timestamp']
        #相应时间转换成毫秒
        if  otherDict['backtime'] !='-':
            otherDict['backtime']= str(float(otherDict['backtime'])*1000)
            otherDict['responsetime']= str(float(otherDict['responsetime'])*1000)
        else:
            otherDict['backtime']= str(0.0)
        #遍历字典，更换新key,有更干净做法？
        for key in otherDict:
            newKey = "u_"+key.lower()
            uaDict[newKey]= otherDict[key]
        #清空旧字典
        otherDict.clear()
        #print cleanOtherDict
    except ValueError as ve:
        #print "\skipping otherDict ve:", json.dumps(otherDict['backtime'])
        opeLines +=1
    except TypeError as te:
        #print te
        #print "\skipping uaDict te: ", uaDict
        opeLines +=1
    finally:
        return uaDict

#解析、清洗、转换日志的request部分
def etlRequest(reqItem,uaDict):
    #reqDict = dict()
    global rpeLines
    bigjsonDict = dict()
    #1. request值先按照空格分割得到四部分: (http_method) (http_uri)?(http_para) (http_verb)
    #每条日志都应该匹配上并正确切分成4部分。
    try:
        pattern = re.compile('(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.1)')
        mat =re.match(pattern,reqItem)
        if mat is not None and len(mat.groups())==4:
            uaDict['u_method'] = mat.group(1)
            uaDict['u_url'] = mat.group(2)
            uaDict['u_verb'] = mat.group(4)
            #for mustUa in flatList:
            #uaDict[mustUa] = ""
            #2. 对实际参数做分割,强制转换为小写，加上前缀u_
            reqList = mat.group(3).split('&')
            for reqEle in reqList:
                #if len(reqEle.split('='))==2:
                kvList = reqEle.split('=',2)
                if len(kvList) < 2:
                    kvList.append("")
                uaEle = 'u_'+kvList[0].lower()
                #将u_channel,u_version,u_setpid使用lambda转换成预定义的filed名
                tf = lambda rf:{'u_channel': 'u_dic','u_version': 'u_div','u_setpid':'u_stepid'}.get(rf,rf)
                cleanEle = tf(uaEle)
                if cleanEle in uaDict:
                    uaDict[cleanEle]=kvList[1]
                else:
                    bigjsonDict[cleanEle]=kvList[1]
            uaDict['u_bigger_json']=json.dumps(bigjsonDict)
    except TypeError as te:
        #print "\skipping te:", mat.group(1)
        rpeLines +=1
    finally:
        return uaDict

def filterSomeMod(uaDict):
    modAc = uaDict['u_mod']+'-'+uaDict['u_ac']
    print modAc
    satArr= ['exit','complete']
    liteDict = dict()
    #recyList = ['emptylog-cdn_download_speed','emptylog-share_onclick', 'user-fav','flower-send','top-hits','flower-good','emptylog-video_play_speed']
    recyList = ['emptylog-cdn_download_speed','emptylog-share_onclick', 'flower-send','flower-good']    
    if modAc == "emptylog-video_play_speed"  and uaDict['u_action'] in satArr and uaDict['u_bigger_json']['u_playtime'] >= '10':
        liteDict['diu'] = uaDict['u_diu']
        liteDict['vid'] = uaDict['u_vid']
        return liteDict
    elif modAc in recyList:
        liteDict['diu'] = uaDict['u_diu']
        liteDict['vid'] = uaDict['u_vid']
        return liteDict
    else :
        pass 
    # if modAc == "emptylog-video_play_speed" and uaDict['u_action'] in satArr and uaDict['u_bigger_json']['u_playtime'] >= '15' ,'top-hits':
    #     print uaDict['u_bigger_json']['u_playtime']
    #     liteDict['diu'] = uaDict['u_diu']
    #     liteDict['vid'] = uaDict['u_vid']
    #     return liteDict
    # if modAc == "emptylog-video_play_speed"  and uaDict['u_action'] in satArr and 'u_playtime' in uaDict['u_bigger_json']:
    #     bigjsonDict = ast.literal_eval(uaDict['u_bigger_json'])
    #     play = int(bigjsonDict['u_playtime'])
    #     if play >= 5:
    #         liteDict['diu'] = uaDict['u_diu']
    #         liteDict['vid'] = uaDict['u_vid']
    #         #liteDict['play'] = bigjsonDict['u_playtime']
    #         return liteDict
    # elif modAc in recyList:
    #     liteDict['diu'] = uaDict['u_diu']
    #     liteDict['vid'] = uaDict['u_vid']
    #     #liteDict['play'] = 'down'
    #     return liteDict
    if modAc in recyList:
        liteDict['diu'] = uaDict['u_diu']
        liteDict['vid'] = uaDict['u_vid']
        #liteDict['play'] = 'down'
        return liteDict
    else:
        pass

# 读取相似视频top10
def getTopkfromRedis(x):
    if x['diu'] == '862827032807144':
        print x['diu']
        print x['vid']
    simtopk = '10.19.131.137'
    rc = redis.StrictRedis(host=simtopk, port=6379, db=0)
    topkDay = rc.lrange('simlitetopklistcomplete',0,0)[0]
    allDict = dict()
    try:
        if x is not None and 'diu' in x and 'vid' in x:
            vidkey = topkDay+"||lite||"+x['vid']
            simList = rc.lrange(vidkey,0,-1)
            if len(simList)>0:
                allDict['diu'] = x['diu']
                allDict['vid'] = simList
                return allDict
        else:
            pass
    except Exception, e:
        raise e


# 读取redis idmap
# def getImfromRedis(x,alsday):
#     idmap = '10.19.151.84'
#     rc = redis.StrictRedis(host=idmap, port=6379, db=0)
#     liteDict =  dict()
#     try:
#         if x is not None and 'diu' in x and 'vid' in x:
#             diu = alsday+'||diu||'+x['diu']
#             vid = alsday+'||vid||'+x['vid']
#             fdiu = rc.get(diu)
#             fvid = rc.get(vid)
#             if fdiu is not None and fvid is not None:
#                 liteDict['u_diu'] = x['diu']
#                 liteDict['u_vid'] = x['vid']
#                 liteDict['f_diu'] = fdiu
#                 liteDict['f_vid'] = fvid
#                 print liteDict
#                 return liteDict
#         else:
#             pass
#     except Exception as e:
#         raise e

#检测HDFS上ALS模型是否生成，返回当前使用模型的日期
def detModelSync():
    yesDay = (date.today() - timedelta(1)).strftime('%Y-%m-%d')
    byesDay = (date.today() - timedelta(2)).strftime('%Y-%m-%d')
    yesPath = "hdfs://Ucluster/olap/da/recy_als_model/"+yesDay+"/_SUCCESS"
    args_list = ['hadoop', 'fs', '-test', '-f', yesPath]
    #用HDFS命令去判断
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE)
    proc.communicate()
    print proc.returncode
    ##返回0代表文件存在
    if proc.returncode == 0:
        return yesDay
    else:
        return byesDay


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat):
    if len(dateList) ==1:
        # yes = date.today() - timedelta(1)
        datePath = (date.today() - timedelta(1)).strftime(dateFormat)
        # print datePath
    elif len(dateList) ==2:
        datePath = datetime.strptime(dateList[1],'%Y-%m-%d').strftime(dateFormat)
        #print datePath
    return datePath

#将传入的ISO8601 时间字符串，转成成指定格式的Local时区字(UTC+8)符串
def isoStr2utc8Str(isoStr):
    #取出timestamp，解析转成iso8601 navie datetime
    utc= datetime.strptime(isoStr,'%Y-%m-%dT%H:%M:%S.%fZ')
    #utc navie datetime设置时区，再换成本地时区，最后解析成字符串。时区可以硬编码。
    utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).replace(tzinfo=None)
    return utc8Time


#写入redis
def list2Redis(rdd):
    #链接realtime_userrecy 单一ip有可能链接超时，后续要捕获异常
    # orcList = ["10.19.81.244","10.19.87.5"]
    # orcset = random.choice(orcList)
    # orc = redis.StrictRedis(host=orcset, port=6379, db=0)
    #链接 recyfeed，目前测试realtime_test
    #recyfeed = '10.19.151.84' #to be edited
    recylist=["10.19.137.83","10.19.178.227","10.19.198.54","10.19.26.182","10.19.137.83",
                    "10.19.23.98"]
    diulist =["862827032807144","45C7EF12-8175-4AE8-978D-303941C1B6BA"]
    recyfeed = random.choice(recylist)
    expireTime = 7200
    oneDayTime = 86400
    rc = redis.StrictRedis(host=recyfeed, port=6379, db=0)
    p = rc.pipeline(transaction=False)
    allList = list()
    today = date.today().strftime('%Y-%m-%d')
    #print "2017-td: "+today
    if rdd.isEmpty() is False and rdd is not None:
        #print len(rdd.collect())
        for item in rdd.collect():
            #example {"diu":"8888","vid":["22","222"]}
            #print item
            if item is not None:
                #推荐列表
                diu = item['diu']
                #推荐过的set,diu需要拼接时间
                #olddiu = "Recyed||"+today+"||"+diu
                #直接写入recyset和recylist.服务端判断推荐列表里面是否有曾经推荐过的
                for recy in item['vid']:
                        p.rpush(diu, recy)
                        #p.sadd(olddiu,recy)
                        if diu in  diulist:
                            print "writing: "+diu+" : "+recy
        p.execute()
    #rc.close()
        #         rc.expire(diu,expireTime)
        #         orc.expire(olddiu,oneDayTime)
        # print rc.dbsize()
        #     print item

#单例sparksession
def getSparkSessionInstance(sparkConf):
    if ('sparkSessionSingletonInstance' not in globals()):
        globals()['sparkSessionSingletonInstance'] = SparkSession\
            .builder\
            .config(conf=sparkConf)\
            .getOrCreate()
    return globals()['sparkSessionSingletonInstance']

if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    uaList = ['u_timestamp','u_backtime','u_responsetime','u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_stepid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_page','u_position','u_vid','u_type','u_percent','u_rate','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_download_start','u_download_stop','u_fail_cdn_source','u_new_cdn_source','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
    sc = SparkContext(appName="real_time_etl")
    allLines = sc.accumulator(0)
    jleLines = sc.accumulator(0)
    #json parse error line count
    jpeLines = sc.accumulator(0)
    #request parse error line
    rpeLines = sc.accumulator(0)
    opeLines = sc.accumulator(0)
    timeLines = sc.accumulator(0)
    numberLines = sc.accumulator(0)
    #idmap = '10.19.151.84'
    #rc = redis.StrictRedis(host=idmap, port=6379, db=0)

    #20秒
    ssc = StreamingContext(sc, 15)
    #检测使用哪天的模型，对应哪天的UVM
    #alsday = detModelSync()
    # alsday = '2017-04-23'
    # print "running model date is:  ",alsday
    #modelPath = "hdfs://Ucluster/olap/da/recy_als_model/"+alsday+"/"
    #print modelPath
    #读取ALS模型
    #alsModel = ALSModel.load(modelPath)
    #alsModel = MatrixFactorizationModel.load(sc, modelpath)
    #print alsModel.rank
    #broadModel = sc.broadcast(alsModel)
    #print broadModel.rank()
    brokers = "ukafka-ghz0cc-1-bj01.service.ucloud.cn:9092,ukafka-ghz0cc-1-bj02.service.ucloud.cn:9092,ukafka-ghz0cc-1-bj03.service.ucloud.cn:9092,ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092"
    topic = "logstash"
    kvs = KafkaUtils.createDirectStream(ssc, [topic], {"metadata.broker.list": brokers})
    #lines = kvs.map(lambda x : readJson(x[1])).filter(lambda x: x is not None).map(lambda x: getImfromRedis(x,alsday))
    #lines = kvs.map(lambda x : readJson(x[1])).filter(lambda x: x is not None).map(lambda x: getTopkfromRedis(x,alsday)).map(lambda x: alsPredict(x,alsday))
    lines = kvs.map(lambda x : readJson(x[1])).filter(lambda x: x is not None).map(lambda x: getTopkfromRedis(x))
    #lines.pprint()
    lines.foreachRDD(lambda rdd: list2Redis(rdd))
    #lines.foreachRDD(lambda rdd: rdd.foreachPartition(list2Redis(rdd)))
    #lines.pprint()
    #lines.foreachRDD(lambda rdd: getImfromRedis(rdd,rc))
    #lines.pprint()
    # r = redis.StrictRedis(host='10.19.151.84', port=6379, db=0)
    # def set2Redis(time,rdd): 
    #     if rdd.isEmpty() is False:
    #         for item in rdd.collect():
    #             r.set(item['diu'], item['vid'])
    # lines.foreachRDD(lambda rdd: rdd.foreachPartition(set2Redis)
    ssc.start()
    print "all line: ",allLines
    print "json load error line",jleLines
    print "json parse error line : ",jpeLines
    print "request parse error line: ",rpeLines
    print "other parse error line: ",opeLines
    print "timestamp empty line", timeLines
    print "number error line", numberLines
    ssc.awaitTermination()
