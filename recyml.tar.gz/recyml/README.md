推荐系统数据算法层
=====

### 1. 数据层
#### 1.1 用户视频行为矩阵
* 每日行为迭代表 uvarating
* 历史评分表 uvmerge
* 看过的作者候选集 candya
* tag候选集 candytag
* 最终融合候选集 finalcandy
