#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 6
from math import atan,pi

def normal(x):
    #x = 55.2
    return 5*atan(x)*2/pi

def linenormal(x):
    #x = 55.2
    max = 240.0
    min = 0.0
    if x > max:
    	x = max
    if x < min:
    	x = min
    return 5*(x-min)/(max-min)
#主入口
if __name__ == "__main__":
	print linenormal(180.0)