#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ May 8

"""
 Implementation of LR to rank 
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler,StringIndexer,OneHotEncoder,StandardScaler
from pyspark.ml.evaluation import BinaryClassificationEvaluator

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath
#特征组合以及标准化
def handleVec(rawFeaList,data):
    assembler = VectorAssembler(inputCols=rawFeaList, outputCol="rawfeatures")
    output = assembler.transform(data)
    scaler = StandardScaler(inputCol="rawfeatures", outputCol="features",
                        withStd=True, withMean=False)
    scalerModel = scaler.fit(output)
    scaledData = scalerModel.transform(output)
    return scaledData
#定义Schema
def conSchema(colList):
    colDict = OrderedDict()
    for col in colList:
        colDict[col] = StructField(col, StringType(), True)
    schema = StructType(list(colDict.values()))
    return schema
#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate = sys.argv[1]
    inHour = sys.argv[2]
    exDate = sys.argv[3]
    exHour = sys.argv[4]
    midDate = sys.argv[5]
    print "inDate = ",inDate
    print "inHour = ", inHour
    print "exDate = ", exDate
    print "exHour = ", exHour
    print "midDate = ", midDate

    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_rank_lrmodel:'+inDate+"_"+inHour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=600")
    # #曝光点击生成label数据
    exclickSQL = "SELECT a.diu, a.vid vid , if(a.m_pv IS NULL,0,a.m_pv)ex, if(b.m_pv IS NULL,0,1)label FROM (SELECT d_diu diu, d_vid vid, d_ruuid, sum(m_dv) m_pv FROM dm.f_new_video_dv WHERE ((dt='"+inDate+"'AND hour<='"+inHour+"') OR (dt='"+exDate+"'AND hour >='"+exHour+"') OR (dt='"+midDate+"')) AND d_module IN ('推荐流', '推荐', '每日推荐', '猜你喜欢', '首页推荐流') AND d_diu <> '-'GROUP BY d_diu, d_vid, d_ruuid)a LEFT OUTER  JOIN (SELECT d_diu diu, d_vid vid, d_ruuid, sum(m_vv) m_pv FROM dm.f_new_video_vv WHERE ((dt='"+inDate+"'AND hour<='"+inHour+"') OR (dt='"+exDate+"'AND hour >='"+exHour+"') OR (dt='"+midDate+"')) AND d_module IN ('推荐流', '推荐', '每日推荐', '猜你喜欢', '首页推荐流') AND d_diu <> '-'GROUP BY d_diu, d_vid, d_ruuid)b on(a.diu = b.diu AND a.vid = b.vid AND a.d_ruuid= b.d_ruuid) GROUP BY a.diu, a.vid, a.m_pv, b.m_pv"
    print(exclickSQL)
    exclickDF = spark.sql(exclickSQL)
    exclickDF.createOrReplaceTempView("exclick")
    exclickDF.printSchema()
    exclickDF.show()
    #读取item特征
    itPath = "hdfs://Ucluster/olap/dm/recy_ltr_itfeature/dt="+inDate+"/hour="+inHour+"/"
    itFeaDF = spark.read.parquet(itPath)
    itFeaDF.createOrReplaceTempView("itFea")
    itFeaDF.printSchema()
    itFeaDF.show()
    #读取user特征
    usPath = "hdfs://Ucluster/olap/dm/recy_ltr_usfeature/dt="+inDate+"/hour="+inHour+"/"
    usFeaDF = spark.read.parquet(usPath)
    usFeaDF.createOrReplaceTempView("usFea")
    usFeaDF.printSchema()
    usFeaDF.show()
    # #关联
    joinSQL = "SELECT c.*,d.f_diu,features as usfeatures  from (SELECT a.*,b.f_vid,b.vid as bvid,b.features as itfeatures from (SELECT diu, vid, label FROM exclick)a JOIN (SELECT vid,f_vid, features  FROM itFea)b ON (a.vid = b.vid))c join (SELECT * from usFea)d on (c.diu = d.diu)"
    joinDF = spark.sql(joinSQL)
    joinDF.printSchema()
    joinDF.show()
    joinDF.createOrReplaceTempView("ltrfe")
    #分层采样
    rateSql =  "SELECT diu,vid,f_vid,f_diu,itfeatures,usfeatures,label FROM (SELECT *, count(*) over (partition BY hash(diu)) AS st_count, rank() over (partition BY hash(diu) ORDER BY rand()) AS rank1 FROM ltrfe WHERE label = 0)a WHERE rank1 <= 0.05 * st_count UNION ALL SELECT diu,vid,f_vid,f_diu,itfeatures,usfeatures,label FROM FROM ltrfe WHERE label = 1"
    ltrData = spark.sql(rateSql)
    # ltrData.printSchema()
    # ltrData.show()
    # print ltrData.count()
    # ltrData.createOrReplaceTempView("sample")
    # labelSql = "select label,count(1)pv from sample group by label"
    # labelCount = spark.sql(labelSql)
    # labelCount.show()
    # #print ltrData.count()
    # #ltrData.show()

    #合并两个特征向量,并标准化
    rawFeaList = ['itfeatures','usfeatures']
    scaledData = handleVec(rawFeaList,ltrData)
    cleanData = scaledData.select("features","label")
    #allFeaPath = "hdfs://Ucluster/test/ltrfeature/"+inDate+"/"
    #cleanData.write.mode('overwrite').save(allFeaPath, format="parquet")
    # cleanData.createOrReplaceTempView("sample")
    # labelSql = "select label,count(1)pv from sample group by label"
    # labelCount = spark.sql(labelSql)
    # labelCount.show()
    #划分训练集和测试集
    (training, test) = cleanData.randomSplit([0.8, 0.2])
    lr = LogisticRegression(maxIter=10, regParam=0.01)


    # # Fit the model
    # lrModel = lr.fit(training)
    # result = lrModel.transform(test)
    # result.printSchema()
    # result.show()
    # # print result.prediction #0.0
    # # print result.probability #[0.962242403983,0.0377575960168]
    # # print result.rawPrediction #[3.23807972368,-3.23807972368]
    # # print result.label
    # evaluator = BinaryClassificationEvaluator()
    # auc = evaluator.evaluate(result)
    # # print auc
    # pr = evaluator.evaluate(result, {evaluator.metricName: "areaUnderPR"})
    # print auc
    # print pr
    # print "auc:", auc, "areaUnderPR:", pr


    # Fit the model
    lrModel = lr.fit(cleanData)
    lr_path ="hdfs://Ucluster/olap/dm/recy_ltr_model/"+inDate+"/"+inHour+"/"
    # 给服务端使用
    lrModel.save(lr_path)




    # #应用在ALS模型粗排序
    # alsSQL="SELECT c.*,d.f_diu,features as usfeatures  from (SELECT a.*,b.f_vid,b.vid as bvid,b.features as itfeatures from (SELECT diu,vid,prediction as pred  FROM da.recy_final_out_topk WHERE dt='"+inDate+"')a JOIN (SELECT vid,f_vid, features  FROM itFea)b ON (a.vid = b.vid))c join (SELECT * from usFea)d on (c.diu = d.diu)"
    # alsDF = spark.sql(alsSQL)
    # alsDF.printSchema()
    # alsDF.show()
    # scaledData = handleVec(rawFeaList,alsDF)
    # predictData = scaledData.select("diu","vid","pred","features")
    # result = lrModel.transform(predictData).select("diu","vid","probability")
    # #sk.show(n=200)
    # finalRS = result.rdd.map(lambda x :[x.diu,x.vid,float(x.probability.values[1])])
    # print finalRS.take(1)
    # colList =["diu","vid","pp"]
    # sq  = spark.createDataFrame(finalRS, "diu: string, vid: string,pp: float")
    # sq.printSchema()
    # sq.show()
    # #print sq.count()
    # outPath = "hdfs://Ucluster/olap/dm/recy_ltr_predict/"+inDate+"/"
    # sq.write.mode('overwrite').save(outPath, format="parquet")

    

    spark.stop()
