#!/usr/bin/env python
#encoding=utf-8
# -*- coding: utf-8 -*- 
import sys

from datetime import datetime,date, timedelta
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors


'''
Created on 2017年6月29日

@author: david
'''

PORT = "6379"
EXPIRE=60*60*24*3
# EXPIRE=60*60*2
NODES=["10.19.85.211","10.19.178.227","10.19.198.54","10.19.26.182","10.19.137.83","10.19.23.98"]
#NODES =["10.10.237.56"]
def rdd2redis(rdd, key='r_coefficients'):
    """将rdd数据导入到redis数据库中
    """
    import redis
    from random import choice

    # redis  连接方式可以提高性能
    def storeToRedis(item, key):
        index = 0
        while(index <3):
            try:
                index = index + 1
                r = redis.StrictRedis(host = choice(NODES), port = PORT,socket_timeout=1000)
		r.set(key,str(item))
                r.expire(key,EXPIRE)
                break
            except Exception, e:
                print 'storeToRedis error, index : %s, msg : %s'%(index,e)
    print rdd
    for item in rdd :
	storeToRedis(item,key)

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

def main(inDate,inHour):
    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_lrmodel2text:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    mPath = "hdfs://Ucluster/olap/dm/recy_ltr_model/"+inDate+"/"+inHour+"/data/"
    ltr_model_df = spark.read.parquet(mPath)
    ltr_model_df.show()
    #ltr_model_df.select("coefficients").show();#.write.text("/tmp/out/recy_ltr_model")
    rdd = ltr_model_df.select("intercept").rdd.map(lambda p : p[0]).collect()
    rdd2redis(rdd, 'r_intercept')
    rdd = ltr_model_df.select("coefficients").rdd.map(lambda p: Vectors.dense(p.coefficients.toArray())).collect()
    rdd2redis(rdd)

if __name__ == '__main__':
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=sys.argv[1]
    inHour=sys.argv[2]
    main(inDate, inHour)
