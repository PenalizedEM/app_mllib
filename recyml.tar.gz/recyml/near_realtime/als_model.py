#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 5

"""
 Implementation of ALS to predict user's rating on video
"""
import dateutil.parser
import json
import time
import itertools
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.ml.feature import VectorAssembler,StringIndexer

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')

    inDate = handleDateArgs(sys.argv)[0]
    print "inDate  ", inDate
    inHour = handleDateArgs(sys.argv)[1]
    print "inHour ", inHour

    conf = SparkConf()
    sc = SparkContext()
    sqlContext = HiveContext(sc)

    #读入用户视频评分
    rateSql =  "select * from dm.user_video_rating where dt='"+inDate+"' and f_diu is not null and f_vid is not null and f_rating is not null and f_rating <>0.0 "
    rating = sqlContext.sql(rateSql)

    als = ALS(rank=10, maxIter=20, regParam=0.1, userCol="f_diu", itemCol="f_vid", ratingCol="f_rating")
 
    model = als.fit(rating)
 
    modelPath =  "hdfs://Ucluster/olap/da/recy_als_model/"+inDate+"/"
    model.write().overwrite().save(modelPath)

    sc.stop()
