#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 17

"""
Recommend top k videos to user.

"""
import datetime
import sys
from pyspark import SparkContext, SparkConf, HiveContext
from pyspark.ml.recommendation import ALSModel
from pyspark.sql import SQLContext
from pyspark.sql.types import *


#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate = handleDateArgs(sys.argv)[0]
    print "inDate  ", inDate
    inHour = handleDateArgs(sys.argv)[1]
    print "inHour ", inHour

    conf = SparkConf()
    sc = SparkContext()
    sqlContext = HiveContext(sc)

    preSQl = "select * from dm.recy_als_candy_final where dt='" + inDate + "' and hour='" + inHour + "'"
    preDF = sqlContext.sql(preSQl)
    modelPath =  "hdfs://Ucluster/olap/dm/recy_als_model/"+inDate+"/"
    model = ALSModel.load(modelPath)
    prediction = model.transform(preDF)
    predictPath =  "hdfs://Ucluster/olap/dm/recy_als_predict/"+inDate+"/"+ inHour + "/"
    prediction.repartition(100).write.mode('overwrite').save(predictPath, format="parquet")
    sc.stop()
