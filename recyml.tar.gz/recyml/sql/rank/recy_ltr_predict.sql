drop TABLE da.recy_ltr_predict;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_ltr_predict(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    pp float  COMMENT '点击概率'
)
COMMENT '用户机器学习预测点击概率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_ltr_predict/';


ALTER TABLE da.recy_ltr_predict ADD IF NOT EXISTS
PARTITION (dt='2017-05-31') LOCATION '/olap/da/recy_ltr_predict/2017-05-31/';