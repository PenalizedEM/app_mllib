-- 视频总点击率(allctr)
-- 视频发布时间距离现在时间(精确到小时)(createhour)
-- duration 时长分成四级,确定0,15,90,300
-- 最近一天视频点击率(onedayctr)
-- 最近七天视频点击率(sevendayctr)
-- 最近一天视频点击数(onedayclick)
-- 最近七天视频点击数(sevendayclick)
-- 最近一天视频点赞数(onedaygood)
-- 最近七天视频点赞数(sevendaygood)
-- 最近一天视频评论数(onedaycomment)
-- 最近七天视频评论数(sevendaycomment)
-- 最近一天视频分享数(onedayshare)
-- 最近七天视频分享数(sevendayshare)

---select percentile_approx(onedayctr,array(0.25,0.5,0.75,0.9)) from da.video_oneday_feature where dt='2017-09-14'
---createhour按照0.25，0.5，0.75，0.9分段: 1300 3100 6000 9000
----onedayctr 按照0.85 0.9 0.95分段:3.5 5.5 11.0
----onedayclick按照0.85,0.9,0.95分段:1.5 3.0 10.0
----onedaygood 分段 0 1 2 （0.99分位数2.0）
----onedaycomment 分段 0 1 （0.99分位数1）
----onedayshare 分段 0 1 （0.99分位数1）

---allctr 按照0.25 0.5 0.75 0.9分段 0.7 3.5 8.5 18.0
---sevendayctr 按照0.75 0.9 分段 5.0 15.0
---sevendayclick 按照0.75 0.9 分段 4.0 25.0
---sevendaygood 按照0.9 0.95 分段 1.0 2.0
---sevendaycomment 分段 0 1.0 2.0
---sevendayshare分段 0 1.0 2.0

CREATE EXTERNAL TABLE IF NOT EXISTS da.video_oneday_feature(
    vid STRING  COMMENT '视频id',
    createtime STRING  COMMENT '视频创建时间',
    createhour DOUBLE COMMENT '视频发布时间距离现在时间(精确到小时)',
    onedayctr DOUBLE COMMENT '最近一天视频点击率',
    onedayclick DOUBLE COMMENT '最近一天视频点击数',
    onedaygood DOUBLE  COMMENT '最近一天视频点赞数',
    onedaycomment DOUBLE COMMENT '最近一天视频评论数',
    onedayshare DOUBLE COMMENT '最近一天视频分享数'
)
COMMENT '视频特征-最近一天视频的点击率，点击数，点赞数，评论数，分享数'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/video_oneday_feature';


INSERT overwrite TABLE da.video_oneday_feature partition (dt='${datebuf}')
SELECT a.vid,
       createtime,
       createhour,
       if(onedayctr IS NULL,0,onedayctr) onedayctr,
       if(onedayclick IS NULL,0,onedayclick) onedayclick,
       if(onedaygood IS NULL,0,onedaygood) onedaygood,
       if(onedaycomment IS NULL,0,onedaycomment) onedaycomment,
       if(onedayshare IS NULL,0,onedayshare) onedayshare
FROM
  (SELECT vid,
          createtime,
          (unix_timestamp()-unix_timestamp(createtime))/(60*60) createhour
   FROM dw.video)a
LEFT OUTER JOIN
  (SELECT vid,
          if(sum(m_vv)/sum(m_dv)*100>100,100,sum(m_vv)/sum(m_dv)*100) onedayctr,
          sum(m_vv) onedayclick
   FROM adm.f_recy_vidctr
   WHERE dt='${datebuf}'
   GROUP BY vid)b ON (a.vid = b.vid)
LEFT OUTER JOIN
  (SELECT d_vid,
          sum(m_cnt) onedaygood
   FROM adm.f_video_like
   WHERE dt='${datebuf}'
   GROUP BY d_vid)c ON a.vid=c.d_vid
LEFT OUTER JOIN
  (SELECT d_vid,
          sum(m_cnt) onedaycomment
   FROM adm.f_video_cmt
   WHERE dt='${datebuf}'
   GROUP BY d_vid)d ON a.vid=d.d_vid
LEFT OUTER JOIN
  (SELECT d_vid,
          sum(m_cnt) onedayshare
   FROM adm.f_video_share
   WHERE dt='${datebuf}'
   GROUP BY d_vid)e ON a.vid=e.d_vid;



CREATE EXTERNAL TABLE IF NOT EXISTS da.video_sevenday_feature(
    vid STRING  COMMENT '视频id',
    allctr DOUBLE COMMENT '视频总点击率',
    sevendayctr DOUBLE COMMENT '最近七天视频点击率',
    sevendayclick DOUBLE COMMENT '最近七天视频点击数',
    sevendaygood DOUBLE  COMMENT '最近七天视频点赞数',
    sevendaycomment DOUBLE COMMENT '最近七天视频评论数',
    sevendayshare DOUBLE COMMENT '最近七天视频分享数'
)
COMMENT '视频特征-视频总点击率，最近7天点击率，最近7天点击数'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/video_sevenday_feature';


INSERT overwrite TABLE da.video_sevenday_feature partition (dt='${datebuf}')
SELECT a.vid,
       if(allctr is null,0,allctr) allctr,
       if(sevendayctr is null,0,sevendayctr) sevendayctr,
       if(sevendayclick is null,0,sevendayclick) sevendayclick,
       if(sevendaygood is null,0,sevendaygood) sevendaygood,
       if(sevendaycomment is null,0,sevendaycomment) sevendaycomment,
       if(sevendayshare is null,0,sevendayshare) sevendayshare
FROM
  (SELECT vid
   FROM dw.video)a
LEFT OUTER JOIN
  (SELECT vid,
          if(sum(m_vv)/sum(m_dv)*100>100,100,sum(m_vv)/sum(m_dv)*100) allctr
   FROM adm.f_recy_vidctr
   WHERE dt>='2017-07-23'
   GROUP BY vid)b ON a.vid=b.vid
LEFT OUTER JOIN
  (SELECT vid,
          sum(m_vv) sevendayclick,
          if(sum(m_vv)/sum(m_dv)*100>100,100,sum(m_vv)/sum(m_dv)*100) sevendayctr
   FROM adm.f_recy_vidctr
   WHERE dt<='${datebuf}'
     AND dt>=date_sub('${datebuf}',6)
   GROUP BY vid)c ON a.vid=c.vid
LEFT OUTER JOIN
  (SELECT d_vid,
          sum(m_cnt) sevendaygood
   FROM adm.f_video_like
   WHERE dt<='${datebuf}'
     AND dt>=date_sub('${datebuf}',6)
   GROUP BY d_vid)d ON a.vid=d.d_vid
LEFT OUTER JOIN
  (SELECT d_vid,
          sum(m_cnt) sevendaycomment
   FROM adm.f_video_cmt
   WHERE dt<='${datebuf}'
     AND dt>=date_sub('${datebuf}',6)
   GROUP BY d_vid)e ON a.vid=e.d_vid
LEFT OUTER JOIN
  (SELECT d_vid,
          sum(m_cnt) sevendayshare
   FROM adm.f_video_share
   WHERE dt<='${datebuf}'
     AND dt>=date_sub('${datebuf}',6)
   GROUP BY d_vid)f ON a.vid=f.d_vid;



CREATE EXTERNAL TABLE IF NOT EXISTS da.video_profile_feature(
    vid STRING  COMMENT '视频id',
    createtime STRING  COMMENT '视频创建时间',
    createhour DOUBLE COMMENT '视频发布时间距离现在时间(精确到小时)',
    createhour_range INT COMMENT '视频发布时间距离现在时间(精确到小时),0:0~1300, 1:1300.1~3100, 2:3100.1~6000, 3:6000.1~9000, 4:9000以上',
    onedayctr DOUBLE COMMENT '最近一天视频点击率',
    onedayctr_range INT COMMENT '最近一天视频点击率,0:0, 1:0.1~3.5, 2:3.6~5.5, 3:5.6~11.0, 4:11.0以上',
    onedayclick DOUBLE COMMENT '最近一天视频点击数',
    onedayclick_range INT COMMENT '最近一天视频点击数，0:0, 1:0.1~1.5, 2:1.6~3.0, 3:3.1~10.0, 4:10.0以上',
    onedaygood DOUBLE  COMMENT '最近一天视频点赞数',
    onedaygood_range INT COMMENT '最近一天视频点赞数: 0:0, 1:1, 2:2, 3:2以上',
    onedaycomment DOUBLE COMMENT '最近一天视频评论数',
    onedaycomment_range INT COMMENT '最近一天视频评论: 0:0, 1:1, 2:1以上',
    onedayshare DOUBLE COMMENT '最近一天视频分享数',
    onedayshare_range INT COMMENT '最近一天视频分享数: 0:0, 1:1, 2:1以上',
    allctr DOUBLE COMMENT '视频总点击率',
    allctr_range INT COMMENT '视频总点击率: 0:0, 1:0.1~0.7, 2: 0.7~3.5, 3: 3.6~8.5, 4:8.6~18.0 5:18.0以上',
    sevendayctr DOUBLE COMMENT '最近七天视频点击率',
    sevendayctr_range INT COMMENT '最近七天视频点击率: 0:0, 1:0.1~5.0, 2:5.1~15.0, 3:15.0以上',
    sevendayclick DOUBLE COMMENT '最近七天视频点击数',
    sevendayclick_range INT COMMENT '最近七天视频点击数: 0:1, 1:0.1~4.0 2:4.1~25.0, 3:25.0以上',
    sevendaygood DOUBLE  COMMENT '最近七天视频点赞数',
    sevendaygood_range INT COMMENT '最近七天视频点赞数: 0:0, 1:1, 2:2, 3:2以上',
    sevendaycomment DOUBLE COMMENT '最近七天视频评论数',
    sevendaycomment_range INT COMMENT '最近七天视频评论数: 0:0, 1:1, 2:2, 3:2以上',
    sevendayshare DOUBLE COMMENT '最近七天视频分享数',
    sevendayshare_range INT COMMENT '最近七天视频分享数: 0:0, 1:1, 2:2, 3:2以上'
)
COMMENT '视频特征-最近一天/7天的视频的点击率，点击数，点赞数，评论数，分享数'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/video_profile_feature';



INSERT overwrite TABLE da.video_profile_feature partition (dt='${datebuf}')
SELECT a.vid ,
       createtime,
       createhour,
       createhour_range,
       onedayctr,
       onedayctr_range,
       onedayclick,
       onedayclick_range,
       onedaygood,
       onedaygood_range,
       onedaycomment,
       onedaycomment_range,
       onedayshare,
       onedayshare_range,
       allctr,
       allctr_range,
       sevendayctr,
       sevendayctr_range,
       sevendayclick,
       sevendayclick_range,
       sevendaygood,
       sevendaygood_range,
       sevendaycomment,
       sevendaycomment_range,
       sevendayshare,
       sevendayshare_range
FROM
  (SELECT vid,
          createtime,
          createhour,
          CASE
              WHEN createhour<=1300 THEN 0
              WHEN createhour<=3100 THEN 1
              WHEN createhour<=6000 THEN 2
              WHEN createhour<=9000 THEN 3
              ELSE 4
          END AS createhour_range,
          onedayctr,
          CASE
              WHEN onedayctr=0 THEN 0
              WHEN onedayctr<=3.5 THEN 1
              WHEN onedayctr<=5.5 THEN 2
              WHEN onedayctr<=11.0 THEN 3
              ELSE 4
          END AS onedayctr_range,
          onedayclick,
          CASE
              WHEN onedayclick=0 THEN 0
              WHEN onedayclick<=1.5 THEN 1
              WHEN onedayclick<=3.0 THEN 2
              WHEN onedayclick<=10.0 THEN 3
              ELSE 4
          END AS onedayclick_range,
          onedaygood,
          CASE
              WHEN onedaygood=0 THEN 0
              WHEN onedaygood=1 THEN 1
              WHEN onedaygood=2 THEN 2
              ELSE 3
          END AS onedaygood_range,
          onedaycomment,
          CASE
              WHEN onedaycomment=0 THEN 0
              WHEN onedaycomment=1 THEN 1
              ELSE 2
          END AS onedaycomment_range,
          onedayshare,
          CASE
              WHEN onedayshare=0 THEN 0
              WHEN onedayshare=1 THEN 1
              ELSE 2
          END AS onedayshare_range
   FROM da.video_oneday_feature
   WHERE dt='${datebuf}')a
JOIN
  (SELECT vid,
          allctr,
          CASE
              WHEN allctr=0 THEN 0
              WHEN allctr<=0.7 THEN 1
              WHEN allctr<=3.5 THEN 2
              WHEN allctr<=8.5 THEN 3
              WHEN allctr<=18.0 THEN 4
              ELSE 5
          END AS allctr_range,
          sevendayctr,
          CASE
              WHEN sevendayctr=0 THEN 0
              WHEN sevendayctr<=5.0 THEN 1
              WHEN sevendayctr<=15.0 THEN 2
              ELSE 3
          END AS sevendayctr_range,
          sevendayclick ,
          CASE
              WHEN sevendayclick=0 THEN 0
              WHEN sevendayclick<=4.0 THEN 1
              WHEN sevendayclick<=25.0 THEN 2
              ELSE 3
          END AS sevendayclick_range,
          sevendaygood ,
          CASE
              WHEN sevendaygood=0 THEN 0
              WHEN sevendaygood=1 THEN 1
              WHEN sevendaygood=2 THEN 2
              ELSE 3
          END AS sevendaygood_range,
          sevendaycomment ,
          CASE
              WHEN sevendaycomment=0 THEN 0
              WHEN sevendaycomment=1 THEN 1
              WHEN sevendaycomment=2 THEN 2
              ELSE 3
          END AS sevendaycomment_range,
          sevendayshare,
          CASE
              WHEN sevendayshare=0 THEN 0
              WHEN sevendayshare=1 THEN 1
              WHEN sevendayshare=2 THEN 2
              ELSE 3
          END AS sevendayshare_range
   FROM da.video_sevenday_feature
   WHERE dt='${datebuf}')b ON a.vid=b.vid