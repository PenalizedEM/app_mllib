drop TABLE da.recy_ltr_feature;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_ltr_feature(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    i_ex   INT COMMENT '曝光次数',
    i_hits_level   INT COMMENT '视频点击次数级别',
    i_comment_level INT COMMENT '评论次数级别',
    i_share_level INT COMMENT '分享次数级别',
    i_duration_level INT COMMENT '视频时长级别',
    i_definition INT COMMENT '清晰度',
    u_act_status INT COMMENT '用户活跃程度级别',
    u_actperiod INT COMMENT '用户活跃时段',
    u_citylevel INT COMMENT '用户所在城市级别',
    u_wvdur_range INT COMMENT '用户观看视频时长级别',
    u_wvcnts_range INT COMMENT '用户观看视频个数级别',
    u_cc INT COMMENT '用户最常观看视频的小类',
    label INT COMMENT '是否点击'
)
COMMENT '用户机器学习排序特征'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_ltr_feature/';




