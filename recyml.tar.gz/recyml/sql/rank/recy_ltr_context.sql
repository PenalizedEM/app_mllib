drop TABLE da.recy_ltr_context;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_ltr_context(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    ruuid STRING COMMENT '推荐唯一标示',
    u_rsource STRING COMMENT '推荐队列',
    u_rank STRING COMMENT '推荐位置',
    ctime STRING COMMENT '曝光时间',
    label INT COMMENT '是否点击'
)
COMMENT 'LTR上下文特征'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_ltr_context/';




