/test/wordcount/wordcount.txt

hadoop jar Hdfs2HBase.jar GeneratePutHFileAndBulkLoadToHBase 2017-02-20 dm_recommend_video 

create 'word_count', 'cf'
disable 'word_count'
drop 'word_count'
exists 'word_count'

create 'test','f'
disable 'test'
alter 'test', NAME => 'f', TTL => '259200'
enable 'test'


drop table da.test;
CREATE EXTERNAL TABLE IF NOT EXISTS da.test(
rowkey String,
vid String,
title String,
pic String,
short_title String,
score double,
hits_total BigInt,
comment_total BigInt,
createtime String
)
COMMENT '用户视频评分历史全量表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE 
LOCATION '/olap/da/test/';

INSERT OVERWRITE TABLE da.test partition(dt='2017-02-20')
SELECT
CONCAT(diu, '_', regexp_replace(dt, '-', ''), '_', vid) rowkey,
vid,
title,
pic,
short_title,
prediction,
hits_total,
comment_total,
createtime
FROM
da.recy_final_out_topk
WHERE
diu != '000000000000000'
AND dt = '2017-02-20' limit 10;