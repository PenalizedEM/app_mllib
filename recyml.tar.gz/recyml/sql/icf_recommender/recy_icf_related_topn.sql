
--  推荐系统-基于视频的协同过滤-相关视频topn

-- 建表
drop table if exists da.recy_icf_related_topn ; 
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_related_topn( 
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
similarity double COMMENT '相关度',
rank int COMMENT 'topk排名'
)
COMMENT '推荐系统-基于视频的协同过滤-相关视频topn'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS textfile
LOCATION '/olap/da/recy_icf_related_topn/';

