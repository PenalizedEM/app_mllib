
use da;
set mapreduce.job.reduces=200 ;

-- drop table if exists recy_icf_similarity_pre;
CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_similarity_pre( 
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT '视频id',
num bigint COMMENT '视频观看人数' 
)
COMMENT '推荐系统-协同过滤-视频相似度数据准备'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_icf_similarity_pre/';

select a.diu, a.vid, a.num from (select * from da.recy_cf_rating_online where actdate>='"+actDate+"') a join (select diu, count(1) vcnt from da.recy_cf_rating_online where actdate>='"+actDate+"'group by diu having vcnt<1000)b on (a.diu=b.diu)

-- 推荐系统-基于视频的协同过滤-视频相似度计算
-- drop table if exists recy_icf_similarity ; 
CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_similarity( 
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
num_1	bigint	COMMENT 'vid_1被看的人数',
num_2	bigint	COMMENT 'vid_2被看的人数',
num_12	bigint	COMMENT '看过vid_1与vid_2的用户数',
similarity double COMMENT '相似度'
)
COMMENT '推荐系统-基于视频的协同过滤-视频相似度计算'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_icf_similarity/';

insert overwrite table recy_icf_similarity partition(dt='$datebuf')
select 
vid_1,
vid_2,
num_12/sqrt(num_1*num_2) similarity 
from 
(select a.vid vid_1 ,
          b.vid vid_2 ,
          a.num num_1,
          b.num num_2,
          count(1) num_12
   from da.recy_icf_similarity_pre a
   join da.recy_icf_similarity_pre b on (a.diu=b.diu)
   where a.vid<b.vid
   group by a.vid,
            b.vid,
            a.num,
            b.num
) b 
 ;

-- drop table if exists da.recy_icf_similarity_mid;
-- create table da.recy_icf_similarity_mid as
-- select a.vid vid_1 ,
--           b.vid vid_2 ,
--           a.num num_1,
--           b.num num_2,
--           count(1) num_12
--    from da.recy_icf_similarity_pre a
--    join da.recy_icf_similarity_pre b on (a.diu=b.diu)
--    where a.vid<b.vid
--    group by a.vid,
--             b.vid,
--             a.num,
--             b.num

-- insert overwrite table recy_icf_similarity partition(dt='$datebuf')
-- select vid_1,
--        vid_2,
--        num_12/sqrt(num_1*num_2) similarity
-- from recy_icf_similarity_mid

drop table if exists recy_icf_similarity_topk ; 
CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_similarity_topk( 
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
similarity double COMMENT '相似度',
rank int COMMENT 'topk排名'
)
COMMENT '推荐系统-基于视频的协同过滤-视频相似度计算topk'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_icf_similarity_topk/';

insert overwrite table recy_icf_similarity_topk partition (dt='')
select vid_1,
             vid_2,
             similarity
      from
        (select vid_1,
                vid_2,
                similarity,
                ROW_NUMBER() OVER (PARTITION by vid_1
                                   order by similarity desc) rank
         from da.recy_icf_similarity
         where dt='"+inDate+"') a
      where rank<=10

insert overwrite table recy_icf_similarity_topk partition (dt='2016-12-31')
select b.vid_1,
             b.vid_2,
             b.similarity/mx_sim similarity,b.rank
      from
        (select vid_1,
                max(similarity) mx_sim
         from da.recy_icf_similarity_topk where dt='2016-12-31'
         group by vid_1) a
        join 
        (select *
         from da.recy_icf_similarity_topk where dt='2016-12-31'
         ) b on(a.vid_1=b.vid_1)

ALTER TABLE da.recy_icf_similarity_topk ADD IF NOT EXISTS PARTITION (dt='2016-12-15') LOCATION '/olap/da/recy_icf_similarity_topk/2016-12-15"


select count(1), count(distinct diu), count(distinct vid)  from da.recy_cf_rating_2 where actdate>'2016-12-12'
88798101	2949406	592921

select count(1), count(distinct diu), count(distinct vid)  from da.recy_cf_rating_2 where actdate>'2016-12-08'
135716073	3344607	623919


