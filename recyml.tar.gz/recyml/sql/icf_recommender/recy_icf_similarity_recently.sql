drop table da.recy_icf_similarity_recently;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_similarity_recently(
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
num_1 int COMMENT 'vid_1被看的人数',
num_2 int COMMENT 'vid_2被看的人数',
num_12 int COMMENT '看过vid_1与vid_2的用户数',
similarity double COMMENT '相似度',
update_hour int COMMENT '更新时间:小时分区, 默认取值24,指1天前'
)
COMMENT '推荐系统-基于视频的协同过滤-近线最近24小时上传的视频相似度'
PARTITIONED BY(dt STRING )
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_icf_similarity_recently/';




from
(
    select
    a.*,
    create_date,
    ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank
    from
    (
        select vid_1, vid_2, num_1, num_2, num_12, similarity from da.recy_icf_similarity where dt='" + datebuf + "' 
    ) a
    join
    (select vid, to_date(createtime) create_date from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) b
    on (a.vid_1=b.vid)
    join
    (select vid  from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) c
    on (a.vid_2=c.vid)
) a
insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "',type='recently')
select vid_1, vid_2,num_1, num_2, num_12, similarity, '24' where create_date>='" + onedayago + "' and rank<=1000
insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "',type='oldly')
select vid_1, vid_2,num_1, num_2, num_12, similarity,'24' where create_date<'" + onedayago + "' and rank<=80

from
(
    select
    a.*,
    create_date,
    ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank
    from
    (
        select vid_1, vid_2, num_1, num_2, num_12, similarity from da.recy_icf_similarity where dt='" + datebuf + "'
    ) a
    join
    (select vid, to_date(createtime) create_date from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) b
    on (a.vid_1=b.vid)
) a
insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "',type='recently')
select vid_1, vid_2,num_1, num_2, num_12, similarity, '24' where create_date>='" + onedayago + "' and rank<=1000
insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "',type='oldly')
select vid_1, vid_2,num_1, num_2, num_12, similarity,'24' where create_date<'" + onedayago + "' and rank<=80

from (select a.*, create_date, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from (select vid_1, vid_2, num_1, num_2, num_12, similarity from da.recy_icf_similarity where dt='" + datebuf + "') a join (select vid, to_date(createtime) create_date from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) b on (a.vid_1=b.vid) join (select vid  from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) c on (a.vid_2=c.vid) ) a insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "',type='recently') select vid_1, vid_2,num_1, num_2, num_12, similarity, '24' where create_date>='" + onedayago + "' and rank<=1000 insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "',type='oldly') select vid_1, vid_2,num_1, num_2, num_12, similarity,'24' where create_date<'" + onedayago + "' and rank<=80