
--  推荐系统-基于视频的协同过滤-视频相似度计算topn n=20

-- 建表
drop table if exists da.recy_icf_similarity_topn ; 
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_similarity_topn( 
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
similarity double COMMENT '相似度',
rank int COMMENT 'topk排名'
)
COMMENT '推荐系统-基于视频的协同过滤-视频相似度计算topn'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS textfile
LOCATION '/olap/da/recy_icf_similarity_topn/';

alter table da.recy_icf_similarity_topn add if not exists partition(dt='2017-02-21') LOCATION '/olap/da/recy_icf_similarity_topn/dt=2017-02-21'
alter table da.recy_icf_similarity_topn add if not exists partition(dt='2017-02-22') LOCATION '/olap/da/recy_icf_similarity_topn/dt=2017-02-22'


-- sql
select vid_1, vid_2, similarity, rank  from (select vid_1, vid_2, similarity, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from da.recy_icf_similarity where dt='"+inDate+"') a where rank<= 20 


-- pyspark
    ################# similary topn 
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_topn:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    simTopkSql = "insert overwrite table da.recy_icf_similarity_topn partition(dt='"+inDate+"') select vid_1, vid_2, similarity, rank  from (select vid_1, vid_2, similarity, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from da.recy_icf_similarity where dt='"+inDate+"') a where rank<= 20 "
    print simTopkSql
    spark.sql(simTopkSql)

    spark.stop()


-- sqoop export 

export --connect jdbc:mysql://10.10.243.51:3306/2016hd?tinyInt1isBit=false --username root --password tangdouapp#123 --table similar_video --columns vid_1,vid_2,similarity,rank  --export-dir /olap/da/recy_icf_similarity_topn/dt=2017-02-21 --update-key vid_1,rank --update-mode allowinsert  --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 1

-- CREATE TABLE `similar_video` (
--  `vid_1` bigint(30) COMMENT 'vid_1',
--  `vid_2` bigint(30) COMMENT 'vid_2',
--  `similarity` double COMMENT '相似度',
--  `rank` int(10) COMMENT 'topk排名',
--  PRIMARY KEY (`vid_1`,`rank`)
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4



