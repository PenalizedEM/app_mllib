
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_out_topk(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    prediction   FLOAT COMMENT '预测打分',
    title   STRING COMMENT '视频标题',
    pic STRING COMMENT '视频标图',
    short_title STRING COMMENT '推荐语',
    hits_total INT COMMENT '播放次数',
    comment_total INT COMMENT '评论次数',
    createtime STRING COMMENT '创建时间'
)
COMMENT '用户视频评分历史全量表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_icf_out_topk/';

insert overwrite table da.recy_icf_out_topk partition(dt='"+inDate+"')
select diu,
       vid,
       prediction ,
       title,
       pic ,
       short_title,
       hits_total,
       comment_total,
       createtime
from
  (select /* +mapjoin(b) */ a.diu,
                            a.vid,
                            cast(round(if(a.rating>5,5,rating),1) as float) prediction ,
                            b.title,
                            b.pic ,
                            b.short_title,
                            b.hits_total,
                            b.comment_total,
                            b.createtime ,
                            ROW_NUMBER() OVER (PARTITION by a.diu
                                               order by a.rating desc) rank
   from
     (select diu,
             vid ,
             rating
      from da.recy_icf_recommend
      where dt='"+inDate+"'
        and rank<=100) a
   join
     (select *
      from dw.video
      where status=0) b on(a.vid=b.vid)
   left outer join
     (select *
      from da.recy_als_out_topk
      where dt='"+inDate+"') c on (a.diu=c.diu
                                   and a.vid=c.vid)
   where c.vid is null) a
where rank<=10
