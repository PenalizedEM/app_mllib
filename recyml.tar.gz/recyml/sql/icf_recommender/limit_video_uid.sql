

-- 1 限制 recy_als_out_topk 中 diu uid 下视频个数不超过3 
insert overwrite table da.recy_als_out_topk partition (dt='2017-02-16')
select u_diu as diu ,
       u_vid as vid,
       round(if(prediction>5,5,prediction),1) prediction,
       title,
       pic,
       short_title,
       hits_total,
       comment_total,
       createtime
from
  (select a.u_diu ,
          a.u_vid ,
          a.prediction ,
          b.title,
          b.pic,
          b.short_title,
          b.hits_total,
          b.comment_total,
          createtime,
          ROW_NUMBER() over (partition by u_diu,uid 
                             order by a.prediction desc) rnk
   from
     (select u_diu,
             u_vid,
             prediction
      from da.recy_als_prediction
      where dt='2017-02-16')a
   join
     (select vid,
             title,
             pic,
             short_title,
             hits_total,
             comment_total,
             createtime,
             uid
      from dw.video
      where status=0)b on (a.u_vid = b.vid))m
where m.rnk <= 3

select dt, count(1) from da.recy_als_out_topk where dt in ('2017-02-16','2017-02-17') group by dt;

-- 2、验证限制后的 diu uid 下视频条数
select dt,
       if(pv>3,'3+','1~3') pv,
       count(distinct diu) uv, 
       count(1) vcnt 
from
  (select dt,
          diu,
          uid,
          count(1) pv
   from
     (select dt,
             diu,
             vid
      from da.recy_als_out_topk
      where dt>='2017-02-16'
        and dt<='2017-02-17') a
   join
     (select vid,
             title,
             pic,
             short_title,
             hits_total,
             comment_total,
             createtime,
             uid
      from dw.video
      where status=0)b on (a.vid = b.vid)
   group by dt,
            diu,
            uid) c
group by dt,
         if(pv>3,'3+','1~3') ;
  dt  pv  uv  vcnt
0 2017-02-16  1~3 1714449 9142974
1 2017-02-17  1~3 1600336 7874110
2 2017-02-17  3+  738858  1163746

-- 3、查看 icf_out_topk 下 diu uid 的视频条数
select dt,
       if(pv>3,'3+','1~3') pv,
       count(distinct diu) uv, 
       count(1) vcnt 
from
  (select dt,
          diu,
          uid,
          count(1) pv
   from
     (select dt,
             diu,
             vid
      from da.recy_icf_out_topk
      where dt='2017-02-16') a
   join
     (select vid,
             title,
             pic,
             short_title,
             hits_total,
             comment_total,
             createtime,
             uid
      from dw.video
      where status=0)b on (a.vid = b.vid)
   group by dt,
            diu,
            uid) c
group by dt,
         if(pv>3,'3+','1~3') ;

  dt  pv  uv  vcnt
0 2017-02-16  3+  3198825 6924673
1 2017-02-16  1~3 4377720 123258965

-- 限制最终的结果 recy_final_out_topk diu uid下视频条数不超过3 
insert overwrite table da.recy_final_out_topk partition (dt='2017-02-16')
select diu ,
       vid,
       prediction,
       title,
       pic,
       short_title,
       hits_total,
       comment_total,
       createtime
from
  ( select * ,
           ROW_NUMBER() over (partition by diu
                              order by prediction desc) rank
   from
     (select a.*,
             ROW_NUMBER() over (partition by diu,uid
                                order by prediction desc) rn
      from
        (select *
         from da.recy_als_out_topk
         where dt='2017-02-16'
         union all 
         select * 
         from da.recy_icf_out_topk
         where dt='2017-02-16') a
        join dw.video b 
        on (a.vid = b.vid) 
     ) b
   where rn<=3 ) c
where rank<=60

-- 验证最终 diu uid下视频条数 
select dt,
       if(pv>3,'3+','1~3') pv,
       count(distinct diu) uv, 
       count(1) vcnt 
from
  (select dt,
          diu,
          uid,
          count(1) pv
   from
     (select dt,
             diu,
             vid
      from da.recy_final_out_topk
      where dt='2017-02-16') a
   join
     (select vid,
             title,
             pic,
             short_title,
             hits_total,
             comment_total,
             createtime,
             uid
      from dw.video
      where status=0)b on (a.vid = b.vid)
   group by dt,
            diu,
            uid) c
group by dt,
         if(pv>3,'3+','1~3') ;
  dt  pv  uv  vcnt
0 2017-02-16  1~3 4402237 130824599

-- 限制后 与日活交集对比

select a.dt,
       count(distinct diu) uv,
       count(distinct vid) vcnt
from
  (select dt,
          diu,
          vid
   from da.recy_final_out_topk
   where dt in ('2017-02-16',
                '2017-02-17')) a
join
  (select dt,
          u_diu
   from dw.uibigger
   where dt='2017-02-16'
     and to_date(u_timestamp)='2017-02-16'
   union all select dt,
                    u_diu
   from dw.uibigger
   where dt='2017-02-17'
     and to_date(u_timestamp)='2017-02-17') b on (a.diu=b.u_diu and a.dt=b.dt )
group by a.dt

  a.dt  uv  vcnt
0 2017-02-16  1197097 315972
1 2017-02-17  1219453 338595
