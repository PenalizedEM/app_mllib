
use da;

-- 推荐系统-基于视频的协同过滤-视频推荐列表
-- drop table if exists recy_icf_recommend ; 
CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_recommend( 
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT 'vid',
rating double COMMENT '推荐度得分',
from_vid STRING  COMMENT '根绝看过的视频推荐',
rank int COMMENT '排名' 
)
COMMENT '推荐系统-基于视频的协同过滤-视频推荐列表'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_icf_recommend/';

insert overwrite table recy_icf_recommend partition(dt='2016-12-15')
select 
d.diu, 
d.vid, 
d.rating,
d.vids,
ROW_NUMBER() OVER (PARTITION by d.diu
                  order by d.rating desc) rank  
from 
(
	select 
	diu,
	vid_2 vid, 
	sum(rating*similarity) rating,
	collect_set(vid) vids  
	from 
	(
		select 
		vid_1,
		vid_2,
		similarity
		from 
		(
			select 
			vid_1,
			vid_2, 
	      	similarity,
			ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank
	      from 
			da.recy_icf_similarity
			where dt='2016-12-15'
		) a 
		where rank<=10 -- top k
	) b 
	join 
	(select diu, vid, rating  from da.recy_cf_rating where dt='2016-12-15') c
	on (b.vid_1=c.vid) 
	group by 
	diu,
	vid_2 
) d 
left outer join 
	(select diu, vid from da.recy_cf_rating where dt='2016-12-15') e
on (d.diu=e.diu and d.vid=e.vid) 
where e.diu is null 


-- drop table if exists recy_icf_recommend_pre ; 
CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_recommend_pre( 
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT 'vid',
rating double COMMENT '推荐度得分',
from_vid STRING  COMMENT '根绝看过的视频推荐'
)
COMMENT '推荐系统-基于视频的协同过滤-视频推荐列表'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_icf_recommend_pre/';

insert overwrite table recy_icf_recommend_pre partition (dt='')
select diu,
       vid_2 vid,
       sum(rating*similarity) rating,
       max(vid) from_vid
from
  (select *
   from da.recy_icf_similarity_topk
   where dt='" +inDate+"') b
join
  (select diu,
          vid,
          rating
   from da.recy_cf_rating
   where dt='"+inDate+"'
     and actdate>='"+actDate+"') c on (b.vid_1=c.vid)
group by diu,
         vid_2

insert overwrite table recy_icf_recommend_pre partition (dt='')
select diu,
       vid_2 vid,
       sum(rating*similarity) rating,
       max(vid) from_vid
from
  (select *
   from da.recy_icf_similarity_topk
   where dt='" +inDate+"') b
join
  (select diu,
          vid,
          rating
   from da.recy_cf_rating_online
   where actdate>='"+actDate+"') c on (b.vid_1=c.vid)
group by diu,
         vid_2

-- -- 训练测试评估
-- select diu,
--        vid_2 vid,
--        sum(rating*similarity) rating,
--        max(vid) from_vid
-- from
--   (select *
--    from da.recy_icf_similarity_topk
--    where dt='" +inDate+"') b
-- join
--   (select diu,
--           vid,
--           rating
--    from da.recy_cf_eval_sample
--    where type='test') c on (b.vid_1=c.vid)
-- group by diu,
--          vid_2


select d.diu, d.vid, d.rating, d.from_vid, ROW_NUMBER() OVER (PARTITION by d.diu order by d.rating desc) rank from (select * from da.recy_icf_recommend_pre where dt='" +inDate+"') d left outer join (select diu, vid from da.recy_cf_eval_sample where type='train') e on (d.diu=e.diu and d.vid=e.vid) where e.diu is null
select * from da.recy_icf_recommend where dt='2016-12-15' and  diu in ('37687478-0C42-4AD5-8CE1-267A47F40CE0') order by rating desc limit 10


