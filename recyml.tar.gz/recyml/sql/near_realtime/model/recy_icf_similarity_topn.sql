--drop table if exists dm.recy_icf_similarity_topn ;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_icf_similarity_topn( 
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
similarity double COMMENT '相似度',
rank int COMMENT 'topk排名'
)
COMMENT '推荐系统-基于视频的协同过滤-视频相似度计算topn'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS textfile
LOCATION '/olap/dm/recy_icf_similarity_topn/';

alter table dm.recy_icf_similarity_topn add if not exists partition(dt='2017-03-14') LOCATION '/olap/dm/recy_icf_similarity_topn/dt=2017-03-14'
