drop table dm.recy_icf_similarity_nearline;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_icf_similarity_nearline(
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
num_1 int COMMENT 'vid_1被看的人数',
num_2 int COMMENT 'vid_2被看的人数',
num_12 int COMMENT '看过vid_1与vid_2的用户数',
similarity double COMMENT '相似度',
update_hour int COMMENT '更新时间:小时分区, 默认取值24,指1天前'
)
COMMENT '推荐系统-基于视频的协同过滤-近线视频相似度'
PARTITIONED BY(dt STRING, type STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_icf_similarity_nearline/';