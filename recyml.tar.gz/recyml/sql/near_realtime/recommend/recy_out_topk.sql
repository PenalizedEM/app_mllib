--drop TABLE dm.recy_out_topk;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_out_topk(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    rank INT COMMENT '排序'
)
COMMENT '最终推荐结果'
PARTITIONED BY(dt STRING, hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/dm/recy_out_topk/';


insert overwrite table dm.recy_out_topk partition(dt='${datebuf}',hour='${hour}')
select diu ,
       vid,
       rank
from
  (select * ,
          ROW_NUMBER() over (partition by diu
                             order by rank desc) rk
   from
     (select a.*,
             uid, ROW_NUMBER() over (partition by diu,uid
                                    order by rank desc) rn
      from
        (select diu,
                vid,
                rank
         from dm.recy_icf_recommend
         where dt='${datebuf}'
          and hour='${hour}'
          ) a
      join (select * from db.video where status=0 )  b on (a.vid = b.vid)) b
   where rn<=5) c
where rk<=2000