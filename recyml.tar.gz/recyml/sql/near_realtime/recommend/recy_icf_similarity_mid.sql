CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_icf_similarity_mid(
	vid_1 STRING,
	vid_2 STRING,
	num_1 BIGINT,
	num_2 BIGINT,
	num_12 BIGINT
)
PARTITIONED BY(dt STRING , hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_icf_similarity_mid';

insert OVERWRITE table dm.recy_icf_similarity_mid PARTITION(dt='${datebuf}',hour='${hour}')
select a.vid vid_1 ,
       b.vid vid_2 ,
       a.num num_1,
       b.num num_2,
       count(1) num_12
from (SELECT * from dm.recy_icf_similarity_pre where dt='${datebuf}' and hour = '${hour}') a
join (SELECT * from dm.recy_icf_similarity_pre where dt='${datebuf}' and hour = '${hour}') b on (a.diu=b.diu)
where a.vid<b.vid
group by a.vid,
         b.vid,
         a.num,
         b.num