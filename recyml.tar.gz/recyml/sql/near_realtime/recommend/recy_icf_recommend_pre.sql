CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_recommend_pre( 
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT 'vid',
rating double COMMENT '推荐度得分',
from_vid STRING  COMMENT '根绝看过的视频推荐'
)
COMMENT '推荐系统-基于视频的协同过滤-视频推荐列表'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_icf_recommend_pre/';


insert overwrite table dm.recy_icf_recommend_pre PARTITION (dt='${datebuf}',hour='${hour}')
select diu,
       vid_2 vid,
       sum(rating*similarity) rating,
       max(vid) from_vid
from
  (select *
   from dm.recy_icf_similarity_topn
   where dt='${model_date}' ) b
join
  (select u_diu diu,
          u_vid vid,
          f_rating rating
   from dm.user_video_rating
   where dt='${datebuf}' and hour='${hour}' ) c on (b.vid_1=c.vid)
group by diu,
         vid_2;
--
---- 强制向最近30天有最常看的视频类别的用户，插入3条按视频小类别分别在当天播放用户数前三的生活类视频。
--set mapreduce.map.memory.mb=3072;
--set hive.auto.convert.join=false;
--drop table if exists dm.recy_icf_tdlive_hot;
--create table dm.recy_icf_tdlive_hot as
--select a.diu,
--       b.vid,
--       title,
--       uv,
--       rank,
--       round(5/rank,0) rating
--from
--  (select diu,
--          cc
--   from dm.user_profile_interest_vcat
--   where dt='${model_date}'
--     and pc in ('65',
--                '55',
--                '54',
--                '53',
--                '47')) a
--join
--  (select *
--   from
--     (select child_category,
--             a.vid,
--             title,
--             uv,
--             ROW_NUMBER() OVER (PARTITION by child_category
--                                order by uv desc) rank
--      from
--        (select u_vid vid,
--                count(distinct u_diu) uv
--         from dm.user_video_index
--         where dt='${datebuf}'
--         group by u_vid) a
--      join
--        (select vid,
--                child_category,
--                title
--         from db.video
--         where child_category not in ('0',
--                                      '3')
--           and parent_category in ('65',
--                                   '55',
--                                   '54',
--                                   '53',
--                                   '47')) b on(a.vid=b.vid)) a
--   where rank<=3) b on(a.cc=b.child_category);
--
--insert overwrite table dm.recy_icf_recommend_pre PARTITION (dt='${datebuf}',hour='${hour}')
--select diu,
--       vid,
--       max(rating),
--       max(from_vid)
--from
--  (select diu,
--          vid,
--          rating,
--          from_vid
--   from dm.recy_icf_recommend_pre
--   where dt='${datebuf}'
--     and hour='${hour}'
--   union all select diu,
--                    vid,
--                    rating,
--                    '' from_vid
--   from dm.recy_icf_tdlive_hot) a
--group by diu,
--         vid
