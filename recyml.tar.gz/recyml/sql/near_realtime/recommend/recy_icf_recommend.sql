CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_recommend(
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT 'vid',
rating double COMMENT '推荐度得分',
from_vid STRING  COMMENT '根绝看过的视频推荐',
rank int COMMENT '排名'
)
COMMENT '推荐系统-基于视频的协同过滤-视频推荐列表(过滤最近观看过的视频)'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_icf_recommend/';


insert overwrite table dm.recy_icf_recommend PARTITION (dt='${datebuf}',hour='${hour}')
select d.diu,
       d.vid,
       d.rating,
       d.from_vid,
       ROW_NUMBER() OVER (PARTITION by d.diu
                          order by d.rating desc) rank
from
  (select *
   from dm.recy_icf_recommend_pre
   where dt='${datebuf}' and hour='${hour}' ) d
left outer join
(
select u_diu, u_vid
from
(
select u_diu, u_vid from dm.user_video_rating -- where dt>='${his_date}'
union all
select diu u_diu, vid u_vid from dm.recy_icf_recommend -- where dt>='${rec_date}'
union all
select u_diu, u_vid from dm.recy_data_viewed_videos where dt='${uvm_date}'
) a
group by u_diu, u_vid )e
on (d.diu=e.u_diu and d.vid=e.u_vid)
where e.u_diu is null