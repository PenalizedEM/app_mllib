CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_icf_similarity_pre(
	diu STRING,
	vid STRING,
	num	BIGINT
)
PARTITIONED BY(dt STRING , hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_icf_similarity_pre';

insert OVERWRITE table dm.recy_icf_similarity_pre PARTITION(dt='${datebuf}',hour='${hour}')


select c.diu,c.vid,c.num from
	(
		select diu,
		       b.vid,
		       num
		from
		  (select u_vid vid,
		          count(1) num
		   from dm.user_video_rating
		   where dt='${datebuf}' and hour='${hour}'
		   group by u_vid) a
		join
		  (select u_diu diu,
		          u_vid vid
		   from dm.user_video_rating
		   where dt='${datebuf}' and hour='${hour}'
		  ) b
		on (a.vid=b.vid)
	) c
join
  ( select vid
    from db.video
    where createtime>= concat(date_sub('${datebuf}',1),' ','${hour}') and status=0 and parent_category  not in ('65', '55', '54', '53', '47')
  ) d
on (c.vid=d.vid);
