CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_icf_similarity(
	vid_1 STRING,
	vid_2 STRING,
	num_1 BIGINT,
	num_2 BIGINT,
	num_12 BIGINT,
	similarity DOUBLE
)
PARTITIONED BY(dt STRING , hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_icf_similarity';

insert OVERWRITE table dm.recy_icf_similarity PARTITION(dt='${datebuf}',hour='${hour}')
select a.* from
	(
	select vid_1,
	       vid_2,
	       num_1,
	       num_2,
	       num_12,
	       num_12/sqrt(num_1*num_2) similarity
	from dm.recy_icf_similarity_mid where dt='${datebuf}'and hour='${hour}'
	union all
	select vid_2 as vid_1,
	       vid_1 as vid_2,
	       num_1,
	       num_2,
	       num_12,
	       num_12/sqrt(num_1*num_2) similarity
	from dm.recy_icf_similarity_mid where dt='${datebuf}'and hour='${hour}'
	)a
join (select distinct vid from db.video where createtime>= concat(date_sub('${datebuf}',1),' ','${hour}') and status=0 and parent_category  not in ('65', '55', '54', '53', '47') ) b
on a.vid_1 = b.vid