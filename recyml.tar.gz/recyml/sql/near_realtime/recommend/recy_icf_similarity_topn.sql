
--  推荐系统-基于视频的协同过滤-相关视频topn

-- 建表
--drop table if exists dm.recy_icf_similarity_topn_hourcdc;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_icf_similarity_topn_hourcdc(
vid_1 STRING  COMMENT 'vid_1',
vid_2  STRING  COMMENT 'vid_2',
similarity double COMMENT '相关度',
rank int COMMENT 'topk排名'
)
COMMENT '推荐系统-基于视频的协同过滤-相关视频topn'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS textfile
LOCATION '/olap/dm/recy_icf_similarity_topn_hourcdc/';
insert OVERWRITE table dm.recy_icf_similarity_topn_hourcdc PARTITION(dt='${datebuf}',hour='${hour}')
select vid_1, vid_2, similarity, rank  from
	(
	select vid_1, vid_2, similarity, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from
		(
			select b.* from
				(select distinct vid_1 from dm.recy_icf_similarity_nearline where dt = date_sub('${datebuf}',1) and update_hour ='${hour}'
				)a
			left join
				(select vid_1,vid_2,similarity from dm.recy_icf_similarity_nearline where dt =date_sub('${datebuf}',1)
				 group by vid_1,vid_2,similarity)b
			on a.vid_1=b.vid_1
		)c
	)d
where rank<= 80;