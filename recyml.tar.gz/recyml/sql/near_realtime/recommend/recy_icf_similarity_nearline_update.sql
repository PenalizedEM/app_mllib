insert OVERWRITE table dm.recy_icf_similarity_nearline PARTITION(dt='${model_date}')
select if(b.vid_1 is NULL,a.vid_1,b.vid_1) vid_1 ,
	   if(b.vid_2 is NULL,a.vid_2,b.vid_2) vid_2 ,
	   if(b.num_1 is NULL,a.num_1,b.num_1) num_1 ,
	   if(b.num_2 is NULL,a.num_2,b.num_2) num_2 ,
	   if(b.num_12 is NULL,a.num_12,b.num_12) num_12,
	   if(b.similarity is null,a.similarity,b.similarity) similarity,
	   if(b.hour is null,a.update_hour,b.hour) update_hour

from
	(
    	select vid_1,
    		   vid_2,
    		   num_1,
    		   num_2,
    		   num_12,
    		   similarity,
    		   update_hour
    	from
    	dm.recy_icf_similarity_nearline
    	where dt = '${model_date}'
	) a
full outer join
   (
       select vid_1,
    		   vid_2,
    		   num_1,
    		   num_2,
    		   num_12,
    		   similarity,
    		   hour
      	from
    	dm.recy_icf_similarity
    	where dt = date_add('${model_date}',1) and hour ='${hour}'
	) b
on (a.vid_1=b.vid_1 AND a.vid_2=b.vid_2);