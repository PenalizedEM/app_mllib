--drop TABLE dm.recy_out_topk;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_out_topk(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    prediction   FLOAT COMMENT '预测打分',
    title   STRING COMMENT '视频标题',
    pic STRING COMMENT '视频标图',
    short_title STRING COMMENT '推荐语',
    hits_total INT COMMENT '播放次数',
    comment_total INT COMMENT '评论次数',
    createtime STRING COMMENT '创建时间'
)
COMMENT '最终推荐结果'
PARTITIONED BY(dt STRING, hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_out_topk/';


insert overwrite table dm.recy_out_topk partition(dt='${datebuf}',hour='${hour}')
select diu ,
       vid,
       prediction,
       title,
       pic,
       short_title,
       hits_total,
       comment_total,
       createtime
from
  (select * ,
          ROW_NUMBER() over (partition by diu
                             order by prediction desc) rank
   from
     (select a.*,
             title,
             pic,
             short_title,
             hits_total,
             comment_total,
             createtime,
             uid, ROW_NUMBER() over (partition by diu,uid
                                    order by prediction desc) rn
      from
        (select diu,
                vid,
                rating prediction
         from dm.recy_icf_recommend
         where dt='${datebuf}'
          and hour='${hour}'
         union all select u_diu diu,
                          u_vid vid,
                          0 prediction
         from dm.recy_als_prediction
         where dt='${datebuf}'
          and hour='${hour}' ) a
      join db.video b on (a.vid = b.vid)) b
   where rn<=3) c
where rank<=60