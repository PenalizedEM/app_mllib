
--drop TABLE dm.recy_cold_pop;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_cold_pop(
    vid   STRING  COMMENT '视频id',
    pop  double COMMENT '流行系数',
    datebuf  STRING COMMENT '日期'
)
COMMENT '每小时冷启动热门'
PARTITIONED BY(dt STRING, hour STRING, type STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/dm/recy_cold_pop/';

from 
(
	select 
	u_vid vid,
	up_days,
	up_hour,
	pow(up_days+1,-1/up_hour)*rating pop,
	'${datebuf}' datebuf,
	if(type='10','lite','normal') type
	from 
	(
	select u_vid,
	count(1) uv,
	avg(f_rating) rating
	from dm.user_video_rating
	where dt='${datebuf}'
	 and hour='${hour}' 
	group by u_vid 
	having uv>10 
	) a 
    join (select vid,type,datediff('${datebuf}',to_date(createtime)) up_days, hour(createtime)+1 up_hour from db.video where status='0' and parent_category not in ('65', '55', '54', '53', '47') and type not in ('9'))  b
	on(a.u_vid=b.vid)
) a 
insert overwrite table dm.recy_cold_pop partition(dt='${datebuf}', hour='${hour}', type='lite')
select vid, pop, datebuf where type='lite' and up_days<=2 order by pop desc
limit 500 
insert overwrite table dm.recy_cold_pop partition(dt='${datebuf}', hour='${hour}', type='normal')
select vid, pop, datebuf where type='normal' and up_days<=2  order by pop desc
limit 500 
;
