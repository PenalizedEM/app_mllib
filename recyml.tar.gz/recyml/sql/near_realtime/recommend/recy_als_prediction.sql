--drop TABLE dm.recy_als_prediction;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_als_prediction(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_diu INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid',
    prediction FLOAT COMMENT '预测结果'
)
COMMENT '用户视频评分预测结果表'
PARTITIONED BY(dt STRING, hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_als_predict/';


ALTER TABLE dm.recy_als_prediction ADD IF NOT EXISTS
PARTITION (dt='2017-03-14', hour='17') LOCATION '/olap/dm/recy_als_predict/2017-03-14/17';