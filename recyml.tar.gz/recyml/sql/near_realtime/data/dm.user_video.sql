-- drop TABLE dm.user_video;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.user_video(
  u_timestamp STRING COMMENT '东八区时间',
	u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
	u_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
	u_uid STRING COMMENT '注册用户id',
	u_mod STRING COMMENT '服务端接口模块',
	u_ac STRING COMMENT '服务端具体接口',
	u_client STRING COMMENT '客户端类型',
	u_vid STRING COMMENT '视频的id',
	u_rate STRING COMMENT '视频播放进度（百分比)',
	u_percent STRING COMMENT '页面停留时间/视频播放时间',
	u_action STRING COMMENT '操作播放器行为',
	u_ishigh STRING COMMENT '是否高清视频',
	u_abtag STRING COMMENT 'AB测试标识',
	u_num STRING COMMENT '送花数量',
	u_content STRING COMMENT '评论内容',
	u_source STRING COMMENT '页面',
	u_client_module STRING COMMENT '模块',
	u_playtime STRING COMMENT '播放时长,单位秒',
	tu_playid STRING COMMENT '播放器ID,diu+vid+playid可唯一标识一次播放',
	u_province STRING COMMENT '用户省份',
  u_city STRING COMMENT '用户城市'
)
COMMENT '用户观看视频相关表-小时表'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/user_video/';


insert overwrite table dm.user_video partition(dt='${datebuf}',hour='${hour}')
select u_timestamp,
       u_div,
       u_diu,
       u_uid,
       u_mod,
       u_ac,
       u_client,
       u_vid,
       u_rate,
       u_percent,
       u_action,
       u_ishigh,
       get_json_object(u_bigger_json,'$.u_abtag') u_abtag ,
       get_json_object(u_bigger_json,'$.u_num') u_num ,
       get_json_object(u_bigger_json,'$.u_content') u_content  ,
       u_source,
       u_client_module,
       get_json_object(u_bigger_json,'$.u_playtime') u_playtime,
       get_json_object(u_bigger_json,'$.u_playid') u_playid,
       u_province,
       u_city
from dw.uamini
where dt='${datebuf}'
  and hour='${hour}'
  and u_vid <> ''
  and u_diu not in ('0123456789abcde',
                    '012345678912345',
                    '123456789012345',
                    '0',
                    '000000',
                    '00000000',
                    '00000000000000',
                    '000000000000000',
                    '0000000000000000',
                    '000000011234564',
                    '111111111111111',
                    '',
                    'UNKNOWN',
                    'Unknown',
                    '+++++000000000',
                    '+GSN:808DCF89',
                    '000000000000026')
  and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed',
                                 'top-hits',
                                 'flower-good',
                                 'flower-send',
                                 'emptylog-share_onclick',
                                 'user-fav',
                                 'emptylog-cdn_download_speed',
                                 'message-video_comment_add',
                                 'message-video_comment_reply')


