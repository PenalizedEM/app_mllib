drop TABLE dm.recy_als_candy_similar;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_als_candy_similar(
    u_diu   STRING  COMMENT '用户id',
    u_vid  STRING COMMENT '视频id'
)
COMMENT '相似视频候选集'
PARTITIONED BY(dt STRING, hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_als_candy_similar/';

insert overwrite table dm.recy_als_candy_similar partition(dt='${datebuf}',hour='${hour}' )
select u_diu,
       b.vid_1 as u_vid
from
  (select u_diu,
          u_vid
   from dm.user_video_rating
   where dt='${datebuf}' and hour='${hour}'
     and f_timestamp >= unix_timestamp('${datebuf}','yyyy-MM-dd')
     and u_diu not in ('0123456789abcde',
                       '012345678912345',
                       '123456789012345',
                       '0',
                       '000000',
                       '00000000',
                       '00000000000000',
                       '000000000000000',
                       '0000000000000000',
                       '000000011234564',
                       '111111111111111',
                       '',
                       'UNKNOWN',
                       'Unknown',
                       '+++++000000000',
                       '+GSN:808DCF89',
                       '000000000000026'))a
left outer join
  (select vid_1,
          vid_2
   from dm.recy_icf_similarity_topn)b on (a.u_vid = b.vid_1)
group by u_diu,
         b.vid_1
