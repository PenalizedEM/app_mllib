CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_als_data_uvm(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_timestamp BIGINT COMMENT '最后观看该视频的时间戳',
    f_diu INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid',
    f_rating   DOUBLE COMMENT '归一化后的评分'
)
COMMENT '用户视频评分历史全量表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_als_data_uvm/';