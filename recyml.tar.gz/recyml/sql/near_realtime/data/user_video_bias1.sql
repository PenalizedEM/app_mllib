--drop table user_video_bias1;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.user_video_bias1(
    diu   STRING  COMMENT '用户id',
    mapr  INT COMMENT '最大值',
    mipr iNT COMMENT '最小值',
    nnpr  INT COMMENT '99分位值',
    ntpr   INT COMMENT '90分位值',
    tpr  INT  COMMENT '10分位值',
    opr INT  COMMENT '1分位值',
    pv INT COMMENT '观看视频次数'
)
COMMENT '用户bias'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/user_video_bias1/';

set mapreduce.map.memory.mb=3072;
insert overwrite table dm.user_video_bias1 PARTITION (dt='${datebuf}',hour='${hour}')
select u_diu,
       max(f_vd)mapr,
       min(f_vd)mipr,
       percentile(cast(f_vd as int),0.99)nnpr,
       percentile(cast(f_vd as int),0.90)ntpr,
       percentile(cast(f_vd as int),0.10)tpr,
       percentile(cast(f_vd as int),0.01)opr,
       count(1)pv
from dm.user_video_index
where dt='${datebuf}'
  and hour='${hour}'
  and f_vd>0
group by u_diu