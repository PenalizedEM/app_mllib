--drop table dm.user_video_rating;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.user_video_rating(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_timestamp BIGINT COMMENT '最后观看该视频的时间戳',
    f_diu INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid',
    f_rating   DOUBLE COMMENT '归一化后的评分'
)
COMMENT '用户视频评分-小时分区表'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/dm/user_video_rating/';


insert overwrite table dm.user_video_rating PARTITION (dt='${datebuf}',hour='${hour}')
select u_diu,
       u_vid,
       f_timestamp,
       f_diu,
       f_vid,
       if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating
from
  (select u_diu,
          u_vid,
          f_timestamp,
          f_diu,
          f_vid,
          f_sb,
          f_sc,
          f_sd,
          f_se,
          f_sf,
          (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa
   from
     (select u_diu,
             u_vid,
             f_timestamp,
             f_diu,
             f_vid,
             f_vd,
             f_sb,
             f_sc,
             f_sd,
             f_se,
             f_sf,
             if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up
      from
        (select u_diu,
                u_vid,
                f_timestamp,
                hash(u_diu) f_diu,
                hash(u_vid) f_vid,
                f_vd,
                cast(if(f_down>0,5.0,0) as double) f_sb,
                cast(if(f_share>0,2.0,0.0) as double) f_sc,
                cast(if(f_fav>0,3.0,0.0) as double)f_sd,
                cast(if(f_flower>0,2.0,0.0) as double)f_se,
                cast(if(f_comment>0,1.0,0.0) as double)f_sf
         from dm.user_video_index
         where dt='${datebuf}' and hour='${hour}'
          ) a
      join
        (select diu,
                nnpr,
                mipr,
                pv
         from dm.user_video_bias1 -- user
         where dt='${datebuf}' and hour='${hour}')b on (a.u_diu = b.diu)) c
   join
     (select vid,
             if(nnpr=0,0.1,nnpr) nnpr,
             mipr,
             pv
      from dm.user_video_bias2 -- video
      where dt='${datebuf}' and hour='${hour}')d on (c.u_vid = d.vid))e
