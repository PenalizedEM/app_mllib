-- drop TABLE dm.user_video_index;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.user_video_index(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_vp   INT COMMENT '观看最大进度',
    f_vd   DOUBLE COMMENT '观看时长',
    f_down BIGINT COMMENT '下载次数',
    f_share BIGINT COMMENT '分享次数',
    f_fav BIGINT COMMENT '收藏次数',
    f_flower BIGINT COMMENT '送花次数',
    f_hits BIGINT COMMENT '播放次数',
    f_comment BIGINT COMMENT '评论次数',
    f_timestamp BIGINT COMMENT '当日观看该视频的时间戳'
)
COMMENT '用户观看视频指标统计'
PARTITIONED BY(dt STRING,hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/user_video_index/';


insert overwrite table dm.user_video_index partition(dt='${datebuf}',hour='${hour}')
select u_diu,
          u_vid,
          max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'
                 and u_action in ('exit','complete'),if(u_percent>100,100,u_percent),0)) vp,
          sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'
                 and u_action in ('exit','complete'),u_playtime,0)) vst,
          sum(if(concat(u_mod,'-',u_ac)='emptylog-cdn_download_speed',1,0)) f_down,
          sum(if(concat(u_mod,'-',u_ac)='emptylog-share_onclick',1,0))f_share,
          sum(if(concat(u_mod,'-',u_ac) in ('user-fav','flower-good'),1,0))f_fav,
          sum(if(concat(u_mod,'-',u_ac)='flower-send',u_num,0)) f_flower,
          sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) f_hits,
          sum(if(concat(u_mod,'-',u_ac) in
          	('message-video_comment_add','message-video_comment_reply'),1,0)) f_comment,
          max(unix_timestamp(substr(u_timestamp,0,19)))f_timestamp
   from dm.user_video
   where dt='${datebuf}' and hour='${hour}'
   group by
    u_diu,
    u_vid







