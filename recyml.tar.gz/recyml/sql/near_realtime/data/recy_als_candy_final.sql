
--drop TABLE dm.recy_als_candy_final;
CREATE EXTERNAL TABLE IF NOT EXISTS dm.recy_als_candy_final(
    u_diu   STRING  COMMENT '用户id',
    u_vid  STRING COMMENT '视频id',
    f_diu   INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid'
)
COMMENT '候选集A'
PARTITIONED BY(dt STRING, hour STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dm/recy_als_candy_final/';

insert overwrite table dm.recy_als_candy_final partition(dt='${datebuf}',hour='${hour}')
select c.* ,
       d.f_vid
from
  (select a.u_diu,
          a.u_vid,
          b.f_diu
   from
     (select u_diu,
             u_vid
      from dm.recy_als_candy_similar
      where dt='${datebuf}'
        and hour='${hour}'
      group by u_diu,
               u_vid)a
   join
     (select u_diu,
             f_diu
      from dm.user_video_rating
      where dt='${datebuf}'
        and hour='${hour}'
      group by u_diu,
               f_diu)b on (a.u_diu = b.u_diu))c
join
  (select u_vid,
          f_vid
   from dm.user_video_rating
   where dt='${datebuf}'
     and hour='${hour}'
   group by u_vid,
            f_vid)d on (c.u_vid = d.u_vid)
