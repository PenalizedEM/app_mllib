import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table video_recommend --fields-terminated-by \001 --hive-delims-replacement , --split-by vid  --target-dir /user/hadoop/db/video_recommend/ -m 1


CREATE EXTERNAL TABLE IF NOT EXISTS dw.video_recommend(
    id   int  COMMENT '推荐视频id',
    vid   bigint  COMMENT '视频id',
    type  STRING COMMENT '推荐类型',
    createtime STRING COMMENT '更新'
)
COMMENT '每日编辑推荐视频'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/db/video_recommend/';



/user/hue/oozie/workspaces/hue-oozie-1474784874.49/lib/mysql-connector-java-5.1.39-bin.jar

/user/hue/oozie/workspaces/hue-oozie-1474784874.49/lib/mysql-connector-java-5.1.39-bin.jar
