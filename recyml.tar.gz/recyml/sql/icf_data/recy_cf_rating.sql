
use da;

-- 推荐系统-协同过滤-用户评分数据生成
-- drop table recy_cf_rating;
CREATE EXTERNAL TABLE IF NOT EXISTS recy_cf_rating( 
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT '视频id',
rating double COMMENT '视频得分',
rank int COMMENT '排名',
actdate STRING COMMENT '更新日期'
)
COMMENT '推荐系统-协同过滤-用户评分数据生成'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_cf_rating/';


-- insert overwrite table da.recy_als_data_uvr partition (dt='2016-11-22')
-- select
-- u_diu, u_vid, f_vp,
-- f_vd,f_timestamp,f_down,
-- f_share,f_fav,f_flower,
-- f_hits,f_comment 
-- from da.recy_als_data_uvr where 
-- dt='2016-11-22'  
-- and !(f_vp=0 and f_vd=0 and f_down=0 and f_share=0 
-- and f_fav=0 and f_flower=0 and f_hits=0 and f_comment=0 ) 


insert overwrite table recy_cf_rating partition(dt='2016-09-30')
select diu,
       f_vid vid,
       vscore rating ,
       ROW_NUMBER() OVER (PARTITION by diu
                          order by vscore desc) rank ,
                                                actdate
from
  (select /* +mapjoin(a) */ u_diu diu,
                            u_vid f_vid,
                            actdate,
                            (b.f_vv-a.avg_vv)/if(std_vv=0,0.0001,std_vv)*2 + 
                            (b.f_vst-a.avg_vst)/if(std_vst=0,0.0001,std_vst)*4 + 
                            (b.f_vp-a.avg_vp)/if(std_vp=0,0.0001,std_vp)*3 + 
                            (b.f_vc-a.avg_vc)/if(std_vc=0,0.0001,std_vc)*1 + 
                            vsf*2 + 
                            (b.f_vf-a.avg_vf)/if(std_vf=0,0.0001,std_vf)*5 + 
                            (b.f_vs-a.avg_vs)/if(std_vs=0,0.0001,std_vs)*3 + 
                            vd*4.5 
                            as vscore
   from
     (select avg(f_hits) avg_vv,
             stddev_pop(f_hits) std_vv,
             avg(f_vd) avg_vst,
             stddev_pop(f_vd) std_vst,
             avg(f_vp) avg_vp,
             stddev_pop(f_vp) std_vp,
             avg(f_comment) avg_vc,
             stddev_pop(f_comment) std_vc,
             avg(f_fav) avg_vf,
             stddev_pop(f_fav) std_vf,
             avg(f_share) avg_vs,
             stddev_pop(f_share) std_vs
      from recy_als_data_uvr
      where dt='2016-09-30') a
   join
     (select u_diu,
             u_vid,
             from_unixtime(f_timestamp,'yyyy-MM-dd') actdate,
             f_hits f_vv,
             f_vd f_vst,
             f_vp,
             f_comment f_vc,
             f_fav f_vf,
             f_share f_vs,
             if(f_flower>0,1,0) vsf,
             if(f_down>0,1,0) vd
      from recy_als_data_uvr
      where dt='2016-09-30') b) c ;

-- select diu, f_vid vid, vscore rating , ROW_NUMBER() OVER (PARTITION by diu order by vscore desc) rank , actdate from (select /* +mapjoin(a) */ u_diu diu, u_vid f_vid, actdate, (b.f_vv-a.avg_vv)/if(std_vv=0,0.0001,std_vv)*2 + (b.f_vst-a.avg_vst)/if(std_vst=0,0.0001,std_vst)*4 + (b.f_vp-a.avg_vp)/if(std_vp=0,0.0001,std_vp)*3 + (b.f_vc-a.avg_vc)/if(std_vc=0,0.0001,std_vc)*1 + vsf*2 + (b.f_vf-a.avg_vf)/if(std_vf=0,0.0001,std_vf)*5 + (b.f_vs-a.avg_vs)/if(std_vs=0,0.0001,std_vs)*3 + vd*4.5 as vscore from (select avg(f_hits) avg_vv, stddev_pop(f_hits) std_vv, avg(f_vd) avg_vst, stddev_pop(f_vd) std_vst, avg(f_vp) avg_vp, stddev_pop(f_vp) std_vp, avg(f_comment) avg_vc, stddev_pop(f_comment) std_vc, avg(f_fav) avg_vf, stddev_pop(f_fav) std_vf, avg(f_share) avg_vs, stddev_pop(f_share) std_vs from recy_als_data_uvr where dt='"+inDate+"') a join (select u_diu, u_vid, from_unixtime(f_timestamp,'yyyy-MM-dd') actdate, f_hits f_vv, f_vd f_vst, f_vp, f_comment f_vc, f_fav f_vf, f_share f_vs, if(f_flower>0,1,0) vsf, if(f_down>0,1,0) vd from recy_als_data_uvr where dt='"+inDate+"') b) c

-- /home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/wenlong/spark/recy_cf_rating.py 2016-12-24
-- /home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_cf_rating ADD IF NOT EXISTS PARTITION (dt='2016-12-24') LOCATION '/olap/da/recy_cf_rating/2016-12-24/'" 

drop table da.recy_cf_rating_online;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_cf_rating_online(
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT '视频id',
type  int  COMMENT '视频类型',
createtime  STRING  COMMENT '视频创建时间',
rating double COMMENT '视频得分',
actdate STRING COMMENT '更新日期',
num bigint COMMENT '视频观看人数'
)
COMMENT '推荐系统-协同过滤-用户评分数据生成2'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_cf_rating_online/'

insert overwrite table recy_cf_rating_2  
select /* +mapjoin(b) */ diu,
                         b.vid,
                         rating,
                         rank,
                         actdate,
                         num
from
  (select vid,
          count(1) num
   from da.recy_cf_rating
   where dt='"+inDate+"'
   group by vid) a
join
  (select *
   from da.recy_cf_rating
   where dt='"+inDate+"') b on(a.vid=b.vid)
  
-- 得分抽样
select /* +mapjoin(a) */ a.diu,
a.vid,
b.title,
b.short_title,
a.num,
a.rating,
a.rank,
a.actdate
from
  (select *
   from da.recy_cf_rating_2
   where diu in ('869154027891915')
   order by rating desc limit 20) a
join dw.video b on(a.vid=b.vid)

-- 得分分值分布
select min(rating) rating_0 ,
       percentile(cast(rating as bigint),0.5) rating_50 ,
       percentile(cast(rating as bigint),0.9) rating_90 ,
       percentile(cast(rating as bigint),0.99) rating_99 ,
       percentile(cast(rating as bigint),0.999) rating_999 ,
       percentile(cast(rating as bigint),0.9999) rating_9999 ,
       max(rating) rating_100
from da.recy_als_data_uvr
      where dt='2016-12-27'
  

-- 第一版
-- f_vc                 1                   视频评论次数
-- f_vd                 4.5                 >0：下载视频，0：未下载
-- f_vf                 5                   >0：收藏视频，0：未收藏
-- f_vp                 3                   视频最大播放完整度
-- f_vs                 3                   视频分享次数
-- f_vsf                2                   >0:送花，0：未送花
-- f_vst                4                   视频累计播放时间-秒
-- f_vv                 2                   视频播放次数

-- 第二版
-- f_vc                 2                   视频评论次数
-- f_vd                 4                   下载视频
-- f_vf                 5                   收藏视频
-- f_vp                 3                   视频最大播放完整度
-- f_vs                 3                   视频分享次数
-- f_vsf                2                   送花
-- f_vst                2                   视频累计播放时间-秒
-- f_vv                 1                   视频播放次数

-- and diu in ('45C7EF12-8175-4AE8-978D-303941C1B6BA',
--            '37687478-0C42-4AD5-8CE1-267A47F40CE0',
--          '2A1807A6-4AE7-459B-B30E-F3DF33C02A06'
-- '862458035751236')

        -- and f_vid in ('8138753',
        --    '6414663',
        --  '8165244',
        --  '8112358',
        --  '1473229820640',
        --  '1472651555',
        --  '1472983514',
        --  '1472634000',
        --  '1458630354',
        --  '1472733964')

         and diu not in
             ('0123456789abcde',
             '012345678912345',
             '123456789012345',
             '812345678912345',
             '353919025680130',
             '867731020001006',
             '865407010000009',
             '861622010000056',
             '352005048247251',
             '0',
             '000000',
             '00000000',
             '00000000000000',
             '000000000000000',
             '0000000000000000',
             '000000011234564',
             '111111111111111',
             '',
             'UNKNOWN',
             'Unknown',
             '+++++000000000',
             '+GSN:808DCF89',
             '000000000000026')

            -- (b.f_vv-a.avg_vv)/if(std_vv=0,0.0001,std_vv)*2  f_vv,
             -- (b.f_vst-a.avg_vst)/if(std_vst=0,0.0001,std_vst)*4 f_vst,
             -- (b.f_vp-a.avg_vp)/if(std_vp=0,0.0001,std_vp)*3 f_vp,
             -- (b.f_vc-a.avg_vc)/if(std_vc=0,0.0001,std_vc)*1 f_vc,
             -- vsf*2 f_vsf,
             -- (b.f_vf-a.avg_vf)/if(std_vf=0,0.0001,std_vf)*5 f_vf,
             -- (b.f_vs-a.avg_vs)/if(std_vs=0,0.0001,std_vs)*3 f_vs,
             -- vd*4 f_vd,


