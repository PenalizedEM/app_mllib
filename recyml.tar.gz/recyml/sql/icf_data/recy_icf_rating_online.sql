
-- ItemCF 最终上线流程 
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_cf_rating_online( 
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT '视频id',
type  int  COMMENT '视频类型',
createtime  STRING  COMMENT '视频创建时间',
rating double COMMENT '视频得分',
actdate STRING COMMENT '更新日期',
num bigint COMMENT '视频观看人数' 
)
COMMENT '推荐系统-协同过滤-用户评分数据生成2'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_cf_rating_online/';

insert overwrite table da.recy_cf_rating_online
select /* +mapjoin(b) */ diu,
                         b.vid,
                         c.type,
                         c.createtime,
                         rating,
                         actdate,
                         num
from
  (select u_vid vid,
          count(1) num
   from da.recy_als_data_uvm
   where dt='"+inDate+"'
   group by u_vid) a
join
  (select u_diu diu,
          u_vid vid ,
          f_rating rating,
          from_unixtime(f_timestamp,'yyyy-MM-dd') actdate
   from da.recy_als_data_uvm
   where dt='"+inDate+"') b on(a.vid=b.vid)
join
  (select vid, type, createtime
   from dw.video
   where status=0) c on(a.vid=c.vid)
