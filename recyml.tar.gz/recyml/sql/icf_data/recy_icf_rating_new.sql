
drop table da.recy_recy_rating_temp;
create table da.recy_recy_rating_temp as 
select /* +mapjoin(a) */ u_diu diu,
                            u_vid f_vid,
                            actdate,
                            (b.f_vv-a.avg_vv)/if(std_vv=0,0.0001,std_vv) vv, 
                            (b.f_vst-a.avg_vst)/if(std_vst=0,0.0001,std_vst) vst, 
                            (b.f_vp-a.avg_vp)/if(std_vp=0,0.0001,std_vp) vp, 
                            (b.f_vc-a.avg_vc)/if(std_vc=0,0.0001,std_vc) vc, 
                            vsf,
                            vf, 
                            (b.f_vs-a.avg_vs)/if(std_vs=0,0.0001,std_vs) vs, 
                            vd 
   from
     (select avg(f_hits) avg_vv,
             stddev_pop(f_hits) std_vv,
             avg(f_vd) avg_vst,
             stddev_pop(f_vd) std_vst,
             avg(f_vp) avg_vp,
             stddev_pop(f_vp) std_vp,
             avg(f_comment) avg_vc,
             stddev_pop(f_comment) std_vc,
             avg(f_share) avg_vs,
             stddev_pop(f_share) std_vs
      from da.recy_als_data_uvr
      where dt='2016-12-31') a
   join
     (select u_diu,
             u_vid,
             from_unixtime(f_timestamp,'yyyy-MM-dd') actdate,
             f_hits f_vv,
             f_vd f_vst,
             f_vp,
             f_comment f_vc,
             if(f_fav>0,1,0) vf,
             f_share f_vs,
             if(f_flower>0,1,0) vsf,
             if(f_down>0,1,0) vd
      from da.recy_als_data_uvr
      where dt='2016-12-31') b;

-- 第二版
-- f_vf                 5                   收藏视频
-- f_vd                 4                   下载视频
-- f_vp                 3                   视频最大播放完整度
-- f_vs                 3                   视频分享次数
-- f_vc                 2                   视频评论次数
-- f_vsf                2                   送花
-- f_vst                2                   视频累计播放时间-秒
-- f_vv                 1                   视频播放次数

drop table da.recy_cf_rating_new;
create table da.recy_cf_rating_new as
select b.diu,
       b.f_vid,
       b.actdate,
       (vv-mn_vv)/if((mx_vv-mn_vv)=0,0.0001,mx_vv-mn_vv)*1 vv,
       (vst-mn_vst)/if((mx_vst-mn_vst)=0,0.0001,mx_vst-mn_vst)*2 vst,
       (vc-mn_vc)/if((mx_vc-mn_vc)=0,0.0001,mx_vc-mn_vc)*2 vc,
       vsf*2 vsf,
       (vp-mn_vp)/if((mx_vp-mn_vp)=0,0.0001,mx_vp-mn_vp)*3 vp,
       (vs-mn_vs)/if((mx_vs-mn_vs)=0,0.0001,mx_vs-mn_vs)*3 vs,
       vd*4 vd,
       vf*5 vf,
       ((vv-mn_vv)/if((mx_vv-mn_vv)=0,0.0001,mx_vv-mn_vv)*1 + (vst-mn_vst)/if((mx_vst-mn_vst)=0,0.0001,mx_vst-mn_vst)*2 + (vc-mn_vc)/if((mx_vc-mn_vc)=0,0.0001,mx_vc-mn_vc)*2 + vsf*2 + (vp-mn_vp)/if((mx_vp-mn_vp)=0,0.0001,mx_vp-mn_vp)*3 + (vs-mn_vs)/if((mx_vs-mn_vs)=0,0.0001,mx_vs-mn_vs)*3 + vd*4 + vf*5)/(1+2+2+2+3+3+4+5)*5 rating
from
  (select diu,
          max(vv) mx_vv,
          min(vv) mn_vv,
          max(vst) mx_vst,
          min(vst) mn_vst,
          max(vp) mx_vp,
          min(vp) mn_vp,
          max(vc) mx_vc,
          min(vc) mn_vc,
          max(vs) mx_vs,
          min(vs) mn_vs
   from da.recy_recy_rating_temp
   group by diu) a
join da.recy_recy_rating_temp b on(a.diu=b.diu)

select * from da.recy_cf_rating_new where diu in ('37687478-0C42-4AD5-8CE1-267A47F40CE0') order by rating desc limit 10;

insert overwrite table recy_cf_rating partition(dt='2016-12-31')
select diu,
       f_vid vid,
       rating ,
       ROW_NUMBER() OVER (PARTITION by diu
                          order by rating desc) rank ,
                                                actdate
from da.recy_cf_rating_new ;


insert overwrite table recy_cf_rating_2  
select /* +mapjoin(b) */ diu,
                         b.vid,
                         rating,
                         rank,
                         actdate,
                         num
from
  (select vid,
          count(1) num
   from da.recy_cf_rating
   where dt='2016-12-31'
   group by vid) a
join
  (select *
   from da.recy_cf_rating
   where dt='2016-12-31') b on(a.vid=b.vid)

-- select /* +mapjoin(a) */ a.diu,
-- a.vid,
-- b.title,
-- b.short_title,
-- a.rating 
-- from
--   (select u_diu diu, f_vid vid , f_rating rating from da.recy_als_data_uvm where dt='2016-12-31'
--    and u_diu in ('45C7EF12-8175-4AE8-978D-303941C1B6BA')
--    order by rating desc limit 20) a
-- join dw.video b on(a.vid=b.vid)

create table da.recy_icf_out_topk like da.recy_als_out_topk;
insert overwrite table da.recy_icf_out_topk partition(dt='2016-12-31')
select /* +mapjoin(a) */ a.diu, 
a.vid,
a.rating prediction , 
b.title,
b.pic ,
b.short_title,
b.hits_total,
b.comment_total,
b.createtime 
from
  (select  diu,  vid , rating from da.recy_icf_recommend where dt='2016-12-31'
    and rank<=60) a
join (select * from dw.video where  status=0 ) b on(a.vid=b.vid)


/home/hadoop/bin/hadoop fs -rmr hdfs://uhadoop-zr4hvu-master1:8020/olap/da/recy_final_out_topk/2016-12-31


/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.171.218:8020/user/hive/warehouse/da.db/recy_icf_out_topk/dt=2016-12-31 hdfs://uhadoop-zr4hvu-master1:8020/olap/da/recy_final_out_topk/2016-12-31

ALTER TABLE da.recy_final_out_topk ADD IF NOT EXISTS PARTITION (dt='2016-12-31') LOCATION '/olap/da/recy_final_out_topk/2016-12-31/';

INSERT OVERWRITE TABLE dm.dm_recommend_video
SELECT
  CONCAT(diu, '_', '2016-12-29', '_', vid) rowkey,
  vid,
  title,
  pic,
  short_title,
  prediction,
  hits_total,
  comment_total,
  createtime
FROM
  da.recy_final_out_topk
WHERE
  diu != '000000000000000'
AND dt = '2016-12-31';