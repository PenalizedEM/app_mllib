SELECT e.u_diu ,
       g.u_vid,
       e.f_diu,
       g.f_vid
FROM
  (SELECT d.u_diu,
          d.f_diu,
          c.vid
   FROM
     (SELECT diu,
             vid
      FROM
        (SELECT d_diu diu,
                d_vid vid
         FROM adm.f_video_dv
         WHERE dt>='"+searchDate+"'
           AND dt<='"+inDate+"'
           AND d_module IN ('框搜',
                            '分类搜')
         GROUP BY d_diu ,
                  d_vid)a
      LEFT OUTER JOIN
        (SELECT u_diu,
                u_vid,
                f_diu,
                f_vid
         FROM da.recy_als_data_uvm
         WHERE dt='"+inDate+"'
         GROUP BY u_diu,
                  u_vid,
                  f_diu,
                  f_vid)b ON (a.diu = b.u_diu
                              AND a.vid = b.u_vid)
      WHERE b.u_diu IS NULL)c
   JOIN
     (SELECT u_diu,
             f_diu
      FROM da.recy_als_data_uvm
      WHERE dt='"+inDate+"'
      GROUP BY u_diu,
               f_diu)d ON (c.diu=d.u_diu))e
JOIN
  (SELECT u_vid,
          f_vid
   FROM da.recy_als_data_uvm
   WHERE dt='"+inDate+"'
   GROUP BY u_vid,
            f_vid)g ON (e.vid = g.u_vid)







SELECT diu, vid, rn FROM (SELECT r.diu, r.vid, r.pp, ROW_NUMBER() over (partition BY r.diu ORDER BY r.pp DESC)rn FROM (SELECT p.* FROM (SELECT * FROM da.recy_ltr_predict)p JOIN (SELECT vid, createtime FROM dw.video WHERE TYPE=10)q ON (p.vid = q.vid))r WHERE dt='"+inDate+"'AND pp>=0.5)a

SELECT c.vtype,
       sum(pv)apv
FROM
  (SELECT a.d_vid,
          pv,
          if(to_date(b.createtime)<'2016-01-01',0,1)vtype
   FROM
     (SELECT d_vid,
             sum(m_dv)pv
      FROM adm.f_video_dv
      WHERE dt='2017-09-14'
      GROUP BY d_vid)a
   JOIN
     (SELECT vid,
             createtime
      FROM dw.video)b ON (a.d_vid = b.vid))c
GROUP BY c.vtype


SELECT a.*,b.u_diu as b,b.u_vid as bvid ,b.u_ruuid as bru,if(b.u_diu is NULL,0,1)label
FROM
  (SELECT u_diu,
          u_vid,
          u_ruuid,


          u_rsource,
          u_rank,
          u_timestamp
   FROM edw.user_dvlog
   WHERE dt<='2017-09-01')a
LEFT OUTER JOIN
  (SELECT u_diu,
          u_vid,
          get_json_object(u_bigger_json,'$.u_ruuid')u_ruuid
   FROM edw.user_ilog
   WHERE dt='2017-09-01'
     AND concat(u_mod,'-',u_ac)='top-hits')b on(a.u_diu = b.u_diu
                                                AND a.u_vid = b.u_vid
                                                AND a.u_ruuid = b.u_ruuid)

SELECT u_timestamp, u_backtime, u_responsetime, u_host, u_xff, u_status, u_size , u_div, u_dic , u_diu, u_diu2 , u_diu3, u_uid , u_time, u_mod , u_ac, u_client , u_ver, u_uuid , u_hash, u_xinge , u_token, u_agent , u_method, u_client_module , u_source, u_vid , u_width, u_height , u_lon, u_lat , u_province, u_city , u_netop , u_nettype, u_sdkversion , u_model, u_device , u_manufacture, get_json_object(u_bigger_json,'$.u_rsource')u_rsource , get_json_object(u_bigger_json,'$.u_rank')u_rank, get_json_object(u_bigger_json,'$.u_rmodelid')u_rmodelid , get_json_object(u_bigger_json,'$.u_ruuid')u_ruuid, get_json_object(u_bigger_json,'$.u_strategyid')u_strategyid FROM dw.uabigger WHERE dt='"+inDate+"'AND concat(u_mod,'-',u_ac)='emptylog-video_display'
SELECT a.*,if(a.u_ruuid is null,0,1)label
FROM
  (SELECT u_diu,
          u_vid,
          u_ruuid,
          u_rsource,
          u_rank,
          u_timestamp
   FROM dw.uabigger
   WHERE dt<='2017-08-30'
     AND concat(u_mod,'-',u_ac)='emptylog-video_display')a
LEFT OUTER JOIN
  (SELECT u_diu,
          u_vid,
          u_ruuid
   FROM dw.uabigger
   WHERE dt<='2017-08-30'
     AND concat(u_mod,'-',u_ac)='top-hits')b on(a.diu = b.diu
                                                AND a.vid = b.vid
                                                AND a.ruuid = b.ruuid)



INSERT overwrite TABLE da.mid_video_ex PARTITION (dt='"+inDate+"')
SELECT a.diu,
       a.cm,
       b.vid,
       sum(pv) m_pv,
       tag
FROM
  (SELECT u_diu AS diu,
          u_client_module AS cm,
          u_vid,
          get_json_object(u_bigger_json,'$.u_abtag') tag,
          count(1) pv
   FROM dw.uabigger
   WHERE dt='"+inDate+"'
     AND concat(u_mod,'-',u_ac)='emptylog-video_display'
   GROUP BY u_diu,
            u_client_module,
            u_vid,
            get_json_object(u_bigger_json,'$.u_abtag'))a LATERAL VIEW explode(split(u_vid,','))b AS vid
GROUP BY a.diu,
         a.cm,
         b.vid,
         tag



SELECT a.d_diu,
       a.d_vid,
       if(a.m_dv IS NULL,0,a.m_dv)ex,
       if(b.m_vv IS NULL,0,1)click
FROM
  (SELECT d_diu,
          d_vid,
          m_dv
   FROM adm.f_video_dv
   WHERE dt='2017-08-30')a
LEFT OUTER  JOIN
  (SELECT d_diu,
          d_vid,
          m_vv
   FROM adm.f_video_vv
   WHERE dt='2017-08-30')b on(a.d_diu = b.d_diu
                              AND a.d_diu = b.d_vid)
GROUP BY a.d_diu,
         a.d_vid,
         a.m_dv,
         b.m_vv



SELECT a.diu,
       cast(a.vid AS int)vid ,
       if(a.m_pv IS NULL,0,a.m_pv)ex,
       if(b.m_pv IS NULL,0,1)label
FROM
  (SELECT d_diu diu,
          d_vid vid,
          sum(m_dv) m_pv
   FROM adm.f_video_dv
   WHERE dt<='" + inDate + "'
     AND dt>='" + exDate + "'
   GROUP BY d_diu,
            d_vid)a
LEFT OUTER  JOIN
  (SELECT d_diu diu,
          d_vid vid,
          sum(m_vv) m_pv
   FROM adm.f_video_vv
   WHERE dt<='" + inDate + "'
     AND dt>='" + exDate + "'
   GROUP BY d_diu,
            d_vid)b on(a.diu = b.diu
                       AND a.vid = b.vid)
GROUP BY a.diu,
         a.vid,
         a.m_pv,
         b.m_pv
