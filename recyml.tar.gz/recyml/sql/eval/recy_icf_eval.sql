use da;

-- 推荐系统-基于视频的协同过滤-topK评估，准确度：rt/r，召回度:rt/h


select sum(rt) rt,
       sum(r) r,
       sum(h) h
from
  (select a.diu,
          count(distinct(if(a.vid=b.vid,a.vid,null))) rt ,
          count(distinct(if(a.vid is not null,a.vid,null))) r ,
          count(distinct(if(b.vid is not null,b.vid,null))) h
   from
     (select diu,
             vid
      from da.recy_icf_recommend
      where dt='2016-12-15'
        and rank<=30) a
   full outer join
     (select diu,
             vid
      from da.recy_cf_eval_sample
      where type='test') b on (a.diu=b.diu)
   group by a.diu) b
where h>0


-- -- 抽取diu验证
-- select a.diu,
--           count(distinct(if(a.vid=b.vid,a.vid,null))) rt ,
--           count(distinct(if(a.vid is not null,a.vid,null))) r ,
--           count(distinct(if(b.vid is not null,b.vid,null))) h
--    from
--      (select diu,
--              vid
--       from da.recy_icf_recommend
--       where dt='2016-12-15'
--      and diu='37687478-0C42-4AD5-8CE1-267A47F40CE0') a
--    full outer join
--      (select diu,
--              vid
--       from da.recy_cf_eval_sample
--       where type='test'
--       and diu='37687478-0C42-4AD5-8CE1-267A47F40CE0') b on (a.diu=b.diu)
--    group by a.diu

-- 37687478-0C42-4AD5-8CE1-267A47F40CE0    3       114     43


