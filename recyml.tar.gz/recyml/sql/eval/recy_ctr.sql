 -- AB 曝光次数 播放次数 播放率 曝光 曝光人数 播放人数

use da;
--
--CREATE EXTERNAL TABLE IF NOT EXISTS recy_eval_click_rate(
--type STRING  COMMENT 'AB-曝光 非AB-曝光',
--datebuf STRING COMMENT '分区日期',
--tag STRING  COMMENT 'A B C NOT-AB',
--display  INT  COMMENT '猜你喜欢+每日精选+糖豆生活+糖豆广场-曝光次数',
--display_uv INT COMMENT '猜你喜欢+每日精选+糖豆生活+糖豆广场-曝光人数',
--play  INT  COMMENT '猜你喜欢+每日精选+糖豆生活+糖豆广场-播放次数',
--play_uv  INT  COMMENT '猜你喜欢+每日精选+糖豆生活+糖豆广场-播放人数',
--cai_diplay  INT  COMMENT '猜你喜欢-曝光次数',
--cai_diplay_uv INT COMMENT '猜你喜欢-曝光人数',
--cai_play  INT  COMMENT '猜你喜欢-播放次数',
--cai_play_uv INT COMMENT '猜你喜欢-播放人数',
--cj_diplay INT COMMENT '猜你喜欢+每日精选-曝光次数',
--cj_diplay_uv INT COMMENT '猜你喜欢+每日精选-曝光人数',
--cj_play INT COMMENT '猜你喜欢+每日精选-播放次数',
--cj_play_uv INT COMMENT '猜你喜欢+每日精选-播放人数'
--)
--COMMENT '推荐————首页各模块点击率'
--PARTITIONED BY(dt STRING, flag STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\t'
--STORED AS TEXTFILE
--LOCATION '/olap/da/recy_eval_click_rate';
--
--insert overwrite table da.recy_eval_click_rate partition(dt='${datebuf}',flag='AB')
--select 'AB-曝光',dt,
--       get_json_object(u_bigger_json,'$.u_abtag') tag,
--       sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display',1,0))display,
--       count(distinct if(concat(u_mod,'-',u_ac)='emptylog-video_display',u_diu,null))display_uv,
--       sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) play,
--       count(distinct if(concat(u_mod,'-',u_ac)='top-hits',u_diu,null)) play_uv,
--       sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--              and trim(u_client_module) in ('猜你喜欢','猜你喜欢,每日精选'),1,0)) cai_diplay,
--       count(distinct if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--                         and trim(u_client_module) in ('猜你喜欢','猜你喜欢,每日精选') ,u_diu,null)) cai_diplay_uv,
--       sum(if(concat(u_mod,'-',u_ac)='top-hits'
--              and trim(u_client_module)='猜你喜欢',1,0)) cai_play,
--       count(distinct if(concat(u_mod,'-',u_ac)='top-hits'
--                         and trim(u_client_module)='猜你喜欢',u_diu,null)) cai_play_uv ,
--       sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--              and trim(u_client_module) in ('猜你喜欢','每日精选','猜你喜欢,每日精选','我的关注,每日精选','每日精选,糖豆生活'),1,0)) cj_diplay,
--       count(distinct if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--                         and trim(u_client_module) in ('猜你喜欢','每日精选','猜你喜欢,每日精选','我的关注,每日精选','每日精选,糖豆生活') ,u_diu,null)) cj_diplay_uv,
--       sum(if(concat(u_mod,'-',u_ac)='top-hits'
--              and trim(u_client_module) in ('猜你喜欢','每日精选'),1,0)) cj_play,
--       count(distinct if(concat(u_mod,'-',u_ac)='top-hits'
--                         and trim(u_client_module) in ('猜你喜欢','每日精选'),u_diu,null)) cj_play_uv
--from dw.uabigger
--where dt='${datebuf}'
--  and u_div>='5.5.2'
--  and concat(u_mod,'-',u_ac) in ('emptylog-video_display',
--                                 'top-hits')
--  and get_json_object(u_bigger_json,'$.u_abtag') is not null
--  and get_json_object(u_bigger_json,'$.u_abtag')<>''
--  and trim(u_client_module)<>''
--  and trim(u_client_module) in ('猜你喜欢',
--                                '每日精选',
--                                '糖豆广场',
--                                '糖豆生活',
--                                '我的关注,每日精选',
--                                '每日精选,糖豆生活',
--                                '糖豆生活,糖豆广场',
--                                '猜你喜欢,每日精选')
--group by dt,
--         get_json_object(u_bigger_json,'$.u_abtag')
--order by dt, tag asc;
--
---- 非AB 曝光次数 播放次数 播放率 曝光 曝光人数 播放人数
--insert overwrite table da.recy_eval_click_rate partition(dt='${datebuf}',flag='NAB')
--select '非AB-曝光',dt,
--       'NOT-AB',
--       sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display',1,0))diplay,
--       count(distinct if(concat(u_mod,'-',u_ac)='emptylog-video_display',u_diu,null))diplay_uv,
--       sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0))cilck,
--       count(distinct if(concat(u_mod,'-',u_ac)='top-hits',u_diu,null)) play_uv,
--       sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--              and trim(u_client_module) in ('猜你喜欢','猜你喜欢,每日精选'),1,0)) cai_diplay,
--       count(distinct if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--                         and trim(u_client_module) in ('猜你喜欢','猜你喜欢,每日精选') ,u_diu,null)) cai_diplay_uv,
--       sum(if(concat(u_mod,'-',u_ac)='top-hits'
--              and trim(u_client_module)='猜你喜欢',1,0)) cai_cilck,
--       count(distinct if(concat(u_mod,'-',u_ac)='top-hits'
--                         and trim(u_client_module)='猜你喜欢',u_diu,null)) cai_play_uv ,
--       sum(if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--              and trim(u_client_module) in ('猜你喜欢','每日精选','猜你喜欢,每日精选','我的关注,每日精选','每日精选,糖豆生活'),1,0)) cj_diplay,
--       count(distinct if(concat(u_mod,'-',u_ac)='emptylog-video_display'
--                         and trim(u_client_module) in ('猜你喜欢','每日精选','猜你喜欢,每日精选','我的关注,每日精选','每日精选,糖豆生活') ,u_diu,null)) cj_diplay_uv,
--       sum(if(concat(u_mod,'-',u_ac)='top-hits'
--              and trim(u_client_module) in ('猜你喜欢','每日精选'),1,0)) cj_cilck,
--       count(distinct if(concat(u_mod,'-',u_ac)='top-hits'
--                         and trim(u_client_module) in ('猜你喜欢','每日精选'),u_diu,null)) cj_play_uv
--from dw.uabigger
--where dt='${datebuf}'
--  and u_div<'5.5.2'
--  and concat(u_mod,'-',u_ac) in ('emptylog-video_display',
--                                 'top-hits')
--   and trim(u_client_module) in ('猜你喜欢',
--                                    '每日精选',
--                                    '糖豆广场',
--                                    '糖豆生活',
--                                    '我的关注,每日精选',
--                                    '每日精选,糖豆生活',
--                                    '糖豆生活,糖豆广场',
--                                    '猜你喜欢,每日精选')
--group by dt
--order by dt asc;
--
--
--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_eval_play_time(
--type STRING  COMMENT 'AB-曝光 非AB-曝光',
--datebuf STRING COMMENT '分区日期',
--tag STRING  COMMENT 'A B C NOT-AB',
--play_time  INT  COMMENT '猜你喜欢+每日精选+糖豆生活+糖豆广场-播放时长',
--c_play_time INT COMMENT '猜你喜欢-播放时长',
--cj_play_time  INT  COMMENT '猜你喜欢+每日精选-播放时长'
--)
--COMMENT '推荐————首页各模块播放时长'
--PARTITIONED BY(dt STRING, flag STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\t'
--STORED AS TEXTFILE
--LOCATION '/olap/da/recy_eval_play_time';
--
-- -- AB 播放时长
--insert overwrite table da.recy_eval_play_time partition(dt='${datebuf}',flag='AB')
--select 'AB-播放时长',dt,
--       tag,
--       sum(play_time) play_time,
--       sum(if (module in ('猜你喜欢','猜你喜欢,每日精选'), play_time, 0)) c_play_time,
--       sum(if (module in ('猜你喜欢','每日精选','猜你喜欢,每日精选','我的关注,每日精选','每日精选,糖豆生活'), play_time, 0)) cj_play_time
--from
--  (select dt,
--          trim(u_client_module) module,
--          get_json_object(u_bigger_json,'$.u_abtag') tag,
--          u_vid,
--          u_diu,
--          get_json_object(u_bigger_json,'$.u_playid') playid,
--          max(get_json_object(u_bigger_json,'$.u_playtime')) play_time
--   from dw.uabigger
--   where dt='${datebuf}'
--     and u_div>='5.5.2'
--     and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed')
--     and get_json_object(u_bigger_json,'$.u_abtag') is not null
--     and get_json_object(u_bigger_json,'$.u_abtag')<>''
--     and trim(u_client_module)<>''
--      and trim(u_client_module) in ('猜你喜欢',
--                                    '每日精选',
--                                    '糖豆广场',
--                                    '糖豆生活',
--                                    '我的关注,每日精选',
--                                    '每日精选,糖豆生活',
--                                    '糖豆生活,糖豆广场',
--                                    '猜你喜欢,每日精选')
--   group by dt,
--            trim(u_client_module) ,
--            get_json_object(u_bigger_json,'$.u_abtag') ,
--            u_vid,
--            u_diu,
--            get_json_object(u_bigger_json,'$.u_playid')) a
--group by dt,
--         tag
--order by dt, tag asc;
--
---- 非AB 播放时长
--insert overwrite table da.recy_eval_play_time partition(dt='${datebuf}',flag='NAB')
--select '非AB-播放时长',dt,
--       'NOT-AB',
--       sum(play_time) play_time,
--       sum(if (module in ('猜你喜欢','猜你喜欢,每日精选'), play_time, 0)) c_play_time,
--       sum(if (module in ('猜你喜欢','每日精选','猜你喜欢,每日精选','我的关注,每日精选','每日精选,糖豆生活'), play_time, 0)) cj_play_time
--from
--  (select dt,
--          trim(u_client_module) module,
--          u_vid,
--          u_diu,
--          get_json_object(u_bigger_json,'$.u_playid') playid,
--          max(get_json_object(u_bigger_json,'$.u_playtime')) play_time
--   from dw.uabigger
--   where dt='${datebuf}'
--     and u_div<'5.5.2'
--     and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed')
--     and trim(u_client_module) in ('猜你喜欢',
--                                    '每日精选',
--                                    '糖豆广场',
--                                    '糖豆生活',
--                                    '我的关注,每日精选',
--                                    '每日精选,糖豆生活',
--                                    '糖豆生活,糖豆广场',
--                                    '猜你喜欢,每日精选')
--   group by dt,
--            trim(u_client_module) ,
--            u_vid,
--            u_diu,
--            get_json_object(u_bigger_json,'$.u_playid')) a
--group by dt
--order by dt asc;


CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_eval_total( 
datebuf STRING COMMENT '分区日期',
tag STRING  COMMENT 'A B C NOT-AB',
uv  INT  COMMENT '总用户数',
play_uv INT COMMENT '播放视频用户数',
play_time  INT  COMMENT '总播放时长'
)
COMMENT '推荐————APP整体情况'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_eval_total';

-- AB版人数，播放次数, 播放时长
set mapreduce.reduce.shuffle.memory.limit.percent=0.1;
insert overwrite table da.recy_eval_total partition(dt='${datebuf}')
select 
       dt,
       tag,
       count(distinct u_diu) uv ,
       count(distinct if(vv>0,u_diu,null)) play_uv,
       sum(vst) play_time
from
  (select dt,
          if(u_div>='5.5.2', get_json_object(u_bigger_json,'$.u_abtag'),'NOT-AB')tag,
          u_vid,
          u_diu,
          get_json_object(u_bigger_json,'$.u_playid') playid,
          sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) vv ,
          max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'
                 and get_json_object(u_bigger_json,'$.u_playtime') is not null,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst
   from dw.uabigger
   where dt='${datebuf}'
     and concat(u_mod,'-',u_ac) not in ('main-start',
                                        'top-count_plush',
                                        'emptylog-push_arrival',
                                        'main-update',
                                        'video-ab_start',
                                        'emptylog-count_plush',
                                        'top-isnew_diu',
                                        'video-gtag',
                                        'top-test')
   group by dt,
            if(u_div>='5.5.2', get_json_object(u_bigger_json,'$.u_abtag'),'NOT-AB'),
            u_vid,
            u_diu,
            get_json_object(u_bigger_json,'$.u_playid')) a
group by dt ,
         tag having tag>='A'
order by tag asc;

-- AB版留存

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_eval_retention( 
datebuf STRING COMMENT '分区日期',
tag STRING  COMMENT 'A B C NOT-AB',
new_uv  INT  COMMENT '新增用户数',
ret_uv INT COMMENT '留存用户数'
)
COMMENT '推荐————新增留存对比'
PARTITIONED BY(dt STRING) 
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_eval_retention';

insert overwrite table da.recy_eval_retention partition(dt='${onedayago}')
select 
       dt,
       tag,
       count(1) new_uv,
       sum(if (c.u_diu is null ,0 ,1)) ret_uv
from
  (select dt,
          if(u_div>='5.5.2',
                    get_json_object(u_bigger_json,'$.u_abtag'),
                    'NOT-AB') tag,
                              u_diu
   from dw.uabigger
   where dt='${onedayago}'
     and concat(u_mod,'-',u_ac) not in ('main-start',
                                        'top-count_plush',
                                        'emptylog-push_arrival',
                                        'main-update',
                                        'video-ab_start',
                                        'emptylog-count_plush',
                                        'top-isnew_diu',
                                        'video-gtag',
                                        'top-test')
   group by dt,
            if(u_div>='5.5.2',
                      get_json_object(u_bigger_json,'$.u_abtag'),
                      'NOT-AB') , u_diu) a
join
  (select u_diu
   from dw.uibigger
   where dt='${onedayago}'
     and to_date(u_timestamp_f)='${onedayago}') b on (a.u_diu=b.u_diu)
left outer join
  (select u_diu
   from dw.uibigger
   where dt='${datebuf}'
     and to_date(u_timestamp)='${datebuf}') c on (a.u_diu=c.u_diu)
group by dt,
         tag having tag>='A'
order by tag asc;

-- -- AB 点击率 点击次数
-- select 'AB 点击率' dt,
--        get_json_object(u_bigger_json,'$.u_abtag') tag,
--        sum(if(trim(u_action) in ('猜你喜欢') ,1,0)) cai_cilck,
--        count(distinct if(trim(u_action) in ('猜你喜欢'),u_diu,null)) cai_click_uv,
--        sum(if(trim(u_action) in ('猜你喜欢','每日精选') ,1,0)) cj_cilck,
--        count(distinct if(trim(u_action) in ('猜你喜欢','每日精选'),u_diu,null)) cj_click_uv,
--        sum(if( trim(u_action) in ('猜你喜欢','每日精选','糖豆广场','糖豆生活') ,1,0)) cilck,
--        count(distinct if(trim(u_action) in ('猜你喜欢','每日精选','糖豆广场','糖豆生活'),u_diu,null)) click_uv
-- from dw.uabigger
-- where dt>='${datebuf}'
--   and u_div>='5.5.2'
--   and u_client=2
--   and concat(u_mod,'-',u_ac) in ('emptylog-user_role')
--   and trim(u_old_activity)='首页'
--   and get_json_object(u_bigger_json,'$.u_abtag') is not null
--   and get_json_object(u_bigger_json,'$.u_abtag')<>''
-- group by dt,
--          get_json_object(u_bigger_json,'$.u_abtag')
-- order by dt desc;

-- -- 非AB 点击率 点击次数
-- -- 点击率 点击次数
-- select '非AB 点击',dt,
--        'NOT-AB',
--        sum(if(trim(u_action) in ('猜你喜欢') ,1,0)) cai_cilck,
--        count(distinct if(trim(u_action) in ('猜你喜欢'),u_diu,null)) cai_click_uv,
--        sum(if(trim(u_action) in ('猜你喜欢','每日精选') ,1,0)) cj_cilck,
--        count(distinct if(trim(u_action) in ('猜你喜欢','每日精选'),u_diu,null)) cj_click_uv,
--        sum(if( trim(u_action) in ('猜你喜欢','每日精选','糖豆广场','糖豆生活') ,1,0)) cilck,
--        count(distinct if(trim(u_action) in ('猜你喜欢','每日精选','糖豆广场','糖豆生活'),u_diu,null)) click_uv
-- from dw.uabigger
-- where dt>='${datebuf}'
--   and u_div<'5.5.2'
--   and concat(u_mod,'-',u_ac) in ('emptylog-user_role')
--   and trim(u_old_activity)='首页'
-- group by dt
-- order by dt desc;

