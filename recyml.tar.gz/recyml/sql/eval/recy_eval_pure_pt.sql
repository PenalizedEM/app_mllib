CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_eval_pure_pt(
datebuf STRING COMMENT '分区日期',
tag STRING  COMMENT 'A B ',
play_uv INT COMMENT '播放用户数',
play_time  INT  COMMENT '播放时长',
per_play_time float  COMMENT '人均播放时长'
)
COMMENT '猜你喜欢纯净(pure)版,(猜你喜欢推荐结果大于60个,无抄底数据的)人均播放时长'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_eval_pure_pt';




-- 猜你喜欢非抄底且推荐视频数足量的用户播放时长
insert overwrite table da.recy_eval_pure_pt partition(dt='${datebuf}')
select '${datebuf}',
       if(b.tag is null, c.tag, b.tag) tag ,
       count(distinct b.diu) play_uv,
       sum(if(m_vst is null,0,m_vst)) play_time,
       round(sum(if(m_vst is null,0,m_vst))/count(distinct b.diu),1) per_play_time
from
  (select dt, diu,
          count(1) pv
   from da.recy_final_out_topk
   where date_add(dt, 1) = '${datebuf}'
   group by dt, diu having pv>=60
   ) a
left outer join
  (select dt,
          tag,
          diu
   from da.mid_video_cmpv
   where dt='${datebuf}'
     and cm='猜你喜欢'
     and m_pv>0
     group by  dt, tag, diu) b
 on (a.diu=b.diu)
 left outer join
  (select dt,
          tag,
          diu,
          sum(m_vst) m_vst
   from da.mid_video_cmpt
   where dt='${datebuf}'
     and cm='猜你喜欢'
     group by
        dt,
          tag,
          diu) c
on (a.diu=c.diu)
group by a.dt ,
         if(b.tag is null, c.tag, b.tag)
order by tag asc;