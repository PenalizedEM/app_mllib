-- ############ 一、 APP内总体新用户人均播放时长  ############
select
datebuf, 
tag,
round(play_time/play_uv,1) avgplay  
from 
da.recy_eval_total_new
where dt>='2017-02-10' 
and tag in ('A','B','C')
order by 
datebuf,
tag
-- ############ 二、 APP内总体CTR  ############
select
datebuf, 
tag,
round(play/display,3)*100 ctr  
from 
da.recy_eval_click_rate_new
where dt>='2017-02-10' 
and tag in ('A','B','C')
order by 
datebuf,
tag




-- ############ 三、 猜你喜欢VS每日精选人均播放时长  ############
select a.datebuf,a.tag,(j_play_time/j_play_uv)avgplay
from
(select
datebuf, 
tag,
j_play_time  
from 
da.recy_eval_play_time_new
where dt>='2017-02-10' 
and tag in ('B'))a
join 
(select 
datebuf,tag,
j_play_uv
from 
da.recy_eval_click_rate_new
where dt>='2017-02-10' 
and tag in ('B'))b 
on (a.datebuf=b.datebuf and a.tag=b.tag)
union all 
select c.datebuf,c.tag,(c_play_time/c_play_uv)avgplay
from 
(select datebuf,tag,c_play_time from
da.recy_eval_play_time_new
where dt>='2017-02-10' 
and tag in ('A','C'))c
join 
(select
datebuf, 
tag , 
c_play_uv
from 
da.recy_eval_click_rate_new
where dt>='2017-02-10' 
and tag in ('A','C'))d on (c.datebuf=d.datebuf and c.tag=d.tag)
order by 
datebuf,
tag


-- ############ 四、 猜你喜欢VS每日精选CTR  ############

select
datebuf, 
tag,
round(j_play/j_diplay,3)*100 ctr 
from 
da.recy_eval_click_rate_new
where dt>='2017-02-10' 
and tag in ('B') 
union all 
select
datebuf, 
tag , 
round(c_play/c_diplay,3)*100 ctr  
from 
da.recy_eval_click_rate_new
where dt>='2017-02-10' 
and tag in ('A','C') 
order by 
datebuf,
tag