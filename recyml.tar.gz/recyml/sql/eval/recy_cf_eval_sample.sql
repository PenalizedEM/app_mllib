use da;

-- 推荐系统-协同过滤-效果评估——样本数据集准备
-- drop table recy_cf_eval_sample;
CREATE EXTERNAL TABLE IF NOT EXISTS recy_cf_eval_sample(
diu STRING  COMMENT 'diu',
vid  STRING  COMMENT '视频id',
rating double COMMENT '视频得分',
rank int COMMENT '排名',
actdate STRING COMMENT '更新日期',
num bigint COMMENT '视频观看人数',
type STRING  COMMENT '训练集:train, 测试集:test'
)
COMMENT '推荐系统-协同过滤-效果评估——样本数据集准备'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_cf_eval_sample/';

-- -- 数据分布调研- 用户观看的视频个数分布
-- select min(vcnt) vcnt_0 ,
--        percentile(cast(vcnt as bigint),0.5) vcnt_50 ,
--        percentile(cast(vcnt as bigint),0.9) vcnt_90 ,
--        percentile(cast(vcnt as bigint),0.99) vcnt_99 ,
--        percentile(cast(vcnt as bigint),0.999) vcnt_999 ,
--        percentile(cast(vcnt as bigint),0.9999) vcnt_9999 ,
--        max(vcnt) vcnt_100
-- from
--   (select diu,
--           count(1) vcnt
--    from da.recy_cf_rating_2
--    where actdate>='2016-11-16'
--    group by diu) a
-- -- 0           50     90     99     99.9   99.99                100
-- -- 1       11.0    96.0    382.0   921.0   2002.0182999996468      17895

-- if(abs( hash( concat(diu,vid) ) % 100 <= 20,'test','train' )

insert overwrite table da.recy_cf_eval_sample
select a.diu,
       a.vid,
       a.rating,
       a.rank,
       a.actdate,
       a.num,
       if(abs(hash(concat(a.diu,a.vid))) % 100 <= 20,'test','train')
from
  (select *
   from da.recy_cf_rating_2
   where actdate>='2016-12-01') a
join
  (select diu,
          count(1) vcnt
   from da.recy_cf_rating_2
   where actdate>='2016-12-01'
   group by diu having vcnt<1000)b on (a.diu=b.diu)



-- select type,
--        sum(cnt),
--        count(distinct diu)
-- from
--   (select type,
--           diu ,
--           count(1) cnt
--    from da.recy_cf_eval_sample
--    group by type,
--             diu) a
-- group by type
-- 0      train  123057645     4118032
-- 1      test   32707334      3263388

select type, count(1) from da.recy_cf_eval_sample where diu in ('37687478-0C42-4AD5-8CE1-267A47F40CE0') group by type




