--新增用户总体情况
select dt,
       tag,
       count(distinct a.u_diu) uv ,
       count(distinct if(vv>0,u_diu,null)) play_uv,
       sum(vst) play_time
from
  (select dt,
          if(u_div>='5.5.2', get_json_object(u_bigger_json,'$.u_abtag'),'NOT-AB')tag,
          u_vid,
          u_diu,
          get_json_object(u_bigger_json,'$.u_playid') playid,
          sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) vv ,
          max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'
                 and get_json_object(u_bigger_json,'$.u_playtime') is not null,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst
   from dw.uabigger
   where dt>='${datebig}' and dt<=dt>='${dateend}'
     and concat(u_mod,'-',u_ac) not in ('main-start',
                                        'top-count_plush',
                                        'emptylog-push_arrival',
                                        'main-update',
                                        'video-ab_start',
                                        'emptylog-count_plush')
   group by dt,
            if(u_div>='5.5.2', get_json_object(u_bigger_json,'$.u_abtag'),'NOT-AB'),
            u_vid,
            u_diu,
            get_json_object(u_bigger_json,'$.u_playid')) a
join
  (select dt,u_diu diu
   from da.dm_ac_action
   where dt>='${datebig}' and dt<=dt>='${dateend}'
   group by dt,u_diu) b on (a.u_diu=b.diu and a.dt=b.dt)
group by dt ,
         tag having tag>='A'
order by tag asc;