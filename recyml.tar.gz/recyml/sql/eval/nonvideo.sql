不看视频用户数量分布
select a.dt,count(distinct a.u_diu)uv from (select dt,u_diu from dw.uabigger where dt>='${datebig}'and dt<='${dateend}' and concat(u_mod,'-',u_ac) not in 
(
'main-start',
'top-count_plush',
'emptylog-push_arrival',
'main-update',
'video-ab_start',
'emptylog-count_plush'
)  group by dt,u_diu)a 
left outer join (select dt,diu from da.dm_ac_feature_b where dt>='${datebig}'and dt<='${dateend}' and vv>0 group by dt,diu)b on (a.u_diu=b.diu and a.dt=b.dt) where b.diu is null group by a.dt order by dt




不看视频用户接口分布
select a.dt,u_mod,u_ac,count(distinct a.u_diu)uv from (select dt,u_mod,u_ac,u_diu from dw.uabigger where dt>='${datebig}'and dt<='${dateend}' and concat(u_mod,'-',u_ac) not in 
(
'main-start',
'top-count_plush',
'emptylog-push_arrival',
'main-update',
'video-ab_start',
'emptylog-count_plush'
)  group by dt,u_mod,u_ac,u_diu)a 
left outer join (select dt,diu from da.dm_ac_feature_b where dt>='${datebig}'and dt<='${dateend}' and vv>0 group by dt,diu)b on (a.u_diu=b.diu and a.dt=b.dt) where b.diu is null group by a.dt,u_mod,u_ac order by uv desc


select c.u_vid,d.title,c.pv,c.uv from (select u_vid,count(1)pv,count(distinct a.u_diu)uv  from (select u_diu from dw.uibigger where dt>='${datebuf}' and to_date(u_timestamp_f)>='${datebuf}')a  join (select u_diu,u_vid from dw.uabigger where dt>='${datebuf}' and concat(u_mod,'|',u_ac) in ('top|hits','top|hits_pc'))b on (a.u_diu = b.u_diu) group by u_vid order by pv desc limit 100)c join (select vid,title from dw.video ) d on (c.u_vid = d.vid) order by pv desc eval