drop TABLE da.recy_evaluate_video_clickrate;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_evaluate_video_clickrate(
    vid   STRING  COMMENT '视频id',
    disnum  BIGINT COMMENT '展示次数',
    clinum   BIGINT COMMENT '点击次数',
    diper BIGINT COMMENT '展示人数',
    cliper   BIGINT COMMENT '点击人数'
)
COMMENT '视频展现点击'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_evaluate_video_clickrate/';



ALTER TABLE da.recy_evaluate_video_clickrate ADD IF NOT EXISTS
PARTITION (dt='2016-12-25') LOCATION '/olap/da/recy_evaluate_video_clickrate/2016-12-25/';

ALTER TABLE da.recy_evaluate_video_clickrate drop IF EXISTS
PARTITION (dt='2016-12-24')

root
 |-- vid: string (nullable = true)
 |-- disnum: long (nullable = true)
 |-- clinum: long (nullable = true)
 |-- diper: long (nullable = false)
 |-- cliper: long (nullable = false)