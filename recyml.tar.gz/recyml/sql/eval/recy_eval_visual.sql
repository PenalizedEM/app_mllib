-- ############ 一、 APP内各版本整体对比以及趋势   ############

-- A C《用户数》对比以及趋势
select
datebuf, 
tag,
uv 
from 
da.recy_eval_total
where dt>='2017-02-01' 
and tag in ('A','C')
order by 
datebuf,
tag

-- A+C 与 B NOT-AB 《用户数》对比以及趋势 

select
datebuf, 
if(tag in ('A','C') , 'A+C',tag) tag , 
sum(uv) uv  
from 
da.recy_eval_total
where dt>='2017-02-01' 
group by 
datebuf, 
if(tag in ('A','C') , 'A+C',tag)
order by 
datebuf,
tag

-- 《播放视频用户比例》对比趋势

select
datebuf, 
tag,
round(uv/play_uv,2) play_rate  
from 
da.recy_eval_total
where dt>='2017-02-01' 
order by 
datebuf,
tag

-- A C《总时长》对比以及趋势（单位秒）

select
datebuf, 
tag,
play_time 
from 
da.recy_eval_total
where dt>='2017-02-01' 
and tag in ('A','C')
order by 
datebuf,
tag

-- A+C 与 B NOT-AB 《总时长》对比以及趋势 （单位秒） 

select
datebuf, 
if(tag in ('A','C') , 'A+C',tag) tag , 
sum(play_time) play_time  
from 
da.recy_eval_total
where dt>='2017-02-01' 
group by 
datebuf, 
if(tag in ('A','C') , 'A+C',tag)
order by 
datebuf,
tag

-- 《人均播放时长》对比趋势（单位秒）

select
datebuf, 
tag,
round(play_time/play_uv,0) per_time  
from 
da.recy_eval_total
where dt>='2017-02-01' 
order by 
datebuf,
tag

-- ############ 二、 【猜你喜欢】各版本对比以及趋势   ############

-- 【猜你喜欢】A C版《点击率》对比以及趋势

select
datebuf, 
tag,
round(cai_play/cai_diplay,3)*100 cai_play_rate  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
and tag in ('A','C')
order by 
datebuf,
tag

-- 【猜你喜欢】A C版《播放时长》对比以及趋势 

select
datebuf, 
tag,
c_play_time   
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
and tag in ('A','C')
order by 
datebuf,
tag

-- 【猜你喜欢】A C版《人均播放时长》对比以及趋势 

select 
a.datebuf,
a.tag,
round(a.c_play_time/b.cai_play_uv,0) per_time 
from 
(
select
datebuf, 
tag,
c_play_time   
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
and tag in ('A','C') 
) a 
join
(
select
datebuf, 
tag,
cai_play_uv 
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
and tag in ('A','C') 
) b 
on(a.datebuf=b.datebuf and a.tag=b.tag)
order by a.datebuf, a.tag 


-- ############ 三、 【猜你喜欢+每日精选】各版对比以及趋势   ############

-- 【猜你喜欢+每日精选】各版《点击率》对比以及趋势

select
datebuf, 
tag,
round(cj_play/cj_diplay,3)*100 cj_play_rate  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
union all 
select
datebuf, 
'A+C'  tag , 
round(sum(cj_play)/sum(cj_diplay),3)*100 cj_play_rate  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
order by 
datebuf,
tag

-- 【猜你喜欢+每日精选】各版《播放时长》对比以及趋势 

select
datebuf, 
tag,
sum(cj_play_time) cj_play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
group by 
datebuf, tag 
union all 
select
datebuf, 
'A+C'  tag , 
sum(cj_play_time) cj_play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
order by 
datebuf,
tag

-- 【猜你喜欢+每日精选】各版《人均播放时长》对比以及趋势 

select 
a.datebuf,
a.tag,
round(a.cj_play_time/b.cj_play_uv,0) per_time 
from 
(
select
datebuf, 
tag,
sum(cj_play_time) cj_play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
group by 
datebuf, tag 
union all 
select
datebuf, 
'A+C'  tag , 
sum(cj_play_time) cj_play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
) a 
join
(
select
datebuf, 
tag,
sum(cj_play_uv) cj_play_uv  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
group by 
datebuf, tag 
union all 
select
datebuf, 
'A+C'  tag , 
sum(cj_play_uv) cj_play_uv  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
) b 
on(a.datebuf=b.datebuf and a.tag=b.tag)
order by a.datebuf, a.tag 

-- ############ 四、 【猜你喜欢+每日精选+糖豆生活+糖豆广场】各版对比以及趋势   ############

-- 【猜你喜欢+每日精选+糖豆生活+糖豆广场】各版《点击率》对比以及趋势

select
datebuf, 
tag,
round(play/display,3)*100 play_rate  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
union all 
select
datebuf, 
'A+C'  tag , 
round(sum(play)/sum(display),3)*100 play_rate  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
order by 
datebuf,
tag

-- 【猜你喜欢+每日精选+糖豆生活+糖豆广场】各版《播放时长》对比以及趋势 

select
datebuf, 
tag,
sum(play_time) play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
group by 
datebuf, tag 
union all 
select
datebuf, 
'A+C'  tag , 
sum(play_time) play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
order by 
datebuf,
tag

-- 【猜你喜欢+每日精选+糖豆生活+糖豆广场】各版《人均播放时长》对比以及趋势 

select 
a.datebuf,
a.tag,
round(a.play_time/b.play_uv,0) per_time 
from 
(
select
datebuf, 
tag,
sum(play_time) play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
group by 
datebuf, tag 
union all 
select
datebuf, 
'A+C'  tag , 
sum(play_time) play_time  
from 
da.recy_eval_play_time
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
) a 
join
(
select
datebuf, 
tag,
sum(play_uv) play_uv  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
group by 
datebuf, tag 
union all 
select
datebuf, 
'A+C'  tag , 
sum(play_uv) play_uv  
from 
da.recy_eval_click_rate
where dt>='2017-02-01' 
and tag in ('A','C') 
group by 
datebuf
) b 
on(a.datebuf=b.datebuf and a.tag=b.tag)
order by a.datebuf, a.tag 

-- ############ 五、各版新增留存对比以及趋势   ############


select
datebuf, 
tag,
round(ret_uv/new_uv*100,1) ret_rate 
from 
da.recy_eval_retention
where dt>='2017-02-01' 
order by 
datebuf, tag 