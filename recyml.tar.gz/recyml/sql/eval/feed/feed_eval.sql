-- Feed猜你喜欢人均时长

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_eval_feed(
datebuf STRING COMMENT '分区日期',
tag STRING  COMMENT 'A B ',
version STRING COMMENT '5.8.7.8  other',
play_uv INT COMMENT '播放用户数',
play_time  INT  COMMENT '播放时长',
per_play_time float  COMMENT '人均播放时长',
cai_paly_uv INT COMMENT '猜你喜欢-播放用户数',
cai_play_time  INT  COMMENT '猜你喜欢-播放时长',
cai_per_play_time float  COMMENT '猜你喜欢-人均播放时长'
)
COMMENT '推荐feed流————人均播放时长'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_eval_feed_cai';

 -- 5.8.7.8 新增用户的播放时长

insert overwrite table da.recy_eval_feed partition(dt='${datebuf}')
select a.dt,
       tag,
       version,
       count(distinct if(play_cnt>0,a.u_diu,null)) paly_uv ,
       sum(vst) play_time,
       round(sum(vst)/count(distinct if(play_cnt>0,a.u_diu,null)),1) per_play_time,
       count(distinct if(u_client_module like '%猜你喜欢%',a.u_diu,null)) cai_paly_uv ,
       sum(if(u_client_module like '%猜你喜欢%',vst,0)) cai_play_time,
       round(sum(if(u_client_module like '%猜你喜欢%',vst,0))/count(distinct if(u_client_module like '%猜你喜欢%',a.u_diu,null)),1) cai_per_play_time
from
  (select dt,
          get_json_object(u_bigger_json,'$.u_abtag') tag,
          u_vid,
          u_diu,
          u_client_module,
          get_json_object(u_bigger_json,'$.u_playid') playid,
          sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) play_cnt,
          max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'
                 and get_json_object(u_bigger_json,'$.u_playtime') is not null,get_json_object(u_bigger_json,'$.u_playtime'),0)) vst
   from dw.uabigger
   where dt>='${datebuf}'
     and dt<='${datebuf}'
     and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed',
                                    'top-hits')
   group by dt,
            get_json_object(u_bigger_json,'$.u_abtag'),
            u_vid,
            u_diu,
            u_client_module,
            get_json_object(u_bigger_json,'$.u_playid')) a
join
  (select dt,
          u_diu diu,
          if(u_div_f>='5.8.7.8','5.8.7.8','other') version
   from dw.uibigger
   where dt>='${datebuf}'
     and dt<='${datebuf}'
     and to_date(u_timestamp_f)='${datebuf}') b on (a.u_diu=b.diu
                                                    and a.dt=b.dt)
group by a.dt ,
         tag ,
         version having tag in ('A',
                                'B')
order by a.dt ,tag asc;


-- 20 7 * * * source .bashrc && cd /home/hadoop/user/wenlong/crontab/feed && ./feed_eval.sh >>recy_eval_feed.log 2>&1
