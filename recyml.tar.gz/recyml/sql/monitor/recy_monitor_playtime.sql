-- 每日离线推荐AB版人均播放时长差

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_monitor_play_time(
datebuf STRING COMMENT '分区日期',
a_ptime float COMMENT 'A版人均播放时长',
b_ptime float COMMENT 'B版人均播放时长',
a_b_ptime INT COMMENT 'A版人均播放时长-B版人均播放时长'
)
COMMENT '每日离线推荐AB版人均播放时长差 '
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_monitor_play_time';


insert overwrite table da.recy_monitor_play_time partition(dt='${datebuf}')
select
a.dt dt ,
sum(if(a.tag='A', round(play_time/play_uv,0) ,0)) a_ptime,
sum(if(a.tag='B', round(play_time/play_uv,0) ,0)) b_ptime,
sum(if(a.tag='A', round(play_time/play_uv,0) ,0)) - sum(if(a.tag='B', round(play_time/play_uv,0) ,0)) a_b_ptime
from
(
SELECT dt,
	   tag,
       sum(m_vst) play_time
FROM da.mid_video_cmpt
WHERE dt='${datebuf}'
  AND tag in ('A','B')
GROUP BY dt ,
		tag
) a
join
(
SELECT dt,tag,
       count(distinct diu) play_uv
FROM da.mid_video_cmpv
WHERE dt='${datebuf}'
  AND tag in ('A','B')
GROUP BY dt ,tag
) b
on(a.dt=b.dt and a.tag=b.tag)
group by
a.dt

