-- 每日离线推荐结果条数

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_monitor_result_cnt(
datebuf STRING COMMENT '分区日期',
model STRING  COMMENT 'als icf total',
counts INT COMMENT '结果条数'
)
COMMENT '每日离线推荐结果条数 '
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\t'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_monitor_result_cnt';


insert overwrite table da.recy_monitor_result_cnt partition(dt='${datebuf}')
select dt, 'total', count(1) from da.recy_final_out_topk where dt = '${datebuf}' group by dt
union all
select dt, 'als', count(1) from da.recy_als_out_topk where dt = '${datebuf}' group by dt
union all
select dt, 'icf', count(1) from da.recy_icf_out_topk where dt = '${datebuf}' group by dt

