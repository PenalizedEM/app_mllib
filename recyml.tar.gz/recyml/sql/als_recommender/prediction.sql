drop TABLE da.recy_als_prediction;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_prediction(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_diu INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid',
    prediction FLOAT COMMENT '预测结果'
)
COMMENT '用户视频评分预测结果表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_predict/';


ALTER TABLE da.recy_als_prediction ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_predict/2016-12-13/';

ALTER TABLE da.recy_als_prediction drop IF EXISTS
PARTITION (dt='2016-11-01')



u_diu: string (nullable = true)
 |-- u_vid: string (nullable = true)
 |-- f_vd: double (nullable = true)
 |-- f_rating: double (nullable = true)
 |-- f_timestamp: long (nullable = true)
 |-- f_diu: integer (nullable = true)
 |-- f_vid: integer (nullable = true)
 |-- dt: string (nullable = true)
 |-- prediction: float (nullable = true)