drop TABLE da.recy_final_out_topk;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_final_out_topk(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    prediction   FLOAT COMMENT '预测打分',
    title   STRING COMMENT '视频标题',
    pic STRING COMMENT '视频标图',
    short_title STRING COMMENT '推荐语',
    hits_total INT COMMENT '播放次数',
    comment_total INT COMMENT '评论次数',
    createtime STRING COMMENT '创建时间'
)
COMMENT '用户视频评分历史全量表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_final_out_topk/';


ALTER TABLE da.recy_final_out_topk ADD IF NOT EXISTS
PARTITION (dt='2016-12-24') LOCATION '/olap/da/recy_final_out_topk/2016-12-24/';

ALTER TABLE da.recy_final_out_topk drop IF EXISTS
PARTITION (dt='2016-12-07')

root
 |-- diu: string (nullable = true)
 |-- vid: string (nullable = true)
 |-- prediction: float (nullable = true)
 |-- title: string (nullable = true)
 |-- pic: string (nullable = true)
 |-- short_title: string (nullable = true)
 |-- hits_total: integer (nullable = true)
 |-- comment_total: integer (nullable = true)
