drop table da.recy_als_out_cpcold

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_out_cpcold(
    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    vid  STRING COMMENT '视频id',
    prediction   FLOAT COMMENT '预测打分',
    title   STRING COMMENT '视频标题',
    pic STRING COMMENT '视频标图',
    short_title STRING COMMENT '推荐语',
    hits_total INT COMMENT '播放次数',
    comment_total INT COMMENT '评论次数',
    createtime STRING COMMENT '创建时间'
)
COMMENT '用户视频评分历史全量表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_out_cpcold/';


ALTER TABLE da.recy_als_out_cpcold ADD IF NOT EXISTS
PARTITION (dt='2017-04-10') LOCATION '/olap/da/recy_als_out_cpcold/2017-04-11/';
