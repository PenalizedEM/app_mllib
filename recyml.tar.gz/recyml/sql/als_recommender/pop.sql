-- CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_out_pop(
--     vid   STRING  COMMENT '视频id',
--     pop  double COMMENT '观看人数',
--     datebuf  STRING COMMENT '日期',
--     title   STRING COMMENT '视频标题',
--     pic STRING COMMENT '视频标图',
--     short_title STRING COMMENT '推荐语',
--     hits_total INT COMMENT '播放次数',
--     comment_total INT COMMENT '评论次数',
--     createtime STRING COMMENT '创建时间'
-- )
-- COMMENT '每日冷启动热门top200'
-- PARTITIONED BY(dt STRING)
-- ROW FORMAT DELIMITED
-- FIELDS TERMINATED BY '\001'
-- STORED AS TEXTFILE
-- -- LOCATION '/olap/da/recy_als_out_pop/';


-- ALTER TABLE da.recy_als_out_pop ADD IF NOT EXISTS
-- PARTITION (dt='2017-02-13') LOCATION '/olap/da/recy_als_out_pop/2017-02-13/';

drop TABLE da.recy_als_out_pop;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_out_pop(
    vid   STRING  COMMENT '视频id',
    pop  double COMMENT '流行系数',
    datebuf  STRING COMMENT '日期'
)
COMMENT '每日冷启动热门top200'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_als_out_pop/';

SELECT vid,title,pic,short_title,hits_total,comment_total,0 as score,createtime,pop " +
        "FROM recycold " +
        "WHERE date(datebuf) =date(NOW() - INTERVAL 1 DAY) " +
        "ORDER BY pop DESC limit 60

drop TABLE da.recy_als_out_popcat
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_out_popcat(
    vid   STRING  COMMENT '视频id',
    pop  double COMMENT '观看人数',
    datebuf  STRING COMMENT '日期',
    child_category STRING COMMENT '子类'
)
COMMENT '每日分类冷启动热门top300'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_als_out_popcat/';





-- -- mysql
CREATE TABLE `related_cold` (
 `vid` varchar(50) NOT NULL DEFAULT '' COMMENT '视频id',
 `pop` double DEFAULT NULL COMMENT '流行程度',
 `datebuf` varchar(20) NOT NULL DEFAULT '' COMMENT '日期',
 `child_category` varchar(30) DEFAULT NULL COMMENT '视频所属子类别',
 PRIMARY KEY (`vid`,`datebuf`),
 KEY `datebuf` (`datebuf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4


export --connect jdbc:mysql://10.10.34.125:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table recycold --columns vid,pop,datebuf  --export-dir /olap/da/recy_als_out_pop/dt=${datebuf} --update-key vid,datebuf --update-mode allowinsert  --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N -m 1