drop table da.recy_final_out_topk_redis

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_final_out_topk_redis(
diu String COMMENT 'diu',
vid String COMMENT '视频id' ,
rn INT  COMMENT '排序'
)
COMMENT '用户视频评分历史全量表-导入Redis'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_final_out_topk_redis/';
