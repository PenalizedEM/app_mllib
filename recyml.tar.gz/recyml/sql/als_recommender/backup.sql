#抄底数据，由服务端定时查数据库，放内存，定时取
SELECT vid,title,createtime,hits_total,(if( hits_total>=1, hits_total - 1,hits_total)/power((TIMESTAMPDIFF(hour,createtime,now())+2),1.8)) as sc  FROM `video` WHERE date(createtime) =  date(now())
ORDER BY `sc`  DESC limit 50


SELECT vid,title,createtime,hits_total,(if( hits_total>=1, hits_total - 1,hits_total)/power((TIMESTAMPDIFF(hour,createtime,now())+2),1.5)) as sc FROM `video` WHERE hits_total > 500 and date(createtime) >=NOW() - INTERVAL 3 DAY ORDER BY `sc` DESC limit 60


#SELECT vid,title,createtime,hits_total,(if( (hits_total+comment_total*1.5+share*1.5)>=1, hits_total+comment_total*1.5+share*1.5 - 1,hits_total+comment_total*1.5+share*1.5)/power((TIMESTAMPDIFF(hour,createtime,now())+2),1.8)) as sc FROM `video` WHERE date(createtime) = date(now()) ORDER BY `sc` DESC limit 50

