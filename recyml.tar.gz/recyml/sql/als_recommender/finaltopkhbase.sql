drop table da.recy_final_out_topk_hbase

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_final_out_topk_hbase(
rowkey String COMMENT 'hbase唯一号,date-diu',
vid String COMMENT '视频id' ,
title String  COMMENT '视频标题' ,
pic String COMMENT '视频标图' ,
short_title String COMMENT '推荐语',
score FLOAT  COMMENT '评分',
hits_total INT COMMENT '播放次数' ,
comment_total INT COMMENT '评论次数' ,
createtime String COMMENT '创建时间'
)
COMMENT '用户视频评分历史全量表-导入HBase'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE 
LOCATION '/olap/da/recy_final_out_topk_hbase/';
