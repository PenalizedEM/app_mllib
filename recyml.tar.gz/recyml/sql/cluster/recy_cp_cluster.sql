drop TABLE da.recy_cp_cluster;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_cp_cluster(
    uid   int  COMMENT 'cpid',
    name  STRING COMMENT '用户名',
    pp int  COMMENT '预测簇id'
)
COMMENT '作者聚类'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_cp_cluster/';


ALTER TABLE da.recy_cp_cluster ADD IF NOT EXISTS
PARTITION (dt='2017-06-22') LOCATION '/olap/da/recy_cp_cluster/2017-06-22/';