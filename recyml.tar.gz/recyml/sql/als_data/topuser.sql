

drop table da.urecy_topuser

CREATE EXTERNAL TABLE IF NOT EXISTS da.urecy_topuser(
uid String COMMENT '用户id',
type String COMMENT '用户类型',
rank int COMMENT '推荐用户排序'
)
COMMENT '推荐用户'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/urecy_topuser/';
