drop TABLE da.recy_als_data_candytag;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_candytag(
    u_diu   STRING  COMMENT '用户id',
    u_vid  STRING COMMENT '视频id'
)
COMMENT 'TAG候选集'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_data_candytag/';



ALTER TABLE da.recy_als_data_candytag ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_data_candytag/2016-12-14/';

ALTER TABLE da.recy_als_data_candytag drop IF EXISTS
PARTITION (dt='2016-12-14')