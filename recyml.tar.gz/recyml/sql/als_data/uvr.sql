drop TABLE da.recy_als_data_uvr;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_uvr(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_vp   INT COMMENT '观看最大进度',
    f_vd   DOUBLE COMMENT '观看时长',
    f_timestamp BIGINT COMMENT '当日观看该视频的时间戳',
    f_down BIGINT COMMENT '下载次数',
    f_share BIGINT COMMENT '分享次数',
    f_fav BIGINT COMMENT '收藏次数',
    f_flower BIGINT COMMENT '送花次数',
    f_hits BIGINT COMMENT '播放次数',
    f_comment BIGINT COMMENT '评论次数'
)
COMMENT '用户视频评分表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_data_uvr/';


ALTER TABLE da.recy_als_data_uvr ADD IF NOT EXISTS
PARTITION (dt='2016-12-23') LOCATION '/olap/da/recy_als_data_uvr/2016-12-23/'

ALTER TABLE da.recy_als_data_uvr drop IF EXISTS
PARTITION (dt='2016-12-23')



root
 |-- u_diu: string (nullable = true)
 |-- u_vid: string (nullable = true)
 |-- f_vd: double (nullable = true)
 |-- f_timestamp: long (nullable = true)
 |-- f_down: long (nullable = true)
 |-- f_share: long (nullable = true)
 |-- f_fav: long (nullable = true)
 |-- f_flower: long (nullable = true)
 |-- f_comment: long (nullable = true)



#一天
select u_diu ,u_vid,vp as f_vp,round(vst/100*duration,3)f_vd,
f_timestamp,f_down,f_share,f_fav,f_flower,f_hits,f_comment 
from (
select u_diu,u_vid,
max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed' and u_action in ('exit','complete'),if(u_percent>100,100,u_percent),0)) vp,
sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed' and u_action in ('exit','complete'),if(u_percent>100,100,u_percent),0)) vst,
sum(if(concat(u_mod,'-',u_ac)='emptylog-cdn_download_speed',1,0)) f_down,
sum(if(concat(u_mod,'-',u_ac)='emptylog-share_onclick',1,0))f_share,
sum(if(concat(u_mod,'-',u_ac)='user-fav',1,0))f_fav,
sum(if(concat(u_mod,'-',u_ac)='flower-send',1,0)) f_flower,
sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) f_hits,
sum(if(concat(u_mod,'-',u_ac) in ('message-video_comment_add','message-video_comment_reply'),1,0)) f_comment,
max(unix_timestamp(substr(u_timestamp,0,19)))f_timestamp 
from 
dw.user_action 
where dt='"+outDate+"'  and u_vid <> ''  and u_diu not in ('0123456789abcde','012345678912345','123456789012345','0','000000','00000000','00000000000000','000000000000000','0000000000000000','000000011234564','111111111111111','','UNKNOWN','Unknown','+++++000000000','+GSN:808DCF89','000000000000026') and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed','top-hits', 'flower-send', 'emptylog-share_onclick', 'user-fav', 'emptylog-cdn_download_speed', 'message-video_comment_add','message-video_comment_reply'
)group by u_diu,u_vid)a 
join (select vid, duration from dw.video) b 
on (a.u_vid=b.vid)
    



select if(m.u_diu is null,n.u_diu,m.u_diu)u_diu, 
 if(m.u_vid is null,n.u_vid,m.u_vid)u_vid,
 case when m.f_vp is null and n.f_vp is not null then n.f_vp when m.f_vp is not null and n.f_vp is null then m.f_vp when m.f_vp is not null and n.f_vp is not null then if(m.f_vp>n.f_vp,m.f_vp,n.f_vp) else 0 end as f_vp,
 case when m.f_vd is null and n.f_vd is not null then n.f_vd when m.f_vd is not null and n.f_vd is null then m.f_vd when m.f_vd is not null and n.f_vd is not null then m.f_vd+n.f_vd else 0.0 end as f_vd,
 if(m.f_timestamp is null, n.f_timestamp,m.f_timestamp) f_timestamp,
 case when m.f_down is null and n.f_down is not null then n.f_down when m.f_down is not null and n.f_down is null then m.f_down when m.f_down is not null and n.f_down is not null then m.f_down+n.f_down else 0 end as f_down,
 case when m.f_share is null and n.f_share is not null then n.f_share when m.f_share is not null and n.f_share is null then m.f_share when m.f_share is not null and n.f_share is not null then m.f_share+n.f_share else 0 end as f_share,
 case when m.f_fav is null and n.f_fav is not null then n.f_fav when m.f_fav is not null and n.f_fav is null then m.f_fav when m.f_fav is not null and n.f_fav is not null then m.f_fav+n.f_fav else 0 end as f_fav,
 case when m.f_flower is null and n.f_flower is not null then n.f_flower when m.f_flower is not null and n.f_flower is null then m.f_flower when m.f_flower is not null and n.f_flower is not null then m.f_flower+n.f_flower else 0 end as f_flower,
 case when m.f_hits is null and n.f_hits is not null then n.f_hits when m.f_hits is not null and n.f_hits is null then m.f_hits when m.f_hits is not null and n.f_hits is not null then m.f_hits+n.f_hits else 0 end as f_hits,
 case when m.f_comment is null and n.f_comment is not null then n.f_comment when m.f_comment is not null and n.f_comment is null then m.f_comment when m.f_comment is not null and n.f_comment is not null then m.f_comment+n.f_comment else 0 end as f_comment 
from
(select u_diu ,u_vid,vp as f_vp,round(vst/100*duration,3)f_vd,
f_timestamp,f_down,f_share,f_fav,f_flower,f_hits,f_comment 
from (
select u_diu,u_vid,
max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed' and u_action in ('exit','complete'),if(u_percent>100,100,u_percent),0)) vp,
sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed' and u_action in ('exit','complete'),if(u_percent>100,100,u_percent),0)) vst,
sum(if(concat(u_mod,'-',u_ac)='emptylog-cdn_download_speed',1,0)) f_down,
sum(if(concat(u_mod,'-',u_ac)='emptylog-share_onclick',1,0))f_share,
sum(if(concat(u_mod,'-',u_ac)='user-fav',1,0))f_fav,
sum(if(concat(u_mod,'-',u_ac)='flower-send',1,0)) f_flower,
sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) f_hits,
sum(if(concat(u_mod,'-',u_ac) in ('message-video_comment_add','message-video_comment_reply'),1,0)) f_comment,
max(unix_timestamp(substr(u_timestamp,0,19)))f_timestamp 
from 
dw.user_action 
where dt='"+outDate+"'  and u_vid <> ''  and u_diu not in ('0123456789abcde','012345678912345','123456789012345','0','000000','00000000','00000000000000','000000000000000','0000000000000000','000000011234564','111111111111111','','UNKNOWN','Unknown','+++++000000000','+GSN:808DCF89','000000000000026') and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed','top-hits', 'flower-send', 'emptylog-share_onclick', 'user-fav', 'emptylog-cdn_download_speed', 'message-video_comment_add','message-video_comment_reply'
) group by u_diu,u_vid)a 
join (select vid, duration from dw.video) b 
on (a.u_vid=b.vid))m 
full outer join 
(select * from da.recy_als_data_uvr where dt='"+inDate+"')n
 on (m.u_diu = n.u_diu and m.u_vid = n.u_vid)

/* select (pop/(sign7d+sign30d+sign90d))pop from
 (select vid,(1/7*uv7d+1/30*uv30d+1/90*uv90d)pop,if(uv7d>0,1,0)sign7d,if(uv30d>0,1,0)sign30d,if(uv90d>0,1,0)sign90d from
 (select if(c.vid is null,d.vid,c.vid)vid,if(c.uv7d is null,0,c.uv7d)uv7d,if(c.uv30d is null,0,c.uv30d)uv30d,if(d.uv is null,0,d.uv)uv90d from
(select if(a.vid is null,b.vid,a.vid)vid,if(a.uv is null,0,a.uv)uv7d,if(b.uv is null,0,b.uv)uv30d from  (select * from da.recy_uv7d where dt='"+indate+"')a full outer join (select * from da.recy_uv30d where dt='"+indate+"')b on(a.vid=b.vid))c full outer join (select * from da.recy_uv90d where dt='"+indate+"')d on (c.vid = d.vid))e)f


select vid,(pop/(sign01d+sign07d+sign30d))pop from (select vid,(1*uv01d+1/7*uv07d+1/30*uv30d)pop,if(uv01d>0,1,0)sign01d,if(uv07d>0,1,0)sign07d,if(uv30d>0,1,0)sign30d from
 (select if(c.vid is null,d.vid,c.vid)vid,if(c.uv is null,0,c.uv01d)uv01d,if(c.uv07d is null,0,c.uv07d)uv07d,if(d.uv is null,0,d.uv)uv30d from 
    (select if(a.vid is null,b.vid,a.vid)vid,if(a.uv is null,0,a.uv)uv01d,if(b.uv is null,0,b.uv)uv07d from  (select * from da.recy_uv01d where dt='"+indate+"')a full outer join (select * from da.recy_uv07d where dt='"+indate+"')b on(a.vid=b.vid))c full outer join (select * from da.recy_uv30d where dt='"+indate+"')d on (c.vid = d.vid))e)f order by pop desc*/

