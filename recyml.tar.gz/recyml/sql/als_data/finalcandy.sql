drop TABLE da.recy_als_data_finalcandy;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_finalcandy(
    u_diu   STRING  COMMENT '用户id',
    u_vid  STRING COMMENT '视频id',
    f_diu   INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid'
)
COMMENT '候选集A'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_data_finalcandy/';



ALTER TABLE da.recy_als_data_finalcandy ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_data_finalcandy/2016-12-14/';

ALTER TABLE da.recy_als_data_finalcandy drop IF EXISTS
PARTITION (dt='2016-12-14')