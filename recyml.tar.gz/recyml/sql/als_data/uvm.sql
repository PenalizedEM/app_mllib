drop TABLE da.recy_als_data_uvm;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_uvm(
    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
    u_vid  STRING COMMENT '视频id',
    f_timestamp BIGINT COMMENT '最后观看该视频的时间戳',
    f_diu INT COMMENT '转换成整数的diu',
    f_vid INT COMMENT '转换成整数的vid',
    f_rating   DOUBLE COMMENT '归一化后的评分'
)
COMMENT '用户视频评分历史全量表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_data_uvm/';


ALTER TABLE da.recy_als_data_uvm ADD IF NOT EXISTS
PARTITION (dt='2016-12-15') LOCATION '/olap/da/recy_als_data_uvm/2016-12-15/';

ALTER TABLE da.recy_als_data_uvm drop IF EXISTS
PARTITION (dt='2016-09-02')




 |-- u_diu: string (nullable = true)
 |-- u_vid: string (nullable = true)
 |-- f_timestamp: long (nullable = true)
 |-- f_diu: integer (nullable = false)
 |-- f_vid: integer (nullable = false)
 |-- f_rating: double (nullable = true)


select u_diu,u_vid,f_timestamp,f_diu,f_vid, if(round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating  from (select u_diu,u_vid,f_timestamp,hash(u_diu) f_diu,hash(u_vid) f_vid,(case when f_vd >= 0  and f_vd <= 45 then 4*(f_vd+f_hits*2)/90 when f_vd >45 and f_vd <=90 then 4*(f_vd/90) when f_vd >90 then 4.0 else 0.0 end )as f_sa,cast(if(f_down>0,5.0,0) as double) f_sb,cast(if(f_share>0,2.0,0.0) as double) f_sc,cast(if(f_fav>0,4.0,0.0) as double)f_sd,cast(if(f_flower>0,2.0,0.0) as double)f_se,cast(if(f_comment>0,1.0,0.0) as double)f_sf from da.recy_als_data_uvr where dt='"+inUVADate+"')k