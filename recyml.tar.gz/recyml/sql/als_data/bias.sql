drop TABLE da.recy_als_data_userbias;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_userbias(
    diu   STRING  COMMENT '用户id',
    mapr  INT COMMENT '最大值',
    mipr iNT COMMENT '最小值',
    nnpr  INT COMMENT '99分位值',
    ntpr   INT COMMENT '90分位值',
    tpr  INT  COMMENT '10分位值',
    opr INT  COMMENT '1分位值',
    pv INT COMMENT '观看视频次数'
)
COMMENT '用户bias'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_data_userbias/';


drop TABLE da.recy_als_data_itembias;
CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_itembias(
     vid  STRING  COMMENT '用户id',
    mapr  INT COMMENT '最大值',
    mipr iNT COMMENT '最小值',
    nnpr  INT COMMENT '99分位值',
    ntpr   INT COMMENT '90分位值',
    tpr  INT  COMMENT '10分位值',
    opr INT  COMMENT '1分位值',
    pv INT COMMENT '视频观看次数'
)
COMMENT '视频bias'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/recy_als_data_itembias/';



SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_sb, f_sc, f_sd, f_se, f_sf, (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_vd, f_sb, f_sc, f_sd, f_se, f_sf, if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up FROM (SELECT u_diu, u_vid, f_timestamp, hash(u_diu) f_diu, hash(u_vid) f_vid, f_vd, cast(if(f_down>0,5.0,0) AS double) f_sb, cast(if(f_share>0,2.0,0.0) AS double) f_sc, cast(if(f_fav>0,3.0,0.0) AS double)f_sd, cast(if(f_flower>0,2.0,0.0) AS double)f_se, cast(if(f_comment>0,1.0,0.0) AS double)f_sf FROM da.recy_als_data_uvr WHERE dt='"+inDate+"'AND f_vd>0) a JOIN (SELECT diu, nnpr, mipr, pv FROM da.recy_als_data_userbias WHERE dt='"+inDate+"')b ON (a.u_diu = b.diu)) c JOIN (SELECT vid, nnpr, mipr, pv FROM da.recy_als_data_itembias WHERE dt='"+inDate+"')d ON (c.u_vid = d.vid))e



 

  select sum(if((f_rating>0 and f_rating<=1),1,0))a,sum(if((f_rating>1 and f_rating<=2),1,0))b,sum(if((f_rating>2 and f_rating<=3),1,0))c,sum(if((f_rating>3 and f_rating<=4),1,0))d,sum(if((f_rating>4 and f_rating<=5),1,0))e from da.temptest 