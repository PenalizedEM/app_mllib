
drop table da.recy_als_data_idmap

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_idmap(
type String COMMENT '类型diu or vid',
id String COMMENT '原来id',
f_id String COMMENT '转换后id'
)
COMMENT '用户视频id映射'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_als_data_idmap/';


drop table da.recy_als_data_watchset

CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_watchset(
u_diu String COMMENT 'diu',
u_vid String COMMENT 'vid'
)
COMMENT '用户看过视频'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/recy_als_data_watchset/';



