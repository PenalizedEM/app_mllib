drop TABLE dw.uabigger;
CREATE EXTERNAL TABLE IF NOT EXISTS dw.uabigger(
  u_timestamp STRING COMMENT '东八区时间',
	u_backtime STRING COMMENT 'php层响应时间',
	u_responsetime STRING COMMENT '完整服务响应时间',
	u_host STRING COMMENT '服务器内网ip',
	u_xff STRING COMMENT '客户端ip',
  u_http_host STRING COMMENT '负载均衡',
  u_clientip STRING COMMENT '内网客户ip',
  u_referer STRING COMMENT '请求来源',
	u_status STRING COMMENT 'http状态',
	u_size STRING COMMENT 'http返回大小',
  u_url STRING COMMENT '请求URL头部',
  u_verb STRING COMMENT 'HTTP协议版本号',
	u_method STRING COMMENT 'http方法',
	u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
	u_dic STRING COMMENT '客户端渠道代码',
	u_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
	u_diu2 STRING COMMENT '广告ID,android--mac, ios--IDFA',
	u_diu3 STRING COMMENT 'GUID,android--guid, ios--guid',
	u_uid STRING COMMENT '注册用户id',
	u_startid STRING COMMENT '启动标识号(距离2016年1月1号0点0分0秒这时刻有多少秒）',
	u_stepid STRING COMMENT '客户端的操作步骤',
	u_time STRING COMMENT '客户端时间戳',
	u_mod STRING COMMENT '服务端接口模块',
	u_ac STRING COMMENT '服务端具体接口',
	u_client STRING COMMENT '客户端类型',
	u_ver STRING COMMENT '服务端版本',
	u_uuid STRING COMMENT '用户设备号(md5)',
	u_hash STRING COMMENT '加密验证串',
	u_xinge STRING COMMENT '信鸽token',
	u_token STRING COMMENT '用户单点登录token',
	u_agent STRING COMMENT '客户端agent',
	u_new_activity STRING COMMENT '跳转到页面名称(当前页)',
	u_old_activity STRING COMMENT '跳转过来页面名称',
	u_key STRING COMMENT '搜索关键词',
	u_client_module STRING COMMENT '用户客户端搜索模块',
	u_source STRING COMMENT '用户搜索调用的接口',
	u_page STRING COMMENT '用户点击第几页的搜索结果',
	u_position STRING COMMENT '用户点击第几条的搜索结果',
	u_vid STRING COMMENT '视频的id',
	u_type STRING COMMENT '搜索排序类型',
	u_percent STRING COMMENT '页面停留时间/视频播放时间',
	u_rate STRING COMMENT '视频播放进度（百分比)',
	u_user_role STRING COMMENT '用户在舞队内的角色',
	u_isnew_user STRING COMMENT '当天注册为新用户',
	u_isdownload STRING COMMENT '是否点击了播放页的下载按钮',
	u_isonline STRING COMMENT '是否在线播放',
	u_buffertime STRING COMMENT '进入播放页到视频开始播放的时间',
	u_action STRING COMMENT '操作播放器行为',
	u_ishigh STRING COMMENT '是否高清视频',
	u_cdn_source STRING COMMENT 'cdn名称',
	u_download_start STRING COMMENT '下载开始',
	u_download_stop STRING COMMENT '下载结束',
	u_fail_cdn_source STRING COMMENT '失败cdn源',
	u_new_cdn_source STRING COMMENT '切换cdn源',
	u_width STRING COMMENT '屏幕尺寸——宽',
	u_height STRING COMMENT '屏幕尺寸——高',
	u_lon STRING COMMENT '用户位置——经度',
	u_lat STRING COMMENT '用户位置——纬度',
	u_province STRING COMMENT '用户省份',
  	u_city STRING COMMENT '用户城市',
	u_netop STRING COMMENT '网络运营商',
	u_nettype STRING COMMENT '网络类型',
	u_sdkversion STRING COMMENT 'android 系统版本号',
	u_model STRING COMMENT 'ios:固件版本, android:手机模型',
	u_device STRING COMMENT 'ios:设备型号, android:设备',
	u_manufacture STRING COMMENT '厂商',
	u_bigger_json STRING COMMENT '最后的大json'
)
COMMENT '用户行为大表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/dw/uabigger/';



ALTER TABLE dw.uabigger ADD IF NOT EXISTS
PARTITION (dt='2016-12-21') LOCATION '/olap/dw/uabigger/2016-12-21/'

ALTER TABLE dw.uabigger drop IF EXISTS
PARTITION (dt='2016-11-02')