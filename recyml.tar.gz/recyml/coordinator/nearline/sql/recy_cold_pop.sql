
from
  (select u_vid vid,
          up_days,
          up_hour,
          pow(up_days+1,-1/up_hour)*rating pop,
          'datebuf' datebuf,
                            if(type='10','lite','normal') type
   from
     (select u_vid,
             count(1) uv,
             avg(f_rating) rating
      from dm.user_video_rating
      where dt='datebuf'
        and hour='hour'
      group by u_vid having uv>75) a
   join
     (select a.vid,
             type,
             up_days,
             up_hour
      from
        (select vid,
                uid,
                type,
                datediff('datebuf',to_date(createtime)) up_days,
                hour(createtime)+1 up_hour
         from db.video
         where !(status <> 0
                 or uid=0
                 or type=9
                 or (parent_category in ('65',
                                         '55',
                                         '54',
                                         '53',
                                         '47')
                     and uid not in ('3512923',
                                     '3194741',
                                     '3512978',
                                     '3083296',
                                     '3114024',
                                     '3503710',
                                     '2584835',
                                     '2723788',
                                     '795605',
                                     '3183159',
                                     '3194481',
                                     '3512692',
                                     '3512781',
                                     '3194629',
                                     '3512815',
                                     '3512803',
                                     '2952436',
                                     '3399207',
                                     '3512804',
                                     '3512778',
                                     '3512808',
                                     '3194554',
                                     '2692975',
                                     '3512916',
                                     '3512979',
                                     '3085667',
                                     '3085957',
                                     '3083188')))) a
      left outer join
        (select vid
         from dm.recy_cold_pop) b on(a.vid=b.vid)
      where b.vid is null) b on(a.u_vid=b.vid)) a
insert overwrite table dm.recy_cold_pop partition(dt='datebuf', hour='hour', type='normal')
select vid,
       pop,
       datebuf
where type='normal'
  and up_days<=1
order by pop desc limit 100