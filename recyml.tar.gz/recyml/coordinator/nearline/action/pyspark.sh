#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
spark_submit=$SPARK_HOME/bin/spark-submit
########################################

##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 hour ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
hour=`date -d" 1 hour ago" +"%H"`

datebuf=$1
hh=$2
pyfile_name=$3
num_executors=$4
executor_cores=$5
executor_memory=$6
driver_memory=$7
onehourago=$8


if [ -z "$1" ] || [ -z "$2" ] ;then
    year=$year
    month=$month
    day=$day
    hour=$hour
else
    if [ -n "$1" ] && [ -n "$2" ] && [ ${#datebuf} -eq 10 ] && [ ${#hh} -eq 2 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
        hour=$hh
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
echo "hour:$hour"

#onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
#echo "onedayago:$onedayago"
onehourago=`date -d" -1 hour ${datebuf} ${hour}:00:00" +"%H"`
echo "onehourago:$onehourago"
##########################################################################################


echo "`date "+%Y-%m-%d %T"` begin ..."

#每2分钟重试一次,重试3次
for((i=1;i<=3;i++))
do
    if [ -n "$driver_memory" ]; then
        $spark_submit --queue root.spark  --master yarn-client  --num-executors $num_executors --executor-cores $executor_cores --executor-memory $executor_memory --driver-memory $driver_memory py/${pyfile_name}.py $datebuf $hour $onehourago
        f=$?
    else
        $spark_submit --queue root.spark  --master yarn-client  --num-executors $num_executors --executor-cores $executor_cores --executor-memory $executor_memory py/${pyfile_name}.py $datebuf $hour
        f=$?
    fi

    if [ $f -ne 0 ] ; then
        echo  "`date "+%Y-%m-%d %T"` The  ${i} times job run failed! ..."
        sleep $((60*2))
    else
        echo "`date "+%Y-%m-%d %T"` The  ${i} times job run success! ..."
        break
    fi
done

echo "`date "+%Y-%m-%d %T"` end ..."