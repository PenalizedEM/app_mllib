#!/bin/sh
date=$1
echo  $date

##################
# dstcp als_model
##################
## delete model
#curl -i -X DELETE "http://uhadoop-who10v-master1:14000/webhdfs/v1/olap/dm/recy_als_model/$date?op=DELETE&recursive=true&user.name=hadoop"
#
## dist cp model
## condition1 try cp data from master1
#/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.171.218:8020/olap/da/recy_als_model/$date /olap/dm/recy_als_model/$date
#a=$?
## condition2 if master1 failed, try master2
#if [ $a -ne 0 ]; then
#/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.186.203:8020/olap/da/recy_als_model/$date /olap/dm/recy_als_model/$date
#fi

##################
##################

##################
# dstcp similarity_topn
##################
# delete similarity_topn

curl -i -X DELETE "http://uhadoop-who10v-master1:14000/webhdfs/v1/olap/dm/recy_icf_similarity_topn_l?op=DELETE&recursive=true&user.name=hadoop"

# dist cp similarity_topn
# condition1 try cp data from master1
/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.171.218:8020/user/hive/warehouse/da.db/recy_icf_similarity_topn_l /olap/dm/recy_icf_similarity_topn_l
b=$?
# condition2 if master1 failed, try master2
if [ $b -ne 0 ]; then
/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.186.203:8020/user/hive/warehouse/da.db/recy_icf_similarity_topn_l /olap/dm/recy_icf_similarity_topn_l
fi

/home/hadoop/hive/bin/hive -e "insert overwrite table dm.recy_icf_similarity_topn partition(dt='${date}') select vid_1, vid_2, similarity, rank from dm.recy_icf_similarity_topn_l"
##################
##################

##################
# dstcp recy_icf_similarity_recently
##################
# delete recy_icf_similarity_recently
curl -i -X DELETE "http://uhadoop-who10v-master1:14000/webhdfs/v1/olap/dm/recy_icf_similarity_recently/dt=$date?op=DELETE&recursive=true&user.name=hadoop"

# dist cp similarity_topn
# condition1 try cp data from master1
/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.171.218:8020/olap/da/recy_icf_similarity_recently/dt=$date /olap/dm/recy_icf_similarity_recently/dt=$date
b=$?
# condition2 if master1 failed, try master2
if [ $b -ne 0 ]; then
/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.186.203:8020/olap/da/recy_icf_similarity_recently/dt=$date /olap/dm/recy_icf_similarity_recently/dt=$date
fi

/home/hadoop/hive/bin/hive -e "alter table dm.recy_icf_similarity_recently add if not exists partition(dt='${date}') location '/olap/dm/recy_icf_similarity_recently/dt=${date}'"
##################
##################