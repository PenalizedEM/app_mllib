#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
spark_submit=$SPARK_HOME/bin/spark-submit
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
current_dir=`pwd`

echo "spark_submit=${spark_submit}"
echo "hadoop=${hadoop}"
echo "hive=${hive}"
echo "current_dir=${current_dir}"
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 hour ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
hour=`date -d" 1 hour ago" +"%H"`

datebuf=$1
hh=$2

if [ -z "$1" ] || [ -z "$2" ] ;then
    year=$year
    month=$month
    day=$day
    hour=$hour
else
    if [ -n "$1" ] && [ -n "$2" ] && [ ${#datebuf} -eq 10 ] && [ ${#hh} -eq 2 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
        hour=$hh
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
echo "hour:$hour"

onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
echo "onedayago:$onedayago"
onehourago=`date -d" -1 hour ${datebuf} ${hour}:00:00" +"%H"`
echo "onehourago:$onehourago"
##########################################################################################


function run_pyspark(){
    dt=$1
    hh=$2
    pyfile_name=$3
    num_executors=$4
    executor_cores=$5
    executor_memory=$6
    driver_memory=$7
    onehourago=$8

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${dt} ${hh} job begin**************************"

    {
        sh ./action/pyspark.sh ${dt} ${hh} ${pyfile_name} ${num_executors} ${executor_cores} ${executor_memory} ${driver_memory} ${onehourago}
    } > log/run_pyspark_${pyfile_name}_${hh}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${dt} ${hh} job end  **************************"
}

function run_shell(){
    dt=$1
    hh=$2
    shfile_name=$3
    num_executors=$4
    executor_cores=$5
    executor_memory=$6

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${shfile_name} ${dt} ${hh} job begin**************************"

    {
        sh ./action/shell.sh ${dt} ${hh} ${shfile_name} ${num_executors} ${executor_cores} ${executor_memory}
    } > log/run_shell_${shfile_name}_${hh}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${shfile_name} ${dt} ${hh} job end  **************************"
}

function add_partition(){
    dt=$1
    hh=$2
    pyfile_name=$3
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${dt} ${hh} add_partition begin**************************"

    {
        $hive -e "ALTER TABLE dm.${pyfile_name} ADD IF NOT EXISTS
PARTITION (dt='$dt') LOCATION '/olap/dm/$pyfile_name/$dt/'"
    } > log/add_partition_${pyfile_name}_${hh}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${dt} ${hh} add_partition end  **************************"
}

function touch_success(){
    dt=$1
    hh=$2
    pyfile_name=$3
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${dt} ${hh} touch_success begin**************************"

    {
        $hive -e "dfs -touchz /olap/dm/$pyfile_name/dt=${dt}/hh=${hh}/_SUCCESS"
    } > log/touch_success_${pyfile_name}_${hh}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${dt} ${hh} touch_success end  **************************"
}


function redis_mr(){
    dt=$1
    hh=$2
    jar=$3
    main_class=$4
    redisdate=$5
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${jar} ${main_class} ${dt} ${hh} redis_mr begin**************************"

    {
        sh ./action/redis_mr.sh ${dt} ${hh} ${jar} ${main_class} ${redisdate}
    } > log/redis_mr_${main_class}_${hh}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${jar} ${main_class} ${dt} ${hh} redis_mr end  **************************"
}

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow begin ---------"
########################################

    {
        run_pyspark ${datebuf} ${hour} user_video 10 5 6g

        run_pyspark ${datebuf} ${hour} user_video_index 10 5 6g
        touch_success ${datebuf} ${hour} user_video_index

        run_pyspark ${datebuf} ${hour} user_video_bias1 6 3 3g   &
        run_pyspark ${datebuf} ${hour} user_video_bias2 6 3 3g  &
#        run_pyspark ${datebuf} ${hour} recy_lite_hour_cpcold 6 3 3g  &

        wait

#        redis_mr ${datebuf} ${hour} recyio HourCpcold2LisrDriver  &

        wait

        run_pyspark ${datebuf} ${hour} user_video_rating 10 5 6g

        {
            run_pyspark ${datebuf} ${hour} recy_icf_similarity_pre 10 5 6g &
#            redis_mr ${datebuf} ${hour} recyio Watch2SetDriver &
        }

        wait

        run_pyspark ${datebuf} ${hour} recy_icf_similarity_mid 10 5 6g
        run_pyspark ${datebuf} ${hour} recy_icf_similarity 10 5 6g
        run_shell ${onedayago} ${hour} recy_icf_similarity_nearline_update 10 5 6g
#        run_pyspark ${onedayago} ${hour} recy_icf_similarity_nearline_update 10 5 6g
        run_pyspark ${datebuf} ${hour} recy_icf_similarity_topn_hourcdc 10 5 6g

        redis_mr ${datebuf} ${hour} recyio HourCDCSim2ListDriver &
        run_pyspark ${onedayago} ${hour} recy_icf_similarity_topn_merge  6 3 3g &

        wait

        {
            run_shell ${datebuf} ${hour} recy_icf_recommend_pre 5 6 6g
            touch_success ${datebuf} ${hour} recy_icf_recommend_pre
        } &

#        {
 #           run_pyspark ${datebuf} ${hour} recy_cold_pop 5 3 3g
 #           touch_success ${datebuf} ${hour} recy_cold_pop

 #           redis_mr ${datebuf} ${hour} recyio HourNPop2ListDriver ${onedayago} &
#            redis_mr ${datebuf} ${hour} recyio HourLPop2ListDriver ${onedayago} &
#        }

        wait

        run_shell ${datebuf} ${hour} recy_icf_recommend 10 6 6g
        touch_success ${datebuf} ${hour} recy_icf_recommend

        run_pyspark ${datebuf} ${hour} recy_out_topk 10 5 6g
        touch_success ${datebuf} ${hour} recy_out_topk

        redis_mr ${datebuf} ${hour} recyio Hour2ListDriver

#        run_pyspark ${datebuf} ${hour} recy_city_pop_topk 10 5 6g 2g ${onehourago} &
#
#        wait
#
#        redis_mr ${datebuf} ${hour} recyio DiuCity2RedisDriver &
#        redis_mr ${datebuf} ${hour} recyio CityPop2RedisDriver &

    }

wait

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow end ---------"
########################################