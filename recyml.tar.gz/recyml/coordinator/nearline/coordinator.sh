#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 hour ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`
hour=`date -d" 1 hour ago" +"%H"`

datebuf=$1
hh=$2

if [ -z "$1" ] || [ -z "$2" ] ;then
    year=$year
    month=$month
    day=$day
    hour=$hour
else
    if [ -n "$1" ] && [ -n "$2" ] && [ ${#datebuf} -eq 10 ] && [ ${#hh} -eq 2 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
        hour=$hh
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
echo "hour:$hour"

#onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
#echo "onedayago:$onedayago"
##########################################################################################


function test_e(){
    directory=$1
    $hadoop fs -test -e $directory/_SUCCESS
    f=$?
    echo $f
}

##########################################################################################
###                              check dependency datas                                ###
##########################################################################################
checkexsits=0;
times=0;

#每次1分钟*600次 等待10小时
while [ $checkexsits -eq 0 ] && [ $times -le 600 ];
do

    f=`test_e /olap//dw/uamini/${datebuf}/${hour} `
    echo "uamini: $f"

    if [ $f -ne 0 ]; then
        let checkexsits=0;
        echo "denpendency data success flag not exists! Waiting!"
        sleep 60;
    else
        let checkexsits=1;
        echo "denpendency data success flag  exists!"
        echo "Success file check compelet: OK!"

        sh ./recy_workflow.sh ${datebuf} ${hour}

        wait

        break

    fi

    let times=times+1

done

if ! [ $checkexsits -eq 1 ]; then
    echo "Success file check compelet: _SUCCESS not exits!"
fi

