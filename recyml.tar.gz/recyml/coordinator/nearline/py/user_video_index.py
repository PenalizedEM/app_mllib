#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour

#主入口
if __name__ == "__main__":
    print str(sys.argv)


    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour


    #########################
    ## user_video_index
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " user_video_index begin"
    spark = SparkSession.builder.master('yarn-client').appName('user_video_index:' + datebuf + "_" +  hour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=200"
    spark.sql(setSparSQLPartNum)
    sql = "insert overwrite table dm.user_video_index partition(dt='" + datebuf + "',hour='" + hour + "') select u_diu, u_vid, max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'and u_action in ('exit','complete'),if(u_percent>100,100,u_percent),0)) vp, sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'and u_action in ('exit','complete'),u_playtime,0)) vst, sum(if(concat(u_mod,'-',u_ac)='emptylog-cdn_download_speed',1,0)) f_down, sum(if(concat(u_mod,'-',u_ac)='emptylog-share_onclick',1,0))f_share, sum(if(concat(u_mod,'-',u_ac) in ('user-fav','flower-good'),1,0))f_fav, sum(if(concat(u_mod,'-',u_ac)='flower-send',u_num,0)) f_flower, sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) f_hits, sum(if(concat(u_mod,'-',u_ac) in ('message-video_comment_add','message-video_comment_reply'),1,0)) f_comment, max(unix_timestamp(substr(u_timestamp,0,19)))f_timestamp from dm.user_video where dt='" + datebuf + "' and hour='" + hour + "'group by u_diu, u_vid"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " user_video_index end"