#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by yinfeng


import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator

def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==3:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==4:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath



#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    coldDate=handleDatePath(sys.argv,'%Y-%m-%d',30)
    print "inDate  ",inDate
    inHour = sys.argv[2]
    print "inHour ",inHour
    befHour = sys.argv[3]
    print "befHour",befHour

    baseTime = inDate+" 00:00:00"
    print(baseTime)



    spark = SparkSession.builder.appName('recy_city_pop_topk:'+inDate+"/"+inHour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=500")

    if inHour == '00':
        spark.sql("FROM (SELECT u_diu, u_vid, f_vp, f_down, f_share, f_fav, f_hits, f_comment FROM dm.user_video_index WHERE dt = '"+inDate+"' AND hour = '"+inHour+"') a JOIN (SELECT diu, abcode city FROM dm.diu_city where city!='') b ON a.u_diu=b.diu JOIN (SELECT vid, createtime FROM db.video) d ON a.u_vid = d.vid INSERT overwrite TABLE dm.video_index_hour partition(dt='"+inDate+"',hour='"+inHour+"') SELECT u_vid, city, createtime createtime, avg(f_vp)*0.01 avg_f_vp, sum(f_down) sum_f_down, sum(f_share) sum_f_share, sum(f_fav) sum_f_fav, count(distinct(u_diu)) sum_f_uv, sum(f_comment) sum_f_comment GROUP BY u_vid, city, createtime INSERT overwrite TABLE dm.video_index_day partition(dt='"+inDate+"',hour='"+inHour+"') SELECT u_vid, city, createtime createtime, avg(f_vp)*0.01 avg_f_vp, sum(f_down) sum_f_down, sum(f_share) sum_f_share, sum(f_fav) sum_f_fav, count(distinct(u_diu)) sum_f_uv, sum(f_comment) sum_f_comment GROUP BY u_vid, city, createtime")

    else:
        spark.sql("INSERT overwrite TABLE dm.video_index_hour partition(dt='" + inDate + "',hour='" + inHour + "') SELECT u_vid, city, createtime createtime, avg(f_vp)*0.01 avg_f_vp, sum(f_down) sum_f_down, sum(f_share) sum_f_share, sum(f_fav) sum_f_fav, count(distinct(u_diu)) sum_f_uv, sum(f_comment) sum_f_comment FROM (SELECT u_diu, u_vid, f_vp, f_down, f_share, f_fav, f_hits, f_comment FROM dm.user_video_index WHERE dt = '" + inDate + "' AND hour = '" + inHour + "') a JOIN (SELECT diu, abcode city FROM dm.diu_city where city!='') b ON a.u_diu=b.diu JOIN (SELECT vid, createtime FROM db.video) d ON a.u_vid = d.vid GROUP BY u_vid, city, createtime")
        spark.sql("INSERT overwrite TABLE dm.video_index_day partition(dt='" + inDate + "',hour='" + inHour + "') SELECT if(a_u_vid is not null,a_u_vid,b_u_vid) u_vid, if(a_city is not null,a_city,b_city) u_city, if(a_createtime is not null,a_createtime,b_creatime) createtime, (a_avg_f_vp+b_avg_f_vp)total_f_vp, (a_sum_f_down+b_sum_f_down)total_f_down, (a_sum_f_share+b_sum_f_share)total_f_share, (a_sum_f_fav+b_sum_f_fav)total_f_fav, (a_sum_f_uv +b_sum_f_uv)total_sum_f_uv, (a_sum_f_comment+b_sum_f_comment)total_f_comment from (select a.u_vid a_u_vid, a.city a_city, a.createtime a_createtime, if(a.avg_f_vp is null,0,a.avg_f_vp) a_avg_f_vp, if(a.sum_f_down is null,0,a.sum_f_down) a_sum_f_down, if(a.sum_f_share is null,0,a.sum_f_share) a_sum_f_share, if(a.sum_f_fav is null,0,a.sum_f_fav) a_sum_f_fav, if(a.sum_f_uv is null,0,a.sum_f_uv) a_sum_f_uv, if(a.sum_f_comment is null ,0,a.sum_f_comment) a_sum_f_comment, b.u_vid b_u_vid, b.city b_city, b.createtime b_creatime, if(b.avg_f_vp is null,0,b.avg_f_vp) b_avg_f_vp, if(b.sum_f_down is null,0,b.sum_f_down) b_sum_f_down, if(b.sum_f_share is null,0,b.sum_f_share) b_sum_f_share, if(b.sum_f_fav is null,0,b.sum_f_fav) b_sum_f_fav, if(b.sum_f_uv is null,0,b.sum_f_uv) b_sum_f_uv, if(b.sum_f_comment is null ,0,b.sum_f_comment) b_sum_f_comment from (SELECT u_vid, city, createtime, avg_f_vp, sum_f_down, sum_f_share, sum_f_fav, sum_f_uv, sum_f_comment FROM dm.video_index_day WHERE dt='" + inDate + "' AND hour='" + befHour + "')a FULL OUTER JOIN (SELECT u_vid, city, createtime, avg_f_vp, sum_f_down, sum_f_share, sum_f_fav, sum_f_uv, sum_f_comment FROM dm.video_index_hour WHERE dt='" + inDate + "' AND hour='" + inHour + "')b ON a.u_vid = b.u_vid and a.city = b.city and a.createtime = b.createtime)c")
    spark.sql("INSERT overwrite TABLE dm.recy_city_pop partition(dt='"+inDate+"',hour='"+inHour+"') SELECT u_vid, city, score, title, createtime, avg_f_vp, sum_f_down, sum_f_share, sum_f_fav, sum_f_uv, sum_f_comment FROM (SELECT u_vid, city, (log10(sum_f_uv) + (unix_timestamp(createtime) - unix_timestamp('"+baseTime+"'))/45000) score, createtime, avg_f_vp, sum_f_down, sum_f_share, sum_f_fav, sum_f_uv, sum_f_comment FROM dm.video_index_day WHERE dt='"+inDate+"'AND hour='"+inHour+"')a JOIN (SELECT vid, title FROM db.video where case when type='10' then datediff('"+inDate+"',to_date(createtime))<=2 else true  end )b ON a.u_vid=b.vid")
    spark.sql("insert overwrite table dm.recy_city_pop_topk partition(dt='" + inDate + "',hour='" + inHour + "') select d.* from (select b.* from (select * from (select u_vid, city, score, sum_f_uv, ROW_NUMBER() OVER(PARTITION by city order by score desc) rank from dm.recy_city_pop where dt='" + inDate + "'and hour = '" + inHour + "')a where rank<=500 and sum_f_uv>=3)b left outer join (select * from dm.recy_city_pop_topk where dt= '" + inDate + "')c on b.u_vid = c.u_vid where c.u_vid is null) d left outer join (select vid from (select vid from db.video where (status <> 0 or uid=0 or type=9 or (parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188'))) union all select vid from db.video_recommend where type=1) e group by vid)f on d.u_vid = f.vid where f.vid is null")
    print 'job success'

    spark.stop()












