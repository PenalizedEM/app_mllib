#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour

#主入口
if __name__ == "__main__":
    print str(sys.argv)


    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour

    #########################
    ## user_video_rating
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " user_video_rating begin"
    spark = SparkSession.builder.master('yarn-client').appName('user_video_rating:' + datebuf + "_" +  hour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=200"
    spark.sql(setSparSQLPartNum)
    sql = "insert overwrite table dm.user_video_rating PARTITION (dt='" + datebuf + "',hour='" + hour + "') select u_diu, u_vid, f_timestamp, f_diu, f_vid, if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating from (select u_diu, u_vid, f_timestamp, f_diu, f_vid, f_sb, f_sc, f_sd, f_se, f_sf, (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa from (select u_diu, u_vid, f_timestamp, f_diu, f_vid, f_vd, f_sb, f_sc, f_sd, f_se, f_sf, if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up from (select u_diu, u_vid, f_timestamp, hash(u_diu) f_diu, hash(u_vid) f_vid, f_vd, cast(if(f_down>0,5.0,0) as double) f_sb, cast(if(f_share>0,2.0,0.0) as double) f_sc, cast(if(f_fav>0,3.0,0.0) as double)f_sd, cast(if(f_flower>0,2.0,0.0) as double)f_se, cast(if(f_comment>0,1.0,0.0) as double)f_sf from dm.user_video_index where dt='" + datebuf + "' and hour='" + hour + "') a join (select diu, nnpr, mipr, pv from dm.user_video_bias1 where dt='" + datebuf + "' and hour='" + hour + "')b on (a.u_diu = b.diu)) c join (select vid, if(nnpr=0,0.1,nnpr) nnpr, mipr, pv from dm.user_video_bias2 where dt='" + datebuf + "' and hour='" + hour + "')d on (c.u_vid = d.vid))e"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " user_video_rating end"