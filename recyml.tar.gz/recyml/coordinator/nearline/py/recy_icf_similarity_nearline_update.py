#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    modelDate = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%%Y-%m-%d")
    if len(dateList) ==4:
        inDay = dateList[1]
        inHour = dateList[2]
        modelDate = dateList[3]
    return inDay,inHour,modelDate

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour
    modeldate = handleDateArgs(sys.argv)[2]
    print "modeldate ", modeldate


    #########################
    ## recy_icf_similarity_nearline_update
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_nearline_update begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_nearline_update:' + datebuf + "_" +  hour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=300"
    spark.sql(setSparSQLPartNum)
    hql = "insert OVERWRITE table dm.recy_icf_similarity_recently PARTITION(dt='" + datebuf + "') select vid_1, vid_2, num_1, num_2, num_12, if(num_12/sqrt(num_1*num_2)>1,1,num_12/sqrt(num_1*num_2)) similarity, update_hour from (select if(b.vid_1 is null,a.vid_1,b.vid_1) vid_1 , if(b.vid_2 is null,a.vid_2,b.vid_2) vid_2 , case when a.num_1 is null and b.num_1 is not null then b.num_1 when a.num_1 is not null and b.num_1 is null then a.num_1 when a.num_1 is not null and b.num_1 is not null then a.num_1+b.num_1 else 0 end as num_1, case when a.num_2 is null and b.num_2 is not null then b.num_2 when a.num_2 is not null and b.num_2 is null then a.num_2 when a.num_2 is not null and b.num_2 is not null then a.num_2+b.num_2 else 0 end as num_2, case when a.num_12 is null and b.num_12 is not null then b.num_12 when a.num_12 is not null and b.num_12 is null then a.num_12 when a.num_12 is not null and b.num_12 is not null then a.num_12+b.num_12 else 0 end as num_12, if(b.hour is null,a.update_hour,b.hour) update_hour from (select vid_1, vid_2, num_1, num_2, num_12, similarity, update_hour from dm.recy_icf_similarity_recently where dt = '"+modeldate+ "') a full outer join (select vid_1, vid_2, num_1, num_2, num_12, similarity, hour from dm.recy_icf_similarity where dt = date_add('"+datebuf+"',1) and hour ='"+hour+"') b on (a.vid_1=b.vid_1 and a.vid_2=b.vid_2) ) a"
    print hql
    spark.sql(hql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_nearline_update end"