#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour


    #########################
    ## recy_out_topk
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_out_topk begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_out_topk:' + datebuf + "_" +  hour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=300"
    spark.sql(setSparSQLPartNum)
    sql = "insert overwrite table dm.recy_out_topk partition(dt='" + datebuf + "',hour='" + hour + "') select diu , vid, rank from (select * , ROW_NUMBER() over (partition by diu order by rank desc) rk from (select a.*, ROW_NUMBER() over (partition by diu,uid order by rank desc) rn from (select diu, e.vid, uid, rank from (select diu, vid, rank from dm.recy_icf_recommend where dt='" + datebuf + "'and hour='" + hour + "') e join (select vid,uid from db.video where !(status <> 0 or uid=0 or type=9 or ( parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188') ) ) ) f on(e.vid=f.vid) ) a left outer join (SELECT vid FROM db.video_recommend WHERE type=1 ) b on (a.vid = b.vid) where b.vid is null ) b where rn<=5) c where rk<=2000"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_out_topk end"