#!/bin/sh

source /etc/profile

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
spark_submit=$SPARK_HOME/bin/spark-submit
########################################

datebuf=$1
hour=$2
num_executors=$3
executor_cores=$4
executor_memory=$5

#yesterday=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
yesterday=${datebuf}

echo "yesterday = "${yesterday}

bef_yesterday=`date -d" -1 day $yesterday" +"%Y-%m-%d"`

echo "bef_yesterday = "${bef_yesterday}

# _SUCCESS check
$hadoop fs -test -e /olap/dm/recy_icf_similarity_recently/dt=$yesterday/_SUCCESS
f=$?

if [ $f -ne 0 ]; then
	similarity_recently_date=$bef_yesterday

	echo "xxx"
       echo " `date` [WARN]   /olap/dm/recy_icf_similarity_recently/dt=$yesterday/_SUCCESS not exists! similarity_recently of $similarity_recently_date will be used!"
	echo "xxx"

    $spark_submit  --master yarn-client --num-executors ${num_executors} --executor-cores ${executor_cores} --executor-memory ${executor_memory} ./py/recy_icf_similarity_nearline_update.py ${datebuf} ${hour} ${similarity_recently_date}
else
	similarity_recently_date=$yesterday

	echo "###"
        echo "`date` [INFO]   /olap/dm/recy_icf_similarity_recently/dt=$yesterday/_SUCCESS exists!  similarity_recently of $similarity_recently_date will be used!"
	echo "###"

    $spark_submit  --master yarn-client --num-executors ${num_executors} --executor-cores ${executor_cores} --executor-memory ${executor_memory} ./py/recy_icf_similarity_nearline_update.py ${datebuf} ${hour} ${similarity_recently_date}
fi