#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    uvm_date = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%%Y-%m-%d")
    if len(dateList) ==4:
        inDay = dateList[1]
        inHour = dateList[2]
        uvm_date = dateList[3]
    return inDay,inHour,uvm_date

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour
    uvm_date = handleDateArgs(sys.argv)[2]
    print "uvm_date ", uvm_date


    #########################
    ## recy_icf_recommend
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_recommend begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_recommend:' + datebuf + "_" +  hour).config('spark.yarn.executor.memoryOverhead', '2048').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=300"
    spark.sql(setSparSQLPartNum)
    sql = "insert overwrite table dm.recy_icf_recommend PARTITION (dt='" + datebuf + "',hour='" + hour + "') select d.diu, d.vid, d.rating, d.from_vid, ROW_NUMBER() OVER (PARTITION by d.diu order by d.rating desc) rank from (select * from dm.recy_icf_recommend_pre where dt='" + datebuf + "'and hour='" + hour + "') d left outer join (select a.* from (select u_diu, u_vid from (select u_diu, u_vid from dm.user_video_rating union all select diu u_diu, vid u_vid from dm.recy_icf_recommend union all select u_diu, u_vid from dm.recy_data_viewed_videos where dt='" + uvm_date + "') a group by u_diu, u_vid ) a join (	select u_diu, count(1) vcnt from (select u_diu, u_vid from (select u_diu, u_vid from dm.user_video_rating union all select diu u_diu, vid u_vid from dm.recy_icf_recommend union all select u_diu, u_vid from dm.recy_data_viewed_videos where dt='" + uvm_date + "') a group by u_diu, u_vid ) a group by u_diu having vcnt <=1000 ) b on(a.u_diu=b.u_diu))e on (d.diu=e.u_diu and d.vid=e.u_vid) where e.u_diu is null"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_recommend end"