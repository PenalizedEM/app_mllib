#!/bin/sh

source /etc/profile

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
spark_submit=$SPARK_HOME/bin/spark-submit
########################################

datebuf=$1
hour=$2
num_executors=$3
executor_cores=$4
executor_memory=$5

yesterday=`date -d" -1 day $datebuf" +"%Y-%m-%d"`

echo "yesterday = "${yesterday}

bef_yesterday=`date -d" -2 day $datebuf" +"%Y-%m-%d"`

echo "bef_yesterday = "${bef_yesterday}

# _SUCCESS check
$hadoop fs -test -e /olap/dm/recy_als_data_uvm/$yesterday/_SUCCESS
f=$?

if [ $f -ne 0 ]; then
	uvm_date=$bef_yesterday

	echo "xxx"
       echo " `date` [WARN]   /olap/dm/recy_als_data_uvm/$yesterday/_SUCCESS not exists! uvm of $uvm_date will be used!"
	echo "xxx"

    $spark_submit  --master yarn-client --num-executors ${num_executors} --executor-cores ${executor_cores} --executor-memory ${executor_memory} ./py/recy_icf_recommend.py ${datebuf} ${hour} ${uvm_date}
else
	uvm_date=$yesterday

	echo "###"
        echo "`date` [INFO]   /olap/dm/recy_als_data_uvm/$yesterday/_SUCCESS exists!  uvm of $uvm_date will be used!"
	echo "###"

    $spark_submit  --master yarn-client --num-executors ${num_executors} --executor-cores ${executor_cores} --executor-memory ${executor_memory} ./py/recy_icf_recommend.py ${datebuf} ${hour} ${uvm_date}
fi