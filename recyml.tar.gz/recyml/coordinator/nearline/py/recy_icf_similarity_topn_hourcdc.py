#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    if len(dateList) ==3:
        inDay = dateList[1]
        inHour = dateList[2]
    return inDay,inHour

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour


    #########################
    ## recy_icf_similarity_topn_hourcdc
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_topn_hourcdc begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_topn_hourcdc:' + datebuf + "_" +  hour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=300"
    spark.sql(setSparSQLPartNum)

    hql = "insert OVERWRITE table dm.recy_icf_similarity_topn_hourcdc PARTITION(dt='" + datebuf + "',hour='" + hour + "') select vid_1, vid_2, similarity, rank from (select vid_1, vid_2, similarity, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from dm.recy_icf_similarity_recently where dt =date_sub('"+datebuf+"',1) ) a where rank<= 80"
    print hql
    spark.sql(hql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_topn_hourcdc end"