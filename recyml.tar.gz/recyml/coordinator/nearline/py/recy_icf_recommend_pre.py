#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    inDay =  (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%Y-%m-%d")
    inHour = (datetime.datetime.now() - datetime.timedelta(hours=1)).strftime("%H")
    modelDate = (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%%Y-%m-%d")
    if len(dateList) ==4:
        inDay = dateList[1]
        inHour = dateList[2]
        modelDate = dateList[3]
    return inDay,inHour,modelDate

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    hour = handleDateArgs(sys.argv)[1]
    print "hour ", hour
    modeldate = handleDateArgs(sys.argv)[2]
    print "modeldate ", modeldate


    #########################
    ## recy_icf_recommend_pre
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_recommend_pre begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_recommend_pre:' + datebuf + "_" +  hour).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=300"
    spark.sql(setSparSQLPartNum)
    sql = "insert overwrite table dm.recy_icf_recommend_pre PARTITION (dt='" + datebuf + "',hour='" + hour + "') select diu, vid_2 vid, sum(rating*similarity) rating, max(vid) from_vid from (select * from dm.recy_icf_similarity_topn where dt='" + modeldate + "' ) b join (select u_diu diu, u_vid vid, f_rating rating from dm.user_video_rating where dt='" + datebuf + "' and hour='" + hour + "' ) c on (b.vid_1=c.vid) group by diu, vid_2"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_recommend_pre end"