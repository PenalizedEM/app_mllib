#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
spark_submit=$SPARK_HOME/bin/spark-submit
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive

cd /home/hadoop/user/vent/crontab/
current_dir=`pwd`

echo "spark_submit=${spark_submit}"
echo "hadoop=${hadoop}"
echo "hive=${hive}"
echo "current_dir=${current_dir}"
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1
pyfile_name=$2
num_executors=$3
executor_cores=$4
executor_memory=$5

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date "+%Y-%m-%d %T"` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"

n_daysago_1=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_1:$n_daysago_1"

n_daysago_2=`date -d" -2 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_2:$n_daysago_2"

n_daysago_4=`date -d" -4 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_4:$n_daysago_4"

n_daysago_7=`date -d" -7 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_7:$n_daysago_7"

n_daysago_14=`date -d" -14 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_14:$n_daysago_14"

n_daysago_15=`date -d" -15 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_15:$n_daysago_15"

n_daysago_30=`date -d" -30 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_30:$n_daysago_30"

n_daysago_365=`date -d" -365 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_365:$n_daysago_365"

##########################################################################################

function run_pyspark_sql(){
    task_name=$1
    date_para=$2
    para_str=$3

    default_para_str="--queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 5 --executor-memory 12g --driver-memory 2g --conf spark.default.parallelism=300   --conf spark.storage.memoryFraction=0.5   --conf spark.shuffle.memoryFraction=0.3"

    if [ -z "$para_str" ] && [ ${#para_str} -lt 5 ]; then
        para_str=${default_para_str}
    fi

    {
        $spark_submit ${para_str} /home/hadoop/user/vent/crontab/py/pyspark_sql.py ${task_name} ${date_para}
        suc_flag=$?
    } >> log/${datebuf}_${task_name}.log 2>&1
    duration_str=$(cat log/${datebuf}_${task_name}.log | grep duration | awk -F ': ' 'END {print $2}')
}

function is_success(){
    task_name=$1
    suc_flag=$2
    duration_str=$3

    if [ $suc_flag -ne 0 ] ; then
        echo  "`date "+%Y-%m-%d %T"` [ERROR] ----------- Job  ${task_name} ${datebuf} run failed! Duration ${duration_str} !"
        exit -1
    else
        echo  "`date "+%Y-%m-%d %T"` [INFO] ----------- Job  ${task_name} ${datebuf} run success! Duration ${duration_str} !"
    fi
}

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow begin ---------"
########################################

{
    run_pyspark_sql recy_als_data_uvr "-d datebuf=${datebuf} -d n_daysago_1=${n_daysago_1}"
    is_success recy_als_data_uvr $((suc_flag)) $duration_str
}

wait

{
    run_pyspark_sql recy_als_data_userbias "-d datebuf=${datebuf} -d n_daysago_30=${n_daysago_30}"
    is_success recy_als_data_userbias $((suc_flag)) $duration_str
} &

{
    run_pyspark_sql recy_als_data_itembias "-d datebuf=${datebuf} -d n_daysago_30=${n_daysago_30}"
    is_success recy_als_data_itembias $((suc_flag)) $duration_str
} &

wait

{
    run_pyspark_sql recy_als_data_uvm "-d datebuf=${datebuf} -d n_daysago_2=${n_daysago_2}"
    is_success recy_als_data_uvm $((suc_flag)) $duration_str

    run_pyspark_sql recy_cf_rating "-d datebuf=${datebuf}"
    is_success recy_cf_rating $((suc_flag)) $duration_str
}

wait

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow end ---------"
########################################