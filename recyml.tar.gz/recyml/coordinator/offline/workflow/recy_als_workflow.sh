#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
spark_submit=$SPARK_HOME/bin/spark-submit
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive

cd /home/hadoop/user/vent/crontab/
current_dir=`pwd`

echo "spark_submit=${spark_submit}"
echo "hadoop=${hadoop}"
echo "hive=${hive}"
echo "current_dir=${current_dir}"
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1
pyfile_name=$2
num_executors=$3
executor_cores=$4
executor_memory=$5

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date "+%Y-%m-%d %T"` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"

n_daysago_1=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_1:$n_daysago_1"

n_daysago_3=`date -d" -3 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_3:$n_daysago_3"

n_daysago_4=`date -d" -4 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_4:$n_daysago_4"

n_daysago_7=`date -d" -7 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_7:$n_daysago_7"

n_daysago_14=`date -d" -14 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_14:$n_daysago_14"

n_daysago_15=`date -d" -15 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_15:$n_daysago_15"

n_daysago_365=`date -d" -365 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_365:$n_daysago_365"

##########################################################################################

function run_pyspark_sql(){
    task_name=$1
    date_para=$2
    para_str=$3

    default_para_str="--queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 25 --executor-cores 4 --executor-memory 11g --driver-memory 2g --conf spark.default.parallelism=300   --conf spark.storage.memoryFraction=0.5   --conf spark.shuffle.memoryFraction=0.3"

    if [ -z "$para_str" ] && [ ${#para_str} -lt 5 ]; then
        para_str=${default_para_str}
    fi

    {
        $spark_submit ${para_str} /home/hadoop/user/vent/crontab/py/pyspark_sql.py ${task_name} ${date_para}
        suc_flag=$?
    } >> log/${datebuf}_${task_name}.log 2>&1
    duration_str=$(cat log/${datebuf}_${task_name}.log | grep duration | awk -F ': ' 'END {print $2}')
}


function run_hive_sql(){
    task_name=$1
    date_para=$2

    {
        echo `date "+%Y-%m-%d %T"`" [INFO] ----------- "${task_name}" "${datebuf}" job begin"
        $hive ${date_para} -f ./sql/${task_name}.sql
        suc_flag=$?
        echo `date "+%Y-%m-%d %T"`" [INFO] ----------- "${task_name}" "${datebuf}" job end"
    } >> log/${datebuf}_${task_name}.log 2>&1

    start_time=`cat log/${datebuf}_${task_name}.log | grep ' job begin' | awk -F ' \\\\[' 'END {print $1}'`
    start_seconds=`date -d"$start_time" +"%s"`
    end_time=`cat log/${datebuf}_${task_name}.log | grep ' job end' | awk -F ' \\\\[' 'END {print $1}'`
    end_seconds=`date -d"$end_time" +"%s"`

    let duration_sec=$end_seconds-$start_seconds


    if [ $duration_sec -lt 60 ];then
        duration_str=${duration_sec}"s "
    else
        duration_str=$(($duration_sec/60))"min"$(($duration_sec%60))"s "
    fi
}

function run_pyspark(){
    task_name=$1
    date_para=$2
    {
        echo `date "+%Y-%m-%d %T"`" [INFO] ----------- "${task_name}" "${datebuf}" job begin"
        $spark_submit --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 25 --executor-cores 4 --executor-memory 11g --driver-memory 2g --conf spark.default.parallelism=300   --conf spark.storage.memoryFraction=0.5   --conf spark.shuffle.memoryFraction=0.3 /home/hadoop/user/vent/crontab/py/${task_name}.py ${date_para}
        suc_flag=$?
        echo  " "
        echo `date "+%Y-%m-%d %T"`" [INFO] ----------- "${task_name}" "${datebuf}" job end"
    } > log/${datebuf}_${task_name}.log 2>&1

    start_time=`cat log/${datebuf}_${task_name}.log | grep ' job begin' | awk -F ' \\\\[' 'END {print $1}'`
    start_seconds=`date -d"$start_time" +"%s"`
    end_time=`cat log/${datebuf}_${task_name}.log | grep ' job end' | awk -F ' \\\\[' 'END {print $1}'`
    end_seconds=`date -d"$end_time" +"%s"`

    let duration_sec=$end_seconds-$start_seconds

    if [ $duration_sec -lt 60 ];then
        duration_str=${duration_sec}"s "
    else
        duration_str=$(($duration_sec/60))"min"$(($duration_sec%60))"s "
    fi
}


function is_success(){
    task_name=$1
    suc_flag=$2
    duration=$3

    if [ $suc_flag -ne 0 ] ; then
        echo  "`date "+%Y-%m-%d %T"` [ERROR] ----------- Job  ${task_name} ${datebuf} run failed! Duration ${duration} !"
        exit -1
    else
        echo  "`date "+%Y-%m-%d %T"` [INFO] ----------- Job  ${task_name} ${datebuf} run success! Duration ${duration} !"
    fi
}

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow begin ---------"
########################################

{
    run_hive_sql recy_als_data_candya_stage1 "--hivevar datebuf=${datebuf} --hivevar n_daysago_3=${n_daysago_3}"
    is_success recy_als_data_candya_stage1 $((suc_flag)) $duration_str

    run_pyspark_sql recy_als_data_candya "-d datebuf=${datebuf} -d n_daysago_1=${n_daysago_1}"
    is_success recy_als_data_candya $((suc_flag)) $duration_str

    run_pyspark_sql recy_als_data_candytag  "-d datebuf=${datebuf} -d n_daysago_14=${n_daysago_14}"
    is_success recy_als_data_candytag $((suc_flag)) $duration_str

    run_pyspark_sql recy_als_data_finalcandy "-d datebuf=${datebuf} -d n_daysago_1=${n_daysago_1} -d n_daysago_7=${n_daysago_7}"
    is_success recy_als_data_finalcandy $((suc_flag)) $duration_str

    run_pyspark recy_als_model ${datebuf}
    is_success recy_als_model $((suc_flag)) $duration_str
    $hive -e "dfs -touchz /olap/da/recy_als_model/${datebuf}/_SUCCESS"

    run_pyspark recy_als_predict ${datebuf}
    is_success recy_als_predict $((suc_flag)) $duration_str
    $hive -e "ALTER TABLE da.recy_als_prediction ADD IF NOT EXISTS PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_predict/$datebuf/'"

    run_pyspark_sql recy_als_out_topk "-d datebuf=${datebuf}"
    is_success recy_als_out_topk $((suc_flag)) $duration_str

    run_pyspark recy_als_out_pop ${datebuf}
    is_success recy_als_out_pop $((suc_flag)) $duration_str
    $hive -e "dfs -touchz /olap/da/recy_als_out_popcat/dt=${datebuf}/_SUCCESS"
}

wait

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow end ---------"
########################################