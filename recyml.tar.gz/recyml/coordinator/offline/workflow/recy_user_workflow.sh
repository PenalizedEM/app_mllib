#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
spark_submit=$SPARK_HOME/bin/spark-submit
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
current_dir=`pwd`

echo "spark_submit=${spark_submit}"
echo "hadoop=${hadoop}"
echo "hive=${hive}"
echo "current_dir=${current_dir}"
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1
pyfile_name=$2
num_executors=$3
executor_cores=$4
executor_memory=$5

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"

onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
echo "onedayago:$onedayago"
##########################################################################################

function run_pyspark(){
    num_executors=$1
    executor_cores=$2
    executor_memory=$3
    pyfile_name=$4
    task_name=$5
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf} ${task_name}  job begin**************************"

    {
        sh ./action/pyspark.sh ${datebuf} ${pyfile_name} ${num_executors} ${executor_cores} ${executor_memory} ${task_name}
    } > log/run_pyspark_${pyfile_name}_${task_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf} ${task_name}  job end  **************************"
}

function run_sql(){
    sqlfile_name=$1
    x=$2
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sqlfile_name}  ${datebuf} job begin**************************"
    {
        sh ./action/sql.sh ${datebuf} ${sqlfile_name} ${x}
    } > ./log/run_sql_${sqlfile_name}.log 2>&1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sqlfile_name}  ${datebuf} job end  **************************"
}

function run_shell(){
    num_executors=$1
    executor_cores=$2
    executor_memory=$3
    shfile_name=$4

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${shfile_name} ${datebuf}  job begin**************************"

    {
        sh ./action/shell.sh ${datebuf}  ${shfile_name} ${num_executors} ${executor_cores} ${executor_memory}
    } > log/run_shell_${shfile_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${shfile_name} ${datebuf}  job end  **************************"
}

function add_partition(){
    pyfile_name=$1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf}  add_partition begin**************************"

    {
        $hive -e "ALTER TABLE da.${pyfile_name} ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/$pyfile_name/$datebuf/'"
    } > log/add_partition_${pyfile_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf}  add_partition end  **************************"
}

function touch_success(){
    file_name=$1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${file_name} ${datebuf}  touch_success begin**************************"

    {
        $hive -e "dfs -touchz /olap/da/$file_name/dt=${datebuf}/_SUCCESS"
    } > log/touch_success_${file_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${file_name} ${datebuf}  touch_success end  **************************"
}


function redis_mr(){
    jar=$1
    main_class=$2
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${jar} ${main_class} ${datebuf}  redis_mr begin**************************"

    {
        sh ./action/redis_mr.sh ${datebuf}  ${jar} ${main_class}
    } > log/redis_mr_${main_class}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${jar} ${main_class} ${datebuf}  redis_mr end  **************************"
}

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow begin ---------"
########################################

# ucf
{

    run_pyspark 40 3 12g recy_ucf recy_ucf_rating
    run_pyspark 45 3 12g recy_ucf recy_ucf_similarity_mid
    run_pyspark 40 3 12g recy_ucf recy_ucf_similarity
    run_sql recy_ucf_similarity_topn_mid
    run_pyspark 40 3 12g recy_ucf recy_ucf_similarity_topn
    redis_mr recyio DiuSim2ListDriver
    run_pyspark 40 3 12g recy_ucf recy_user_sim_topn_diu
    redis_mr recyio SimDiuUid2ListDriver
    run_pyspark 40 3 12g recy_ucf recy_user_sim
    run_pyspark 40 3 12g recy_ucf recy_user_mutual_fans_topn
    run_sql recy_user_sim_topn
    redis_mr recyio SimUid2ListDriver

}

wait

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow end ---------"
########################################
