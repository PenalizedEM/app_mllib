#!/usr/bin/python
#   -*- coding: UTF-8 -*-
# create  by vent @ Dec 12

"""
Generate Candidate Videos
Two filter condition:
1. util 6 months ago tags author's videos.
2. util 1 months ago had been viewed autor's videos.(and hits_total>=50)

Next Step:
Song similiraty
Title top model(LDA)
"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    #inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    #print "inUAPath HDFS Path: ",inUAPath
    # UVA输出目录的日期格式
    outDate = handleDatePath(sys.argv,'%Y-%m-%d',0)
    inDate = handleDatePath(sys.argv,'%Y-%m-%d',1)
    tagDate = handleDatePath(sys.argv,'%Y-%m-%d',45)
    authorDate =  handleDatePath(sys.argv,'%Y-%m-%d',30)
    filterDate = handleDatePath(sys.argv,'%Y-%m-%d',7)
    print "tagDate: ",tagDate
    print "authorDate: ",authorDate

    outPath = "hdfs://Ucluster/olap/da/recy_als_data_finalcandy/"+outDate+"/"
    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-data-finalcandy:'+outDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    #filter
    #filterSQL = "select e.u_diu,c.vid from (select d.u_diu ,c.tag from (select a.uid,tag,vid from recy_dic_video_tag where to_date(createtime)>='"+tagDate+"' join (select  u_diu,u_vid from da.recy_als_data_uvm where dt='"+outDate+"' )d  on (c.vid = d.u_vid) group by u_diu,tag)e join select tag,vid from c on (e.tag=c.tag)"

    #得到diu,vid的候选大表
    #candySQL = "select a.u_diu,c.vid,hash(a.u_diu)f_diu,hash(c.vid) f_vid from (select a.*, b.uid from ( select u_diu, u_vid from da.recy_als_data_uvm where dt='2016-12-14' and to_date(from_unixtime(f_timestamp,'yyyy-MM-dd'))='2016-12-14' and u_diu not in ('0','0123456789abcde','012345678912345','123456789012345','00000000','000000000000000','111111111111111') ) a join (select uid,vid from dw.video where to_date(createtime)='2016-12-14' and hits_total>=100) b on (a.u_vid=b.vid)) a left outer join dw.video c on (a.uid=c.uid) where a.u_vid<>c.vid "
        #vid的候选大表
    # candySQL = "select a.u_vid,a.f_vid,b.uid from (select u_vid,f_vid from  da.recy_als_data_uvm where dt='"+outDate+"' group by u_vid,f_vid)a join (select uid,vid,createtime,hits_total from dw.video where to_date(createtime)>='"+authorDate+"' and to_date(createtime)<='"+outDate+"' and hits_total>=100)b  on (a.u_vid=b.vid)  "
    # candyDF = spark.sql(candySQL)
    # candyDF.createOrReplaceTempView("canvideo")
    # userSQL = "select c.u_diu,d.u_vid,c.f_diu,d.f_vid from (select a.u_diu,a.f_diu,b.uid,b.f_vid from (select u_diu,u_vid,f_diu,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' and u_diu not in ('0','0123456789abcde','012345678912345','123456789012345','00000000','000000000000000','111111111111111') )a join (select u_vid,f_vid,uid from canvideo)b on (a.f_vid = b.f_vid))c left outer join canvideo d on c.uid = d.uid where c.f_vid <> d.f_vid group by c.u_diu,d.u_vid,c.f_diu,d.f_vid"

    spark.sql("SET spark.sql.shuffle.partitions=500")
    #tag数据
    candymSQL  = "SELECT c.* ,d.f_vid from  (select  a.u_diu,a.u_vid,b.f_diu from (select u_diu,u_vid from da.recy_als_data_candytag where dt='"+outDate+"' group by u_diu,u_vid)a join (SELECT u_diu,f_diu from da.recy_als_data_uvm where dt='"+outDate+"' group by u_diu,f_diu)b on (a.u_diu = b.u_diu))c join (SELECT u_vid,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' group by u_vid,f_vid )d on (c.u_vid = d.u_vid) "
    candymDF = spark.sql(candymSQL)
    # candymDF.printSchema()
    # candymDF.show()
    candymDF.createOrReplaceTempView("cantagvideo")
    #author数据
    # candySQL = "select a.u_vid,a.f_vid,b.uid from (select u_vid,f_vid from  da.recy_als_data_uvm where dt='"+outDate+"' group by u_vid,f_vid)a join (select uid,vid,createtime,hits_total from dw.video where to_date(createtime)>='"+authorDate+"' and to_date(createtime)<='"+outDate+"' and hits_total>=100)b  on (a.u_vid=b.vid)  "
    # candyDF = spark.sql(candySQL)
    # candyDF.createOrReplaceTempView("canvideo")
    # userSQL = "select c.u_diu,d.u_vid,c.f_diu,d.f_vid from (select a.u_diu,a.f_diu,b.uid,b.f_vid from (select u_diu,u_vid,f_diu,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' and u_diu not in ('0','0123456789abcde','012345678912345','123456789012345','00000000','000000000000000','111111111111111') )a join (select u_vid,f_vid,uid from canvideo)b on (a.f_vid = b.f_vid))c left outer join canvideo d on c.uid = d.uid where c.f_vid <> d.f_vid group by c.u_diu,d.u_vid,c.f_diu,d.f_vid"
    # userDF = spark.sql(userSQL)
    # userDF.createOrReplaceTempView("canauthorvideo")
    #合并tag 和 author 数据
    spark.sql("SET spark.sql.shuffle.partitions=500")
    onefSQL = "SELECT u_diu,u_vid,f_diu,f_vid from (select u_diu,u_vid,f_diu,f_vid from cantagvideo  union all  select u_diu,u_vid,f_diu,f_vid from da.recy_als_data_candya  where dt='"+outDate+"' )c group by u_diu,u_vid,f_diu,f_vid"
    onefDF = spark.sql(onefSQL)
    onefDF.printSchema()
    onefDF.createOrReplaceTempView("onefcandy")
    #过滤看过的视频
    spark.sql("SET spark.sql.shuffle.partitions=500")
    twofSQL = "SELECT a.u_diu,a.u_vid,a.f_diu,a.f_vid from (select * from  onefcandy )a left outer join (select * from da.recy_als_data_uvm where dt='"+outDate+"')b  on (a.u_diu=b.u_diu and a.u_vid=b.u_vid) where b.u_diu is null"
    twofDF = spark.sql(twofSQL)
    twofDF.createOrReplaceTempView("twofcandy")
    #过滤前七天推荐结果
    # ffSQL = "SELECT a.* from (select * from  twofcandy )a left outer join (select diu ,vid  from da.recy_final_out_topk where dt>='"+filterDate+"' and dt<'"+inDate+"' group by diu,vid)b  on (a.u_diu=b.diu and a.u_vid=b.vid) where b.diu is null"
    # # 过滤前七天推荐结果 在最后一步过滤小视频
    # ffSQL = "select d.* from (select a.* from (select * from twofcandy)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='"+filterDate+"'and dt<'"+inDate+"'group by diu, vid)b on (a.u_diu=b.diu and a.u_vid=b.vid) where b.diu is null) d join (select vid from dw.video where type<>10) e on(d.u_vid=e.vid)"
    # 过滤前七天推荐结果 放开小视频的过滤
    ffSQL = "select a.* from (select * from twofcandy)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='"+filterDate+"'and dt<'"+inDate+"'group by diu, vid)b on (a.u_diu=b.diu and a.u_vid=b.vid) where b.diu is null"
    ffDF = spark.sql(ffSQL)
    #Mar 28 改成过滤 过去7天的推荐结果
    #过滤掉过去7天推荐曝光超过4次的视频(mar 25 ,edit as 14天所有模块,mar 27 改 7天3次首页)
    #threefSQL = "SELECT a.u_diu,a.u_vid,a.f_diu,a.f_vid from (select * from  twofcandy )a left outer join (select diu ,vid  from da.recy_final_out_topk where dt>='"+filterDate+"' and dt<='"+inDate+"' group by diu,vid)b  on (a.u_diu=b.diu and a.u_vid=b.vid) where b.diu is null"
    #threeDF = spark.sql(threefSQL)
    # threeDF.printSchema()
    # threeDF.show()
    # print threeDF.count()
    ffDF.repartition(500).write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
        # #print "dd---------",candyDF.count()
    # candyDF.printSchema()
    # candyDF.show()
    # print candyDF.count()
    #
    # tag-video 矩阵  20亿
    # diuSQL = "select u_diu from dw.user_info where dt='2016-12-14' and to_date(substr(u_timestamp,0,19))>='2016-12-07' "
    # diuDF = spark.sql(diuSQL)
    # print "diu count :",diuDF.count()
    # vidSQL = "select vid from da.recy_dic_video_tag where to_date(createtime)>='2016-11-14' group by vid"
    # vidDF = spark.sql(vidSQL)
    # print "vid count ",vidDF.count()
    #candyDF = diuDF.rdd.cartesian(vidDF.rdd).toDF()
    #print candyDF.count()
    #candyDF.show()
