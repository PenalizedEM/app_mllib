#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 5

"""
 Implementation of ALS to predict user's rating on video
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.ml.feature import VectorAssembler,StringIndexer
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath
# p@k 评估
def patK(predictions,spark):
    predictions.createOrReplaceTempView("temp_prediction")
    #patK = "select u_diu,u_vid,f_rating,prediction,rank() over (partition by u_diu,u_vid order by prediction desc) rnk from temp_prediction  "
    pakSQL= "select sum(if(f_rating>=3.5,1,0))all,sum(if(f_rating >=3.5 and prediction >= 3.5,1,0))pak from temp_prediction "
    pak = spark.sql(pakSQL)
    numP = pak
    return paK/allK
#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inUVMDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    sixMoth =  handleDatePath(sys.argv,'%Y-%m-%d',365)
    print "inUVinUVMDateADate  ",inUVMDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_als_model:'+inUVMDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    #读入用户视频评分全量表
    rateSql =  "select * from da.recy_als_data_uvm where dt='"+inUVMDate+"' and f_diu is not null and f_vid is not null and f_rating is not null and f_rating >0.4 and f_timestamp >= unix_timestamp('"+sixMoth+"','yyyy-MM-dd') "
    rating = spark.sql(rateSql)

    # candySql = "select * from da.recy_als_data_candya where dt='"+inUVMDate+"'"
    # candy = spark.sql(candySql)
    #val result = log.select("page","visitor").groupBy('page).agg('page, countDistinct('visitor))

    #分割训练集和测试集,0.8,0.2
    #(training, test) = rating.randomSplit([0.8, 0.2])
    # numRating = rating.count()
    # numTrain = training.count()
    # numTest = test.count()
    # print "总数据集条数",numRating
    # print "训练集条数",numTrain
    # print "测试集条数",numTest
    #test.show()
    #ALS模型参数
    # ranks = [8, 10]
    # lambdas = [0.01,0.05, 0.1]
    # numIters = [20]
    # bestModel = None
    # bestValidationRmse = float("inf")
    # bestRank = 0
    # bestLambda = -1.0
    # bestNumIter = -1
    # #调参
    # for rank, lmbda, numIter in itertools.product(ranks, lambdas, numIters):
    # #model = ALS.train(training, rank, numIter, lmbda)
    #     als = ALS(rank=rank,maxIter=numIter, regParam=lmbda, userCol="f_diu", itemCol="f_vid", ratingCol="f_rating", nonnegative=True)
    #     model = als.fit(training)
    #     predictions = model.transform(test).dropna('any')
    #     evaluator = RegressionEvaluator(metricName="rmse", labelCol="f_rating",
    #                                     predictionCol="prediction")
    #     validationRmse = evaluator.evaluate(predictions)
    #     print "RMSE (validation) = %f for the model trained with " % validationRmse + \
    #           "rank = %d, lambda = %.1f, and numIter = %d." % (rank, lmbda, numIter)
    #     if (validationRmse < bestValidationRmse):
    #         bestModel = model
    #         bestValidationRmse = validationRmse
    #         bestRank = rank
    #         bestLambda = lmbda
    #         bestNumIter = numIter
    # # evaluate the best model on the test set
    # print "The best model was trained with rank = %d and lambda = %.1f, " % (bestRank, bestLambda) \
    #   + "and numIter = %d, and its RMSE on the test set is %f." % (bestNumIter, bestValidationRmse)
    # predictions = bestModel.transform(rating).dropna('any')
    # predictPath =  "hdfs://Ucluster/olap/da/recy_als_predict/"+inUVMDate+"/"
    # predictions.repartition(200).write.mode('overwrite').save(predictPath, format="parquet")
    als = ALS(rank=10, maxIter=20, regParam=0.1, userCol="f_diu", itemCol="f_vid", ratingCol="f_rating")
    #model = als.fit(rating)
    #only for evaluate
    model = als.fit(rating)
    # print "model rank: ",model.rank
    # # 保存模型
    # model.userFactors.orderBy("id").show()
    modelPath =  "hdfs://Ucluster/olap/da/recy_als_model/"+inUVMDate+"/"
    model.write().overwrite().save(modelPath)
    # 根据模型，使用测试集评估模型，通过RMSE来评估模型。由于测试集中可能有模型中没出现过的user,那就会有预测值为nan。drop即可。
    #predictions = model.transform(test).dropna('any')
    # predictPath =  "hdfs://Ucluster/olap/da/recy_als_predict/"+inUVMDate+"/"
    # #predictions.show()
    # # # predictions.printSchema()
    # predictions.write.mode('overwrite').save(predictPath, format="parquet")
    # numberPre = predictions.count()
    # print "预测结果条数",numberPre
    #p@k
    # predictions.createOrReplaceTempView("temp_prediction")
    # #in use
    # pakSQL = "select sum(if(b.prediction >= 4.0,1,0))all,sum(if(b.f_rating >= 4.0 and b.prediction >= 4.0,1,0))pak from (select a.u_diu,a.u_vid,a.f_rating,a.prediction,a.rnk from (select u_diu,u_vid,f_rating,prediction,rank() over (partition by u_diu order by prediction desc) rnk from temp_prediction)a where rnk <= 30 )b"
    # pak = spark.sql(pakSQL)
    # pak.show()
    #per = int(pak.first()['all'])/int(pak.first()['pak'])
    #print per
    # evaluator = RegressionEvaluator(metricName="rmse", labelCol="f_rating",
    #                                 predictionCol="prediction")
    # rmse = evaluator.evaluate(predictions)
    # print("Root-mean-square error = " + str(rmse))
    spark.stop()
