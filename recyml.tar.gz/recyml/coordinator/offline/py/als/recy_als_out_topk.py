#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 8

"""
Recommend top k videos to user.

"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_als_out_topk:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    #读入用户视频评分全量表  and prediction >= 3
    # topkSql="select u_diu as diu , u_vid as vid, round(if(prediction>5,5,prediction),1) prediction, title, pic, short_title, hits_total, comment_total, createtime from (select a.u_diu , a.u_vid , a.prediction , b.title, b.pic, b.short_title, b.hits_total, b.comment_total, createtime, ROW_NUMBER() over (partition by u_diu,uid order by a.prediction desc) rnk from (select u_diu, u_vid, prediction from da.recy_als_prediction where dt='"+inDate+"')a join (select vid, title, pic, short_title, hits_total, comment_total, createtime, uid from dw.video where status=0)b on (a.u_vid = b.vid))m where m.rnk <= 3"
    # topkSql =  "select a.u_diu as diu, a.u_vid as vid, round(if(prediction>5,5,prediction),1)prediction, b.title, b.pic, b.short_title, b.hits_total, b.comment_total, createtime from (select u_diu, u_vid, prediction from da.recy_als_prediction where dt='"+inDate+"')a join (select vid, title, pic, short_title, hits_total, comment_total, createtime, uid from dw.video)b on (a.u_vid = b.vid)"
    topkSql="select u_diu as diu, u_vid as vid, round(if(prediction>5,5,prediction),1) prediction, '' title, '' pic, '' short_title, 0 as hits_total, 0 as comment_total, '' createtime from da.recy_als_prediction where dt='"+inDate+"'"
    topk = spark.sql(topkSql)
    topk.printSchema()
    # topk.show()
    # print "count ",topk.count()
    topkPath = "hdfs://Ucluster/olap/da/recy_als_out_topk/"+inDate+"/"
    topk.repartition(400).write.mode('overwrite').save(topkPath, format="parquet")
    spark.stop()
