#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    ndaysago=handleDatePath(sys.argv,'%Y-%m-%d',7)
    print ndaysago
    onedaysago=handleDatePath(sys.argv,'%Y-%m-%d',1)
    print onedaysago
    
    #########################
    ## recy_als_data_finalcandy
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_finalcandy begin"

    spark = SparkSession.builder.master('yarn-client').appName('recy_als_data_finalcandy:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=500"
    spark.sql(setSparSQLPartNum)

    sql = "SELECT c.* ,d.f_vid from  (select  a.u_diu,a.u_vid,b.f_diu from (select u_diu,u_vid from da.recy_als_data_candytag where dt='"+datebuf+"' group by u_diu,u_vid)a join (SELECT u_diu,f_diu from da.recy_als_data_uvm where dt='"+datebuf+"' group by u_diu,f_diu)b on (a.u_diu = b.u_diu))c join (SELECT u_vid,f_vid from da.recy_als_data_uvm where dt='"+datebuf+"' group by u_vid,f_vid )d on (c.u_vid = d.u_vid)"
    print sql
    candymDF=spark.sql(sql)

    candymDF.createOrReplaceTempView("cantagvideo")

    spark.sql("SET spark.sql.shuffle.partitions=500")
    onefSQL = "SELECT u_diu,u_vid,f_diu,f_vid from (select u_diu,u_vid,f_diu,f_vid from cantagvideo  union all  select u_diu,u_vid,f_diu,f_vid from da.recy_als_data_candya  where dt='" + datebuf + "' )c group by u_diu,u_vid,f_diu,f_vid"
    onefDF = spark.sql(onefSQL)
    onefDF.printSchema()
    onefDF.createOrReplaceTempView("onefcandy")
    # 过滤看过的视频
    spark.sql("SET spark.sql.shuffle.partitions=500")
    twofSQL = "SELECT a.u_diu,a.u_vid,a.f_diu,a.f_vid from (select * from  onefcandy )a left outer join (select * from da.recy_als_data_uvm where dt='" + datebuf + "')b  on (a.u_diu=b.u_diu and a.u_vid=b.u_vid) where b.u_diu is null"
    twofDF = spark.sql(twofSQL)
    twofDF.createOrReplaceTempView("twofcandy")

    ffSQL = "select a.* from (select * from twofcandy)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='" + ndaysago + "'and dt<'" + onedaysago + "'group by diu, vid)b on (a.u_diu=b.diu and a.u_vid=b.vid) where b.diu is null"
    ffDF = spark.sql(ffSQL)

    outputPath = "hdfs://Ucluster/olap/da/recy_als_data_finalcandy/"+datebuf+"/"
    print outputPath

    ffDF.repartition(500).write.mode('overwrite').save(outputPath, format="parquet")
    spark.stop()

    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_finalcandy end"