#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    onedayago=handleDatePath(sys.argv,'%Y-%m-%d',1)
    print onedayago

    #########################
    ## recy_als_data_uvr
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_uvr begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_als_data_uvr:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    sql = "select if(m.u_diu is null,n.u_diu,m.u_diu)u_diu, if(m.u_vid is null,n.u_vid,m.u_vid)u_vid, case when m.f_vp is null and n.f_vp is not null then n.f_vp when m.f_vp is not null and n.f_vp is null then m.f_vp when m.f_vp is not null and n.f_vp is not null then if(m.f_vp>n.f_vp,m.f_vp,n.f_vp) else 0 end as f_vp, case when m.f_vd is null and n.f_vd is not null then n.f_vd when m.f_vd is not null and n.f_vd is null then m.f_vd when m.f_vd is not null and n.f_vd is not null then m.f_vd+n.f_vd else 0.0 end as f_vd, if(m.f_timestamp is null, n.f_timestamp,m.f_timestamp) f_timestamp, case when m.f_down is null and n.f_down is not null then n.f_down when m.f_down is not null and n.f_down is null then m.f_down when m.f_down is not null and n.f_down is not null then m.f_down+n.f_down else 0 end as f_down, case when m.f_share is null and n.f_share is not null then n.f_share when m.f_share is not null and n.f_share is null then m.f_share when m.f_share is not null and n.f_share is not null then m.f_share+n.f_share else 0 end as f_share, case when m.f_fav is null and n.f_fav is not null then n.f_fav when m.f_fav is not null and n.f_fav is null then m.f_fav when m.f_fav is not null and n.f_fav is not null then m.f_fav+n.f_fav else 0 end as f_fav, case when m.f_flower is null and n.f_flower is not null then n.f_flower when m.f_flower is not null and n.f_flower is null then m.f_flower when m.f_flower is not null and n.f_flower is not null then m.f_flower+n.f_flower else 0 end as f_flower, case when m.f_hits is null and n.f_hits is not null then n.f_hits when m.f_hits is not null and n.f_hits is null then m.f_hits when m.f_hits is not null and n.f_hits is not null then m.f_hits+n.f_hits else 0 end as f_hits, case when m.f_comment is null and n.f_comment is not null then n.f_comment when m.f_comment is not null and n.f_comment is null then m.f_comment when m.f_comment is not null and n.f_comment is not null then m.f_comment+n.f_comment else 0 end as f_comment from (select u_diu ,u_vid,vp as f_vp,round(vst/100*duration,3)f_vd,f_timestamp,f_down,f_share,f_fav,f_flower,f_hits,f_comment from (select u_diu,u_vid,max(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'and u_action in ('exit','complete'),if(u_percent>100,100,cast(u_percent as int)),0)) vp,sum(if(concat(u_mod,'-',u_ac)='emptylog-video_play_speed'and u_action in ('exit','complete'),if(u_percent>100,100,cast(u_percent as int)),0)) vst,sum(if(concat(u_mod,'-',u_ac)='emptylog-cdn_download_speed',1,0)) f_down,sum(if(concat(u_mod,'-',u_ac)='emptylog-share_onclick',1,0))f_share,sum(if(concat(u_mod,'-',u_ac) in ('user-fav','flower-good'),1,0))f_fav,sum(if(concat(u_mod,'-',u_ac)='flower-send',1,0)) f_flower,sum(if(concat(u_mod,'-',u_ac)='top-hits',1,0)) f_hits,sum(if(concat(u_mod,'-',u_ac) in ('message-video_comment_add','message-video_comment_reply'),1,0)) f_comment,max(unix_timestamp(substr(u_timestamp,0,19)))f_timestamp from dw.uabigger where dt='"+datebuf+"'and u_vid <> ''and u_diu not in ('0123456789abcde','012345678912345','123456789012345','0','000000','00000000','00000000000000','000000000000000','0000000000000000','000000011234564','111111111111111','','UNKNOWN','Unknown','+++++000000000','+GSN:808DCF89','000000000000026') and concat(u_mod,'-',u_ac) in ('emptylog-video_play_speed','top-hits', 'flower-send', 'emptylog-share_onclick', 'user-fav', 'emptylog-cdn_download_speed', 'message-video_comment_add','message-video_comment_reply') group by u_diu,u_vid)a join (select vid, duration from dw.video) b on (a.u_vid=b.vid))m full outer join (select * from da.recy_als_data_uvr where dt='"+onedayago+"')n on (m.u_diu = n.u_diu and m.u_vid = n.u_vid)"
    print sql
    df=spark.sql(sql)
    outputPath = "hdfs://Ucluster/olap/da/recy_als_data_uvr/" + datebuf + "/"
    print outputPath
    df.repartition(300).write.mode('overwrite').save(outputPath, format="parquet")
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_uvr end"