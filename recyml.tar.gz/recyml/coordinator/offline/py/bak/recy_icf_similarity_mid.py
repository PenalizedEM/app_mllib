#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf


    #########################
    ## recy_icf_similarity_mid
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_mid begin"

    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_mid:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=2000"
    spark.sql(setSparSQLPartNum)

    dropTabSql = "drop table if exists da.recy_icf_similarity_mid "
    print dropTabSql
    spark.sql(dropTabSql)

    sql = " create table da.recy_icf_similarity_mid as select a.vid vid_1 , b.vid vid_2 , a.num num_1, b.num num_2, count(1) num_12 from da.recy_icf_similarity_pre a join da.recy_icf_similarity_pre b on (a.diu=b.diu) where a.vid<b.vid group by a.vid, b.vid, a.num, b.num"
    print sql
    spark.sql(sql)

    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_mid end"