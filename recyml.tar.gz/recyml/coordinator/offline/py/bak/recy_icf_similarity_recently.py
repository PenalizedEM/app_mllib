#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession, SQLContext
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    onedayago=handleDatePath(sys.argv,'%Y-%m-%d',1)
    print onedayago

    #########################
    ## recy_icf_similarity_topn
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_recently begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_recently:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    print setSparSQLPartNum
    spark.sql(setSparSQLPartNum)

    sql4 = "insert overwrite table da.recy_icf_similarity_recently partition(dt='" + datebuf + "') select vid_1, vid_2, num_1, num_2, num_12, similarity, '24'from da.recy_icf_similarity_topn_mid where create_date>='" + onedayago + "'and concat(type_1,'-',type_2) in ('nolife-nolife') and rank<=500"
    print sql4
    spark.sql(sql4)

    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_recently end"