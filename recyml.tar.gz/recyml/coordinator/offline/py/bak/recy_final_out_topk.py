#!/usr/bin/python
# -*- coding: UTF-8 -*-
# created  by vent @ Dec 8
# edited by vent @ Apr 12
"""
Recommend top k videos to user.

"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer
import random
from pyspark.sql.functions import lit

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    filterDate = handleDatePath(sys.argv,'%Y-%m-%d',3)
    print "inDate  ",inDate

    #########################
    ## recy_final_out_topk
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_final_out_topk begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_final_out_topk:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=1200")
    #融合两种算法模型输出结果，限制每个作者最多三条，取排名前500
    # topkSql="select diu , vid, prediction, title, pic, short_title, hits_total, comment_total, createtime from ( select * , ROW_NUMBER() over (partition by diu order by prediction desc) rank from (select a.*, ROW_NUMBER() over (partition by diu,uid order by prediction desc) rn from (select * from da.recy_als_out_topk where dt='"+inDate+"' union all select * from da.recy_icf_out_topk where dt='"+inDate+"') a join dw.video b on (a.vid = b.vid) ) b where rn<=4 ) c where rank<=500"
    topkSql="select diu , vid, prediction, '' title, '' pic, '' short_title, 0 as hits_total, 0 as comment_total, '' createtime from (select * , ROW_NUMBER() over (partition by diu order by prediction desc) rank from (select a.*, ROW_NUMBER() over (partition by diu,uid order by prediction desc) rn from (select diu, vid, max(prediction) prediction from (select diu, vid, prediction from da.recy_als_out_topk where dt='"+inDate+"'union all select diu, vid, prediction from da.recy_icf_out_topk where dt='"+inDate+"'union all select diu, vid, prediction from da.recy_siucf_recommend ) aa group by diu, vid ) a join (select vid,uid from dw.video where !(sync <> 0 or uid=0 or type=9 or ( parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188') ) ) ) b on(a.vid=b.vid) ) b where rn<=6) c where rank<=500"
    topk = spark.sql(topkSql)
    topk.createOrReplaceTempView("onefinal")

    spark.sql("SET spark.sql.shuffle.partitions=1200")
    # ffSQL = "select a.* from (select * from onefinal)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='"+filterDate+"'and dt<'"+inDate+"'group by diu, vid)b on (a.diu=b.diu and a.vid=b.vid) where b.diu is null"
    ffSQL="select e.* from (select c.* from (select a.* from (select * from onefinal)a left outer join (select diu , vid from da.recy_final_out_topk where dt>='"+filterDate+"'and dt<'"+inDate+"'group by diu, vid)b on (a.diu=b.diu and a.vid=b.vid) where b.diu is null) c left outer join da.recy_cf_rating_online d on (c.diu=d.diu and c.vid=d.vid) where d.diu is null ) e left outer join (SELECT vid FROM dw.video_recommend WHERE type=1 ) f on(e.vid=f.vid) where f.vid is null"
    ffDF = spark.sql(ffSQL)
    topkPath = "hdfs://Ucluster/olap/da/recy_final_out_topk/"+inDate+"/"
    ffDF.repartition(600).write.mode('overwrite').save(topkPath, format="parquet")
    spark.stop()

    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_final_out_topk end"
