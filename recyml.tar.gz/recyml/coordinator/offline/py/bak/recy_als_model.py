#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 5

"""
 Implementation of ALS to predict user's rating on video
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS
from pyspark.ml.feature import VectorAssembler,StringIndexer
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath
# p@k 评估
def patK(predictions,spark):
    predictions.createOrReplaceTempView("temp_prediction")
    #patK = "select u_diu,u_vid,f_rating,prediction,rank() over (partition by u_diu,u_vid order by prediction desc) rnk from temp_prediction  "
    pakSQL= "select sum(if(f_rating>=3.5,1,0))all,sum(if(f_rating >=3.5 and prediction >= 3.5,1,0))pak from temp_prediction "
    pak = spark.sql(pakSQL)
    numP = pak
    return paK/allK
#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inUVMDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inUVinUVMDateADate  ",inUVMDate


    #########################
    ## recy_als_model
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_model begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_als_model:'+inUVMDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    #读入用户视频评分全量表
    rateSql =  "select * from da.recy_als_data_uvm where dt='"+inUVMDate+"' and f_diu is not null and f_vid is not null and f_rating is not null and f_rating <>0.0 "
    rating = spark.sql(rateSql)

    als = ALS(rank=10, maxIter=20, regParam=0.1, userCol="f_diu", itemCol="f_vid", ratingCol="f_rating")
    model = als.fit(rating)
    modelPath =  "hdfs://Ucluster/olap/da/recy_als_model/"+inUVMDate+"/"
    model.write().overwrite().save(modelPath)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_model end"