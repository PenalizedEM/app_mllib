#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 8

"""
Recommend top k videos to user.

"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.recommendation import ALS,ALSModel
from pyspark.ml.feature import VectorAssembler,StringIndexer

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inDate  ",inDate

    #########################
    ## recy_icf_out_topk
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_out_topk begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_out_topk:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=1000")
    # topkSql="select diu, vid, prediction , title, pic , short_title, hits_total, comment_total, createtime from (select /* +mapjoin(b) */ a.diu, a.vid, cast(round(if(a.rating>5,5,rating),1) as float) prediction , b.title, b.pic , b.short_title, b.hits_total, b.comment_total, b.createtime , ROW_NUMBER() OVER (PARTITION by a.diu order by a.rating desc) rank from (select diu, vid , rating from da.recy_icf_recommend where dt='"+inDate+"'and rank<=500) a join (select * from dw.video where sync=0) b on(a.vid=b.vid) left outer join (select * from da.recy_als_out_topk where dt='"+inDate+"' ) c on (a.diu=c.diu and a.vid=c.vid) where c.vid is null ) a where rank<=500"
    topkSql="select diu, vid, cast(round(if(rating>5,5,rating),1) as float) prediction , '' title, '' pic , '' short_title, 0 as hits_total, 0 as comment_total, '' createtime from da.recy_icf_recommend where dt='"+inDate+"'and rank<=2000"
    print topkSql
    topk = spark.sql(topkSql)
    topk.printSchema()
    # topk.show()
    # print "count ",topk.count()
    topkPath = "hdfs://Ucluster/olap/da/recy_icf_out_topk/"+inDate+"/"
    topk.repartition(500).write.mode('overwrite').save(topkPath, format="parquet")

    addPartSql = "ALTER TABLE da.recy_icf_out_topk ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_icf_out_topk/"+inDate+"/'"
    print addPartSql
    spark.sql(addPartSql)

    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_out_topk end"
