#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
import datetime
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf,HiveContext
from pyspark.sql import SQLContext
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi

#处理传入的时间参数, 默认未传参则取1个小时前的日期和小时, 若传入了日期和小时, 则取传入的
def handleDateArgs(dateList):
    datebuf =  (datetime.datetime.now() - datetime.timedelta(days=1)).strftime("%Y-%m-%d")
    onedayago = (datetime.datetime.now() - datetime.timedelta(days=2)).strftime("%H")
    if len(dateList) ==3:
        datebuf = dateList[1]
        onedayago = dateList[2]
    return datebuf,onedayago

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')

    datebuf = handleDateArgs(sys.argv)[0]
    print "datebuf  ", datebuf
    onedayago = handleDateArgs(sys.argv)[1]
    print "onedayago ", onedayago


    #########################
    ## recy_icf_similarity_nearline
    #########################
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_nearline begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_nearline:' + datebuf ).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=300"
    spark.sql(setSparSQLPartNum)
    hql = "from (select a.*, create_date, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from (select vid_1, vid_2, num_1, num_2, num_12, similarity from da.recy_icf_similarity where dt='" + datebuf + "') a join (select vid, to_date(createtime) create_date from dw.video where parent_category not in ('65', '55', '54', '53', '47') and sync=0 ) b on (a.vid_1=b.vid) ) a insert overwrite table da.recy_icf_similarity_nearline partition(dt='" + datebuf + "',type='recently') select vid_1, vid_2,num_1, num_2, num_12, similarity, '24' where create_date>='" + onedayago + "' and rank<=1000 insert overwrite table da.recy_icf_similarity_nearline partition(dt='" + datebuf + "',type='oldly') select vid_1, vid_2,num_1, num_2, num_12, similarity,'24' where create_date<'" + onedayago + "' and rank<=80"
    print hql
    spark.sql(hql)
    spark.stop()
    print "================>" + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_nearline end"