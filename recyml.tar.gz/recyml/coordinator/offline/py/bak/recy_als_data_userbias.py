#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    ndaysago=handleDatePath(sys.argv,'%Y-%m-%d',30)
    print ndaysago

    #########################
    ## recy_als_data_userbias
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_userbias begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_als_data_userbias:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    sql = "INSERT overwrite table da.recy_als_data_userbias PARTITION (dt='"+datebuf+"') SELECT diu,max(m_vst)mapr,min(m_vst)mipr,percentile(m_vst,0.99)nnpr,percentile(m_vst,0.90)ntpr,percentile(m_vst,0.10)tpr,percentile(m_vst,0.01)opr,count(1)pv  from da.mid_video_playtime where  dt<='"+datebuf+"' and dt>='"+ndaysago+"' and m_vst>0 group by  diu"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_userbias end"