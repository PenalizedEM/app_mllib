#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    ndaysago=handleDatePath(sys.argv,'%Y-%m-%d',7)
    print ndaysago

    #########################
    ## recy_als_data_uvm
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_uvm begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_als_data_uvm:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    sql = "SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_sb, f_sc, f_sd, f_se, f_sf, (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_vd, f_sb, f_sc, f_sd, f_se, f_sf, if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up FROM (SELECT u_diu, u_vid, f_timestamp, hash(u_diu) f_diu, hash(u_vid) f_vid, f_vd, cast(if(f_down>0,5.0,0) AS double) f_sb, cast(if(f_share>0,2.0,0.0) AS double) f_sc, cast(if(f_fav>0,3.0,0.0) AS double)f_sd, cast(if(f_flower>0,2.0,0.0) AS double)f_se, cast(if(f_comment>0,1.0,0.0) AS double)f_sf FROM da.recy_als_data_uvr WHERE dt='"+datebuf+"') a JOIN (SELECT diu, nnpr, mipr, pv FROM da.recy_als_data_userbias WHERE dt='"+datebuf+"')b ON (a.u_diu = b.diu)) c JOIN (SELECT vid, nnpr, mipr, pv FROM da.recy_als_data_itembias WHERE dt='"+datebuf+"')d ON (c.u_vid = d.vid))e"
    print sql
    df=spark.sql(sql)
    df.createOrReplaceTempView("tempTable")
    ##May 24 2017 加入对曝光的负反馈
    sql2 = "SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, if(f_rating-0.8*if(ex is null,0,ex)<0,0,f_rating-0.8*if(ex is null,0,ex))f_rating from (select * from tempTable)a left outer join (select diu, vid, sum(m_pv)ex from da.mid_video_ex where dt<='"+datebuf+"'and dt>='"+ndaysago+"'group by diu, vid)b on (a.u_diu=b.diu and a.u_vid = b.vid)"
    df2 = spark.sql(sql2)
    outputPath = "hdfs://Ucluster/olap/da/recy_als_data_uvm/"+datebuf+"/"
    print outputPath
    df2.write.mode('overwrite').save(outputPath, format="parquet")
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_als_data_uvm end"