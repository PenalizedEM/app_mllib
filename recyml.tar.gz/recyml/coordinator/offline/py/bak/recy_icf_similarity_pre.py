#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv) 
    reload(sys)
    sys.setdefaultencoding('utf-8')
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    ndaysago=handleDatePath(sys.argv,'%Y-%m-%d',12)
    print ndaysago

    #########################
    ## recy_icf_similarity_pre
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_pre begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_pre:'+datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=400"
    spark.sql(setSparSQLPartNum)
    sql = " select a.diu, a.vid, a.num from (select * from da.recy_cf_rating_online where actdate>='"+ndaysago+"') a join (select diu, count(1) vcnt from da.recy_cf_rating_online where actdate>='"+ndaysago+"'group by diu having vcnt<1000)b on (a.diu=b.diu)"
    print sql
    df=spark.sql(sql)
    outputPath = "hdfs://Ucluster/olap/da/recy_icf_similarity_pre/"
    print outputPath
    df.repartition(600).write.mode('overwrite').save(outputPath, format="parquet")
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_pre end"