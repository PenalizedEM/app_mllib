#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',90)
    buDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    print "business date==========================" + buDate
    print "run date===============================" + inDate

    #########################
    ## recy_siucf_recommend
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_recommend begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_recommend:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_recommend"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_recommend as select diu, vid, cast(rating as float) prediction, rank from (select d.diu_1 diu, e.vid, interest*rating rating, ROW_NUMBER() OVER (PARTITION by d.diu_1 order by interest*rating desc) rank from (select b.diu diu_1, c.diu diu_2, interest from (select a.* from (select uid_1, uid_2, interest, ROW_NUMBER() OVER (PARTITION by uid_1 order by interest desc) rank from da.recy_siucf_social_interest) a where rank<=30) a join (select id, diu from dw.user) b on (a.uid_2=b.id) join (select id, diu from dw.user) c on (a.uid_1=c.id)) d join (select diu, a.vid, rating from (select diu, vid, rating from da.recy_cf_rating where actdate>='" + inDate + "') a join (select vid from dw.video where parent_category not in ('65', '55', '54', '53', '47') and sync=0) b on(a.vid=b.vid)) e on(d.diu_2=e.diu)) f where rank<=2000"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_recommend end"