#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',90)
    buDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    print "business date==========================" + buDate
    print "run date===============================" + inDate

    #########################
    ## recy_siucf_follow_pre1
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_follow_pre1 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_follow_pre1:'+buDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_follow_pre1"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_follow_pre1 as select a.uid uid_1, a.reuid uid_2, follow_cnt from (select * from dw.follow_user where to_date(time)>='"+inDate+"') a join (select uid, count(1) follow_cnt from dw.follow_user where to_date(time)>='"+inDate+"'group by uid)b on (a.uid=b.uid) join (select reuid, count(1) fans from dw.follow_user where to_date(time)>='"+inDate+"'group by reuid having fans<10000)c on (a.reuid=c.reuid)"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_follow_pre1 end"

    #########################
    ## recy_siucf_follow_pre2
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_follow_pre2 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_follow_pre2:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_follow_pre2"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_follow_pre2 as select a.uid_1 , b.uid_1 uid_2, a.follow_cnt num_1, b.follow_cnt num_2, count(1) num_12 from da.recy_siucf_follow_pre1 a join da.recy_siucf_follow_pre1 b on (a.uid_2=b.uid_2) where a.uid_1<b.uid_1 group by a.uid_1, b.uid_1, a.follow_cnt, b.follow_cnt"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_follow_pre2 end"

    #########################
    ## recy_siucf_follow
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_follow begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_follow:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_follow"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_follow as select uid_1, uid_2, num_1, num_2, num_12, num_12/sqrt(num_1*num_2) intimacy from da.recy_siucf_follow_pre2 union all select uid_2 as uid_1, uid_1 as uid_2,  num_2 as num_1, num_1 as num_2, num_12,num_12/sqrt(num_1*num_2) intimacy from da.recy_siucf_follow_pre2"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_follow end"


    #########################
    ## recy_user_follow
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_user_follow begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_user_follow:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    sql = "insert overwrite table da.recy_user_follow partition(dt='"+buDate+"') select uid_1, uid_2, num_1, num_2, num_12, intimacy, rank from (select uid_1, uid_2, num_1, num_2, num_12, intimacy, ROW_NUMBER() OVER (PARTITION by uid_1 order by intimacy desc) rank from da.recy_siucf_follow a join (select uid from dw.video where uid>0 and sync=0 group by uid) b on(a.uid_2=b.uid) left outer join dw.follow_user c on(a.uid_1=c.uid and a.uid_2=c.reuid) where c.uid is null ) d where rank<=30"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_user_follow end"
