#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',90)
    buDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    print "business date==========================" + buDate
    print "run date===============================" + inDate

    #########################
    ## recy_siucf_social_interest_pre1
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest_pre1 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_social_interest_pre1:'+buDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_social_interest_pre1"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_social_interest_pre1 as select c.uid_1, c.uid_2, intimacy, interaction, (if(intimacy is null, 0, intimacy)+if(interaction is null ,0, interaction))/2 degree from (select if(a.uid_1 is null , b.uid_1, a.uid_1) uid_1, if(a.uid_2 is null , b.uid_2, a.uid_2) uid_2, if(intimacy is null, 0, intimacy) intimacy, if(interaction is null ,0, interaction) interaction from da.recy_siucf_follow a full outer join da.recy_siucf_interact b on(a.uid_1=b.uid_1 and a.uid_2=b.uid_2) ) c join (select uid uid_1, reuid uid_2 from dw.follow_user where to_date(time)>='"+inDate+"') d on (c.uid_1=d.uid_1 and c.uid_2=d.uid_2)"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest_pre1 end"

    #########################
    ## recy_siucf_social_interest_pre2
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest_pre2 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_social_interest_pre2:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_social_interest_pre2"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_social_interest_pre2 as select a.uid_1, a.uid_2, a.degree, b.sqrt_degree from da.recy_siucf_social_interest_pre1 a join (select uid_1, sqrt(sum(degree*degree)) sqrt_degree from da.recy_siucf_social_interest_pre1 group by uid_1 ) b on(a.uid_1=b.uid_1) join (select uid_2, count(1) uv from da.recy_siucf_social_interest_pre1 group by uid_2 having uv<10000 )c on (a.uid_2=c.uid_2)"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest_pre2 end"

    #########################
    ## recy_siucf_social_interest_pre3
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest_pre3 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_social_interest:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_social_interest_pre3"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_social_interest_pre3 as select a.uid_1, b.uid_1 uid_2, sum(a.degree*b.degree/(a.sqrt_degree*b.sqrt_degree)) interest from da.recy_siucf_social_interest_pre2 a join da.recy_siucf_social_interest_pre2 b on(a.uid_2=b.uid_2) where a.uid_1<b.uid_1 group by a.uid_1, b.uid_1"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest_pre3 end"

    #########################
    ## recy_siucf_social_interest
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_social_interest:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_social_interest"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_social_interest as select uid_1, uid_2, interest from da.recy_siucf_social_interest_pre3 union all select uid_2 uid_1, uid_1 uid_2, interest from da.recy_siucf_social_interest_pre3"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_social_interest end"