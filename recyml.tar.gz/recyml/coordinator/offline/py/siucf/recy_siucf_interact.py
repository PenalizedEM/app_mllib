#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',60)
    buDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    print "business date==========================" + buDate
    print "run date===============================" + inDate

    #########################
    ## recy_siucf_interact_pre1
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_interact_pre1 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_interact_pre1:'+buDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_interact_pre1"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_interact_pre1 as select a.uid_1, uid_2 , a.num_12, num_1, num_2 from (select d_uid uid_1, d_reuid uid_2, sum(if(d_type='fav',m_cnt*2.5, m_cnt)) num_12 from adm.f_account_interact where dt>='"+inDate+"'group by d_uid, d_reuid) a join (select d_uid uid_1, sum(if(d_type='fav',m_cnt*2.5, m_cnt)) num_1 from adm.f_account_interact where dt>='"+inDate+"'group by d_uid) b on(a.uid_1=b.uid_1) join (select d_uid uid_1, sum(if(d_type='fav',m_cnt*2.5, m_cnt)) num_2 from adm.f_account_interact where dt>='"+inDate+"'group by d_uid) c on(a.uid_2=c.uid_1)"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_interact_pre1 end"

    #########################
    ## recy_siucf_interact_pre2
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_interact_pre2 begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_interact_pre2:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_interact_pre2"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_interact_pre2 as select a.uid_1, a.uid_2, a.num_12, if(b.num_12 is null,0,b.num_12) num_21, a.num_1 , a.num_2 from da.recy_siucf_interact_pre1 a left outer join da.recy_siucf_interact_pre1 b on(a.uid_2=b.uid_1 and a.uid_1=b.uid_2)"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_interact_pre2 end"

    #########################
    ## recy_siucf_interact
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_interact begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_siucf_interact:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    dropsql = "drop table if exists da.recy_siucf_interact"
    spark.sql(dropsql)
    sql = "create table da.recy_siucf_interact as select uid_1, uid_2, num_12, num_21, num_1, num_2, (num_12 + num_21)/(sqrt(num_1*num_2)*2)  interaction from da.recy_siucf_interact_pre2"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_siucf_interact end"
