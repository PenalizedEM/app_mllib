#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
pyspark read and excute sql scripts

"""
from datetime import datetime,date, timedelta
from pyspark.sql.types import *
from pyspark.sql import SparkSession
import sys, getopt

def usage():
  print "usage: python pyspark_sql.py <task_name>(must arg) [date](option arg) \n Ex: sql_name -d datebuf1=2017-11-09 datebuf2=2017-10-09"

def argsDeal():
    opts, args = getopt.getopt(sys.argv[2:], "hd:")
    date_args={}
    for op, value in opts:
        if op == "-d":
            date_args[value.split("=")[0]]=value.split("=")[1]
        elif op == "-h":
            usage()
            sys.exit()

    return date_args

#业务日期获取
def busDate(days,dateFormat):
    busDate =  (date.today() - timedelta(days)).strftime(dateFormat)
    return busDate

#主入口
if __name__ == "__main__":
    taskName = sys.argv[1]
    datebuf=busDate(1,'%Y-%m-%d')
    date_args = argsDeal()

    #########################
    ## taskName
    #########################
    start_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    start_seconds= int(datetime.now().strftime('%s'))
    print start_time + " [INFO] ----------- " + taskName + " " + datebuf + " job begin "

    spark = SparkSession.builder.master('yarn-client').appName(taskName + ':' + datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    sql_object = open('./sql/' + taskName + '.sql')
    sql_context = sql_object.read()
    try:
        for key in date_args:
            sql_context = sql_context.replace("${" + key + "}", date_args[key])
        sql_array = sql_context.split(';')
        for sql in sql_array:
            if sql and len(sql) > 2:
                print sql
                spark.sql(sql)
    finally:
        sql_object.close()

    spark.stop()

    end_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    end_seconds= int(datetime.now().strftime('%s'))
    duration=end_seconds - start_seconds
    duration_str = ""
    if ( duration < 60):
        duration_str = str(duration) + "s"
    else:
        duration_str = str(duration/60) + "min" +str(duration%60) + "s"

    print start_time + " [INFO] ----------- " + taskName + " " + datebuf + " job end, duration: " + duration_str + " !"
