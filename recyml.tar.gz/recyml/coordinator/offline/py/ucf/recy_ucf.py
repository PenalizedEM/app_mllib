#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import time
from datetime import datetime,date, timedelta
import re
import sys
from pyspark.sql.types import *
from pyspark.sql import SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import MinMaxScaler


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==2:
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
    elif len(dateList) ==3:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
    return datePath

#主入口
if __name__ == "__main__":
    print str(sys.argv)
    reload(sys)
    sys.setdefaultencoding('utf-8')
    taskName = sys.argv[2]
    print taskName
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print datebuf
    n_daysago_5=handleDatePath(sys.argv,'%Y-%m-%d',5)
    print n_daysago_5



    #########################
    ## taskName
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') +  taskName + " begin"

    spark = SparkSession.builder.master('yarn-client').appName(taskName + ':' + datebuf).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    if taskName in "recy_ucf_similarity_mid recy_ucf_similarity_topn recy_user_sim":
        setSparSQLPartNum = "SET spark.sql.shuffle.partitions=2000"
        spark.sql(setSparSQLPartNum)

    sql_object = open('./sql/' + taskName + '.sql')
    try:
        sql_context = sql_object.read().replace('${datebuf}',datebuf).replace('${n_daysago_5}',n_daysago_5)
        sql_array = sql_context.split(';')
        for sql in sql_array:
            if sql:
                print sql
                spark.sql(sql)
    finally:
        sql_object.close()

    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') +  taskName + " end"