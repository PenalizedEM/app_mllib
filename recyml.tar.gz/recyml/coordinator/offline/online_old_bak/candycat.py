 #!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 13

"""
Generate video cat

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession



#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    datebuf=handleDatePath(sys.argv,'%Y-%m-%d',0)
    n_daysago_1=handleDatePath(sys.argv,'%Y-%m-%d',1)
    n_daysago_30=handleDatePath(sys.argv,'%Y-%m-%d',30)

    spark = SparkSession.builder.master('yarn-client').appName('recy_als_data_candycat:'+datebuf).config("spark.sql.crossJoin.enabled","true").config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=1000")

    cathot = "insert overwrite table da.recy_als_data_cathot select pre_cate_id, pre_cate_name, vid, uv, cat_max, rank from (select a.vid, b.pre_cate_id, b.pre_cate_name, uv, cat_max, row_number() over (partition BY b.pre_cate_id ORDER BY uv DESC) AS rank from (select vid, count(1) uv from da.recy_cf_rating where 	sync=0 and uid>0 and type=10 and actdate>='" + n_daysago_30 + "'group by vid ) a join (select vid, pre_cate_id, pre_cate_name from dw.lvcat ) b on(a.vid=b.vid) join (select pre_cate_id, round(count(1)*0.01) cat_max from dw.lvcat group by pre_cate_id ) c on(b.pre_cate_id=c.pre_cate_id) ) d where rank<=cat_max"
    print cathot
    spark.sql(cathot)

    spark.sql("SET spark.sql.shuffle.partitions=1000")

    candycat = "insert overwrite table da.recy_als_data_candycat PARTITION (dt='" +datebuf + "') select diu, b.vid from (select diu, cid from da.user_profile_interest_lvcat where dt='" +n_daysago_1 + "'and cid>0 and cid not in ('85')) a join (select cid, vid from da.recy_als_data_cathot  where cid not in ('85'))b on (a.cid = b.cid) group by diu, b.vid"
    print candycat
    spark.sql(candycat)

    spark.stop()
