#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 12

"""
Generate Candidate Videos
Two filter condition:
1. util 6 months ago tags author's videos.
2. util 1 months ago had been viewed autor's videos.(and hits_total>=50)

Next Step:
Song similiraty
Title top model(LDA)
"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    #inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    #print "inUAPath HDFS Path: ",inUAPath
    # UVA输出目录的日期格式
    outDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "outDate: ",outDate
    #tagDate = handleDatePath(sys.argv,'%Y-%m-%d',45)
    #Feb 14 2017，由30改为15
    #authorDate =  handleDatePath(sys.argv,'%Y-%m-%d',2)
    popDate =  handleDatePath(sys.argv,'%Y-%m-%d',3)
    createDate =  handleDatePath(sys.argv,'%Y-%m-%d',365)
    sixMoth = handleDatePath(sys.argv,'%Y-%m-%d',180)
    twoMonth = handleDatePath(sys.argv,'%Y-%m-%d',60)
    #print "tagDate: ",tagDate
    print "createDate: ",createDate

    outPath = "hdfs://Ucluster/olap/da/recy_als_data_candya/"+outDate+"/"
    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-data-candya:'+outDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    # #为用户推荐他过去N天最喜欢的K个类别的热门视频(过滤0,3，避免数据倾斜)
    # spark.sql("SET spark.sql.shuffle.partitions=400")
    # # catSql = "SELECT u_diu, vid AS u_vid FROM (SELECT u_diu, child_category FROM (SELECT u_diu,child_category,srating, ROW_NUMBER() OVER (PARTITION BY u_diu ORDER BY srating DESC)rank FROM (SELECT u_diu, child_category, sum(f_rating)srating FROM (SELECT u_diu, u_vid, f_rating FROM da.recy_als_data_uvm WHERE dt='"+outDate+"' and f_timestamp >= unix_timestamp('"+createDate+"','yyyy-MM-dd') )a JOIN (SELECT vid, child_category FROM dw.video where to_date(createtime)>='"+createDate+"')b ON (a.u_vid = b.vid) GROUP BY u_diu, child_category HAVING srating>=5)c group by u_diu,child_category,srating)d WHERE rank<=3 group by u_diu, child_category)e JOIN (SELECT vid, child_category FROM da.recy_als_out_popcat WHERE dt>='"+popDate+"' AND dt<'"+outDate+"' AND child_category not in ('0','3') group by vid,child_category)f ON (e.child_category =f.child_category) GROUP BY u_diu, vid"
    # #catSql = "SELECT u_diu, vid AS u_vid FROM (SELECT u_diu, child_category FROM (SELECT u_diu,child_category,srating, ROW_NUMBER() OVER (PARTITION BY u_diu ORDER BY srating DESC)rank FROM (SELECT u_diu, child_category, sum(f_rating)srating FROM (SELECT u_diu, u_vid, f_rating FROM da.recy_als_data_uvm WHERE dt='"+outDate+"')a JOIN (SELECT vid, child_category FROM dw.video)b ON (a.u_vid = b.vid) GROUP BY u_diu, child_category HAVING srating>=5)c group by u_diu,child_category,srating)d WHERE rank<=3 group by u_diu, child_category)e "
    # catSql= "SELECT vid,good_total,hits_total,user_hits,createtime FROM dw.video WHERE hits_total>4000 and user_hits>3200 and good_total>400 and comment_total>40 and to_date(createtime)>'"+twoMonth+"' and type=10 ORDER BY createtime DESC"
    #
    # candyDF = spark.sql(catSql)
    # candyDF.createOrReplaceTempView("canvideo")
    #print candyDF.count()
    # 过滤掉用户看过该作者的视频，最后得到用户没看过该作者的视频
    spark.sql("SET spark.sql.shuffle.partitions=600")
    userCatSQL = "SELECT e.u_diu , g.u_vid, e.f_diu, g.f_vid FROM (SELECT d.u_diu, d.f_diu, c.u_vid FROM (SELECT u_diu, u_vid FROM da.recy_als_data_candya_stage1)c JOIN (SELECT u_diu, f_diu FROM da.recy_als_data_uvm WHERE dt='"+outDate+"' GROUP BY u_diu, f_diu)d ON (c.u_diu=d.u_diu) GROUP BY d.u_diu, d.f_diu, c.u_vid)e JOIN (SELECT u_vid, f_vid FROM da.recy_als_data_uvm WHERE dt='"+outDate+"'  GROUP BY u_vid, f_vid)g ON (e.u_vid = g.u_vid) GROUP BY e.u_diu , g.u_vid, e.f_diu, g.f_vid"
    usercatDF = spark.sql(userCatSQL)
    #usercatDF.createOrReplaceTempView("useCatCan")
    usercatDF.write.mode('overwrite').save(outPath, format="parquet")
    ##Mar 13 尝试去除作者因素,Mar 17恢复作者因素,Mar21依然去除作者因素
    #mergeSql = "SELECT u_diu,u_vid,f_diu,f_vid from useCatCan union all  SELECT u_diu,u_vid,f_diu,f_vid from da.recy_als_data_candysea where dt='"+outDate+"' "
    ##Nov 9 注释掉搜索行为
    # mergeSql = "SELECT u_diu,u_vid,f_diu,f_vid from useCatCan"
    # #mergeSql = "SELECT u_diu,u_vid,f_diu,f_vid from da.recy_als_data_candysea where dt='"+outDate+"' "
    # mergeDF = spark.sql(mergeSql)
    # #mergeDF.show()
    # mergeDF.repartition(600).write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
    # userDF.printSchema()
    # userDF.show()
    # print userDF.count()
    # #print "dd---------",candyDF.count()
    # candyDF.printSchema()
    # candyDF.show()
    # print candyDF.count()
    #u_diu not in ('0123456789abcde','012345678912345','123456789012345','0','000000','00000000','00000000000000','000000000000000','0000000000000000','000000011234564','111111111111111','','UNKNOWN','Unknown','+++++000000000','+GSN:808DCF89','000000000000026')
    # tag-video 矩阵  20亿
    # diuSQL = "select u_diu from dw.user_info where dt='2016-12-14' and to_date(substr(u_timestamp,0,19))>='2016-12-07' "
    # diuDF = spark.sql(diuSQL)
    # print "diu count :",diuDF.count()
    # vidSQL = "select vid from da.recy_dic_video_tag where to_date(createtime)>='2016-11-14' group by vid"
    # vidDF = spark.sql(vidSQL)
    # print "vid count ",vidDF.count()
    #candyDF = diuDF.rdd.cartesian(vidDF.rdd).toDF()
    #print candyDF.count()
    #candyDF.show()

