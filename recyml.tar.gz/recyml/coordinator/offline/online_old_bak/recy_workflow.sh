#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
spark_submit=$SPARK_HOME/bin/spark-submit
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
current_dir=`pwd`

echo "spark_submit=${spark_submit}"
echo "hadoop=${hadoop}"
echo "hive=${hive}"
echo "current_dir=${current_dir}"
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1
pyfile_name=$2
num_executors=$3
executor_cores=$4
executor_memory=$5

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"

onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
echo "onedayago:$onedayago"
##########################################################################################


function run_pyspark(){
    num_executors=$1
    executor_cores=$2
    executor_memory=$3
    pyfile_name=$4
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf}  job begin**************************"

    {
        sh ./action/pyspark.sh ${datebuf} ${pyfile_name} ${num_executors} ${executor_cores} ${executor_memory}
    } > log/run_pyspark_${pyfile_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf}  job end  **************************"
}

function run_sql(){
    sqlfile_name=$1
    x=$2
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sqlfile_name}  ${datebuf} job begin**************************"
    {
        sh ./action/sql.sh ${datebuf} ${sqlfile_name} ${x}
    } > ./log/run_sql_${sqlfile_name}.log 2>&1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${sqlfile_name}  ${datebuf} job end  **************************"
}

function run_shell(){
    num_executors=$1
    executor_cores=$2
    executor_memory=$3
    shfile_name=$4

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${shfile_name} ${datebuf}  job begin**************************"

    {
        sh ./action/shell.sh ${datebuf}  ${shfile_name} ${num_executors} ${executor_cores} ${executor_memory}
    } > log/run_shell_${shfile_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${shfile_name} ${datebuf}  job end  **************************"
}

function add_partition(){
    pyfile_name=$1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf}  add_partition begin**************************"

    {
        $hive -e "ALTER TABLE da.${pyfile_name} ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/$pyfile_name/$datebuf/'"
    } > log/add_partition_${pyfile_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${pyfile_name} ${datebuf}  add_partition end  **************************"
}

function touch_success(){
    file_name=$1
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${file_name} ${datebuf}  touch_success begin**************************"

    {
        $hive -e "dfs -touchz /olap/da/$file_name/dt=${datebuf}/_SUCCESS"
    } > log/touch_success_${file_name}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${file_name} ${datebuf}  touch_success end  **************************"
}


function redis_mr(){
    jar=$1
    main_class=$2
    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${jar} ${main_class} ${datebuf}  redis_mr begin**************************"

    {
        sh ./action/redis_mr.sh ${datebuf}  ${jar} ${main_class}
    } > log/redis_mr_${main_class}.log 2>&1

    echo "`date "+%Y-%m-%d %T"` [INFO]***************************${jar} ${main_class} ${datebuf}  redis_mr end  **************************"
}

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow begin ---------"
########################################

    {
#        {
#            run_pyspark 36 7 12g recy_als_data_uvr
#            add_partition recy_als_data_uvr
#        } &
#
#        run_pyspark 36 7 12g recy_als_data_itembias &
#        run_pyspark 36 7 12g recy_als_data_userbias &
#
#        wait
#
#        run_pyspark 36 7 12g recy_als_data_uvm
#        add_partition recy_als_data_uvm

#        run_pyspark 36 7 12g recy_cf_rating_online
#        run_pyspark 36 7 12g recy_icf_similarity_pre
#        run_pyspark 36 7 12g recy_icf_similarity_mid
#        run_pyspark 36 7 12g recy_icf_similarity
#        run_pyspark 36 7 12g recy_icf_similarity_topn_mid

#        {
#            run_sql recy_icf_similarity_topn
#            touch_success recy_icf_similarity_topn
#        } &
#
#        {
#            run_sql recy_icf_similar_nolife_topn
#            touch_success recy_icf_similar_nolife_topn
#        } &
#
#        {
#            run_sql recy_icf_similarity_recently ${onedayago}
#            touch_success recy_icf_similarity_recently
#        } &

#        wait

#        redis_mr recyio Sim2ListDriver  &
#        redis_mr recyio LiteSim2ListDriver  &
        {
            run_pyspark 30 5 10g recy_icf_recommend
            run_pyspark 18 5 6g recy_icf_out_topk
        }  &

        run_pyspark 18 5 6g recy_cold_pop
#        redis_mr recyio Pop2ListDriver

        wait

#        {
#            run_pyspark 16 4 5g recy_als_data_candysea
#            run_pyspark 16 4 5g recy_als_data_candytag
#            run_pyspark 18 5 6g recy_als_data_candya
#            run_pyspark 18 5 6g recy_als_data_finalcandy
#
#            run_pyspark 18 5 6g recy_als_model
#            touch_success recy_als_model
#
#            run_pyspark 18 5 6g recy_als_predict
#            run_pyspark 18 5 6g recy_als_out_topk
#        }  &
#
#        {
#            run_pyspark 18 5 6g recy_siucf_follow
#            run_pyspark 18 5 6g recy_siucf_interact
#            run_pyspark 18 5 6g recy_siucf_social_interest
#            run_pyspark 18 5 6g recy_siucf_recommend
#        }  &
#
#        wait
#
#        run_pyspark 18 5 6g recy_final_out_topk &
#
#        run_pyspark 18 5 6g recy_ltr_feature  &
#
#        wait
#
#        run_pyspark 18 5 6g recy_ltr_model
#        run_pyspark 18 5 6g recy_final_out_topk_redis

#        redis_mr recyio Day2ListDriver

    }

wait

########################################
echo "`date "+%Y-%m-%d %T"` [INFO] ----------- workflow end ---------"
########################################