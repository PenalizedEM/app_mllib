#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    actDate=handleDatePath(sys.argv,'%Y-%m-%d',7)
    onedayago=handleDatePath(sys.argv,'%Y-%m-%d',1)
    createDate= handleDatePath(sys.argv,'%Y-%m-%d',365)
    print inDate
    print actDate
    print onedayago
    print createDate

    # # ################# similar pre
    # simiPreDir = "hdfs://Ucluster/olap/da/recy_icf_similarity_pre_lite/"
    # spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_lite_pre_lite:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    # simPreSql = "select a.diu, a.vid, e.num, a.type from (select c.*,type from (select * from da.recy_cf_rating_online where actdate>='"+actDate+"') c join (select vid, createtime, type from dw.video where to_date(createtime)>='"+createDate+"'and status=0)d on (c.vid = d.vid)) a join (select diu, count(1) vcnt from da.recy_cf_rating_online where actdate>='"+actDate+"'group by diu having vcnt<1000) b on (a.diu=b.diu) join (select vid, count(1) num from da.recy_cf_rating_online where actdate>='"+actDate+"'group by vid) e on (a.vid=e.vid)"
    # print simPreSql
    # simPreDF = spark.sql(simPreSql)
    # simPreDF.printSchema()
    # simPreDF.repartition(1200).write.mode('overwrite').save(simiPreDir, format="parquet")
    # print simiPreDir
    #
    # spark.stop()

   ################# similary topn
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_lite_topn:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=1200"
    spark.sql(setSparSQLPartNum)

    # simTopkSql = "from (select c.*, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank, d.type type_2 from (select a.*, b.type type_1 from (select vid_1, vid_2, similarity from da.recy_icf_similarity_lite where dt='"+inDate+"') a left outer join (select vid, if(parent_category in ('65', '55', '54', '53', '47'),'life','nolife') type from dw.video where status=0) b on(a.vid_1=b.vid)) c left outer join (select vid, if(parent_category in ('65', '55', '54', '53', '47'),'life','nolife') type from dw.video where status=0) d on(c.vid_2=d.vid)) e insert overwrite table da.recy_icf_similarity_lite_topn partition(dt='"+inDate+"') select vid_1, vid_2, similarity, rank where rank<= 30 insert overwrite table da.recy_icf_similar_nolife_topn partition(dt='"+inDate+"') select vid_1, vid_2, similarity, rank where concat(type_1,'-',type_2) in ('nolife-nolife') and rank<= 80"
    # print simTopkSql
    # spark.sql(simTopkSql)

    ################################################################

    dropTabSql = "drop table if exists da.recy_icf_similarity_topn_mid "
    print dropTabSql
    spark.sql(dropTabSql)

    sql = "create table da.recy_icf_similarity_topn_mid as select c.*, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank, d.type type_2, d.isauthor_2 isauthor_2, d.islite_2 islite_2 from (select a.*, b.type type_1, b.islite_1 , b.create_date from (select vid_1, vid_2, num_1, num_2, num_12, similarity from da.recy_icf_similarity where dt='" + inDate + "') a left outer join (select vid, to_date(createtime) create_date, status status_1, if(TYPE in ('10') ,'lite','nolite') islite_1, if(uid='0','no-author','author') isauthor_1, if(parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188'), 'life', 'nolife') type from dw.video) b on(a.vid_1=b.vid)) c left outer join (select vid, status status_2, if(TYPE in ('10'),'lite','nolite') islite_2, if(uid='0','no-author','author') isauthor_2, if(parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188'), 'life', 'nolife') type from dw.video) d on(c.vid_2=d.vid)"
    print sql
    df=spark.sql(sql)

    df.createOrReplaceTempView("recy_icf_similarity_topn_mid")

    sql2 = "insert overwrite table da.recy_icf_similarity_topn partition(dt='" + inDate + "') select vid_1, vid_2, similarity, rank from da.recy_icf_similarity_topn_mid where isauthor_2='author' and  rank<= 30 "
    print sql2
    spark.sql(sql2)

    sql3 = "insert overwrite table da.recy_icf_similar_nolife_topn partition(dt='" + inDate + "') select c.* from (select a.* from (select vid_1, vid_2, similarity, rank from da.recy_icf_similarity_topn_mid where concat(type_1,'-',type_2) in ('nolife-nolife') and case when islite_1='lite' then islite_2='lite' else true end and rank<= 80) a left outer join (select vid from dw.video_recommend where type=1) b on(a.vid_2=b.vid) where b.vid is null) c join (select vid from dw.video where !(sync <> 0 or uid=0 or type=9)) d on(c.vid_2=d.vid)"
    print sql3
    spark.sql(sql3)

    sql4 = "insert overwrite table da.recy_icf_similarity_recently partition(dt='" + inDate + "') select c.* from (select a.* from (select vid_1, vid_2, num_1, num_2, num_12, similarity, '24'from da.recy_icf_similarity_topn_mid where create_date>='" + onedayago + "'and concat(type_1,'-',type_2) in ('nolife-nolife') and rank<=1000 ) a left outer join (select vid from dw.video_recommend where type=1) b on(a.vid_2=b.vid) where b.vid is null) c join (select vid from dw.video where !(sync <> 0 or uid=0 or type=9)) d on(c.vid_2=d.vid)"
    print sql4
    spark.sql(sql4)

    ################################################################


    spark.stop()
