#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################

date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
year=$year
month=$month
day=$day
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
exit 0
fi
fi

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf

n_daysago_7=`date -d" -7 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_7:$n_daysago_7"

########################################
echo "`date` [INFO] ----------- job begin ---------"
########################################



########################################
echo "`date` [INFO] ----------- 1、 recy_als_data_uvr begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/uvrating.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_data_uvr ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_data_uvr/$datebuf/'"
} >> recylog/als_data_uvr_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 1、 recy_als_data_uvr end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 2、 recy_als_data_bias begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/bias.py $datebuf
} >> recylog/als_data_bias_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 2、 recy_als_data_bias end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 3、 recy_als_data_uvm begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/uvmerge.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_data_uvm ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_data_uvm/$datebuf/'"
} >> recylog/als_data_uvm_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 3、 recy_als_data_uvm end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 4、 temp_icf_workflow begin ---------"
########################################
{
    cd /home/hadoop/user/vent/crontab
    sh temp_workflow.sh
    cd /home/hadoop/user/vent/
} >> /home/hadoop/user/vent/recylog/temp_icf_workflow_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 4、 temp_icf_workflow end ---------"
################################################################################

#########################################
#echo "`date` [INFO] ----------- 4、 recy_cf_rating begin ---------"
#########################################
#{
# /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_cf_rating.py $datebuf
# } >> recylog/recy_cf_rating_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 4、 recy_cf_rating end ---------"
#################################################################################



#########################################
#echo "`date` [INFO] ----------- 5、 recy_icf_similarity begin ---------"
#########################################
#{
# /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_icf_similarity.py $datebuf
# } >> recylog/recy_icf_similarity_${datebuf}.log 2>&1;
# /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_icf_similarity_topn/dt=${datebuf}/_SUCCESS"
#  /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_icf_similar_nolife_topn/dt=${datebuf}/_SUCCESS"
# /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_icf_similarity_recently/dt=${datebuf}/_SUCCESS"
#################################################################################
#echo "`date` [INFO] ----------- 5、 recy_icf_similarity end ---------"
#################################################################################

#########################################
#echo "`date` [INFO] ----------- 22、 Sim2ListDriver begin ---------"
#########################################
#{
# hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Sim2ListDriver $datebuf
# } >> recylog/sim_list_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 22、 Sim2ListDriver end ---------"
#################################################################################

#########################################
#echo "`date` [INFO] ----------- 25、 LiteSim2ListDriver begin ---------"
#########################################
#{
# hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.LiteSim2ListDriver $datebuf
# } >> recylog/lite_sim_list_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 25、 LiteSim2ListDriver end ---------"
#################################################################################

########################################
echo "`date` [INFO] ----------- 7、 recy_als_data_candya begin ---------"
########################################
{
/home/hadoop/hive/bin/hive --hivevar datebuf=${datebuf} --hivevar n_daysago_7=${n_daysago_7} -f recy_als_data_candya_stage1.sql
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candya.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_data_candya ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_data_candya/$datebuf/'"
} >> recylog/als_data_candya_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 7、 recy_als_data_candya end ---------"
################################################################################



########################################
echo "`date` [INFO] ----------- 8、 recy_als_data_candytag begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candytag.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_data_candytag ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_data_candytag/$datebuf/'"
} >> recylog/als_data_candytag_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 8、 recy_als_data_candytag end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 6、 recy_als_data_candycat begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candycat.py $datebuf
} >> recylog/recy_als_data_candycat_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 6、 recy_als_data_candycat end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 9、 recy_als_data_finalcandy begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finalcandy.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_data_finalcandy ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_data_finalcandy/$datebuf/'"
} >> recylog/als_data_finalcandy_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 9、 recy_als_data_finalcandy end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 19、 recy_als_out_pop begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/pop.py $datebuf
 /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_als_out_popcat/dt=${datebuf}/_SUCCESS"
 } >> recylog/recy_als_out_pop_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 19、 recy_als_out_pop end ---------"
################################################################################


#ALS 是模型，不建表
########################################
echo "`date` [INFO] ----------- 10、 recy_als_model begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 1 --executor-memory 12g /home/hadoop/user/vent/als.py $datebuf
 } >> recylog/als_model_${datebuf}.log 2>&1;
 /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_als_model/${datebuf}/_SUCCESS"
################################################################################
echo "`date` [INFO] ----------- 10、 recy_als_model end ---------"
################################################################################



########################################
echo "`date` [INFO] ----------- 11、 recy_als_predict begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/prediction.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_prediction ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_predict/$datebuf/'"
 } >> recylog/als_predict_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 11、 recy_als_predict end ---------"
################################################################################



########################################
echo "`date` [INFO] ----------- 12、 recy_als_out_topk begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/topk.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_out_topk ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_out_topk/$datebuf/'"
 } >> recylog/als_out_topk_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 12、 recy_als_out_topk end ---------"
################################################################################



########################################
echo "`date` [INFO] ----------- 13、 recy_icf_recommend begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_icf_recommend.py $datebuf
 } >> recylog/recy_icf_recommend_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 13、 recy_icf_recommend end ---------"
################################################################################



########################################
echo "`date` [INFO] ----------- 14、 recy_icf_out_topk begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_icf_out_topk.py $datebuf
 } >> recylog/recy_icf_out_topk_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 14、 recy_icf_out_topk end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 14.1、 recy_siucf_follow begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_siucf_follow.py $datebuf
 } >> recylog/recy_siucf_follow_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 14.1、 recy_siucf_follow end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 14.1.1、 RecyUser2ListDriver begin ---------"
########################################
{
 hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.RecyUser2ListDriver $datebuf
 } >> recylog/recy_user_list_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 14.1.1、 RecyUser2ListDriver end ---------"
################################################################################
#
#########################################
#echo "`date` [INFO] ----------- 14.2、 recy_siucf_interact begin ---------"
#########################################
#{
# /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_siucf_interact.py $datebuf
# } >> recylog/recy_siucf_interact_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 14.2、 recy_siucf_interact end ---------"
#################################################################################
#
#########################################
#echo "`date` [INFO] ----------- 14.3、 recy_siucf_social_interest begin ---------"
#########################################
#{
# /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_siucf_social_interest.py $datebuf
# } >> recylog/recy_siucf_social_interest_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 14.3、 recy_siucf_social_interest end ---------"
#################################################################################
#
#########################################
#echo "`date` [INFO] ----------- 14.4、 recy_siucf_recommend begin ---------"
#########################################
#{
# /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_siucf_recommend.py $datebuf
# } >> recylog/recy_siucf_recommend_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 14.4、 recy_siucf_recommend end ---------"
#################################################################################

########################################
echo "`date` [INFO] ----------- 14.5、 recy_ucf_out_topk begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_ucf_out_topk.py $datebuf
 } >> recylog/recy_ucf_out_topk_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 14.5、 recy_ucf_out_topk end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 15、 recy_final_out_topk begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finaltopk.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_final_out_topk ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_final_out_topk/$datebuf/'"
 } >> recylog/als_fianl_out_topk_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 15、 recy_final_out_topk end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 17、1 video_profile_feature begin ---------"
########################################
{
 hive --hivevar datebuf=${datebuf} -f ./sql/video_profile_feature.sql

 } >> recylog/video_profile_feature-${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 17、1 video_profile_feature end ---------"
################################################################################



########################################
echo "`date` [INFO] ----------- 17、2 recy-als-rank-features begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/feature.py $datebuf

 } >> recylog/recy-als-rank-features-${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 17、2 recy-als-rank-features end ---------"
################################################################################

#########################################
#echo "`date` [INFO] ----------- 17、2 recy_als_rank_sample begin ---------"
#########################################
#{
# /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/lrsample.py $datebuf
#
# } >> recylog/recy_als_rank_sample_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 17、2 recy_als_rank_sample end ---------"
#################################################################################

########################################
echo "`date` [INFO] ----------- 17、3 recy_ltr_rank_lrmodel begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/lrmodel.py $datebuf
 /home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_ltr_predict ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_ltr_predict/$datebuf/'"
 } >> recylog/recy_ltr_rank_lrmodel-${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 17、3 recy_ltr_rank_lrmodel end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 18、 recy_final_out_topk_redis begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finaltopkredis.py $datebuf
 /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_final_out_topk_redis/dt=${datebuf}/_SUCCESS"
 } >> recylog/recy_final_out_topk_redis_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 18、 recy_final_out_topk_redis end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 19、 recy_final_out_topk_redis_split begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finaltopkredissplit.py $datebuf
 /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_final_out_topk_redis_lite/dt=${datebuf}/_SUCCESS"
 /home/hadoop/hive/bin/hive -e "dfs -touchz /olap/da/recy_final_out_topk_redis_normal/dt=${datebuf}/_SUCCESS"
 } >> recylog/recy_final_out_topk_redis_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 19、 recy_final_out_topk_redis_split end ---------"
################################################################################


#########################################
#echo "`date` [INFO] ----------- 21.0 recy_day_redis_list begin ---------"
#########################################
#{
# hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Day2ListDriver $datebuf
# } >> recylog/recy_day_redis_list_${datebuf}.log 2>&1;
#################################################################################
#echo "`date` [INFO] ----------- 21.0 recy_day_redis_list end ---------"
#################################################################################

########################################
echo "`date` [INFO] ----------- 21.1 recy_day_redis_list_lite begin ---------"
########################################
{
 hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Day2ListLiteDriver $datebuf
 } >> recylog/recy_day_redis_list_lite_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 21.1 recy_day_redis_list_lite end ---------"
################################################################################
########################################
echo "`date` [INFO] ----------- 21.2 recy_day_redis_list_normal begin ---------"
########################################
{
 hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Day2ListNormalDriver $datebuf
 } >> recylog/recy_day_redis_list_normal_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 21.2 recy_day_redis_list_normal end ---------"
################################################################################

# ########################################
# echo "`date` [INFO] ----------- 22.1、propfile_pop job begin ---------"
# ########################################
# {
# /home/hadoop/spark/bin/spark-submit --queue root.spark --master yarn --deploy-mode client --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 5 --executor-memory 4g /home/hadoop/user/vent/profile_pop.py $datebuf
# } >> recylog/propfile_pop_${datebuf}.log 2>&1
# ################################################################################
# echo "`date` [INFO] ----------- 22.1、propfile_pop end ---------"
# ################################################################################

# ########################################
# echo "`date` [INFO] ----------- 22.2、 Category2ListDriver begin ---------"
# ########################################
# {
#  hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Category2ListDriver $datebuf
#  } >> recylog/Category2ListDriver_${datebuf}.log 2>&1
# ################################################################################
# echo "`date` [INFO] ----------- 22.2、 Category2ListDriver end ---------"
# ################################################################################

# ########################################
# echo "`date` [INFO] ----------- 22.3、 User2RedisDriver begin ---------"
# ########################################
# {
#  hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.User2RedisDriver $datebuf
#  } >> recylog/Category2ListDriver_${datebuf}.log 2>&1
# ################################################################################
# echo "`date` [INFO] ----------- 22.3、 User2RedisDriver end ---------"
# ################################################################################

