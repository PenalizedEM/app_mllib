#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 12

"""
Generate Candidate Videos
util 10 ago had been viewed autor's videos.(and hits_total>=100)
"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath


#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',1)
    #inUAPath = "hdfs://Ucluster/olap/dw/uabigger/"+inUADate+"/"
    #print "inUAPath HDFS Path: ",inUAPath
    # UVA输出目录的日期格式
    outDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    authorDate =  handleDatePath(sys.argv,'%Y-%m-%d',10)
    print "authorDate: ",authorDate

    outPath = "hdfs://Ucluster/olap/da/recy_als_data_canvideo/"+outDate+"/"
    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-data-canvideo:'+outDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()


    #vid的候选大表
    candySQL = "select b.* from (select u_vid from  da.recy_als_data_uvm where dt='2016-12-14' group by u_vid)a join (select uid,vid,createtime,hits_total from dw.video where to_date(createtime)>='2016-12-14' and to_date(createtime)<='2016-12-14' and hits_total>=100)b  on (a.u_vid=b.vid)  "
    candyDF = spark.sql(candySQL)
    candyDF.createOrReplaceTempView("canvideo")
    userSQL = "select c.u_diu,c.vid old,d.vid new from (select a.u_diu,b.uid,b.vid from (select u_diu,u_vid from da.recy_als_data_uvm where dt='2016-12-14')a join (select * from canvideo)b on (a.u_vid = b.vid))c left outer join canvideo d on c.uid = d.uid where c.vid <> d.vid"
    userDF = spark.sql(userSQL)
    userDF.printSchema()
    userDF.show()
    print userDF.count()
    #candyDF.write.mode('overwrite').save(outPath, format="parquet")
    #print "dd---------",candyDF.count()
    # candyDF.printSchema()
    # candyDF.show()
    # print candyDF.count()
    spark.stop()
    #
    # tag-video 矩阵  20亿
    # diuSQL = "select u_diu from dw.user_info where dt='2016-12-14' and to_date(substr(u_timestamp,0,19))>='2016-12-07' "
    # diuDF = spark.sql(diuSQL)
    # print "diu count :",diuDF.count()
    # vidSQL = "select vid from da.recy_dic_video_tag where to_date(createtime)>='2016-11-14' group by vid"
    # vidDF = spark.sql(vidSQL)
    # print "vid count ",vidDF.count()
    #candyDF = diuDF.rdd.cartesian(vidDF.rdd).toDF()
    #print candyDF.count()
    #candyDF.show()
