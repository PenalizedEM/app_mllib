#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 22 2017

"""
基础数据层—曝光
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#定义好Schema
def conSchema():
    uaList=['u_timestamp','u_host','u_xff','u_status','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_client_module','u_source','u_vid','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_rsource','u_rank','u_rmodelid','u_ruuid','u_strategyid']
    uaDict = OrderedDict()
    for ua in uaList:
        uaDict[ua] = StructField(ua, StringType(), True)
    schema = StructType(list(uaDict.values()))
    return schema

#拆分、拼装的日志(需要大改)
def spiltLog(x):
    XD = x.asDict()
    xdList = list()
    c = dict()
    rParaList=['u_rsource','u_rank','u_rmodelid','u_ruuid','u_strategyid']
    rkeys = ['u_vid','u_rsource','u_rank','u_rmodelid','u_ruuid','u_strategyid']
    defArr = ['-1']
    if XD['u_vid'] is not None and len(XD.keys())>0:
        XD['u_vid'] = XD['u_vid'].split(',')
        for rPara in rParaList:
            if XD[rPara] is  None :
                XD[rPara]= defArr*len(XD['u_vid'])
            else:
                XD[rPara] = XD[rPara].split(',')
                eSize = len(XD[rPara])-len(XD['u_vid'])
                if eSize>0:
                    XD[rPara] = x[rPara][0:len(XD['u_vid'])]
                elif eSize<0:
                    reSize = eSize*-1
                    XD[rPara].extend(defArr*reSize)
        ukeys =[item for item in XD.keys() if item not in rkeys]
        c = dict((k, XD[k]) for k  in ukeys)
        for i in range(0,len(XD['u_vid'])):
            b = dict((k, XD[k][i]) for k in rkeys)
            c.update(b)
            xdList.append(c.copy())
    return xdList

# def  assemblyField(key,dic):
#
#
# #拆分、拼装的日志()
# def spiltLog(x):
#     XD = x.asDict()
#     xdList = list()
#     c = dict()
#     rkeys = ['u_vid','u_rsource','u_rank','u_rmodelid','u_ruuid','u_strategyid']
#     ukeys =[item for item in XD.keys() if item not in rkeys]
#     c = dict((k, XD[k]) for k  in ukeys)
#     defArr = ['-1']
#     if XD['u_vid'] is not None and len(XD.keys())>0:
#         XD['u_vid'] = XD['u_vid'].split(',')
#         for rPara in rkeys[1,-1]:
#             if XD[rPara] is  None :
#                 XD[rPara]= defArr*len(XD['u_vid'])
#             else:
#                 XD[rPara] = XD[rPara].split(',')
#                 eSize = len(XD[rPara])-len(XD['u_vid'])
#                 if eSize>0:
#                     XD[rPara] = x[rPara][0:len(XD['u_vid'])]
#                 elif eSize<0:
#                     reSize = eSize*-1
#                     XD[rPara].extend(defArr*reSize)
#         for i in range(0,len(XD['u_vid'])):
#             b = dict((k, XD[k][i]) for k in rkeys)
#             c.update(b)
#             xdList.append(c)
#     return xdList

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    outPath = "hdfs://Ucluster/dw/edw/user_dvlog/"+inDate+"/"
    print "inDate  ",inDate


    spark = SparkSession.builder.master('yarn-client').appName('user_dvlog:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    #从uabigger取出曝光日志
    inSql = "SELECT u_timestamp, u_host, u_xff, u_status, u_size , u_div, u_dic , u_diu, u_diu2 , u_diu3, u_uid , u_time, u_mod , u_ac, u_client , u_ver, u_uuid , u_hash, u_xinge , u_token, u_agent , u_method, u_client_module , u_source, u_vid , u_width, u_height , u_lon, u_lat , u_province, u_city , u_netop , u_nettype, u_sdkversion , u_model, u_device , u_manufacture, get_json_object(u_bigger_json,'$.u_rsource')u_rsource , get_json_object(u_bigger_json,'$.u_rank')u_rank, get_json_object(u_bigger_json,'$.u_rmodelid')u_rmodelid , get_json_object(u_bigger_json,'$.u_ruuid')u_ruuid, get_json_object(u_bigger_json,'$.u_strategyid')u_strategyid FROM dw.uabigger WHERE dt='"+inDate+"'AND concat(u_mod,'-',u_ac)='emptylog-video_display' "
    #and u_diu='02375D5A-1DF6-4A49-B28E-24C05DD1B14B' and u_vid='1500653263413,1500653252289,1500653273683,1500653376913,1500653250523,1500653266331,1500653244700'
    #执行、表结构、展现
    rawDF = spark.sql(inSql)
    # rawC =rawDF.count()
    # print rawC
    # rawDF.printSchema()
    # rawDF.show()
    #拆分日志，返回多条
    dvRDD = rawDF.rdd.flatMap(lambda x : spiltLog(x))
    # print dvRDD.count()
    dvDF = spark.createDataFrame(dvRDD,conSchema())
    dvDF.printSchema()
    # dvDF.show()
    dvDF.repartition(800).write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
	# print uvmDF.count()
