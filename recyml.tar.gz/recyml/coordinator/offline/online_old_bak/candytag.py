 #!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 13

"""
Generate video tag

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession



#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UA输入目录的日期格式
    outDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    tagDate=handleDatePath(sys.argv,'%Y-%m-%d',14)
    outPath = "hdfs://Ucluster/olap/da/recy_als_data_candytag/"+outDate+"/"

    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-data-candytag:'+outDate).config("spark.sql.crossJoin.enabled","true").config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=1000")
    #相似度80分位数 0.1
    icfSQL = "SELECT u_diu,b.vid_2 as u_vid from (SELECT u_diu,u_vid from da.recy_als_data_uvm where dt='"+outDate+"' and f_timestamp >= unix_timestamp('"+tagDate+"','yyyy-MM-dd') and u_diu not in ('0123456789abcde','012345678912345','123456789012345','0','000000','00000000','00000000000000','000000000000000','0000000000000000','000000011234564','111111111111111','','UNKNOWN','Unknown','+++++000000000','+GSN:808DCF89','000000000000026') )a left outer join (SELECT vid_1,vid_2 from da.recy_icf_similarity_topn where dt='"+outDate+"' and similarity >= 0.1)b on (a.u_vid = b.vid_1) group by u_diu,b.vid_2"

    df = spark.sql(icfSQL)
    #df.printSchema()
    #df.show()
    #print df.count()
    df.repartition(500).write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
    # tagSQL = "select cast(vid as string) as u_vid from (select uid from da.recy_dic_talent_tag)a join (select uid,vid,createtime from dw.video where to_date(createtime)>='"+tagDate+"' and hits_total>=100 )b on (a.uid=b.uid) group by cast(vid as string)"
    # df = spark.sql(tagSQL)
    # df.createOrReplaceTempView("tagvideo")
    # canSQL = "select /* +mapjoin(b) */ a.u_diu,b.u_vid from(select u_diu from da.recy_als_data_uvm where dt='"+outDate+"' and f_timestamp >= unix_timestamp('"+tagDate+"','yyyy-MM-dd') and u_diu not in ('0123456789abcde','012345678912345','123456789012345','0','000000','00000000','00000000000000','000000000000000','0000000000000000','000000011234564','111111111111111','','UNKNOWN','Unknown','+++++000000000','+GSN:808DCF89','000000000000026') group by u_diu)a cross join (select u_vid from tagvideo)b  "
    # canDF = spark.sql(canSQL)
    # canDF.coalesce(5000).write.mode('overwrite').save(outPath, format="parquet")
    # spark.stop()



         #filter
    #tagSQL = "select d.u_vid,d.f_vid,c.tag,c.weight,c.createtime from (select a.uid,vid,tag,weight,createtime from (select uid,tag,weight from da.recy_dic_talent_tag)a join (select uid,vid,createtime from dw.video where to_date(createtime)>='"+tagDate+"')b on a.uid=b.uid)c join (select u_vid,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' group by u_vid,f_vid )d on (c.vid = d.u_vid) group by d.u_vid,d.f_vid,c.tag,c.weight,c.createtime"

    # diuSQL = "select u_diu,f_diu from da.recy_als_data_uvm where dt='"+outDate+"' and f_timestamp >= unix_timestamp('"+tagDate+"','yyyy-MM-dd') group by u_diu,f_diu"
    # diuDF = spark.sql(diuSQL)
    # diuDF.createOrReplaceTempView("diuall")
    # vidSQL = "select u_vid,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' and f_timestamp >= unix_timestamp('"+tagDate+"','yyyy-MM-dd') group by u_vid,f_vid"
    # vidDF = spark.sql(vidSQL)
    # vidDF.createOrReplaceTempView("vidall")
        # canDiuSQL = "select c.u_diu,d.u_vid,c.f_diu,d.f_vid from (select a.u_diu,a.f_diu,b.u_vid from (select u_diu,f_diu from diuall)a join (select u_diu,u_vid from canvideo)b on (a.u_diu = b.u_diu))c join (select u_vid,f_vid from vidall)d on (c.u_vid = d.u_vid )"
    # canDiuDF = spark.sql(canDiuSQL)

    # candySQL = "select b.u_diu,b.f_diu,b.u_vid,b.f_vid from (select u_diu,u_vid from tagall)a join (select u_diu,f_diu,u_vid,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' )b on (a.u_diu = b.u_diu and a.u_vid = b.u_vid) "
    # canDF = spark.sql(candySQL)
    #userDF.show()
    #userDF.count()
        # df.show()
    # print df.count()
    #userSQL = "select /* +mapjoin(d) */ c.u_diu,d.u_vid,c.f_diu,d.f_vid from (select a.u_diu,a.f_diu,b.tag,b.f_vid from (select u_diu,u_vid,f_diu,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' and u_diu not in ('0','0123456789abcde','012345678912345','123456789012345','00000000','000000000000000','111111111111111') )a join (select u_vid,f_vid,tag from tagvideo)b on (a.f_vid = b.f_vid))c left outer join tagvideo d on c.tag = d.tag where c.f_vid <> d.f_vid group by c.u_diu,d.u_vid,c.f_diu,d.f_vid"
    #userSQL = "select /* +mapjoin(b) */ a.u_diu,a.f_diu,b.u_vid,b.f_vid from(select u_diu,f_diu,u_vid,f_vid from da.recy_als_data_uvm where dt='"+outDate+"' and f_timestamp >= unix_timestamp('"+tagDate+"','yyyy-MM-dd'))a cross join (select u_vid,f_vid from tagvideo)b where a.f_vid<>b.f_vid  "
