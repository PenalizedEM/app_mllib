#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 10 2017

"""
整体热门视频
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession


#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
	print sys.argv
	reload(sys)
	sys.setdefaultencoding('utf-8')
	inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	oDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
	sDate=handleDatePath(sys.argv,'%Y-%m-%d',7)
	tDate=handleDatePath(sys.argv,'%Y-%m-%d',30)
	print "popDate  ",inDate
	print "1Day  ",oDate
	print "7Days  ",sDate
	print "30Days  ",tDate
	spark = SparkSession.builder.master('yarn-client').appName('pop:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
	#POP(item) = ( w1*num_7(item) + w2*num_30(item) + w3*num_90(item) ) / ( sign(num_7(item)) + sign(num_30(item)) + sign(num_90(item)) )
	#其中，w1 = 1/7, w2 = 1/30, w3 = 90为权重系数，可以调整；当x>0时，sign(x)=1；否则sign(x)=0。
	#根据我们的情况改为7days,30days,90days
	#先生成一个简单模型，后续加入用户画像模型
	outPath = "hdfs://Ucluster/olap/da/recy_als_out_pop/"+inDate+"/"
	w1 = 1
	w2 = 1/6
	w3 = 1/25
	mdSql = "from (select * from adm.f_video_vv where dt>='"+tDate+"'and dt<='"+inDate+"')a insert overwrite table da.recy_uv01d PARTITION (dt='"+inDate+"') select d_vid vid, count(distinct d_diu)uv where dt>='"+oDate+"'and dt<='"+inDate+"'group by d_vid order by uv desc limit 10000 insert overwrite table da.recy_uv07d PARTITION (dt='"+inDate+"') select d_vid vid, count(distinct d_diu)uv where dt>='"+sDate+"'and dt<='"+inDate+"'group by d_vid order by uv desc limit 10000 insert overwrite table da.recy_uv30d PARTITION (dt='"+inDate+"') select d_vid vid, count(distinct d_diu)uv where dt>='"+tDate+"'and dt<='"+inDate+"'group by d_vid order by uv desc limit 10000"
	mdDF = spark.sql(mdSql)
	#全局热门
	popSql = "insert overwrite table da.recy_als_out_pop PARTITION (dt='"+inDate+"') select vid, pop, datebuf from (select f.vid,(pop/(sign01d+sign07d+sign30d))pop, '"+inDate+"'datebuf , ROW_NUMBER() over (partition by uid order by pop desc) rn from (select vid,(1*uv01d+1/6*uv07d+1/25*uv30d)pop, if(uv01d>0,1,0)sign01d, if(uv07d>0,1,0)sign07d, if(uv30d>0,1,0)sign30d from (select if(c.vid is null,d.vid,c.vid)vid, if(c.uv01d is null,0,c.uv01d)uv01d, if(c.uv07d is null,0,c.uv07d)uv07d, if(d.uv is null,0,d.uv)uv30d from (select if(a.vid is null,b.vid,a.vid)vid, if(a.uv is null,0,a.uv)uv01d, if(b.uv is null,0,b.uv)uv07d from (select * from da.recy_uv01d where dt='"+inDate+"'and uv>1000)a full outer join (select * from da.recy_uv07d where dt='"+inDate+"'and uv>1000)b on(a.vid=b.vid))c full outer join (select * from da.recy_uv30d where dt='"+inDate+"'and uv>1000)d on (c.vid = d.vid))e)f join (select a.vid, uid from (select vid,uid from dw.video where !(sync <> 0 or uid=0 or type=9 or ( parent_category in ('65', '55', '54', '53', '47') and uid not in ('3512923', '3194741', '3512978', '3083296', '3114024', '3503710', '2584835', '2723788', '795605', '3183159', '3194481', '3512692', '3512781', '3194629', '3512815', '3512803', '2952436', '3399207', '3512804', '3512778', '3512808', '3194554', '2692975', '3512916', '3512979', '3085667', '3085957', '3083188') ) ) ) a left outer join ( SELECT vid FROM dw.video_recommend WHERE type=1 ) b on(a.vid=b.vid) where b.vid is null ) g on(f.vid=g.vid)) h where rn<=3 order by pop desc limit 3000"
	popDF = spark.sql(popSql)
	##分类热门
	preCatSql = " from (select o_date, s_date, t_date, child_category, vid, uv, o_rank, s_rank, ROW_NUMBER() over (partition by t_date, child_category order by uv desc) t_rank from (select o_date, s_date, t_date, child_category, vid, uv, o_rank, ROW_NUMBER() over (partition by s_date, child_category order by uv desc) s_rank from (select o_date, s_date, t_date, child_category, vid, uv, ROW_NUMBER() over (partition by o_date, child_category order by uv desc) o_rank from (select a.vid, if(a.dt>='"+inDate+"', 1, 0) o_date, if(a.dt>='"+sDate+"', 1, 0) s_date, if(a.dt>='"+tDate+"', 1, 0) t_date, b.child_category, sum(a.uv) uv from (select d_vid vid, dt , count(distinct d_diu) uv from adm.f_video_vv where dt>='"+tDate+"'and dt<='"+inDate+"'group by d_vid, dt)a join (select vid, child_category from dw.video)b on (a.vid=b.vid) group by a.vid, if(a.dt>='"+inDate+"', 1, 0) , if(a.dt>='"+sDate+"', 1, 0) , if(a.dt>='"+tDate+"', 1, 0) , b.child_category)c) d) e) f insert overwrite table da.recy_cat_uv01d PARTITION (dt='"+inDate+"') select vid, child_category, max(uv) uv where o_date=1 and o_rank<=300 group by vid, child_category having uv>5000 order by uv desc insert overwrite table da.recy_cat_uv07d PARTITION (dt='"+inDate+"') select vid, child_category, max(uv) uv where s_date=1 and s_rank<=300 group by vid, child_category having uv>5000 order by uv desc insert overwrite table da.recy_cat_uv30d PARTITION (dt='"+inDate+"') select vid, child_category, max(uv) uv where t_date=1 and t_rank<=300 group by vid, child_category having uv>5000 order by uv desc"
	spark.sql(preCatSql)

	#为生活视频提权
	popCatSql = "INSERT overwrite TABLE da.recy_als_out_popcat PARTITION (dt='"+inDate+"') SELECT j.vid, if(parent_category IN ('65', '55', '54', '53', '47'),pop*3,pop)pop, j.datebuf, child_category FROM (SELECT vid,(pop/(sign01d+sign07d+sign30d))pop, '"+inDate+"'datebuf FROM (SELECT vid,(1*uv01d+1/6*uv07d+1/25*uv30d)pop, if(uv01d>0,1,0)sign01d, if(uv07d>0,1,0)sign07d, if(uv30d>0,1,0)sign30d FROM (SELECT if(c.vid IS NULL,d.vid,c.vid)vid, if(c.uv01d IS NULL,0,c.uv01d)uv01d, if(c.uv07d IS NULL,0,c.uv07d)uv07d, if(d.uv IS NULL,0,d.uv)uv30d FROM (SELECT if(a.vid IS NULL,b.vid,a.vid)vid, if(a.uv IS NULL,0,a.uv)uv01d, if(b.uv IS NULL,0,b.uv)uv07d FROM (SELECT * FROM da.recy_cat_uv01d WHERE dt='"+inDate+"')a FULL OUTER JOIN (SELECT * FROM da.recy_cat_uv07d WHERE dt='"+inDate+"')b on(a.vid=b.vid))c FULL OUTER JOIN (SELECT * FROM da.recy_cat_uv30d WHERE dt='"+inDate+"')d ON (c.vid = d.vid))e)f ORDER BY pop DESC)j JOIN (SELECT vid, parent_category, child_category FROM dw.video WHERE sync=0)k ON (j.vid = k.vid)"
	spark.sql(popCatSql)
	# mdSql = "from (select * from dw.uabigger where dt>='"+tDate+"' and  dt<='"+inDate+"')a insert overwrite table da.recy_uv01d PARTITION (dt='"+inDate+"') select u_vid,count(distinct u_diu)uv where dt>='"+oDate+"' and  dt<='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' group by u_vid order by uv desc limit 10000 insert overwrite table da.recy_uv07d PARTITION (dt='"+inDate+"') select u_vid,count(distinct u_diu)uv where dt>='"+sDate+"' and  dt<='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' group by u_vid order by uv desc limit 10000 insert overwrite table da.recy_uv30d PARTITION (dt='"+inDate+"') select u_vid,count(distinct u_diu)uv where dt>='"+tDate+"' and  dt<='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' group by u_vid order by uv desc limit 10000"
	# mdDF = spark.sql(mdSql)
	# popSql = "insert overwrite table da.recy_als_out_pop PARTITION (dt='"+inDate+"') select vid,(pop/(sign01d+sign07d+sign30d))pop,'"+inDate+"'datebuf from (select vid,(1*uv01d+1/5*uv07d+1/15*uv30d)pop,if(uv01d>0,1,0)sign01d,if(uv07d>0,1,0)sign07d,if(uv30d>0,1,0)sign30d from (select if(c.vid is null,d.vid,c.vid)vid,if(c.uv01d is null,0,c.uv01d)uv01d,if(c.uv07d is null,0,c.uv07d)uv07d,if(d.uv is null,0,d.uv)uv30d from (select if(a.vid is null,b.vid,a.vid)vid,if(a.uv is null,0,a.uv)uv01d,if(b.uv is null,0,b.uv)uv07d from  (select * from da.recy_uv01d where dt='"+inDate+"')a full outer join (select * from da.recy_uv07d where dt='"+inDate+"')b on(a.vid=b.vid))c full outer join (select * from da.recy_uv30d where dt='"+inDate+"')d on (c.vid = d.vid))e)f order by pop desc limit 600"

	# popDF = spark.sql(popSql)
	# preCatSql = "FROM (SELECT a.*,b.* from  (SELECT * FROM dw.uabigger WHERE dt>='"+tDate+"'AND dt<='"+inDate+"')a join (select vid,child_category from dw.video)b on (a.u_vid=b.vid))c INSERT overwrite TABLE da.recy_cat_uv01d PARTITION (dt='"+inDate+"') SELECT u_vid,child_category, count(DISTINCT u_diu)uv WHERE dt>='"+oDate+"'AND dt<='"+inDate+"'AND concat(u_mod,'-',u_ac)='top-hits'GROUP BY u_vid,child_category ORDER BY uv DESC LIMIT 600 INSERT overwrite TABLE da.recy_cat_uv07d PARTITION (dt='"+inDate+"') SELECT u_vid,child_category, count(DISTINCT u_diu)uv WHERE dt>='"+sDate+"'AND dt<='"+inDate+"'AND concat(u_mod,'-',u_ac)='top-hits'GROUP BY u_vid,child_category ORDER BY uv DESC LIMIT 600 INSERT overwrite TABLE da.recy_cat_uv30d PARTITION (dt='"+inDate+"') SELECT u_vid,child_category, count(DISTINCT u_diu)uv WHERE dt>='"+tDate+"'AND dt<='"+inDate+"'AND concat(u_mod,'-',u_ac)='top-hits'GROUP BY u_vid,child_category ORDER BY uv DESC LIMIT 600"
	# spark.sql(preCatSql)
	# popCatSql = "INSERT overwrite TABLE da.recy_als_out_popcat PARTITION (dt='"+inDate+"') SELECT j.vid, j.pop,j.datebuf,child_category FROM (SELECT vid,(pop/(sign01d+sign07d+sign30d))pop, '"+inDate+"'datebuf FROM (SELECT vid,(1*uv01d+1/5*uv07d+1/15*uv30d)pop, if(uv01d>0,1,0)sign01d, if(uv07d>0,1,0)sign07d, if(uv30d>0,1,0)sign30d FROM (SELECT if(c.vid IS NULL,d.vid,c.vid)vid, if(c.uv01d IS NULL,0,c.uv01d)uv01d, if(c.uv07d IS NULL,0,c.uv07d)uv07d, if(d.uv IS NULL,0,d.uv)uv30d FROM (SELECT if(a.vid IS NULL,b.vid,a.vid)vid, if(a.uv IS NULL,0,a.uv)uv01d, if(b.uv IS NULL,0,b.uv)uv07d FROM (SELECT * FROM da.recy_cat_uv01d WHERE dt='"+inDate+"')a FULL OUTER JOIN (SELECT * FROM da.recy_cat_uv07d WHERE dt='"+inDate+"')b on(a.vid=b.vid))c FULL OUTER JOIN (SELECT * FROM da.recy_cat_uv30d WHERE dt='"+inDate+"')d ON (c.vid = d.vid))e)f ORDER BY pop DESC )j JOIN (SELECT vid, child_category FROM dw.video WHERE sync=0)k ON (j.vid = k.vid)"
	#spark.sql(popCatSql)
	#spark.sql("dfs -touchz /olap/da/recy_als_out_pop/dt=${inDate}/_SUCCESS")
	# popDF.printSchema()
	# popDF.show()
	#popDF.repartition(20).write.mode('overwrite').save(outPath, format="text")
	#addPartSql = "ALTER TABLE da.recy_als_out_pop ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_als_out_pop/"+inDate+"/'"
	#print addPartSql
	#spark.sql(addPartSql)
	spark.stop()
	# print uvmDF.count()

