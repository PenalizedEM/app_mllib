insert overwrite table da.recy_user_follow partition(dt='datebuf')
select uid_1,
       uid_2,
       num_1,
       num_2,
       num_12,
       intimacy,
       rank
from
  (select uid_1,
          uid_2,
          num_1,
          num_2,
          num_12,
          intimacy,
          ROW_NUMBER() OVER (PARTITION by uid_1
                             order by intimacy desc) rank
   from da.recy_siucf_follow a
   join
     (select uid
      from dw.video
      where uid>0
        and sync=0
      group by uid) b on(a.uid_2=b.uid)
   left outer join dw.follow_user c on(a.uid_1=c.uid
                                       and a.uid_2=c.reuid)
   where c.uid is null) d
where rank<=30
