#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print inDate
    # ratingDir = "hdfs://Ucluster/olap/da/recy_cf_rating/"+inDate+"/"
    # rating2Dir = "hdfs://Ucluster/olap/da/recy_cf_rating_2/"
    spark = SparkSession.builder.master('yarn-client').appName('recy_cf_rating:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    # ratingSql = " select diu, f_vid vid, vscore rating , ROW_NUMBER() OVER (PARTITION by diu order by vscore desc) rank , actdate from (select /* +mapjoin(a) */ u_diu diu, u_vid f_vid, actdate, (b.f_vv-a.avg_vv)/if(std_vv=0,0.0001,std_vv)*2 + (b.f_vst-a.avg_vst)/if(std_vst=0,0.0001,std_vst)*4 + (b.f_vp-a.avg_vp)/if(std_vp=0,0.0001,std_vp)*3 + (b.f_vc-a.avg_vc)/if(std_vc=0,0.0001,std_vc)*1 + vsf*2 + (b.f_vf-a.avg_vf)/if(std_vf=0,0.0001,std_vf)*5 + (b.f_vs-a.avg_vs)/if(std_vs=0,0.0001,std_vs)*3 + vd*4.5 as vscore from (select avg(f_hits) avg_vv, stddev_pop(f_hits) std_vv, avg(f_vd) avg_vst, stddev_pop(f_vd) std_vst, avg(f_vp) avg_vp, stddev_pop(f_vp) std_vp, avg(f_comment) avg_vc, stddev_pop(f_comment) std_vc, avg(f_fav) avg_vf, stddev_pop(f_fav) std_vf, avg(f_share) avg_vs, stddev_pop(f_share) std_vs from da.recy_als_data_uvr where dt='"+inDate+"') a join (select u_diu, u_vid, from_unixtime(f_timestamp,'yyyy-MM-dd') actdate, f_hits f_vv, f_vd f_vst, f_vp, f_comment f_vc, f_fav f_vf, f_share f_vs, if(f_flower>0,1,0) vsf, if(f_down>0,1,0) vd from da.recy_als_data_uvr where dt='"+inDate+"') b) c"
    #update PARTITION
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=1000"
    spark.sql(setSparSQLPartNum)
    # # 过滤小视频 video表中type=10
    # rating_new = "insert overwrite table da.recy_cf_rating_online select /* +mapjoin(b) */ diu, b.vid, rating, actdate, num from (select u_vid vid, count(1) num from da.recy_als_data_uvm where dt='"+inDate+"'group by u_vid) a join (select u_diu diu, u_vid vid , f_rating rating, from_unixtime(f_timestamp,'yyyy-MM-dd') actdate from da.recy_als_data_uvm where dt='"+inDate+"') b on(a.vid=b.vid) join (select vid from dw.video where type<>10 ) c on(a.vid=c.vid)"
    rating_new = "insert overwrite table da.recy_cf_rating_online select /* +mapjoin(b) */ diu, b.vid, c.type, c.createtime, rating, actdate, num from (select u_vid vid, count(1) num from da.recy_als_data_uvm where dt='"+inDate+"'group by u_vid) a join (select u_diu diu, u_vid vid , f_rating rating, from_unixtime(f_timestamp,'yyyy-MM-dd') actdate from da.recy_als_data_uvm where dt='"+inDate+"') b on(a.vid=b.vid) join (select vid, type, createtime from dw.video where sync=0) c on(a.vid=c.vid)"
    print rating_new
    spark.sql(rating_new)

    # addPartSql = "ALTER TABLE da.recy_cf_rating ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_cf_rating/"+inDate+"/'"
    # rating2Sql = "select /* +mapjoin(b) */ diu, b.vid, rating, rank, actdate, num from (select vid, count(1) num from da.recy_cf_rating where dt='"+inDate+"'group by vid) a join (select * from da.recy_cf_rating where dt='"+inDate+"') b on(a.vid=b.vid)"
    # print ratingSql
    # ratingDF = spark.sql(ratingSql)
    # ratingDF.printSchema()
    # ratingDF.repartition(300).write.mode('overwrite').save(ratingDir, format="parquet")
    # print addPartSql
    # spark.sql(addPartSql)
    # print rating2Sql
    # rating2DF = spark.sql(rating2Sql)
    # rating2DF.printSchema()
    # rating2DF.repartition(300).write.mode('overwrite').save(rating2Dir, format="parquet")

    spark.stop()

