#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ May 8

"""
 Implementation of LR to rank 
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler,StringIndexer,OneHotEncoder,StandardScaler
from pyspark.ml.evaluation import BinaryClassificationEvaluator

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    exDate = handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_rank_lr:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    #item特征
    itemSQL = "SELECT c.*, CASE WHEN d.flower_uv IS NULL OR d.flower_uv <=0 THEN 0 WHEN d.flower_uv =1 THEN 1 WHEN d.flower_uv >1 AND d.flower_uv <= 5 THEN 2 WHEN d.flower_uv > 5 AND d.flower_uv<= 10 THEN 3 WHEN d.flower_uv > 10 AND d.flower_uv <=20 THEN 4 WHEN d.flower_uv > 20 AND d.flower_uv <= 40 THEN 5 WHEN d.flower_uv >40 AND d.flower_uv <= 80 THEN 6 WHEN d.flower_uv >80 AND d.flower_uv <=150 THEN 7 ELSE 8 END AS floweruv_level FROM (SELECT a.*, if(b.fav_count_level IS NULL,0,b.fav_count_level)fav_count_level FROM (SELECT vid, CASE WHEN hits_total IS NULL THEN 0 WHEN hits_total >=0 AND hits_total <=50 THEN 1 WHEN hits_total >50 AND hits_total <=100 THEN 2 WHEN hits_total > 100 AND hits_total <= 500 THEN 3 WHEN hits_total > 500 AND hits_total <= 40000 THEN 4 ELSE 5 END AS hits_level, CASE WHEN comment_total IS NULL THEN 0 WHEN comment_total >=0 AND comment_total <=5 THEN 1 WHEN comment_total >5 AND comment_total <=10 THEN 2 WHEN comment_total > 10 AND comment_total <= 60 THEN 3 WHEN comment_total > 60 AND comment_total <= 300 THEN 4 ELSE 5 END AS comment_level, CASE WHEN SHARE IS NULL THEN 0 WHEN SHARE >=0 AND SHARE <=5 THEN 1 WHEN SHARE >5 AND SHARE <=10 THEN 2 WHEN SHARE > 10 AND SHARE <= 20 THEN 3 WHEN SHARE > 20 AND SHARE <= 50 THEN 4 ELSE 5 END AS share_level, CASE WHEN duration IS NULL THEN 0 WHEN duration >=0 AND duration <=90 THEN 1 WHEN duration >90 AND duration <=300 THEN 2 ELSE 3 END AS duration_level, if(cast(cast(coderate AS int)/256 AS int) IS NULL,0,cast(cast(coderate AS int)/256 AS int))coderate, if(definition IS NULL,0,definition)definition, if(uid is NULL,0,uid)uid, if(TYPE IS NULL,0,TYPE)TYPE, if(child_category IS NULL,0,child_category)child_category, if(degree IS NULL,0,degree)degree, if(genre IS NULL,0,genre)genre, if(parent_category IS NULL,0,parent_category)parent_category FROM dw.video)a LEFT OUTER JOIN (SELECT cast(vid AS int)vid, CASE WHEN fav_count IS NULL OR fav_count<1 THEN 0 WHEN fav_count =1 THEN 1 WHEN fav_count >1 AND fav_count<=10 THEN 2 WHEN fav_count>10 AND fav_count<= 20 THEN 3 WHEN fav_count>20 AND fav_count<=50 THEN 4 WHEN fav_count>50 AND fav_count<=100 THEN 5 WHEN fav_count>100 AND fav_count<=500 THEN 6 ELSE 7 END AS fav_count_level FROM (SELECT cast(vid AS int)vid, count(1)fav_count FROM dw.fav GROUP BY vid)k)b on(a.vid = b.vid))c LEFT OUTER JOIN (SELECT cast(vid AS int)vid, count(1)flower_uv FROM dw.flower_video GROUP BY cast(vid AS int))d on(c.vid = d.vid)"
    itemDF = spark.sql(itemSQL)
    itemDF.printSchema()
    itemDF.show()
    itemDF.createOrReplaceTempView("itemfe")
    #print bc
    #用户特征
    userSQL = "SELECT u_diu, if(u_act_status IS NULL,0,u_act_status)u_act_status, if(u_actperiod IS NULL,0,u_actperiod)u_actperiod, if(u_citylevel IS NULL,0,u_citylevel)u_citylevel, if(u_wvdur_range IS NULL,0,u_wvdur_range)u_wvdur_range, if(u_wvcnts_range IS NULL,0,u_wvcnts_range)u_wvcnts_range, if(cc IS NULL,0,cc)u_cc, if(cc_2 IS NULL,0,cc_2)u_cc2, if(u_osv IS NULL,0,u_osv)u_osv, if(cast(u_client AS int) IS NULL,0,cast(u_client AS int))u_client, CASE WHEN u_fresh IS NULL THEN 0 WHEN u_fresh>=0 AND u_fresh<=7 THEN 1 WHEN u_fresh >7 AND u_fresh <=30 THEN 2 WHEN u_fresh>30 AND u_fresh<=90 THEN 3 WHEN u_fresh >90 AND u_fresh<=180 THEN 4 WHEN u_fresh>180 AND u_fresh<=360 THEN 5 ELSE 6 END AS u_fresh_level, CASE WHEN u_active IS NULL THEN 0 WHEN u_active=1 THEN 1 WHEN u_active>1 AND u_active<=7 THEN 2 WHEN u_active>7 AND u_active<=14 THEN 3 WHEN u_active>14 AND u_active<=30 THEN 4 WHEN u_active>30 AND u_active<=90 THEN 5 WHEN u_active>90 AND u_active<=180 THEN 6 ELSE 7 END AS u_active_level FROM da.user_profile WHERE dt='"+inDate+"'"
    userDF = spark.sql(userSQL)
    userDF.show()
    userDF.createOrReplaceTempView("userfe")

    # crossSQL = "SELECT diu, vid, if(allex>0,1,0)ex, if(f_down IS NULL,0,1)down, if(f_share IS NULL,0,1)SHARE, if(f_fav IS NULL,0,1)fav, if(f_flower IS NULL,0,1)flower, if(f_hits IS NULL,0,1)hits, if(f_comment IS NULL,0,1)COMMENT, if(allex IS NOT NULL AND f_hits >0,1,0)tag FROM (SELECT diu, vid, sum(m_pv)allex FROM da.mid_video_ex WHERE dt= '"+inDate+"' GROUP BY diu, vid)a LEFT OUTER JOIN (SELECT u_diu, u_vid, f_down, f_share, f_fav, f_flower, f_hits, f_comment FROM da.recy_als_data_uvr WHERE dt='"+inDate+"' )b on(a.diu = b.u_diu AND a.vid = b.u_vid) " AND cm LIKE '%猜你喜欢%'
    #userDF.show()
    # #曝光点击生成label数据
    exclickSQL = "SELECT a.d_diu as diu ,a.d_vid as vid ,if(a.m_dv IS NULL,0,a.m_dv)ex,if(b.m_vv IS NULL,0,1)click from (SELECT d_diu,d_vid,m_dv from adm.f_video_dv where  dt<='"+inDate+"' AND dt>='"+exDate+"' )a left outer  join (SELECT d_diu,d_vid,m_vv from adm.f_video_vv where  dt<='"+inDate+"' AND dt>='"+exDate+"' )b on(a.d_diu = b.d_diu and a.d_diu = b.d_vid) group by a.d_diu,a.d_vid,a.m_dv,b.m_vv"
    exclickDF = spark.sql(exclickSQL)
    exclickDF.createOrReplaceTempView("exclick")
    #exclickDF.show()
    #关联
    joinSQL = "SELECT c.diu, vid, if(ex IS NULL,0,ex)i_ex, if(hits_level IS NULL,0,hits_level)i_hits_level, if(comment_level IS NULL,0,comment_level)i_comment_level, if(share_level IS NULL,0,share_level)i_share_level, if(duration_level IS NULL,0,duration_level)i_duration_level, if(definition IS NULL,0,definition)i_definition, if(uid IS NULL,0,uid)i_uid, if(coderate IS NULL,0,coderate)i_coderate, if(TYPE IS NULL,0,TYPE)i_type, if(child_category IS NULL,0,child_category)i_child_category, if(degree IS NULL,0,degree)i_degree, if(genre IS NULL,0,genre)i_genre, if(fav_count_level IS NULL,0,fav_count_level)i_fav_count_level, if(floweruv_level IS NULL,0,floweruv_level)i_floweruv_level, if(u_act_status IS NULL,0,u_act_status)u_act_status, if(u_actperiod IS NULL,0,u_actperiod)u_actperiod, if(u_citylevel IS NULL,0,u_citylevel)u_citylevel, if(u_wvdur_range IS NULL,0,u_wvdur_range)u_wvdur_range, if(u_wvcnts_range IS NULL,0,u_wvcnts_range)u_wvcnts_range, if(u_cc IS NULL,0,u_cc)u_cc, if(u_cc2 IS NULL,0,u_cc2)u_cc2, if(u_osv IS NULL,0,u_osv)u_osv, if(u_client IS NULL,0,u_client)u_client, if(u_fresh_level IS NULL,0,u_fresh_level)u_fresh_level, if(u_active_level IS NULL,0,u_active_level)u_active_level, click AS label FROM (SELECT a.diu, a.vid, ex, click, hits_level, comment_level, share_level, duration_level, definition, uid, coderate, TYPE, child_category, fav_count_level, floweruv_level, degree, genre FROM (SELECT diu, vid, ex, click FROM exclick)a /*LEFT OUTER*/ JOIN (SELECT vid, hits_level, comment_level, share_level, duration_level, definition, uid, coderate, TYPE, child_category, fav_count_level, floweruv_level, degree, genre FROM itemfe)b ON (a.vid = b.vid))c /*LEFT OUTER*/ JOIN (SELECT u_diu, u_act_status, u_actperiod, u_citylevel, u_wvdur_range, u_wvcnts_range, u_cc, u_cc2, u_osv, u_client, u_fresh_level, u_active_level FROM userfe)d ON (c.diu = d.u_diu)"
    ltrJoinDF = spark.sql(joinSQL)
    ltrJoinDF.printSchema()
    ltrJoinDF.show()
    ltrJoinDF.createOrReplaceTempView("ltrfe")
    #分层采样
    rateSql =  "SELECT hash(diu)f_diu, hash(vid)f_vid, i_ex, i_hits_level, i_comment_level, i_share_level, i_duration_level, i_definition, i_uid, i_coderate, i_type, i_child_category, i_fav_count_level, i_floweruv_level, i_degree, i_genre, u_act_status, u_actperiod, u_citylevel, u_wvdur_range, u_wvcnts_range, u_cc, u_cc2, u_osv, u_client, u_fresh_level, u_active_level, label FROM (SELECT diu, vid, i_ex, i_hits_level, i_comment_level, i_share_level, i_duration_level, i_definition, i_uid, i_coderate, i_type, i_child_category, i_fav_count_level, i_floweruv_level, i_degree, i_genre, u_act_status, u_actperiod, u_citylevel, u_wvdur_range, u_wvcnts_range, u_cc, u_cc2, u_osv, u_client, u_fresh_level, u_active_level, label FROM (SELECT *, count(*) over (partition BY hash(diu)) AS st_count, rank() over (partition BY hash(diu) ORDER BY rand()) AS rank1 FROM ltrfe WHERE label = 0)a WHERE rank1 <= 0.05 * st_count UNION ALL SELECT diu, vid, i_ex, i_hits_level, i_comment_level, i_share_level, i_duration_level, i_definition, i_uid, i_coderate, i_type, i_child_category, i_fav_count_level, i_floweruv_level, i_degree, i_genre, u_act_status, u_actperiod, u_citylevel, u_wvdur_range, u_wvcnts_range, u_cc, u_cc2, u_osv, u_client, u_fresh_level, u_active_level, label FROM FROM ltrfe WHERE label = 1)a"
    ltrData = spark.sql(rateSql)
    ltrData.printSchema()
    # ltrData.createOrReplaceTempView("sample")
    # labelSql = "select label,count(1)pv from sample group by label"
    # labelCount = spark.sql(labelSql)
    # labelCount.show()
    #print ltrData.count()
    #ltrData.show()
    #离散化以下字段
    rawFeaList = ['i_hits_level','i_comment_level','i_share_level','i_duration_level','i_definition','i_type','i_coderate','i_child_category','i_fav_count_level','i_floweruv_level','i_degree','i_genre','u_act_status','u_actperiod','u_citylevel','u_wvdur_range','u_wvcnts_range','u_cc','u_cc2','u_osv','u_client','u_fresh_level','u_active_level']
    vecFeaList = list()
    nodisList = ["f_diu","f_vid",'i_uid']#,'i_ex'
    for raw in rawFeaList:
        vec = raw+"_vec"
        encode = OneHotEncoder(inputCol=raw, outputCol=vec)
        ltrData = encode.transform(ltrData)
        vecFeaList.append(vec)
    vecFeaList.extend(nodisList)
    assembler = VectorAssembler(inputCols=vecFeaList, outputCol="rawfeatures")
    output = assembler.transform(ltrData)
    scaler = StandardScaler(inputCol="rawfeatures", outputCol="features",
                        withStd=True, withMean=False)
    # Compute summary statistics by fitting the StandardScaler
    scalerModel = scaler.fit(output)
    # Normalize each feature to have unit standard deviation.
    scaledData = scalerModel.transform(output)
    scaledData.show()

    scaledData.select("f_diu","f_vid","rawfeatures","features","label").show()
    cleanData = scaledData.select("features","label")
    #划分训练集和测试集
    (training, test) = cleanData.randomSplit([0.8, 0.2])
    # output.printSchema()
    # output.show()
    lr = LogisticRegression(maxIter=10, regParam=0.01)
    # Fit the model
    lrModel = lr.fit(training)
    result = lrModel.transform(test)
    # print result.prediction #0.0
    # print result.probability #[0.962242403983,0.0377575960168]
    # print result.rawPrediction #[3.23807972368,-3.23807972368]
    # print result.label
    evaluator = BinaryClassificationEvaluator()
    auc = evaluator.evaluate(result)
    print auc
    pr = evaluator.evaluate(result, {evaluator.metricName: "areaUnderPR"})
    print pr
    


    # Instantiate metrics object
    #evaluator = BinaryClassificationEvaluator()
    #cv = CrossValidator(estimator=lr, estimatorParamMaps=grid, evaluator=evaluator)
    #metrics = evaluator
    # Area under precision-recall curve
    #print("Area under PR = %s" % metrics.areaUnderPR)
    # Area under ROC curve
    #print("Area under ROC = %s" % metrics.areaUnderROC)

    # Print the coefficients and intercept for logistic regression
    #print("Coefficients: " + str(lrModel.coefficients))
    #print("Intercept: " + str(lrModel.intercept))
    #print lrModel.summary.areaUnderROC
    # roc = lrModel.summary.roc()
    # roc.show()
    # fm =  lrModel.summary.fMeasureByThreshold()
    # fm.show()
    spark.stop()
