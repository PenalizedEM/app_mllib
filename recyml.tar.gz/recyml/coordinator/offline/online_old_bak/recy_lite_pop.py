#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Feb 10 2017

"""
整体热门视频
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime, date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row, SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession


# 接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList, dateFormat, days):
    if len(dateList) == 1:
        # yes = date.today() - timedelta(1)
        days += 1
        datePath = (date.today() - timedelta(days)).strftime(dateFormat)
        # print datePath
    elif len(dateList) == 2:
        datePath = (datetime.strptime(dateList[1], '%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        # print datePath
    return datePath


# 主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate = handleDatePath(sys.argv, '%Y-%m-%d', 0)
    # oDate = handleDatePath(sys.argv, '%Y-%m-%d', 0)
    # sDate = handleDatePath(sys.argv, '%Y-%m-%d', 7)
    # tDate = handleDatePath(sys.argv, '%Y-%m-%d', 30)
    # print "popDate  ", inDate
    # print "1Day  ", oDate
    # print "7Days  ", sDate
    # print "30Days  ", tDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_lite_out_popcat:' + inDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    # POP(item) = ( w1*num_7(item) + w2*num_30(item) + w3*num_90(item) ) / ( sign(num_7(item)) + sign(num_30(item)) + sign(num_90(item)) )
    # 其中，w1 = 1/7, w2 = 1/30, w3 = 90为权重系数，可以调整；当x>0时，sign(x)=1；否则sign(x)=0。
    # 根据我们的情况改为7days,30days,90days
    # 先生成一个简单模型，后续加入用户画像模型
    # w1 = 1
    # w2 = 1 / 6
    # w3 = 1 / 25
    #
    # ##全局热门
    # popSql = " from (select o_date, s_date, t_date, d_vid, uv, o_rank, s_rank, ROW_NUMBER() over (partition by t_date order by uv desc) t_rank from (select o_date, s_date, t_date, d_vid, uv, o_rank, ROW_NUMBER() over (partition by s_date order by uv desc) s_rank from (select o_date, s_date, t_date, d_vid, uv, ROW_NUMBER() over (partition by o_date order by uv desc) o_rank from (select a.d_vid, if(a.dt>='" + inDate + "', 1, 0) o_date, if(a.dt>='" + sDate + "', 1, 0) s_date, if(a.dt>='" + tDate + "', 1, 0) t_date, sum(uv) uv from (select d_vid, dt , count(distinct d_diu) uv from adm.f_video_vv where dt>='" + tDate + "'and dt<='" + inDate + "'group by d_vid, dt)a join (select vid from dw.video where type=10 and status=0 )b on (a.d_vid=b.vid) group by a.d_vid, if(a.dt>='" + inDate + "', 1, 0) , if(a.dt>='" + sDate + "', 1, 0) , if(a.dt>='" + tDate + "', 1, 0))c) d) e) f insert overwrite table da.recy_lite_hot_uv01d PARTITION (dt='" + inDate + "') select d_vid, max(uv) uv where o_date=1  group by d_vid having uv>100 order by uv desc insert overwrite table da.recy_lite_hot_uv07d PARTITION (dt='" + inDate + "') select d_vid, max(uv) uv where s_date=1  group by d_vid having uv>150 order by uv desc insert overwrite table da.recy_lite_hot_uv30d PARTITION (dt='" + inDate + "') select d_vid, max(uv) uv where t_date=1  group by d_vid having uv>200 order by uv desc"
    # spark.sql(popSql)
    #
    # # 综合热门
    # allSql = "insert overwrite table da.recy_lite_pop PARTITION (dt='" + inDate + "') select vid,(pop/(sign01d+sign07d+sign30d))pop, '" + inDate + "'datebuf from (select vid,(1*uv01d+1/60*uv07d+1/250*uv30d)pop, if(uv01d>0,1,0)sign01d, if(uv07d>0,1,0)sign07d, if(uv30d>0,1,0)sign30d from (select if(c.vid is null,d.vid,c.vid)vid, if(c.uv01d is null,0,c.uv01d)uv01d, if(c.uv07d is null,0,c.uv07d)uv07d, if(d.uv is null,0,d.uv)uv30d from (select if(a.vid is null,b.vid,a.vid)vid, if(a.uv is null,0,a.uv)uv01d, if(b.uv is null,0,b.uv)uv07d from (select * from da.recy_lite_hot_uv01d where dt='" + inDate + "')a full outer join (select * from da.recy_lite_hot_uv07d where dt='" + inDate + "')b on(a.vid=b.vid))c full outer join (select * from da.recy_lite_hot_uv30d where dt='" + inDate + "')d on (c.vid = d.vid))e)f order by pop desc "

    allSql = "insert overwrite table da.recy_lite_pop partition(dt='" + inDate + "') select u_vid vid, pow(up_days+1,-1/up_hour)*rating pop, '" + inDate + "' datebuf from (select u_vid, count(1) uv, sum(f_rating) rating from da.recy_als_data_uvm where dt='" + inDate + "'group by u_vid having uv>100 ) a join (select vid, type, datediff('" + inDate + "',to_date(createtime)) up_days, hour(createtime)+1 up_hour from dw.video where sync='0'and type  in ('10','12'))  b on(a.u_vid=b.vid) where up_days<=3  order by pop desc limit 5000"
    spark.sql(allSql)
    spark.stop()
