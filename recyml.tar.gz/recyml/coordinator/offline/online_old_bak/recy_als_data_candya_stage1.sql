drop table if exists da.recy_als_data_candya_stage1;
create table da.recy_als_data_candya_stage1 as
select
	u_diu,
	f_diu,
	u_vid,
	f_vid
from
(
select u_diu , f_diu
from da.recy_als_data_uvm
where dt='${datebuf}'
	and f_timestamp >= unix_timestamp('${n_daysago_7}','yyyy-MM-dd')
group by
	u_diu , f_diu
) a
join
(
	select
		vid u_vid,
		f_vid
	from
	(
		select vid
		from dw.video
		where hits_total>4000
		  and user_hits>3200
		  and good_total>400
		  and comment_total>40
		  and to_date(createtime)>'${n_daysago_7}'
		  and TYPE in ('10')
		  and sync=0
	) b
	join
	(select u_vid,
	      f_vid
	from da.recy_als_data_uvm
	where dt='${datebuf}'
	and f_timestamp >= unix_timestamp('${n_daysago_7}','yyyy-MM-dd')
	group by u_vid,
	        f_vid) c
	on (c.u_vid = b.vid)
) b

