#!/bin/sh

source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################

date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
year=$year
month=$month
day=$day
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
exit 0
fi
fi

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf

n_daysago_7=`date -d" -7 day $datebuf" +"%Y-%m-%d"`
echo "n_daysago_7:$n_daysago_7"

########################################
echo "`date` [INFO] ----------- job begin ---------"
########################################



########################################
echo "`date` [INFO] ----------- 4、 temp_icf_workflow begin ---------"
########################################
{
    cd /home/hadoop/user/vent/crontab
#    sh temp_workflow.sh
    echo 'test'
    cd /home/hadoop/user/vent/
} >> /home/hadoop/user/vent/recylog/temp_icf_workflow_${datebuf}.log 2>&1
################################################################################
echo "`date` [INFO] ----------- 4、 temp_icf_workflow end ---------"
################################################################################

########################################
echo "`date` [INFO] ----------- 6、 recy_als_data_candycat begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candycat.py $datebuf
} >> recylog/recy_als_data_candycat_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 6、 recy_als_data_candycat end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 9、 recy_als_data_finalcandy begin ---------"
########################################
{
/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finalcandy.py $datebuf
/home/hadoop/hive/bin/hive -e "ALTER TABLE da.recy_als_data_finalcandy ADD IF NOT EXISTS
PARTITION (dt='$datebuf') LOCATION '/olap/da/recy_als_data_finalcandy/$datebuf/'"
} >> recylog/als_data_finalcandy_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 9、 recy_als_data_finalcandy end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 13、 recy_icf_recommend begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_icf_recommend.py $datebuf
 } >> recylog/recy_icf_recommend_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 13、 recy_icf_recommend end ---------"
################################################################################


########################################
echo "`date` [INFO] ----------- 14.4、 recy_siucf_recommend begin ---------"
########################################
{
 /home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/recy_siucf_recommend.py $datebuf
 } >> recylog/recy_siucf_recommend_${datebuf}.log 2>&1;
################################################################################
echo "`date` [INFO] ----------- 14.4、 recy_siucf_recommend end ---------"
################################################################################
