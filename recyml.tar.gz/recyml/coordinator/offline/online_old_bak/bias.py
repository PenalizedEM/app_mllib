#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Mar 5 2017

"""
Generate user/item bias(Last N days) to regular our weight formula.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.feature import StringIndexer


#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UvA输入目录的日期格式
    inDate = handleDatePath(sys.argv,'%Y-%m-%d',0)
    ttDate = handleDatePath(sys.argv,'%Y-%m-%d',30)
    #inUVMDate=handleDatePath(sys.argv,'%Y-%m-%d',1)
    print "inDate  ",inDate
    # UVA-Merge 输出目录的日期格式
    #outUVMPath = "hdfs://Ucluster/olap/da/recy_als_data_uvm/"+inUVADate+"/"
    #print "outUVMPath ",outUVMPath
    #max = str(240.0)
    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-data-bias:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    userbias = "insert overwrite table da.recy_als_data_userbias PARTITION (dt='"+inDate+"') select d_diu, max(m_pt)mapr, min(m_pt)mipr, percentile(m_pt,0.99)nnpr, percentile(m_pt,0.90)ntpr, percentile(m_pt,0.10)tpr, percentile(m_pt,0.01)opr, count(1)pv from adm.f_video_pt where dt<='"+inDate+"'and dt>='"+ttDate+"'and m_pt>0 group by d_diu"
    #print merge
    spark.sql(userbias)

    itembias = "insert overwrite table da.recy_als_data_itembias PARTITION (dt='"+inDate+"') select d_vid, max(m_pt)mapr, min(m_pt)mipr, percentile(m_pt,0.99)nnpr, percentile(m_pt,0.90)ntpr, percentile(m_pt,0.10)tpr, percentile(m_pt,0.01)opr, count(1)pv from adm.f_video_pt where dt<='"+inDate+"'and dt>='"+ttDate+"'and m_pt>0 group by d_vid"
    #print merge
    spark.sql(itembias)
    #spark.sql("SET spark.sql.shuffle.partitions=300")
    # bias = "CREATE table da.temptest as SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_sb, f_sc, f_sd, f_se, f_sf, (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_vd, f_sb, f_sc, f_sd, f_se, f_sf, if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up FROM (SELECT u_diu, u_vid, f_timestamp, hash(u_diu) f_diu, hash(u_vid) f_vid, f_vd, cast(if(f_down>0,5.0,0) AS double) f_sb, cast(if(f_share>0,2.0,0.0) AS double) f_sc, cast(if(f_fav>0,3.0,0.0) AS double)f_sd, cast(if(f_flower>0,2.0,0.0) AS double)f_se, cast(if(f_comment>0,1.0,0.0) AS double)f_sf FROM da.recy_als_data_uvr WHERE dt='"+inDate+"'AND f_vd>0) a JOIN (SELECT diu, nnpr, mipr, pv FROM da.recy_als_data_userbias WHERE dt='"+inDate+"')b ON (a.u_diu = b.diu)) c JOIN (SELECT vid, nnpr, mipr, pv FROM da.recy_als_data_itembias WHERE dt='"+inDate+"')d ON (c.u_vid = d.vid))e"
    # spark.sql(bias)
    spark.stop()
