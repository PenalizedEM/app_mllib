#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user action on video.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.feature import StringIndexer


#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    # UvA输入目录的日期格式
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    exDate = handleDatePath(sys.argv,'%Y-%m-%d',2)
    #inUVMDate=handleDatePath(sys.argv,'%Y-%m-%d',1)
    print "inDate  ",inDate
    # UVA-Merge 输出目录的日期格式
    outPath = "hdfs://Ucluster/olap/da/recy_als_data_uvm/"+inDate+"/"
    print "outPath ",outPath
    #max = str(240.0)
    spark = SparkSession.builder.master('yarn-client').appName('Recy-als-data-uam:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    #下载 => 4, 观看次数/时长 => 4 , 分享、收藏、送花 => 2, 评论 => 1

    #merge = "select a.f_diu,a.f_vid,a.f_vd,if(a.f_timestamp is null ,b.f_timestamp,a.f_timestamp) from (select u_diu,u_vid,f_vd,round((5*if(f_vd>" + max+ "," + max+ ",f_vd)/" + max+ "),1) f_rating,f_timestamp from da.recy_als_data_uvr where dt='"+inUVADate+"')a full outer join (select u_diu,u_vid,f_vd,f_rating,f_timestamp,f_diu,f_vid from da.recy_als_data_uvm where dt="+inUVABDate+")b on(a.u_diu=b.u_diu and a.u_vid=b.u_vid)"

    #merge = "select u_diu,u_vid,f_vd,round((5*if(f_vd>" + max+ "," + max+ ",f_vd)/" + max+ "),1) f_rating,f_timestamp from da.recy_als_data_uvr where dt='"+inUVADate+"'"
    ##四舍五入
    #merge = "select u_diu,u_vid,f_timestamp,f_diu,f_vid,(case when(f_sa+f_sb+f_sc+f_sd+f_se+f_sf)<=0.0 then 0.0 when(f_sa+f_sb+f_sc+f_sd+f_se+f_sf)>=3.5 and (f_sa+f_sb+f_sc+f_sd+f_se+f_sf)<=4.0 then 4.0  when(f_sa+f_sb+f_sc+f_sd+f_se+f_sf) >= 4.5 then 5.0 else round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1) end)f_rating  from (select u_diu,u_vid,f_timestamp,hash(u_diu) f_diu,hash(u_vid) f_vid,(case when f_vd >= 0  and f_vd <= 60 then 4*(f_vd+f_hits*5)/180 when f_vd >60 and f_vd <=180 then 4*(f_vd/180) when f_vd >180 then 4.0 else 0.0 end )as f_sa,cast(if(f_down>0,4.0,0) as double) f_sb,cast(if(f_share>0,1.5,0.0) as double) f_sc,cast(if(f_fav>0,2.0,0.0) as double)f_sd,cast(if(f_flower>0,2.0,0.0) as double)f_se,cast(if(f_comment>0,1.0,0.0) as double)f_sf from da.recy_als_data_uvr where dt='"+inUVADate+"')k"
    #merge = "select u_diu,u_vid,f_timestamp,f_diu,f_vid, if(round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating  from (select u_diu,u_vid,f_timestamp,hash(u_diu) f_diu,hash(u_vid) f_vid,(case when f_vd >= 0  and f_vd <= 60 then 4*(f_vd+f_hits*5)/120 when f_vd >60 and f_vd <=120 then 4*(f_vd/120) when f_vd >120 then 4.0 else 0.0 end )as f_sa,cast(if(f_down>0,5.0,0) as double) f_sb,cast(if(f_share>0,2.0,0.0) as double) f_sc,cast(if(f_fav>0,4.0,0.0) as double)f_sd,cast(if(f_flower>0,2.0,0.0) as double)f_se,cast(if(f_comment>0,1.0,0.0) as double)f_sf from da.recy_als_data_uvr where dt='"+inUVADate+"')k"
    #merge = "select u_diu,u_vid,f_timestamp,f_diu,f_vid, if(round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating  from (select u_diu,u_vid,f_timestamp,hash(u_diu) f_diu,hash(u_vid) f_vid,(case when f_vd >= 0  and f_vd <= 45 then 4*(f_vd+f_hits*2)/90 when f_vd >45 and f_vd <=90 then 4*(f_vd/90) when f_vd >90 then 4.0 else 0.0 end )as f_sa,cast(if(f_down>0,5.0,0) as double) f_sb,cast(if(f_share>0,2.0,0.0) as double) f_sc,cast(if(f_fav>0,4.0,0.0) as double)f_sd,cast(if(f_flower>0,2.0,0.0) as double)f_se,cast(if(f_comment>0,1.0,0.0) as double)f_sf from da.recy_als_data_uvr where dt='"+inUVADate+"')k"
    #print merge
    spark.sql("SET spark.sql.shuffle.partitions=1000")
    merge = "SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_sb, f_sc, f_sd, f_se, f_sf, (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa FROM (SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, f_vd, f_sb, f_sc, f_sd, f_se, f_sf, if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up FROM (SELECT u_diu, u_vid, f_timestamp, hash(u_diu) f_diu, hash(u_vid) f_vid, f_vd, cast(if(f_down>0,5.0,0) AS double) f_sb, cast(if(f_share>0,2.0,0.0) AS double) f_sc, cast(if(f_fav>0,3.0,0.0) AS double)f_sd, cast(if(f_flower>0,2.0,0.0) AS double)f_se, cast(if(f_comment>0,1.0,0.0) AS double)f_sf FROM da.recy_als_data_uvr WHERE dt='"+inDate+"') a JOIN (SELECT diu, nnpr, mipr, pv FROM da.recy_als_data_userbias WHERE dt='"+inDate+"')b ON (a.u_diu = b.diu)) c JOIN (SELECT vid, nnpr, mipr, pv FROM da.recy_als_data_itembias WHERE dt='"+inDate+"')d ON (c.u_vid = d.vid))e"
    uvmDF = spark.sql(merge)
    # uvmDF.printSchema()
    # uvmDF.show()
    uvmDF.createOrReplaceTempView("oldrating")
    ##May 24 2017 加入对曝光的负反馈
    update = "SELECT u_diu, u_vid, f_timestamp, f_diu, f_vid, if(f_rating-0.8*if(ex is null,0,ex)<0,0,f_rating-0.8*if(ex is null,0,ex))f_rating from (select * from oldrating)a left outer join (select d_diu, d_vid, sum(m_dv)ex from adm.f_video_dv where dt<='"+inDate+"'and dt>='"+exDate+"'group by d_diu, d_vid)b on (a.u_diu=b.d_diu and a.u_vid = b.d_vid)"
    updateDF = spark.sql(update)
    # updateDF.printSchema()
    # updateDF.show()
    # diuIndexer = StringIndexer(inputCol="u_diu", outputCol="d_diu")
    # diuDF = diuIndexer.fit(uvmDF).transform(uvmDF)
    # vidIndexer = StringIndexer(inputCol="u_vid", outputCol="d_vid")
    # vidDF = vidIndexer.fit(diuDF).transform(diuDF).repartition(300)
    # ddDF = vidDF.withColumn("f_diu", vidDF["d_diu"].cast(IntegerType())).repartition(300)
    # finalDF = ddDF.withColumn("f_vid", vidDF["d_vid"].cast(IntegerType())).repartition(300)
    # tfDF = finalDF.drop("d_diu").drop("d_vid").repartition(300)
    # uvmDF.printSchema()
    # uvmDF.show()
    # print uvmDF.count()
    updateDF.write.mode('overwrite').save(outPath, format="parquet")
    spark.stop()
