#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
spark_submit=$SPARK_HOME/bin/spark-submit
########################################

##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1
pyfile_name=$2
num_executors=$3
executor_cores=$4
executor_memory=$5
task_name=$6

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01 00"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"

#onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
#echo "onedayago:$onedayago"
##########################################################################################


echo "`date "+%Y-%m-%d %T"` begin ..."

#每2分钟重试一次,失败或超时,重试3次
for((i=1;i<=3;i++))
do
    begin_time=`date "+%s"`
    $spark_submit  --queue root.spark --master yarn-client  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors $num_executors --executor-cores $executor_cores --executor-memory $executor_memory py/${pyfile_name}.py $datebuf $task_name
    f=$?
    end_time=`date "+%s"`
    let takes=$end_time-$begin_time

    if [ $f -ne 0 ] ; then
        echo  "`date "+%Y-%m-%d %T"` The  ${i} times job run failed! ..."
        sleep $((60*2))
    elif [ $takes -gt 3600 ]; then
        # kill   -9   `ps   -ef|grep  "recy_icf_recommend" | grep -v "grep"| grep -v "pyspark.sh" | awk   '{print   $2} '`
        for pid in $(ps -ef |grep  ${pyfile_name} | grep -v "grep"| grep -v "pyspark.sh" | cut -c 9-15); do
            echo $pid
            kill -9 $pid
        done
        echo  "`date "+%Y-%m-%d %T"` The  ${i} times job run timeout! Already killed ..."
        sleep $((60*2))
    else
        echo "`date "+%Y-%m-%d %T"` The  ${i} times job run success! ..."
        break
    fi
done

echo "`date "+%Y-%m-%d %T"` end ..."