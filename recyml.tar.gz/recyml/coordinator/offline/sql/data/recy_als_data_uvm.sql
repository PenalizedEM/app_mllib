--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_uvm(
--    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
--    u_vid  STRING COMMENT '视频id',
--    f_timestamp BIGINT COMMENT '最后观看该视频的时间戳',
--    f_diu INT COMMENT '转换成整数的diu',
--    f_vid INT COMMENT '转换成整数的vid',
--    f_rating   DOUBLE COMMENT '归一化后的评分'
--)
--COMMENT '用户视频评分历史全量表'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_uvm/'

SET spark.sql.shuffle.partitions=1000;
drop table if exists da.recy_als_data_uvm_stage1;
create table da.recy_als_data_uvm_stage1 as
select u_diu,
       u_vid,
       f_timestamp,
       f_diu,
       f_vid,
       if(round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)>5.0,5.0,round((f_sa*2.5+f_sb+f_sc+f_sd+f_se+f_sf),1)) f_rating
from
  (select u_diu,
          u_vid,
          f_timestamp,
          f_diu,
          f_vid,
          f_sb,
          f_sc,
          f_sd,
          f_se,
          f_sf,
          (if(if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr))<0,0,if(pv>1,((f_vd - d.mipr)/(d.nnpr-d.mipr+0.01)),(f_vd/d.nnpr)))+up) as f_sa
   from
     (select u_diu,
             u_vid,
             f_timestamp,
             f_diu,
             f_vid,
             f_vd,
             f_sb,
             f_sc,
             f_sd,
             f_se,
             f_sf,
             if(if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr)<0,0,if(pv>1,(f_vd-b.mipr)/(b.nnpr-b.mipr+0.01),f_vd/b.nnpr))up
      from
        (select u_diu,
                u_vid,
                f_timestamp,
                hash(u_diu) f_diu,
                hash(u_vid) f_vid,
                f_vd,
                cast(if(f_down>0,5.0,0) as double) f_sb,
                cast(if(f_share>0,2.0,0.0) as double) f_sc,
                cast(if(f_fav>0,3.0,0.0) as double)f_sd,
                cast(if(f_flower>0,2.0,0.0) as double)f_se,
                cast(if(f_comment>0,1.0,0.0) as double)f_sf
         from da.recy_als_data_uvr
         where dt='${datebuf}') a
      join
        (select diu,
                nnpr,
                mipr,
                pv
         from da.recy_als_data_userbias
         where dt='${datebuf}')b on (a.u_diu = b.diu)) c
   join
     (select vid,
             nnpr,
             mipr,
             pv
      from da.recy_als_data_itembias
      where dt='${datebuf}')d on (c.u_vid = d.vid))e;

insert overwrite table da.recy_als_data_uvm partition(dt='${datebuf}')
select u_diu,
       u_vid,
       f_timestamp,
       f_diu,
       f_vid,
       if(f_rating-0.8*if(ex is null,0,ex)<0,0,f_rating-0.8*if(ex is null,0,ex))f_rating
from
  (select *
   from da.recy_als_data_uvm_stage1)a
left outer join
  (select d_diu,
          d_vid,
          sum(m_dv)ex
   from adm.f_video_dv
   where dt<='${datebuf}'
     and dt>='${n_daysago_2}'
   group by d_diu,
            d_vid)b on (a.u_diu=b.d_diu
                        and a.u_vid = b.d_vid)