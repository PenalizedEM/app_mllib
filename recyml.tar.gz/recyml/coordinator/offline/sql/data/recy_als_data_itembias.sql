--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_itembias(
--     vid  STRING  COMMENT '用户id',
--    mapr  INT COMMENT '最大值',
--    mipr iNT COMMENT '最小值',
--    nnpr  INT COMMENT '99分位值',
--    ntpr   INT COMMENT '90分位值',
--    tpr  INT  COMMENT '10分位值',
--    opr INT  COMMENT '1分位值',
--    pv INT COMMENT '视频观看次数'
--)
--COMMENT '视频bias'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_itembias/'

insert overwrite table da.recy_als_data_itembias PARTITION (dt='${datebuf}')
select d_vid,
       max(m_pt)mapr,
       min(m_pt)mipr,
       percentile(m_pt,0.99)nnpr,
       percentile(m_pt,0.90)ntpr,
       percentile(m_pt,0.10)tpr,
       percentile(m_pt,0.01)opr,
       count(1)pv
from adm.f_video_pt
where dt<='${datebuf}'
  and dt>='${n_daysago_30}'
  and m_pt>0
group by d_vid

