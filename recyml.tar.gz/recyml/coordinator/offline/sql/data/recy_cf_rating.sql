--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_cf_rating(
--diu STRING  COMMENT 'diu',
--vid  STRING  COMMENT '视频id',
--type  int  COMMENT '视频类型',
--createtime  STRING  COMMENT '视频创建时间',
--sync int  COMMENT '是否分发 0分发 1不分发 -1模糊审核中',
--status int  COMMENT '视频状态 0正常 1处理中 2审核中 3剔除 5删除',
--uid int  COMMENT '视频作者uid',
--rating double COMMENT '视频得分',
--actdate STRING COMMENT '更新日期'
--)
--COMMENT '推荐系统-协同过滤-用户评分数据生成2'
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_cf_rating/'

SET spark.sql.shuffle.partitions=1000;
insert overwrite table da.recy_cf_rating
select /* +mapjoin(b) */ diu,
                         a.vid,
                         b.type,
                         b.createtime,
                         b.sync,
                         b.status,
                         b.uid,
                         rating,
                         actdate
from
  (select u_diu diu,
          u_vid vid ,
          f_rating rating,
          from_unixtime(f_timestamp,'yyyy-MM-dd') actdate
   from da.recy_als_data_uvm
   where dt='${datebuf}') a
join
  (select vid,
          type,
          createtime,
          status,
          sync,
          uid
   from dw.video ) b
on(a.vid=b.vid)