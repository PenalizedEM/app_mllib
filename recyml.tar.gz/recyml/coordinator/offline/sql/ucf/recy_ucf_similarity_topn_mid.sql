drop table da.recy_ucf_similarity_topn_mid;
create table da.recy_ucf_similarity_topn_mid as
select
    *
from da.recy_ucf_similarity
where similarity>0.05
    and num_12>1;