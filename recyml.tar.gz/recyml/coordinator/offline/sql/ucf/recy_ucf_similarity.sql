--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_ucf_similarity(
--    diu_1 string COMMENT 'diu_1',
--    diu_2 string COMMENT 'diu_2',
--    num_1 int COMMENT 'diu_1看过的视频数',
--    num_2 int COMMENT 'diu_2看过的视频数',
--    num_12 int COMMENT 'diu_1和2共同看过的视频数',
--    similarity float COMMENT '相似度'
--)
--COMMENT '推荐——用户推荐——相似用户计算中间表'
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\t'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_ucf_similarity'

insert overwrite table da.recy_ucf_similarity
select diu_1,
       diu_2,
       num_1,
       num_2,
       num_12,
       num_12/sqrt(num_1*num_2) similarity
from da.recy_ucf_similarity_mid
union all
select diu_2 as diu_1,
       diu_1 as diu_2,
       num_2 as num_1,
       num_1 as num_2,
       num_12,
       num_12/sqrt(num_1*num_2) similarity
from da.recy_ucf_similarity_mid