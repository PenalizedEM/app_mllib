--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_ucf_rating(
--    diu string COMMENT 'diu',
--    vid string COMMENT 'vid',
--    rating float COMMENT '打分',
--    uv int COMMENT '视频uv',
--    pv int COMMENT '用户观看视频个数'
--)
--COMMENT '推荐——用户推荐——数据准备'
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\t'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_ucf_rating'

set mapred.reduce.tasks=600;
insert overwrite table da.recy_ucf_rating
select
	a.diu,
	a.vid,
  rating,
	uv,
	pv
from
(
  select
    diu,
    vid,
    rating
  from da.recy_cf_rating
  where actdate>='${n_daysago_5}'
) a
join
(
	select
		vid,
    count(distinct diu) uv
	from da.recy_cf_rating
	where actdate>='${n_daysago_5}'
  group by vid
  having uv<2500 and uv>5
) b
on (a.vid=b.vid)
join
(
	select
		diu, count(1) pv
	from da.recy_cf_rating
	where actdate>='${n_daysago_5}'
	group by
		diu
	having pv<1000 and pv>5
) c
on (a.diu=c.diu)