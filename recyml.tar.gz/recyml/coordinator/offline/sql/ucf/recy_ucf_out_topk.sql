drop table if exists da.recy_ucf_out_topk;
create table da.recy_ucf_out_topk as
select diu_1 diu,
       vid,
       rating*similarity prediction
from
  (select diu_1,
          diu_2,
          similarity
   from da.recy_ucf_similarity_topn
   where rank<=30) a
join
  (select diu,
          vid,
          rating
   from
     (select diu,
             vid ,
             rating,
             ROW_NUMBER() OVER (PARTITION by diu
                                order by rating, uv desc) rank
      from da.recy_ucf_rating
      where sync=0
      and uid>0
      and TYPE in ('10')
      ) b
   where rank<=10) b on(a.diu_2=b.diu);
