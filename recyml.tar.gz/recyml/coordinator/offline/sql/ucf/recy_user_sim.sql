SET spark.sql.shuffle.partitions=2000;

drop table if exists da.recy_user_sim;
create table da.recy_user_sim as
select uid_1,
       uid_2,
       num_1,
       num_2,
       num_12,
       similarity,
       rank
from
(
  select
    id uid_1,
    uid_2,
    num_1,
    num_2,
    num_12,
    similarity,
    ROW_NUMBER() OVER (PARTITION by id
                             order by similarity desc) rank
  from 
  (select * from da.recy_ucf_similarity where num_2> 15 ) a
  join 
  (
    select diu, id uid_2  
    from dw.user c 
    join (select uid from dw.video where sync=0 group by uid) d
    on(c.id=d.uid) 
    group by diu , id
  ) b 
  on(a.diu_2=b.diu)
  join 
    dw.user e 
  on(a.diu_1=e.diu) 
) f 
where rank<=50