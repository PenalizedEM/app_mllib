SET spark.sql.shuffle.partitions=2000;

drop table if exists da.recy_ucf_similarity_topn;
create table da.recy_ucf_similarity_topn as
select diu_1,
       diu_2,
       num_1,
       num_2,
       num_12,
       similarity,
       rank
from
  (select diu_1,
          diu_2,
          num_1,
          num_2,
          num_12,
          similarity,
          ROW_NUMBER() OVER (PARTITION by diu_1
                             order by similarity desc) rank
    from
        da.recy_ucf_similarity_topn_mid
   ) d
where rank<=100