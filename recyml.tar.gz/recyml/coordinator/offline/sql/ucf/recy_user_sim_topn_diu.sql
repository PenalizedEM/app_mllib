
drop table if exists da.recy_user_sim_topn_diu;
create table da.recy_user_sim_topn_diu as
select diu_1,
       diu_2,
       uid,
       similarity,
       rank
from
    (select * from da.recy_ucf_similarity_topn where num_1 is not null and diu_2<>'')  a
join
    (
        select
            diu,
            a.uid uid
        from
        (select diu, max(id) uid from dw.user where diu<>'' group by diu) a
        join
        (select uid from dw.video where sync=0 group by uid ) b
        on(a.uid=b.uid)
     )  b
on(a.diu_2=b.diu)


