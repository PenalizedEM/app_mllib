--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_ucf_similarity_mid(
--    diu_1 string COMMENT 'diu_1',
--    diu_2 string COMMENT 'diu_2',
--    num_1 int COMMENT 'diu_1看过的视频数',
--    num_2 int COMMENT 'diu_2看过的视频数',
--    num_12 int COMMENT 'diu_1和2共同看过的视频数'
--)
--COMMENT '推荐——用户推荐——相似用户计算中间表'
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\t'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_ucf_similarity_mid'
SET spark.sql.shuffle.partitions=2000;
insert overwrite table da.recy_ucf_similarity_mid
select a.diu diu_1 ,
       b.diu diu_2 ,
       a.pv num_1,
       b.pv num_2,
       count(1) num_12
from da.recy_ucf_rating a
join da.recy_ucf_rating b on (a.vid=b.vid)
where a.diu<b.diu
group by a.diu,
         b.diu,
         a.pv,
         b.pv