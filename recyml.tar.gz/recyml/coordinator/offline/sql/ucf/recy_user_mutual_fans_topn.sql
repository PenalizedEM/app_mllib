drop table if exists da.recy_user_mutual_fans_1;
create table da.recy_user_mutual_fans_1 as
select a.reuid uid_1,
       a.uid uid_2,
       fans
from
  (select *
   from dw.follow_user
   -- where to_date(time)>='2017-06-01'
   ) a
join
  (select reuid,
          count(1) fans
   from dw.follow_user
   group by reuid having fans>2000 )c
on (a.reuid=c.reuid)
;

drop table if exists da.recy_user_mutual_fans_2;
create table da.recy_user_mutual_fans_2 as
select a.uid_1 uid_1 ,
       b.uid_1 uid_2 ,
       a.fans num_1,
       b.fans num_2,
       count(1) num_12
from da.recy_user_mutual_fans_1 a
join da.recy_user_mutual_fans_1 b on (a.uid_2=b.uid_2)
where a.uid_1<b.uid_1
group by a.uid_1,
         b.uid_1,
         a.fans,
         b.fans
;

drop table if exists da.recy_user_mutual_fans;
create table da.recy_user_mutual_fans as
select uid_1,
       uid_2,
       num_1,
       num_2,
       num_12,
       num_12/sqrt(num_1*num_2) similarity
from da.recy_user_mutual_fans_2
union all
select uid_2 as uid_1,
       uid_1 as uid_2,
       num_2 as num_1,
       num_1 as num_2,
       num_12,
       num_12/sqrt(num_1*num_2) similarity
from da.recy_user_mutual_fans_2
;

drop table if exists da.recy_user_mutual_fans_topn;
create table da.recy_user_mutual_fans_topn as
select uid_1,
       uid_2,
       num_1,
       num_2,
       num_12,
       similarity,
       rank
from
(
  select
    uid_1,
    uid_2,
    num_1,
    num_2,
    num_12,
    similarity,
    ROW_NUMBER() OVER (PARTITION by uid_1
                             order by similarity desc) rank
  from da.recy_user_mutual_fans
) f
where rank<=50