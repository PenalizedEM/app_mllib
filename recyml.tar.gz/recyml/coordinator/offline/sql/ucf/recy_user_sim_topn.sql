drop table if exists da.recy_user_sim_topn;
create table da.recy_user_sim_topn as
select
  uid_1,
  uid_2,
  num_1,
  num_2,
  num_12,
  similarity,
  rank
from
(
	select
		a.*
	from da.recy_user_sim a
	left outer join
	da.recy_user_mutual_fans_topn b
	on(a.uid_1=b.uid_1)
	where b.uid_1 is null
) c
union all
select * from da.recy_user_mutual_fans_topn
;
