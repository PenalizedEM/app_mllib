SET spark.sql.shuffle.partitions=400;

insert OVERWRITE table da.recy_final_out_topk_redis partition(dt='${datebuf}')
select diu,
       vid,
       rn
from
  (select diu,
          vid,
          pp,
          ROW_NUMBER() over (partition by diu
                             order by pp desc)rn
   from da.recy_ltr_predict
   where dt='${datebuf}'
     and pp>=0.15)a;
dfs -touchz /olap/da/recy_final_out_topk_redis/dt=${datebuf}/_SUCCESS