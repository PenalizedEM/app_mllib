SET spark.sql.shuffle.partitions=1200;

drop table if exists da.recy_final_out_topk_stage1;
create table  da.recy_final_out_topk_stage1 as
select diu ,
       vid,
       prediction,
       '' title,
          '' pic,
             '' short_title,
                0 as hits_total,
                modelid as comment_total,
                '' createtime
from
  (select * ,
          ROW_NUMBER() over (partition by diu
                             order by prediction desc) rank
   from
     (select a.*,
             ROW_NUMBER() over (partition by diu,uid
                                order by prediction desc) rn
      from
        (select diu,
                vid,
                max(prediction) prediction,
                min(modelid) modelid
         from
           (select diu,
                   vid,
                   prediction,
                   2 modelid
            from da.recy_als_out_topk
            where dt='${datebuf}'
            union all select diu,
                             vid,
                             prediction,
                             1 modelid
            from da.recy_icf_out_topk
            where dt='${datebuf}'
            union all select diu,
                             vid,
                             prediction,
                             4 modelid
            from da.recy_siucf_recommend
            union all select diu,
                             vid,
                             prediction,
                             3 modelid
            from da.recy_ucf_out_topk) aa
         group by diu,
                  vid) a
      join
        (select vid,
                uid
         from dw.video
         where sync=0 and uid>0
           and to_date(createtime)>=date_sub('${datebuf}',365)
        ) b on(a.vid=b.vid)) b
   where rn<=6) c
where rank<=400;

insert overwrite table da.recy_final_out_topk PARTITION (dt='${datebuf}')
select c.*
   from
     (select a.*
      from
        (select *
         from da.recy_final_out_topk_stage1)a
      left outer join
        (select diu ,
                vid
         from da.recy_final_out_topk
         where dt>=date_sub('${datebuf}',3)
           and dt<'${datebuf}'
         group by diu,
                  vid)b on (a.diu=b.diu
                            and a.vid=b.vid)
      where b.diu is null) c
   left outer join da.recy_cf_rating d on (c.diu=d.diu
                                                  and c.vid=d.vid)
   where d.diu is null