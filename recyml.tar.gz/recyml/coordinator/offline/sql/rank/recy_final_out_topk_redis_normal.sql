SET spark.sql.shuffle.partitions=800;
insert OVERWRITE table da.recy_final_out_topk_redis_normal partition(dt='${datebuf}')
select diu,
       vid,
       rn
from
  (select r.diu,
          r.vid,
          r.pp,
          ROW_NUMBER() over (partition by r.diu
                             order by r.pp desc)rn
   from
     (select p.*
      from
        (select *
         from da.recy_ltr_predict)p
      join
        (select vid,
                createtime
         from dw.video
         where type not in ('10','12'))q on (p.vid = q.vid))r
   where dt='${datebuf}'
     and pp>=0.5)a;

dfs -touchz /olap/da/recy_final_out_topk_redis_normal/dt=${datebuf}/_SUCCESS