--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_finalcandy(
--    u_diu   STRING  COMMENT '用户id',
--    u_vid  STRING COMMENT '视频id',
--    f_diu   INT COMMENT '转换成整数的diu',
--    f_vid INT COMMENT '转换成整数的vid'
--)
--COMMENT '候选集A'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_finalcandy/'

SET spark.sql.shuffle.partitions=500;
drop table if exists da.recy_als_data_finalcandy_stage1;
create table da.recy_als_data_finalcandy_stage1 as
select c.* ,
       d.f_vid
from
  (select a.u_diu,
          a.u_vid,
          b.f_diu
   from
     (select u_diu,
             u_vid
      from da.recy_als_data_candytag
      where dt='${datebuf}'
      group by u_diu,
               u_vid)a
   join
     (select u_diu,
             f_diu
      from da.recy_als_data_uvm
      where dt='${datebuf}'
      group by u_diu,
               f_diu)b on (a.u_diu = b.u_diu))c
join
  (select u_vid,
          f_vid
   from da.recy_als_data_uvm
   where dt='${datebuf}'
   group by u_vid,
            f_vid)d on (c.u_vid = d.u_vid);

drop table if exists da.recy_als_data_finalcandy_stage2;
create table da.recy_als_data_finalcandy_stage2 as
select u_diu,
       u_vid,
       f_diu,
       f_vid
from
  (select u_diu,
          u_vid,
          f_diu,
          f_vid
   from da.recy_als_data_finalcandy_stage1
   union all select u_diu,
                    u_vid,
                    f_diu,
                    f_vid
   from da.recy_als_data_candya
   where dt='${datebuf}')c
group by u_diu,
         u_vid,
         f_diu,
         f_vid;

drop table if exists da.recy_als_data_finalcandy_stage3;
create table da.recy_als_data_finalcandy_stage3 as
select a.u_diu,
       a.u_vid,
       a.f_diu,
       a.f_vid
from
  (select *
   from da.recy_als_data_finalcandy_stage2)a
left outer join
(select diu u_diu,
     vid u_vid
 from da.recy_cf_rating
 where sync=0
   and uid>0
   and TYPE in ('10')
) b
on (a.u_diu=b.u_diu and a.u_vid=b.u_vid)
where b.u_diu is null;

insert overwrite table da.recy_als_data_finalcandy PARTITION (dt='${datebuf}')
select a.*
from
  (select *
   from da.recy_als_data_finalcandy_stage3)a
left outer join
  (select diu ,
          vid
   from da.recy_final_out_topk
   where dt>='${n_daysago_7}'
     and dt<'${n_daysago_1}'
   group by diu,
            vid)b on (a.u_diu=b.diu
                      and a.u_vid=b.vid)
where b.diu is null;