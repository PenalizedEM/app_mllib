--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_candya(
--    u_diu   STRING  COMMENT '用户id',
--    u_vid  STRING COMMENT '视频id',
--    f_diu   INT COMMENT '转换成整数的diu',
--    f_vid INT COMMENT '转换成整数的vid'
--)
--COMMENT '候选集A'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_candya/'

SET spark.sql.shuffle.partitions=1000;
insert overwrite table da.recy_als_data_candya PARTITION (dt='${datebuf}')
select e.u_diu ,
       g.u_vid,
       e.f_diu,
       g.f_vid
from
  (select d.u_diu,
          d.f_diu,
          c.u_vid
   from
     (select u_diu,
             u_vid
      from da.recy_als_data_candya_stage1)c
   join
     (select u_diu,
             f_diu
      from da.recy_als_data_uvm
      where dt='${datebuf}'
      group by u_diu,
               f_diu)d on (c.u_diu=d.u_diu)
   group by d.u_diu,
            d.f_diu,
            c.u_vid)e
join
  (select u_vid,
          f_vid
   from da.recy_als_data_uvm
   where dt='${datebuf}'
   group by u_vid,
            f_vid)g on (e.u_vid = g.u_vid)
group by e.u_diu ,
         g.u_vid,
         e.f_diu,
         g.f_vid;
