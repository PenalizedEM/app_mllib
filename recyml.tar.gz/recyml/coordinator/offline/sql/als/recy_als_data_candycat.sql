--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_cathot(
--    cid   int  COMMENT '分类id',
--    cname   STRING  COMMENT '分类名',
--    vid  bigint COMMENT '视频id',
--    uv  int COMMENT '视频播放人数',
--    cmax  int COMMENT '各类视频的前百分之十的视频个数取整',
--    rank  int COMMENT '分类排名'
--)
--COMMENT '最近30天小视频分类热门'
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_cathot/'

insert overwrite table da.recy_als_data_cathot
select
	pre_cate_id,
	pre_cate_name,
	vid,
	uv,
	cat_max,
	rank
from
(
select
	a.vid,
	b.pre_cate_id,
	b.pre_cate_name,
	uv,
	cat_max,
	row_number() over (partition BY b.pre_cate_id
	             ORDER BY uv DESC) AS rank
from
(
select
	vid,
	count(1) uv
from da.recy_cf_rating
where 	sync=0 and uid>0 and type=10
and actdate>='${n_daysago_30}'
group by
	vid
) a
join
(
select
	vid, pre_cate_id, pre_cate_name
from dw.lvcat
) b
on(a.vid=b.vid)
join
(
	select
		pre_cate_id, if(pre_cate_id='85' , round(count(1)*0.001), round(count(1)*0.01))  cat_max
	from dw.lvcat
	group by
		pre_cate_id
) c
on(b.pre_cate_id=c.pre_cate_id)
) d
where rank<=cat_max;

--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_candycat(
--    u_diu   STRING  COMMENT '用户id',
--    u_vid  STRING COMMENT '视频id'
--)
--COMMENT '小视频分类热门候选集'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_candycat/'

SET spark.sql.shuffle.partitions=1000;
insert overwrite table da.recy_als_data_candycat PARTITION (dt='${datebuf}')
select diu,
       b.vid
from
 (
    select diu, cid from da.user_profile_interest_lvcat where dt='${datebuf}' and cid>0 and cid not in ('85')
    union all
    select diu, cid_2 cid from da.user_profile_interest_lvcat where dt='${datebuf}' and cid_2>0 and cid_2 not in ('85')
    union all
    select diu, cid_3 cid from da.user_profile_interest_lvcat where dt='${datebuf}' and cid_3>0 and cid_3 not in ('85')
    union all
    select diu, cid_4 cid from da.user_profile_interest_lvcat where dt='${datebuf}' and cid_4>0 and cid_4 not in ('85')
    union all
    select diu, cid_5 cid from da.user_profile_interest_lvcat where dt='${datebuf}' and cid_5>0 and cid_5 not in ('85')
 ) a
join
(
    select cid, vid from da.recy_als_data_cathot  where cid not in ('85')
)b on (a.cid = b.cid)
group by diu,
         b.vid
