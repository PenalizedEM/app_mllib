--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_out_topk(
--    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
--    vid  STRING COMMENT '视频id',
--    prediction   FLOAT COMMENT '预测打分',
--    title   STRING COMMENT '视频标题',
--    pic STRING COMMENT '视频标图',
--    short_title STRING COMMENT '推荐语',
--    hits_total INT COMMENT '播放次数',
--    comment_total INT COMMENT '评论次数',
--    createtime STRING COMMENT '创建时间'
--)
--COMMENT '用户视频评分历史全量表'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_out_topk/'

insert overwrite table da.recy_als_out_topk PARTITION (dt='${datebuf}')
select u_diu as diu,
       u_vid as vid,
       round(if(prediction>5,5,prediction),1) prediction,
       '' title,
          '' pic,
             '' short_title,
                0 as hits_total,
                0 as comment_total,
                '' createtime
from da.recy_als_prediction
where dt='${datebuf}'