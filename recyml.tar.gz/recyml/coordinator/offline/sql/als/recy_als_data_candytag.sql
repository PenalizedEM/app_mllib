--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_als_data_candytag(
--    u_diu   STRING  COMMENT '用户id',
--    u_vid  STRING COMMENT '视频id'
--)
--COMMENT 'TAG候选集'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_als_data_candytag/'

SET spark.sql.shuffle.partitions=1000;
insert overwrite table da.recy_als_data_candytag PARTITION (dt='${datebuf}')
select diu,
       b.vid_2 as u_vid
from
 (select diu,
         vid
     from da.recy_cf_rating
     where actdate>='${n_daysago_14}'
       and sync=0
       and uid>0
       and TYPE in ('10')
 ) a
left outer join
  (select vid_1,
          vid_2
   from da.recy_icf_similarity_topn_l
   where  similarity >= 0.1)b on (a.vid = b.vid_1)
group by diu,
         b.vid_2
