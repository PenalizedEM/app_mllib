SET spark.sql.shuffle.partitions=2000;
drop table if exists da.recy_siucf_social_interest_pre1;
create table da.recy_siucf_social_interest_pre1 as
select c.uid_1,
       c.uid_2,
       intimacy,
       interaction,
       (if(intimacy is null, 0, intimacy)+if(interaction is null ,0, interaction))/2 degree
from
  (select if(a.uid_1 is null , b.uid_1, a.uid_1) uid_1,
          if(a.uid_2 is null , b.uid_2, a.uid_2) uid_2,
          if(intimacy is null, 0, intimacy) intimacy,
          if(interaction is null ,0, interaction) interaction
   from da.recy_siucf_follow a
   full outer join
   da.recy_siucf_interact b
   on(a.uid_1=b.uid_1 and a.uid_2=b.uid_2)) c
join
  (select uid uid_1,
          reuid uid_2
   from dw.follow_user
   where to_date(time)>='${n_daysago_30}') d
   on (c.uid_1=d.uid_1  and c.uid_2=d.uid_2);

drop table if exists da.recy_siucf_social_interest_pre2;
create table da.recy_siucf_social_interest_pre2 as
select a.uid_1,
       a.uid_2,
       a.degree,
       b.sqrt_degree
from da.recy_siucf_social_interest_pre1 a
join
  (select uid_1,
          sqrt(sum(degree*degree)) sqrt_degree
   from da.recy_siucf_social_interest_pre1
   group by uid_1) b on(a.uid_1=b.uid_1)
join
  (select uid_2,
          count(1) uv
   from da.recy_siucf_social_interest_pre1
   group by uid_2 having uv<10000)c on (a.uid_2=c.uid_2);

drop table if exists da.recy_siucf_social_interest_pre3;
create table da.recy_siucf_social_interest_pre3 as
select a.uid_1,
       b.uid_1 uid_2,
       sum(a.degree*b.degree/(a.sqrt_degree*b.sqrt_degree)) interest
from da.recy_siucf_social_interest_pre2 a
join da.recy_siucf_social_interest_pre2 b on(a.uid_2=b.uid_2)
where a.uid_1<b.uid_1
group by a.uid_1,
         b.uid_1;

drop table if exists da.recy_siucf_social_interest;
create table da.recy_siucf_social_interest as
select uid_1,
       uid_2,
       interest
from da.recy_siucf_social_interest_pre3
union all
select uid_2 uid_1,
       uid_1 uid_2,
       interest
from da.recy_siucf_social_interest_pre3;

