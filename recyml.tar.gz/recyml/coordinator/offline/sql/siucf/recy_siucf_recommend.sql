SET spark.sql.shuffle.partitions=1000;
drop table if exists da.recy_siucf_recommend;
create table da.recy_siucf_recommend as
select diu,
       vid,
       cast(rating as float) prediction,
       rank
from
  (select d.diu_1 diu,
          e.vid,
          interest*rating rating,
          ROW_NUMBER() OVER (PARTITION by d.diu_1
                             order by interest*rating desc) rank
   from
     (select b.diu diu_1,
             c.diu diu_2,
             interest
      from
        (select a.*
         from
           (select uid_1,
                   uid_2,
                   interest,
                   ROW_NUMBER() OVER (PARTITION by uid_1
                                      order by interest desc) rank
            from da.recy_siucf_social_interest) a
         where rank<=30) a
      join
        (select id,
                diu
         from dw.user) b on (a.uid_2=b.id)
      join
        (select id,
                diu
         from dw.user) c on (a.uid_1=c.id)) d
   join
     (select diu,
                vid,
                rating
         from da.recy_cf_rating
         where actdate>='${n_daysago_30}'
           and sync=0
           and uid>0
           and TYPE in ('10')
     ) e on(d.diu_2=e.diu)) f
where rank<=80;
