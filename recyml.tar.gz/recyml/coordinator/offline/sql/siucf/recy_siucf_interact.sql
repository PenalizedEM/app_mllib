SET spark.sql.shuffle.partitions=600;
drop table if exists da.recy_siucf_interact_pre1;
create table da.recy_siucf_interact_pre1 as
select a.uid_1,
       uid_2 ,
       a.num_12,
       num_1,
       num_2
from
  (select d_uid uid_1,
          d_reuid uid_2,
          sum(if(d_type='fav',m_cnt*2.5, m_cnt)) num_12
   from adm.f_account_interact
   where dt>='${n_daysago_30}'
   group by d_uid,
            d_reuid) a
join
  (select d_uid uid_1,
          sum(if(d_type='fav',m_cnt*2.5, m_cnt)) num_1
   from adm.f_account_interact
   where dt>='${n_daysago_30}'
   group by d_uid) b on(a.uid_1=b.uid_1)
join
  (select d_uid uid_1,
          sum(if(d_type='fav',m_cnt*2.5, m_cnt)) num_2
   from adm.f_account_interact
   where dt>='${n_daysago_30}'
   group by d_uid) c on(a.uid_2=c.uid_1);


drop table if exists da.recy_siucf_interact_pre2;
create table da.recy_siucf_interact_pre2 as
select a.uid_1,
       a.uid_2,
       a.num_12,
       if(b.num_12 is null,0,b.num_12) num_21,
       a.num_1 ,
       a.num_2
from da.recy_siucf_interact_pre1 a
left outer join da.recy_siucf_interact_pre1 b on(a.uid_2=b.uid_1
                                                 and a.uid_1=b.uid_2);

drop table if exists da.recy_siucf_interact;
create table da.recy_siucf_interact as
select uid_1,
       uid_2,
       num_12,
       num_21,
       num_1,
       num_2,
       (num_12 + num_21)/(sqrt(num_1*num_2)*2) interaction
from da.recy_siucf_interact_pre2;

