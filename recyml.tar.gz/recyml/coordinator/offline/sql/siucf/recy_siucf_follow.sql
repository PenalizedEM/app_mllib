--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_siucf_follow(
--    u_diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
--    u_vid  STRING COMMENT '视频id',
--    f_timestamp BIGINT COMMENT '最后观看该视频的时间戳',
--    f_diu INT COMMENT '转换成整数的diu',
--    f_vid INT COMMENT '转换成整数的vid',
--    f_rating   DOUBLE COMMENT '归一化后的评分'
--)
--COMMENT '用户视频评分历史全量表'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_siucf_follow/'

SET spark.sql.shuffle.partitions=2000;
drop table if exists da.recy_siucf_follow_pre1;
create table da.recy_siucf_follow_pre1 as
select a.uid uid_1,
       a.reuid uid_2,
       follow_cnt
from
  (select *
   from dw.follow_user
   where to_date(time)>='${n_daysago_30}') a
join
  (select uid,
          count(1) follow_cnt
   from dw.follow_user
   where to_date(time)>='${n_daysago_30}'
   group by uid)b on (a.uid=b.uid)
join
  (select reuid,
          count(1) fans
   from dw.follow_user
   where to_date(time)>='${n_daysago_30}'
   group by reuid having fans<10000)c on (a.reuid=c.reuid);

drop table if exists da.recy_siucf_follow_pre2;
create table da.recy_siucf_follow_pre2 as
select a.uid_1 ,
       b.uid_1 uid_2,
       a.follow_cnt num_1,
       b.follow_cnt num_2,
       count(1) num_12
from da.recy_siucf_follow_pre1 a
join da.recy_siucf_follow_pre1 b on (a.uid_2=b.uid_2)
where a.uid_1<b.uid_1
group by a.uid_1,
         b.uid_1,
         a.follow_cnt,
         b.follow_cnt;

drop table if exists da.recy_siucf_follow;
create table da.recy_siucf_follow as
select uid_1,
       uid_2,
       num_1,
       num_2,
       num_12,
       num_12/sqrt(num_1*num_2) intimacy
from da.recy_siucf_follow_pre2
union all
select uid_2 as uid_1,
       uid_1 as uid_2,
       num_2 as num_1,
       num_1 as num_2,
       num_12,
       num_12/sqrt(num_1*num_2) intimacy
from da.recy_siucf_follow_pre2;

insert overwrite table da.recy_user_follow partition(dt='${datebuf}')
select uid_1,
       uid_2,
       num_1,
       num_2,
       num_12,
       intimacy,
       rank
from
  (select uid_1,
          uid_2,
          num_1,
          num_2,
          num_12,
          intimacy,
          ROW_NUMBER() OVER (PARTITION by uid_1
                             order by intimacy desc) rank
   from da.recy_siucf_follow a
   join
     (select uid
      from dw.video
      where uid>0
        and sync=0
      group by uid) b on(a.uid_2=b.uid)
   left outer join dw.follow_user c on(a.uid_1=c.uid
                                       and a.uid_2=c.reuid)
   where c.uid is null) d
where rank<=30;
