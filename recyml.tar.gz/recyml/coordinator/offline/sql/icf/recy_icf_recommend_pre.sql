--CREATE EXTERNAL TABLE IF NOT EXISTS recy_icf_recommend_pre(
--diu STRING  COMMENT 'diu',
--vid  STRING  COMMENT 'vid',
--rating double COMMENT '推荐度得分',
--from_vid STRING  COMMENT '根绝看过的视频推荐'
--)
--COMMENT '推荐系统-基于视频的协同过滤-视频推荐列表'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_icf_recommend_pre/'

--SET spark.sql.shuffle.partitions=600
insert overwrite table da.recy_icf_recommend_pre PARTITION (dt='${datebuf}')
select diu,
       vid_2 vid,
       sum(rating*similarity) rating,
       max(vid) from_vid
from
  (select *
   from da.recy_icf_similarity_topn_l
  ) b
join
  (select diu,
          vid,
          rating
   from da.recy_cf_rating
   where actdate>='${n_daysago_30}'
   and sync=0
   and uid>0
   and TYPE in ('10')
   ) c on (b.vid_1=c.vid)
group by diu,
         vid_2