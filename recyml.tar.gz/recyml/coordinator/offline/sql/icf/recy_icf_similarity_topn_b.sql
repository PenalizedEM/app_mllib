drop table if exists da.recy_icf_similarity_topn_b;
create table da.recy_icf_similarity_topn_b as
select vid_1,
       vid_2,
       similarity,
       rank
from
  (select vid_1,
          vid_2,
          similarity,
          ROW_NUMBER() OVER (PARTITION by vid_1
                             order by similarity desc) rank
   from
     (select vid_1,
             vid_2,
             num_1,
             num_2,
             num_12,
             num_12/sqrt(num_1*num_2) similarity
      from da.recy_icf_similarity_mid_b
      where
        type_1 not in ('10','12')
        and type_2 not in ('10','12')
      union all
      select vid_2 as vid_1,
                       vid_1 as vid_2,
                       num_2 as num_1,
                       num_1 as num_2,
                       num_12,
                       num_12/sqrt(num_1*num_2) similarity
      from da.recy_icf_similarity_mid_b
      where
        type_1 not in ('10','12')
        and type_2 not in ('10','12')
      ) a
  ) b
where rank<= 50