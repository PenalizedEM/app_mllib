insert overwrite table da.recy_icf_similarity_topn partition(dt='${datebuf}')
select
    vid_1,
    vid_2,
    max(similarity)  similarity,
    max(rank) rank
from
(
    select vid_1,
           vid_2,
           similarity,
           rank
    from da.recy_icf_similarity_topn_b
    where rank<=30
    union all
    select vid_1,
           vid_2,
           similarity,
           rank
    from da.recy_icf_similarity_topn_l
    where rank<=30
) a
group by
    vid_1,
    vid_2