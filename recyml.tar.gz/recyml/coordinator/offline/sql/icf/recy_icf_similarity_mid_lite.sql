SET spark.sql.shuffle.partitions=2000;
drop table if exists da.recy_icf_similarity_mid_lite ;
create table da.recy_icf_similarity_mid_lite as
select a.vid vid_1 ,
       b.vid vid_2 ,
       a.num num_1,
       b.num num_2,
       count(1) num_12
from
  (select *
   from da.recy_icf_similarity_pre_lb
   where TYPE in ('10')  and sync=0 and uid>0) a
join
  (select *
   from da.recy_icf_similarity_pre_lb
   where TYPE in ('10')  and sync=0 and uid>0) b on (a.diu=b.diu)
where a.vid<b.vid
group by a.vid,
         b.vid,
         a.num,
         b.num