--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_out_topk(
--    diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
--    vid  STRING COMMENT '视频id',
--    prediction   FLOAT COMMENT '预测打分',
--    title   STRING COMMENT '视频标题',
--    pic STRING COMMENT '视频标图',
--    short_title STRING COMMENT '推荐语',
--    hits_total INT COMMENT '播放次数',
--    comment_total INT COMMENT '评论次数',
--    createtime STRING COMMENT '创建时间'
--)
--COMMENT '用户视频评分历史全量表'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_icf_out_topk/'

--SET spark.sql.shuffle.partitions=1000
insert overwrite table da.recy_icf_out_topk PARTITION (dt='${datebuf}')
select diu,
       vid,
       cast(round(if(rating>5,5,rating),1) as float) prediction ,
       '' title,
          '' pic ,
             '' short_title,
                0 as hits_total,
                0 as comment_total,
                '' createtime
from da.recy_icf_recommend
where dt='${datebuf}'
  and rank<=800