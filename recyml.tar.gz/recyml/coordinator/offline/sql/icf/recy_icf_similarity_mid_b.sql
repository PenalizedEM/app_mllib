SET spark.sql.shuffle.partitions=2000;
drop table if exists da.recy_icf_similarity_mid_b ;
create table da.recy_icf_similarity_mid_b as
select a.vid vid_1 ,
       a.type type_1,
       b.vid vid_2 ,
       b.type type_2,
       a.num num_1,
       b.num num_2,
       count(1) num_12
from
  (
   select *
   from da.recy_icf_similarity_pre_lb
   where actdate>=date_sub('${datebuf}',7)
  ) a
join
  (
   select *
   from da.recy_icf_similarity_pre_lb
   where  actdate>=date_sub('${datebuf}',7)
  ) b on (a.diu=b.diu)
where a.vid<b.vid
group by a.vid,
         a.type,
         b.vid,
         b.type,
         a.num,
         b.num