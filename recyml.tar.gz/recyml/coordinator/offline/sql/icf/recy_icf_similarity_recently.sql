insert overwrite table da.recy_icf_similarity_recently partition(dt='${datebuf}')
select vid_1,
       vid_2,
       num_1,
       num_2,
       num_12,
       similarity,
       '24'
from da.recy_icf_similarity_topn_l a
join
  (select vid
   from dw.video
   where sync=0
     and uid>0
     and TYPE in ('10')
     and to_date(createtime)>='${n_daysago_1}'
  ) b on(a.vid_1=b.vid)