drop table if exists da.recy_icf_similarity_topn_big;
create table da.recy_icf_similarity_topn_big as
select vid_1,
       vid_2,
       similarity,
       rank
from
  (select vid_1,
          vid_2,
          similarity,
          ROW_NUMBER() OVER (PARTITION by vid_1
                             order by similarity desc) rank
   from
     (select vid_1,
             vid_2,
             num_1,
             num_2,
             num_12,
             num_12/sqrt(num_1*num_2) similarity
      from da.recy_icf_similarity_mid_big
      union all select vid_2 as vid_1,
                       vid_1 as vid_2,
                       num_2 as num_1,
                       num_1 as num_2,
                       num_12,
                       num_12/sqrt(num_1*num_2) similarity
      from da.recy_icf_similarity_mid_big) a) b
where rank<= 50