--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_similarity_pre_lb(
-- diu STRING  COMMENT 'diu',
-- vid  STRING  COMMENT '视频id',
-- num bigint COMMENT '视频观看人数',
-- type int COMMENT '视频类别',
-- createtime  STRING  COMMENT '视频创建时间',
-- sync int  COMMENT '是否分发 0分发 1不分发 -1模糊审核中',
-- status int  COMMENT '视频状态 0正常 1处理中 2审核中 3剔除 5删除',
-- uid int  COMMENT '视频作者uid',
-- actdate  STRING  COMMENT '最后一次观看视频的时间'
-- )
-- COMMENT '推荐系统-协同过滤-视频相似度数据准备'
-- ROW FORMAT DELIMITED
-- FIELDS TERMINATED BY '\001'
-- STORED AS PARQUET
-- LOCATION '/olap/da/recy_icf_similarity_pre_lb/'

SET spark.sql.shuffle.partitions=1200;
insert overwrite table da.recy_icf_similarity_pre_lb
select a.diu,
       a.vid,
       num,
       a.type,
       a.createtime,
       a.sync,
       a.status,
       a.uid,
       a.actdate
from
(
    select *
    from da.recy_cf_rating
    where case when TYPE in ('10') then actdate>=date_sub('${datebuf}',25)
             when type not in ('10') then actdate>=date_sub('${datebuf}',7)
    end
    and to_date(createtime)>=date_sub('${datebuf}',365)
    and sync=0
    and uid>0
) a
join
  (select diu,
          count(1) vcnt
   from da.recy_cf_rating
   where actdate>=date_sub('${datebuf}',20)
   group by diu having vcnt<5000
   ) b
on (a.diu=b.diu)
join
  (select vid,
          count(1) num
   from da.recy_cf_rating
   where actdate>=date_sub('${datebuf}',20)
   group by vid having num<100000
   ) c
on (a.vid=c.vid)
;
