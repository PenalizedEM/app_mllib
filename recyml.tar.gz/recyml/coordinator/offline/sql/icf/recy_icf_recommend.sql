--CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_icf_recommend(
--diu STRING  COMMENT 'diu',
--vid  STRING  COMMENT 'vid',
--rating double COMMENT '推荐度得分',
--from_vid STRING  COMMENT '根绝看过的视频推荐',
--rank int COMMENT '排名'
--)
--COMMENT '推荐系统-基于视频的协同过滤-视频推荐列表'
--PARTITIONED BY(dt STRING)
--ROW FORMAT DELIMITED
--FIELDS TERMINATED BY '\001'
--STORED AS PARQUET
--LOCATION '/olap/da/recy_icf_recommend/'

--SET spark.sql.shuffle.partitions=600
insert overwrite table da.recy_icf_recommend PARTITION (dt='${datebuf}')
select a.*
from
  (select d.diu,
          d.vid,
          d.rating,
          d.from_vid,
          ROW_NUMBER() OVER (PARTITION by d.diu
                             order by d.rating desc) rank
   from
     (select *
      from da.recy_icf_recommend_pre
      where dt='${datebuf}') d
   left outer join
   (select diu, vid from da.recy_cf_rating where sync=0 and uid>0 and TYPE in ('10')  ) e
   on (d.diu=e.diu  and d.vid=e.vid)
   where e.diu is null) a
left outer join
  (select diu ,
          vid
   from da.recy_final_out_topk
   where dt>='${n_daysago_4}'
     and dt<'${datebuf}'
   group by diu,
            vid)b on (a.diu=b.diu
                      and a.vid=b.vid)
where b.diu is null