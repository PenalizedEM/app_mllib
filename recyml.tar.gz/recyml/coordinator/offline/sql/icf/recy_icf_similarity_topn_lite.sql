SET spark.sql.shuffle.partitions=1200;
drop table if exists da.recy_icf_similarity_topn_lite;
create table da.recy_icf_similarity_topn_lite as
select vid_1,
       vid_2,
       num_1,
       num_2,
       num_12,
       similarity,
       rank
from
  (select vid_1,
          vid_2,
          num_1,
          num_2,
          num_12,
          similarity,
          ROW_NUMBER() OVER (PARTITION by vid_1
                             order by similarity desc) rank
   from
     (select vid_1,
             vid_2,
             num_1,
             num_2,
             num_12,
             num_12/sqrt(num_1*num_2) similarity
      from da.recy_icf_similarity_mid_lite where num_12/sqrt(num_1*num_2)>0.001
      union all select vid_2 as vid_1,
                       vid_1 as vid_2,
                       num_2 as num_1,
                       num_1 as num_2,
                       num_12,
                       num_12/sqrt(num_1*num_2) similarity
      from da.recy_icf_similarity_mid_lite where num_12/sqrt(num_1*num_2)>0.001
      ) a
   ) b
where rank<= 100