#! /bin/bash


source /etc/profile
export PATH=${PATH}

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################


##########################################################################################
###                              handle date args                                      ###
##########################################################################################
date=`date -d" 1 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
    year=$year
    month=$month
    day=$day
else
    if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
        year=${datebuf:0:4}
        month=${datebuf:5:2}
        day=${datebuf:8:2}
    else
        echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
        exit 0
    fi
fi

datebuf=${year}-${month}-${day}
echo "datebuf:$datebuf"
#onedayago=`date -d" -1 day $datebuf" +"%Y-%m-%d"`
#echo "onedayago:$onedayago"
##########################################################################################


function test_e(){
    directory=$1
    $hadoop fs -test -e $directory/_SUCCESS
    f=$?
    echo $f
}

##########################################################################################
###                              check dependency datas                                ###
##########################################################################################
checkexsits=0;
times=0;

#每次5分钟*120次 等待10小时
while [ $checkexsits -eq 0 ] && [ $times -le 120 ];
do

    f=`test_e /olap/dw/uabigger/${datebuf} `
    echo "uabigger: $f"
    g=`test_e /dw/adm/f_video_cmdv/dt=${datebuf} `
    echo "f_video_cmdv: $g"
    h=`test_e /dw/adm/f_video_vv/dt=${datebuf} `
    echo "f_video_vv: $h"
    i=`test_e /dw/adm/f_video_pt/dt=${datebuf} `
    echo "f_video_pt: $i"
    j=`test_e /dw/adm/f_video_pagedv/dt=${datebuf} `
    echo "f_video_pagedv: $j"
    k=`test_e /dw/adm/f_video_dv/dt=${datebuf} `
    echo "f_video_dv: $k"
    l=`test_e /dw/edw/user_dvlog/${datebuf} `
    echo "user_dvlog: $l"

    if [ $f -ne 0 ] || [ $g -ne 0 ]  || [ $h -ne 0 ]  || [ $i -ne 0 ] || [ $j -ne 0 ] || [ $k -ne 0 ] || [ $l -ne 0 ]; then
        let checkexsits=0;
        sleep 300;
        echo "denpendency data success flag not exists! Waiting!"
    else
        let checkexsits=1;
        echo "denpendency data success flag  exists!"
        echo "Success file check compelet: OK!"

        sh ./recy_als.sh ${datebuf}

        break

    fi

    let times=times+1

done

if ! [ $checkexsits -eq 1 ]; then
    echo "Success file check compelet: _SUCCESS not exits!"
fi

