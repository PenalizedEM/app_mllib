


########################################
echo "`date` [INFO] ----------- 9、 recy_als_predict begin ---------"
########################################
{
/home/hadoop/hive/bin/hive -e "select * from da.dm_ac_action where dt='2017-02-16' and diu='37687478-0C42-4AD5-8CE1-267A47F40CE0' limit 10"
a=$?
/home/hadoop/hive/bin/hive -e "select * from da.dm_ac_action where dt='2017-02-17' and diu='37687478-0C42-4AD5-8CE1-267A47F40CE0' limit 10"
b=$?
 } >> temp.log 2>&1
if [ $(( a+b )) -ne 0 ]; then
echo "`date` [ERROR] ----------- failed"
sleep 60;
echo "`date` [INFO] ----------- retry"
{
/home/hadoop/hive/bin/hive -e "select * from da.dm_ac_action where dt='2017-02-16' and diu='37687478-0C42-4AD5-8CE1-267A47F40CE0' limit 10"
a=$?
/home/hadoop/hive/bin/hive -e "select * from da.dm_ac_action where dt='2017-02-17' and u_diu='37687478-0C42-4AD5-8CE1-267A47F40CE0' limit 10"
b=$?
} >> temp.log 2>&1
if [ $(( a+b )) -ne 0 ]; then
echo "`date` [ERROR] ----------- failed"
else
echo "`date` [INFO] ----------- success!"
fi 
else
echo "`date` [INFO] ----------- success!"
fi
################################################################################
echo "`date` [INFO] ----------- 9、 recy_als_predict end ---------"
################################################################################





