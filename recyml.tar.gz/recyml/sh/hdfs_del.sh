#! /bin/bash


source /etc/profile 
export PATH=${PATH}
date=`date -d" 7 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
year=$year
month=$month
day=$day
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
exit 0
fi
fi

yesterday=`date -d" 1 day ago" +"%Y-%m-%d"`
if [ $1 == $yesterday ]; then
echo "`date` [ERROR] ----------- can't delete files of yesterday"
exit 0 
fi 

########################################
# hadoop master1
hadoop=/home/hadoop/bin/hadoop
hive=/home/hadoop/hive/bin/hive
########################################

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf 

########################################
echo "`date` [INFO] ----------- delete job begin ---------"
########################################

$hive -e "ALTER TABLE da.recy_als_data_candya drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_candya/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_data_candytag drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_candytag/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_data_finalcandy drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_finalcandy/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_data_uvm drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_uvm/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_data_uvr drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_uvr/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_model drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_model/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_out_topk drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_out_topk/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_prediction drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_predict/${datebuf}/

$hive -e "ALTER TABLE da.recy_final_out_topk drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_final_out_topk/${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_out_topk drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_out_topk/${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_recommend drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_recommend/${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_recommend_pre drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_recommend_pre/${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_similarity drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_similarity/${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_similarity_topk drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_similarity_topk/${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_similarity_topn drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_similarity_topn/dt=${datebuf}/

$hive -e "ALTER TABLE da.user_profile drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/user_profile/dt=${datebuf}/

$hive -e "ALTER TABLE da.recy_icf_similar_nolife_topn drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_icf_similar_nolife_topn/dt=${datebuf}/

$hadoop fs -rmr /olap/da/recy_ltr_usfeature/${datebuf}/

$hive -e "ALTER TABLE da.recy_als_data_candysea drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_candysea/dt=${datebuf}/

$hive -e "ALTER TABLE da.recy_als_data_userbias drop if exists PARTITION (dt='${datebuf}')"
$hadoop fs -rmr /olap/da/recy_als_data_userbias/dt=${datebuf}/


########################################
echo "`date` [INFO] ----------- delete job end ---------"
########################################

# del recy hdfs overdue files
# 00 07 * * * cd /home/hadoop/user/vent && ./hdfs_del.sh >> /home/hadoop/user/vent/hdfs_del.log 2>&1

