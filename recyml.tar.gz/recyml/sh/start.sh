/home/hadoop/spark/bin/pyspark --master yarn-client --num-executors 10 --executor-cores 6 --executor-memory 6g

/home/hadoop/spark/bin/spark-submit  --master yarn --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 4 /home/hadoop/user/vent/logetl.py

/home/hadoop/spark/bin/spark-submit  --master yarn --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/raw2ua.py 2017-04-01


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 22 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/ua2ui.py 2017-01-01

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/ua2uis.py 2016-12-21

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 6g /home/hadoop/user/vent/uvaction.py 2016-10-29

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/uvrating.py 2016-12-23

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 6g /home/hadoop/user/vent/uvmerge.py 

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candysea.py

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candya.py 2017-02-28

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candytag.py 2016-12-14

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finalcandy.py 2016-12-24

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/als.py 2016-12-23

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/prediction.py 2016-12-24

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/topk.py 2016-12-24

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finaltopk.py 2016-12-24

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finaltopkhbase.py 2017-02-16

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/pop.py 2017-02-15

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/cpcold.py  2017-04-15

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py,/home/hadoop/user/vent/redis.zip --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/idmapping.py  2017-04-15

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/topuser.py 2017-04-26


/home/hadoop/spark/bin/spark-submit  --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 60 --executor-cores 4 --executor-memory 4g /home/hadoop/user/vent/finaltopkredissplit.py




---- on going ------
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 50 --executor-cores 8 --executor-memory 12g /home/hadoop/user/vent/feature.py 

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 34 --executor-cores 7 --executor-memory 12g /home/hadoop/user/vent/lrrank.py 2017-05-25


/home/hadoop/spark/bin/spark-submit --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 50 --executor-cores 8 --executor-memory 12g /home/hadoop/user/vent/lrmodel.py 2017-08-01

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 15 --executor-cores 7 --executor-memory 12g /home/hadoop/user/vent/profile_pop.py 

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 15 --executor-cores 7 --executor-memory 12g /home/hadoop/user/vent/cpcluster.py 

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 35 --executor-cores 4 --executor-memory 12g /home/hadoop/user/vent/test.py 2017-10-11


/home/hadoop/spark/bin/spark-submit --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/user_dvlog.py

/home/hadoop/spark/bin/spark-submit --queue root.spark --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 45 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/context.py

hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.DelRecyFeedDriver
hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.LtrimRecyFeedDriver 2017-09-20
hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Hour2ListDriver
hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Hour2SetDriver
hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Day2ListLiteDriver 2017-09-20
hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Day2ListNormalDriver 2017-09-20

hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.DelExpoedDriver


#hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.IM2StringDriver
hadoop jar /home/hadoop/user/vent/recyio1.jar com.xiaotang.recyio.driver.Hour2ListDriver


hadoop jar /home/hadoop/user/vent/recyio.jar com.xiaotang.recyio.driver.Sim2ListDriver
hadoop jar /home/hadoop/user/wenlong/crontab/jar/recyio.jar com.xiaotang.recyio.driver.Watch2SetDriver 2017-07-25/08


-------- temp -----


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/test/dateutil.zip,/home/hadoop/user/vent/test/six.py --num-executors 20 --executor-cores 7 --executor-memory 12g /home/hadoop/user/vent/test/test.py 


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 24 --executor-cores 7 --executor-memory 12g /home/hadoop/user/vent/test.py 2017-05-25

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/retention.py 2016-12-26

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/bias.py 2017-03-05


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 20 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/test.py  2017-02-28


/home/hadoop/spark/bin/spark-submit --jars /home/hadoop/user/vent/park-streaming-kafka-0-8-assembly_2.11-2.1.0.jar /home/hadoop/user/vent/kafka.py ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092 logstash-tv

/home/hadoop/spark/bin/spark-submit  --master yarn --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.1.0 --num-executors 6 --executor-cores 2 --executor-memory 2g /home/hadoop/user/vent/kafka.py ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092 logstash


/home/hadoop/spark/bin/spark-submit  --master yarn --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.1.0 --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 6 --executor-cores 4 --executor-memory 6g /home/hadoop/user/vent/etl.py

/home/hadoop/spark/bin/spark-submit  --master yarn --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.1.0 --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py,/home/hadoop/user/vent/redis.zip --num-executors 6 --executor-cores 4 --executor-memory 6g /home/hadoop/user/vent/litetl.py

/home/hadoop/spark/bin/spark-submit  --master yarn --packages org.apache.spark:spark-streaming-kafka-0-8_2.11:2.1.0 --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py,/home/hadoop/user/vent/redis.zip --num-executors 3 --executor-cores 3 --executor-memory 6g /home/hadoop/user/vent/watchset.py