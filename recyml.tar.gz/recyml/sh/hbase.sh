#!/bin/sh

datebuf=$1
echo  "rundate:" $datebuf

# discp final top k
/home/hadoop/bin/hadoop distcp -m 5 -i -overwrite hdfs://10.10.171.218:8020/olap/da/recy_final_out_topk/$datebuf hdfs://uhadoop-zr4hvu-master1:8020/olap/da/recy_final_out_topk/$datebuf

# add partition for final top k
-- CREATE EXTERNAL TABLE IF NOT EXISTS da.recy_final_out_topk(
--     diu   STRING  COMMENT '设备唯一号,android--imei,ios--IDFV',
--     vid  STRING COMMENT '视频id',
--     prediction   FLOAT COMMENT '预测打分',
--     title   STRING COMMENT '视频标题',
--     pic STRING COMMENT '视频标图',
--     short_title STRING COMMENT '推荐语',
--     hits_total INT COMMENT '播放次数',
--     comment_total INT COMMENT '评论次数'
-- )
-- COMMENT '用户视频评分历史全量表'
-- PARTITIONED BY(dt STRING)
-- ROW FORMAT DELIMITED
-- FIELDS TERMINATED BY '\001'
-- STORED AS PARQUET
-- LOCATION '/olap/da/recy_final_out_topk/';
ALTER TABLE da.recy_final_out_topk ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/da/recy_final_out_topk/${datebuf}/';

# update recommend dataset
CREATE EXTERNAL TABLE IF NOT EXISTS dm.dm_recommend_video
(
   rowkey String,
   vid String,
   title String,
   pic String,
   short_title String,
   score double,
   hits_total BigInt,
   comment_total BigInt,
   createtime String
)
STORED BY 'org.apache.hadoop.hive.hbase.HBaseStorageHandler'
WITH SERDEPROPERTIES ("hbase.columns.mapping" = ":key,f:vid,f:title,f:pic,f:short_title,f:score,f:hits_total,f:comment_total,f:createtime")
TBLPROPERTIES("hbase.table.name" = "dm_recommend_video");

-- hbase cli
-- disable 'dm_recommend_video'
-- alter 'dm_recommend_video', NAME => 'f', TTL => '259200'
-- enable 'dm_recommend_video'


INSERT OVERWRITE TABLE dm.dm_recommend_video
SELECT
  CONCAT(diu, '_', regexp_replace(dt, '-', ''), '_', vid) rowkey,
  vid,
  title,
  pic,
  short_title,
  prediction,
  hits_total,
  comment_total,
  createtime
FROM
  da.recy_final_out_topk
WHERE
  diu != '000000000000000'
AND dt = '${datebuf}';