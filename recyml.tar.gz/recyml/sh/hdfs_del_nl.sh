#! /bin/bash

# delete near_real_time cluster hdfs data
source /etc/profile 
export PATH=${PATH}
date=`date -d" 4 day ago" +"%Y%m%d"`
year=`date -d"$date" +"%Y"`
month=`date -d"$date" +"%m"`
day=`date -d"$date" +"%d"`

datebuf=$1

if [ -z "$1" ] ;then
year=$year
month=$month
day=$day
else
if [ -n "$1" ] && [ ${#datebuf} -eq 10 ]; then
year=${datebuf:0:4}
month=${datebuf:5:2}
day=${datebuf:8:2}
else
echo "`date` [ERROR] ----------- parameter error! please check it once again! dateformat eg:2013-09-01"
exit 0
fi
fi

yesterday=`date -d" 1 day ago" +"%Y-%m-%d"`
if [ $1 == $yesterday ]; then
echo "`date` [ERROR] ----------- can't delete files of yesterday"
exit 0 
fi 

########################################
hadoop=$HADOOP_HOME/bin/hadoop
hive=$HIVE_HOME/bin/hive
########################################

datebuf=$year-$month-$day
echo "`date` [INFO] ----------- rundate:" $datebuf 

########################################
echo "`date` [INFO] ----------- delete job begin ---------"
########################################

# delete near_real_time cluster hdfs data
threedaysago=`date -d" 4 day ago" +"%Y-%m-%d"`
flume_threedaysago=`date -d" 4 day ago" +"%y-%m-%d"`

$hive -e "ALTER TABLE dw.uamini drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dw/uamini/${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_recommend drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_recommend/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_recommend_pre drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_recommend_pre/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity_topn drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity_topn/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_out_topk drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_out_topk/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.user_video drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_video/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.user_video_bias1 drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_video_bias1/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.user_video_bias2 drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_video_bias2/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.user_video_index drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_video_index/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.user_video_rating drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_video_rating/dt=${threedaysago}/

$hadoop fs -rmr -skipTrash /flume/${flume_threedaysago}/

$hadoop fs -rmr -skipTrash /olap/dm/recy_als_model/${threedaysago}/

$hive -e "ALTER TABLE dm.recy_als_data_uvm drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_als_data_uvm/${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity_nearline drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity_nearline/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_cold_pop drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_cold_pop/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_city_pop_topk drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_city_pop_topk/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_data_viewed_videos drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_data_viewed_videos/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity_mid drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity_mid/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity_pre drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity_pre/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity_recently drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity_recently/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_icf_similarity_topn_hourcdc drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_icf_similarity_topn_hourcdc/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_lite_hour_cpcold drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_lite_hour_cpcold/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.video_index_day drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/video_index_day/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.video_index_hour drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/video_index_hour/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_ltr_diumapping drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_ltr_diumapping/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_ltr_itfeature drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_ltr_itfeature/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_ltr_itfeature_libsvm drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_ltr_itfeature_libsvm/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_ltr_usfeature drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_ltr_usfeature/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.recy_ltr_vidmapping drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/recy_ltr_vidmapping/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.user_profile drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_profile/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.mid_video_cmpv drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/mid_video_cmpv/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.mid_video_ex drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/mid_video_ex/dt=${threedaysago}/

$hive -e "ALTER TABLE dm.f_new_video_vv drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/f_new_video_vv/${threedaysago}/

$hive -e "ALTER TABLE dm.f_new_video_dv drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/f_new_video_dv/${threedaysago}/

$hive -e "ALTER TABLE dm.user_dvlog drop if exists PARTITION (dt='${threedaysago}')"
$hadoop fs -rmr -skipTrash /olap/dm/user_dvlog/${threedaysago}/

########################################
echo "`date` [INFO] ----------- delete job end ---------"
########################################

# del hdfs overdue files
# 00 07 * * * cd /home/hadoop/user/wenlong/crontab && ./hdfs_del_nl.sh >> /home/hadoop/user/wenlong/crontab/hdfs_del.log 2>&1

