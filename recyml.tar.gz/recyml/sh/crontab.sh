/home/hadoop/spark/bin/spark-submit  --master yarn --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/raw2ua.py 2016-12-22
ALTER TABLE dw.uabigger ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/dw/uabigger/2016-12-14/'

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/uvrating.py 2016-12-22
ALTER TABLE da.recy_als_data_uvr ADD IF NOT EXISTS
PARTITION (dt='2016-09-02') LOCATION '/olap/da/recy_als_data_uvr/2016-09-02/'

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/uvmerge.py 2016-12-22
ALTER TABLE da.recy_als_data_uvm ADD IF NOT EXISTS
PARTITION (dt='2016-12-15') LOCATION '/olap/da/recy_als_data_uvm/2016-12-15/';

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candya.py 2016-12-22
ALTER TABLE da.recy_als_data_candya ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_data_candya/2016-12-14/';

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/candytag.py 2016-12-22
ALTER TABLE da.recy_als_data_candytag ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_data_candytag/2016-12-14/';

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finalcandy.py 2016-12-22
ALTER TABLE da.recy_als_data_finalcandy ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_data_finalcandy/2016-12-14/';

#ALS 是模型，不建表
/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/als.py 2016-12-22


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/prediction.py 2016-12-22
ALTER TABLE da.recy_als_prediction ADD IF NOT EXISTS
PARTITION (dt='2016-12-14') LOCATION '/olap/da/recy_als_predict/2016-12-13/';


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/topk.py 2016-12-22
ALTER TABLE da.recy_als_out_topk ADD IF NOT EXISTS
PARTITION (dt='2016-12-15') LOCATION '/olap/da/recy_als_out_topk/2016-12-15/';


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/finaltopk.py 2016-12-22
ALTER TABLE da.recy_fianl_out_topk ADD IF NOT EXISTS
PARTITION (dt='2016-12-15') LOCATION '/olap/da/recy_fianl_out_topk/2016-12-15/';