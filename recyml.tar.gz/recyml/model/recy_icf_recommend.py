#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
Generate user rating on video Day by Day.

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    filterDate = handleDatePath(sys.argv, '%Y-%m-%d', 4)
    actDate=handleDatePath(sys.argv,'%Y-%m-%d',15)
    print inDate
    print actDate

    ############## recommend_pre
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_recommend_pre:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=600")
    recPreDir = "hdfs://Ucluster/olap/da/recy_icf_recommend_pre/"+inDate+"/"
    recPreSql = "select diu, vid_2 vid, sum(rating*similarity) rating, max(vid) from_vid from (select * from da.recy_icf_similarity_topn where dt='" +inDate+"') b join (select diu, vid, rating from da.recy_cf_rating_online where actdate>='"+actDate+"') c on (b.vid_1=c.vid) group by diu, vid_2"
    # recPreSql = "select diu, vid_2 vid, sum(rating*similarity) rating, max(vid) from_vid from (select * from da.recy_icf_similarity_topk where dt='" +inDate+"') b join (select diu, vid, rating from da.recy_cf_eval_sample where type='train') c on (b.vid_1=c.vid) group by diu, vid_2"

    print recPreSql
    df = spark.sql(recPreSql)
    df.printSchema()
    df.repartition(600).write.mode('overwrite').save(recPreDir, format="parquet")

    addPartSql = "ALTER TABLE da.recy_icf_recommend_pre ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_icf_recommend_pre/"+inDate+"/'"
    print addPartSql
    spark.sql(addPartSql)

    spark.stop()

    ############## recommend_
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_recommend:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=600")
    recDir = "hdfs://Ucluster/olap/da/recy_icf_recommend/"+inDate+"/"
    recSql = "SELECT a.* FROM (SELECT d.diu, d.vid, d.rating, d.from_vid, ROW_NUMBER() OVER (PARTITION BY d.diu ORDER BY d.rating DESC) rank FROM (SELECT * FROM da.recy_icf_recommend_pre WHERE dt='" +inDate+"') d LEFT OUTER JOIN da.recy_cf_rating_online e ON (d.diu=e.diu AND d.vid=e.vid) WHERE e.diu IS NULL) a LEFT OUTER JOIN (SELECT diu , vid FROM da.recy_final_out_topk WHERE dt>='"+filterDate+"'AND dt<'"+inDate+"'GROUP BY diu, vid)b ON (a.diu=b.diu AND a.vid=b.vid) WHERE b.diu IS NULL"

    # recSql = "select d.diu, d.vid, d.rating, d.from_vid, ROW_NUMBER() OVER (PARTITION by d.diu order by d.rating desc) rank from (select * from da.recy_icf_recommend_pre where dt='" +inDate+"') d left outer join (select diu, vid from da.recy_cf_eval_sample where type='train') e on (d.diu=e.diu and d.vid=e.vid) where e.diu is null"


    print recSql
    recdf = spark.sql(recSql)
    recdf.printSchema()
    recdf.repartition(600).write.mode('overwrite').save(recDir, format="parquet")

    addPartSql2 = "ALTER TABLE da.recy_icf_recommend ADD IF NOT EXISTS PARTITION (dt='"+inDate+"') LOCATION '/olap/da/recy_icf_recommend/"+inDate+"/'"
    print addPartSql2
    spark.sql(addPartSql2)

    spark.stop()

#/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g /home/hadoop/user/wenlong/spark/recy_icf_recommend.py 2016-12-15
