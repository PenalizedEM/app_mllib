#!/usr/bin/python
# -*- coding: UTF-8 -*-

import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',1)
    buDate=handleDatePath(sys.argv,'%Y-%m-%d',0)

    print "business date==========================" + buDate
    print "run date===============================" + inDate

    #########################
    ## recy_icf_similarity_nearline
    #########################
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_nearline begin"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_nearline:' + buDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=600"
    spark.sql(setSparSQLPartNum)
    sql = "from (select a.*, create_date, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from (   select vid_1, vid_2, num_1, num_2, num_12, num_12/sqrt(num_1*num_2) similarity from da.recy_icf_similarity_mid union all select vid_2 as vid_1, vid_1 as vid_2, num_1, num_2, num_12, num_12/sqrt(num_1*num_2) similarity from da.recy_icf_similarity_mid ) a join (select vid, to_date(createtime) create_date from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) b on (a.vid_1=b.vid) join (select vid  from dw.video where parent_category not in ('65', '55', '54', '53', '47') and status=0 ) c on (a.vid_2=c.vid) ) a insert overwrite table da.recy_icf_similarity_nearline partition(dt='"+buDate+"',type='recently') select vid_1, vid_2,num_1, num_2, num_12, similarity, '24' where create_date>='"+inDate+"'insert overwrite table da.recy_icf_similarity_nearline partition(dt='"+buDate+"',type='oldly') select vid_1, vid_2,num_1, num_2, num_12, similarity,'24' where create_date<'"+inDate+"' and rank<=80"
    print sql
    spark.sql(sql)
    spark.stop()
    print "================>" + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + " recy_icf_similarity_nearline end"


