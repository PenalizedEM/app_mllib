#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 2

"""
big and lite video similarity

"""
import dateutil.parser
import json
import time
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.linalg import Vectors
from pyspark.ml.feature import VectorAssembler,StringIndexer
from pyspark.ml.feature import MinMaxScaler
from math import atan,pi
#from pyspark.ml.feature import MinMaxScaler
#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    liteActDate=handleDatePath(sys.argv,'%Y-%m-%d',14)
    bigActDate=handleDatePath(sys.argv,'%Y-%m-%d',7)
    onedayago=handleDatePath(sys.argv,'%Y-%m-%d',1)
    createDate= handleDatePath(sys.argv,'%Y-%m-%d',365)
    print "inDate",inDate
    print "liteActDate",liteActDate
    print "bigActDate",bigActDate
    print "onedayago",onedayago
    print "createDate",createDate

    # ################# similar pre
    simiPreDir = "hdfs://Ucluster/olap/da/recy_icf_similarity_pre_lite_big/"
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_pre_lite_big:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    simPreSql = "select a.diu, a.vid, num, a.type from (select c.* from (select * from da.recy_cf_rating_online where case when type='10' then actdate>='"+liteActDate+"'when type not in ('10','12') then actdate>='"+bigActDate+"'  end ) c join (select vid from dw.video where to_date(createtime)>='"+createDate+"'and sync=0 and uid>0 )d on (c.vid = d.vid) ) a join (select diu, count(1) vcnt from da.recy_cf_rating_online where actdate>='"+liteActDate+"'group by diu having vcnt<10000 ) b on (a.diu=b.diu)"
    print simPreSql
    simPreDF = spark.sql(simPreSql)
    simPreDF.printSchema()
    simPreDF.repartition(1200).write.mode('overwrite').save(simiPreDir, format="parquet")
    print simiPreDir

    spark.stop()


    ################# similarity topn compute
    spark = SparkSession.builder.master('yarn-client').appName('recy_icf_similarity_topn_lite_big:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    setSparSQLPartNum = "SET spark.sql.shuffle.partitions=2000"
    print setSparSQLPartNum
    spark.sql(setSparSQLPartNum)

    dropTabSqlLite = "drop table if exists da.recy_icf_similarity_mid_lite "
    print dropTabSqlLite
    spark.sql(dropTabSqlLite)
    simMidSqlLite = "create table da.recy_icf_similarity_mid_lite as select a.vid vid_1 , b.vid vid_2 , a.num num_1, b.num num_2, count(1) num_12 from (select * from da.recy_icf_similarity_pre_lite_big where type=10)  a join (select * from da.recy_icf_similarity_pre_lite_big where type=10) b on (a.diu=b.diu) where a.vid<b.vid group by a.vid, b.vid, a.num, b.num"
    print simMidSqlLite
    spark.sql(simMidSqlLite)

    dropTabSqlBig = "drop table if exists da.recy_icf_similarity_mid_big "
    print dropTabSqlBig
    spark.sql(dropTabSqlBig)
    simMidSqlBig = "create table da.recy_icf_similarity_mid_big as select a.vid vid_1 , b.vid vid_2 , a.num num_1, b.num num_2, count(1) num_12 from (select * from da.recy_icf_similarity_pre_lite_big where type<>10) a join (select * from da.recy_icf_similarity_pre_lite_big where type<>10) b on (a.diu=b.diu) where a.vid<b.vid group by a.vid, b.vid, a.num, b.num"
    print simMidSqlBig
    spark.sql(simMidSqlBig)


    dropTabSimLite = "drop table if exists da.recy_icf_similarity_topn_big "
    print dropTabSimLite
    spark.sql(dropTabSimLite)
    simLiteSql = "create table da.recy_icf_similarity_topn_big as select vid_1, vid_2, similarity, rank from (select vid_1, vid_2, similarity, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from (select vid_1, vid_2, num_1, num_2, num_12, num_12/sqrt(num_1*num_2) similarity from da.recy_icf_similarity_mid_big union all select vid_2 as vid_1, vid_1 as vid_2, num_2 as num_1, num_1 as num_2, num_12, num_12/sqrt(num_1*num_2) similarity from da.recy_icf_similarity_mid_big ) a ) b where rank<= 50"
    print simLiteSql
    similarDF = spark.sql(simLiteSql)
    similarDF.printSchema()

    dropTabSimBig = "drop table if exists da.recy_icf_similarity_topn_lite "
    print dropTabSimBig
    spark.sql(dropTabSimBig)
    simBigSql = "create table da.recy_icf_similarity_topn_lite as select vid_1, vid_2, similarity, rank from (select vid_1, vid_2, similarity, ROW_NUMBER() OVER (PARTITION by vid_1 order by similarity desc) rank from (select vid_1, vid_2, num_1, num_2, num_12, num_12/sqrt(num_1*num_2) similarity from da.recy_icf_similarity_mid_lite union all select vid_2 as vid_1, vid_1 as vid_2, num_2 as num_1, num_1 as num_2, num_12, num_12/sqrt(num_1*num_2) similarity from da.recy_icf_similarity_mid_lite ) a ) b where rank<= 100"
    print simBigSql
    similarDF = spark.sql(simBigSql)
    similarDF.printSchema()

    spark.stop()

