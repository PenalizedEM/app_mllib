#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ May 8

"""
 Implementation of LR to rank 
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler,StringIndexer,OneHotEncoder,StandardScaler
from pyspark.ml.evaluation import BinaryClassificationEvaluator

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    exDate = handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_rank_lrpredict:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
   
    #读取item特征
    itPath = "hdfs://Ucluster/olap/da/recy_ltr_itfeature/"+inDate+"/"
    itFeaDF = spark.read.parquet(itPath)
    itFeaDF.createOrReplaceTempView("itFea")
    itFeaDF.printSchema()
    itFeaDF.show()
    #读取user特征
    usPath = "hdfs://Ucluster/olap/da/recy_ltr_usfeature/"+inDate+"/"
    usFeaDF = spark.read.parquet(usPath)
    usFeaDF.createOrReplaceTempView("usFea")
    usFeaDF.printSchema()
    usFeaDF.show()
    #组合特征
    alsSQL="SELECT c.*,d.f_diu,features as usfeatures  from (SELECT a.*,b.f_vid,b.vid as bvid,b.features as itfeatures from (SELECT diu,vid,prediction as pred  FROM da.recy_final_out_topk WHERE dt='"+inDate+"')a JOIN (SELECT vid,f_vid, features  FROM itFea)b ON (a.vid = b.vid))c join (SELECT * from usFea)d on (c.diu = d.diu)"
    alsDF = spark.sql(alsSQL)
    alsDF.printSchema()
    alsDF.show()
    scaledData = handleVec(rawFeaList,alsDF)
    predictData = scaledData.select("diu","vid","pred","features")
    #读入模型
    
    spark.stop()
