#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ May 8

"""
 Implementation of LR to rank
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler,StringIndexer,OneHotEncoder,StandardScaler
from pyspark.ml.evaluation import BinaryClassificationEvaluator

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_context:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()
    spark.sql("SET spark.sql.shuffle.partitions=400")
    #关联
    joinSQL = "INSERT OVERWRITE TABLE da.recy_ltr_context partition(dt='"+inDate+"')  SELECT a.u_diu as diu , a.u_vid as vid, a.u_ruuid as ruuid, a.u_rsource as rsource, a.u_rank as rank,ctime,if(b.u_diu is NULL or b.u_vid is NULL,0,1)label from (SELECT u_diu, u_vid, u_ruuid, u_rsource, u_rank, max(u_timestamp)ctime from edw.user_dvlog where dt='"+inDate+"' and u_client_module in ('推荐流','推荐') group by u_diu,u_vid,u_ruuid,u_rsource,u_rank )a left outer join (SELECT u_diu,u_vid,get_json_object(u_bigger_json,'$.u_ruuid')u_ruuid,get_json_object(u_bigger_json,'$.u_rank')u_rank from edw.user_ilog where dt='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' and u_client_module in ('推荐流','推荐') )b on(a.u_diu = b.u_diu and  a.u_vid = b.u_vid and a.u_ruuid = b.u_ruuid AND a.u_rank = b.u_rank)"
    #joinSQL = "INSERT OVERWRITE TABLE da.recy_ltr_context partition(dt='"+inDate+"')  SELECT a.u_diu as diu , a.u_vid as vid, a.u_ruuid as ruuid, a.u_rsource as rsource, a.u_rank as rank,ctime,if(b.u_diu is NULL or b.u_vid is NULL,0,1)label from (SELECT u_diu, u_vid, u_ruuid, u_rsource, u_rank, u_timestamp as ctime from edw.user_dvlog where dt='"+inDate+"' and u_client_module in ('推荐流','推荐')  )a left outer join (SELECT u_diu,u_vid,get_json_object(u_bigger_json,'$.u_ruuid')u_ruuid,get_json_object(u_bigger_json,'$.u_rank')u_rank from edw.user_ilog where dt='"+inDate+"' and concat(u_mod,'-',u_ac)='top-hits' and u_client_module in ('推荐流','推荐') )b on(a.u_diu = b.u_diu and  a.u_vid = b.u_vid and a.u_ruuid = b.u_ruuid AND a.u_rank = b.u_rank)"
    spark.sql(joinSQL)
    # ltrJoinDF.printSchema()
    # ltrJoinDF.show()
    # ltrJoinDF.createOrReplaceTempView("ltrfe")
    spark.stop()
