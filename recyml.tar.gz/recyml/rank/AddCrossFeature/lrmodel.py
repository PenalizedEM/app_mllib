#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ May 8

"""
 Implementation of LR to rank 
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime, date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row, SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row, SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder, StandardScaler
from pyspark.ml.evaluation import BinaryClassificationEvaluator
import subprocess


# 接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList, dateFormat, days):
    if len(dateList) == 1:
        # yes = date.today() - timedelta(1)
        days += 1
        datePath = (date.today() - timedelta(days)).strftime(dateFormat)
        # print datePath
    elif len(dateList) == 2:
        datePath = (datetime.strptime(dateList[1], '%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        # print datePath
    return datePath

#
# # 特征转换
# def vecTrans(rawList, noList, df):
#     vecList = list()
#     vecList.extend(noList)
#     for raw in rawList:
#         vec = raw + "_vec"
#         encode = OneHotEncoder(inputCol=raw, outputCol=vec)
#         df = encode.transform(df)
#         vecList.append(vec)
#     assembler = VectorAssembler(inputCols=vecList, outputCol="crossfeatures")
#     output = assembler.transform(df)
#     return output


# 特征组合以及标准化
def handleVec(rawFeaList, data):
    assembler = VectorAssembler(inputCols=rawFeaList, outputCol="rawfeatures")
    output = assembler.transform(data)
    scaler = StandardScaler(inputCol="rawfeatures", outputCol="features",
                            withStd=True, withMean=False)
    scalerModel = scaler.fit(output)
    scaledData = scalerModel.transform(output)
    return scaledData


# 定义Schema
def conSchema(colList):
    colDict = OrderedDict()
    for col in colList:
        colDict[col] = StructField(col, StringType(), True)
    schema = StructType(list(colDict.values()))
    return schema


# 删除HDFS上指定特征目录
def delOldDir(path):
    args_list = ['hadoop', 'fs', '-rmr', path]
    # 用HDFS命令去判断
    proc = subprocess.Popen(args_list, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    proc.communicate()
    print proc.returncode
    ##返回0代表已经删除


# 主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate = handleDatePath(sys.argv, '%Y-%m-%d', 0)
    # exDate = handleDatePath(sys.argv, '%Y-%m-%d', 2)
    print "inDate  ", inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_ltr_rank_lrmodel:' + inDate).config(
        'spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=600")
    Path = "hdfs://Ucluster/olap/da/recy_ltr_ltrdata/" + inDate + "/"
    FeaDF = spark.read.parquet(Path)
    FeaDF.printSchema()
    FeaDF.show()

    # 合并两个特征向量,并标准化
    rawFeaList = ['itfeatures', 'usfeatures']
    scaledData = handleVec(rawFeaList, FeaDF)
    cleanData = scaledData.select("features", "label")


    # savePath = "hdfs://Ucluster/olap/da/ltr_feature_label"+inDate+"/"
    # cleanData.write.mode('overwrite').save(savePath, format="parquet")
    # print "write ok"


    # allFeaPath = "hdfs://Ucluster/test/ltrfeature/"+inDate+"/"
    # cleanData.write.mode('overwrite').save(allFeaPath, format="parquet")
    # cleanData.createOrReplaceTempView("sample")
    # labelSql = "select label,count(1)pv from sample group by label"
    # labelCount = spark.sql(labelSql)
    # labelCount.show()
    # 划分训练集和测试集
    (training, test) = cleanData.randomSplit([0.8, 0.2])
    lr = LogisticRegression(maxIter=10, regParam=0.01)

    # Fit the model
    lrModel = lr.fit(training)
    result = lrModel.transform(test)
    evaluator = BinaryClassificationEvaluator()
    auc = evaluator.evaluate(result)
    pr = evaluator.evaluate(result, {evaluator.metricName: "areaUnderPR"})
    print auc
    print pr


    # # Fit the model
    # lrModel = lr.fit(cleanData)
    # lr_path = "hdfs://Ucluster/olap/da/recy_ltr_model/" + inDate + "/"
    # # 给服务端使用
    # delOldDir(lr_path)
    # lrModel.save(lr_path)
    # # 应用在ALS模型粗排序
    # alsSQL = "SELECT c.*,d.f_diu,features as usfeatures  from (SELECT a.*,b.f_vid,b.vid as bvid,b.features as itfeatures from (SELECT diu,vid,prediction as pred  FROM da.recy_final_out_topk WHERE dt='" + inDate + "')a JOIN (SELECT vid,f_vid, features  FROM itFea)b ON (a.vid = b.vid))c join (SELECT * from usFea)d on (c.diu = d.diu)"
    # alsDF = spark.sql(alsSQL)
    # alsDF.printSchema()
    # alsDF.show()
    # scaledData = handleVec(rawFeaList, alsDF)
    # predictData = scaledData.select("diu", "vid", "pred", "features")
    # result = lrModel.transform(predictData).select("diu", "vid", "probability")
    # # sk.show(n=200)
    # finalRS = result.rdd.map(lambda x: [x.diu, x.vid, float(x.probability.values[1])])
    # print finalRS.take(1)
    # colList = ["diu", "vid", "pp"]
    # sq = spark.createDataFrame(finalRS, "diu: string, vid: string,pp: float")
    # sq.printSchema()
    # sq.show()
    # # print sq.count()
    # outPath = "hdfs://Ucluster/olap/da/recy_ltr_predict/" + inDate + "/"
    # sq.write.mode('overwrite').save(outPath, format="parquet")

    spark.stop()
