#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ May 8

"""
 cp clustering for remmendation
"""
import dateutil.parser
import json
import time
import itertools
from datetime import datetime,date, timedelta
from dateutil import tz
import re
import sys
from collections import OrderedDict
from pyspark.sql import Row,SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row,SparkSession
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.classification import LogisticRegression, LogisticRegressionModel
from pyspark.ml.feature import VectorAssembler,StringIndexer,OneHotEncoder,StandardScaler
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.clustering import KMeans

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath
#计算时间差   
def days_between(d1, d2):
    d1 = datetime.strptime(d1, "%Y-%m-%d")
    d2 = datetime.strptime(d2, "%Y-%m-%d")
    return abs((d2 - d1).days)
#定义Schema
def conSchema(colList):
    colDict = OrderedDict()
    for col in colList:
        colDict[col] = StructField(col, StringType(), True)
    schema = StructType(list(colDict.values()))
    return schema
#特征转换
def vecTrans(rawList,df):
    vecList = list()
    #vecList.extend(noList)
    for raw in rawList:
        vec = raw+"_vec"
        encode = OneHotEncoder(inputCol=raw, outputCol=vec)
        df = encode.transform(df)
        vecList.append(vec) 
    assembler = VectorAssembler(inputCols=vecList, outputCol="features")
    output = assembler.transform(df)
    return output

#主入口
if __name__ == "__main__":
    print sys.argv
    reload(sys)
    sys.setdefaultencoding('utf-8')
    inDate=handleDatePath(sys.argv,'%Y-%m-%d',0)
    exDate = handleDatePath(sys.argv,'%Y-%m-%d',2)
    print "inDate  ",inDate
    spark = SparkSession.builder.master('yarn-client').appName('recy_cp_cluster:'+inDate).config('spark.sql.warehouse.dir', '/user/hive/warehouse').enableHiveSupport().getOrCreate()

    spark.sql("SET spark.sql.shuffle.partitions=250")
    #特征选择和处理
    cpSQL = "SELECT c.*,d.fan,d.name from (SELECT a.*,cast(b.client as int)client,cast(b.type as int)type,datediff('"+inDate+"',substr(b.regtime,0,10))regdays,b.sign,b.groupid,cast(b.level as int)level FROM(SELECT uid,cast(count(1) as int)pv,cast(sum(hits_total) as int)hits,cast(sum(share) as int)share from dw.video group by uid)a join (select * from dw.user)b on(a.uid=b.id))c join (select id,name,fan from da.user_full)d on(c.uid=d.id) "
    print cpSQL
    itemDF = spark.sql(cpSQL)
    itemDF.printSchema()
    itemDF.show()
    #特征选择
    rawFeaList = ['pv','hits','share','client','regdays','sign','groupid','level','fan']
    assembler = VectorAssembler(inputCols=rawFeaList, outputCol="features")
    output = assembler.transform(itemDF)
    output.printSchema()
    output.show()
    # Trains a k-means model.
    kmeans = KMeans().setK(50).setSeed(1)
    model = kmeans.fit(output)
    transformed = model.transform(output).select("uid", "name","prediction")
    transformed.printSchema()
    transformed.show()
    transformed.createOrReplaceTempView("uscluster")
    uscSQL =  "INSERT OVERWRITE TABLE da.recy_cp_cluster partition(dt='"+inDate+"')  SELECT  * from uscluster group by uid,name,prediction"
    spark.sql(uscSQL)
    # # Evaluate clustering by computing Within Set Sum of Squared Errors.
    # wssse = model.computeCost(output)
    # print("Within Set Sum of Squared Errors = " + str(wssse))

    # # Shows the result.
    # centers = model.clusterCenters()
    # print("Cluster Centers: ")
    # for center in centers:
    #     print(center)
    spark.stop()
