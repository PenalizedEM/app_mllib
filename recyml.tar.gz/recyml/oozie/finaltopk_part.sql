ALTER TABLE da.recy_als_data_finalcandy ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/da/recy_fianl_out_topk/${datebuf}'