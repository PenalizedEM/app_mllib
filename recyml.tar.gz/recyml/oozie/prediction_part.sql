ALTER TABLE da.recy_als_data_candya ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/da/recy_als_prediction/${datebuf}'