ALTER TABLE da.recy_als_data_candytag ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/da/recy_als_data_candytag/${datebuf}'