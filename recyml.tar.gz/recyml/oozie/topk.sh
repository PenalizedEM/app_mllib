#!/bin/bash
source /etc/profile
echo "begin spark program "
/home/hadoop/spark/bin/spark-submit  --master yarn-cluster --py-files hdfs://Ucluster/user/3pjar/dateutil.zip,hdfs://Ucluster/user/3pjar/six.py --num-executors 16 --executor-cores 6 --executor-memory 12g hdfs://Ucluster/user/3pjar/topk.py
echo "end spark program "