ALTER TABLE da.recy_als_data_uvr ADD IF NOT EXISTS
PARTITION (dt='${datebuf}') LOCATION '/olap/da/recy_als_data_uvr/${datebuf}'