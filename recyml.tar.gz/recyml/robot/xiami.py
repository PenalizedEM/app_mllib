#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Dec 15
"""
download music tag data from xiami

"""
import requests
from datetime import datetime
import time

def timer(n):
    while True:
    	url = "https://aa.tangdou.com:12308/api.php?mod=top&ac=hits&vid=9187543&cdn_source=ucloud&source=发现推荐&rsource=1&ruuid=1819237123341943817&rank=5&rmodelid=-1&strategyid=111&client_module=推荐流&page=1&position=5&client=2&uuid=0c6b18ec8e4effb399d2fe3d7c68f098&device=A11-Android:4.4.4&channel=oppo&ver=v2&package=com.bokecc.dance&version=6.0.7&smallvideo=1&lon=117.967532&lat=28.423062&city=上饶市&province=江西省&xinge=Au8GgkFa_ypz-kA6zPvMvnyIgZ6gL0q4Z-CX4Nvaycg2&div=6.0.7&dic=oppo&diu=867578023535658&diu2=bc3aeabd0c76&diu3=1b2fdc95fd1d45cd89d3414653560b5a&startid=54132498&stepid=7&width=480&height=854&nettype=WIFI&netop=移动&sdkversion=4.4.4&model=A11&device_s=A11&manufacture=OPPO&time=1505710185596&hash=c0e31738067bf9e63648157e7896f7f4"
        getURL(url)
        time.sleep(n)

def createHashedQueryString(qdict)：

def  getURL(url):
	response = requests.post(url)
	content = requests.post(url).content
	#print "response headers:", response.headers
	print "content:", content
	#print response.cookies
#主入口
if __name__ == "__main__":
	timer(1)



	# public static String createHashedQueryString(Map<String, String> queryMap, long time, String salt) {

	# 	Map<String, String> map = new TreeMap<String, String>(queryMap);
	# 	String qs = createQueryString(map);
	# 	if (qs == null) {
	# 		return null;
	# 	}
		
	# 	time = time / 1000;
	# 	String hash = Md5Encrypt.md5(String.format("%s&time=%d&salt=%s", qs, time, salt));
	# 	hash = hash.toLowerCase();
	# 	String htqs = String.format("%s&time=%d&hash=%s", qs, time, hash);

	# 	return htqs;
	# }


	# 	public static String createQueryString(Map<String, String> queryMap) {

	# 	if (queryMap == null) {
	# 		return null;
	# 	}

	# 	try {
	# 		StringBuilder sb = new StringBuilder();
	# 		for (Map.Entry<String, String> entry : queryMap.entrySet()) {
	# 			if (entry.getValue() == null) {
	# 				continue;
	# 			}
	# 			String key = entry.getKey().trim();
	# 			String value = URLEncoder.encode(entry.getValue().trim(), "utf-8");
	# 			sb.append(String.format("%s=%s&", key, value));
	# 		}
	# 		return sb.substring(0, sb.length() - 1);
	# 	} catch (StringIndexOutOfBoundsException e) {
	# 		Log.e(TAG, e.getMessage());
	# 		return null;
	# 	} catch (UnsupportedEncodingException e) {
	# 		Log.e(TAG, e.getMessage());
	# 		return null;
	# 	}
	# }