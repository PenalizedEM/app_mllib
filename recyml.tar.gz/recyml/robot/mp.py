from multiprocessing import Pool
import os, time, random
import requests
import multiprocessing
import time

def long_time_task(name):
    print 'Run task %s (%s)...' % (name, os.getpid())
    start = time.time()
    time.sleep(random.random() * 3)
    end = time.time()
    print 'Task %s runs %0.2f seconds.' % (name, (end - start))


def getUrl(url):
	#response = requests.post(url)
	content = requests.post(url).content
	print "content:", content

if __name__=='__main__':
    print 'Parent process %s.' % os.getpid()
	url = "https://aa.tangdou.com:12308/api.php?mod=top&ac=hits&vid=2956526&cdn_source=ucloud&source=发现推荐&rsource=1&ruuid=1819278867496436743&rank=9&rmodelid=-1&strategyid=111&client_module=推荐流&page=5&position=81&client=2&uuid=b471b27a655c30e39f00ff1c96f85764&device=Y685C-Android:5.1&channel=meizu&ver=v2&package=com.bokecc.dance&version=6.0.7&smallvideo=1&token=d2ddaeb258e533cd72d0918631ff1e89&uid=2865595&lon=0.0&lat=0.0&xinge=Ak-pOaM0UMtFOHzfX-MtfB9YSCjjeiCQRqUMdn8opti-&div=6.0.7&dic=meizu&diu=861400038257689&diu2=UNKNOWN&diu3=b49aaf021c0746019d324aeb91534025&startid=54132267&stepid=9&width=720&height=1280&nettype=WIFI&netop=移动&sdkversion=5.1&model=Y685C&device_s=M3s&manufacture=Meizu&time=1505710185913&hash=dc16bae4e4cdd799953ca344e7a9fa7a"
    p = Pool()
    for i in range(5):
        p.apply_async(getUrl, args=(url,))
        i = i +1
    print 'Waiting for all subprocesses done...'
    print "i",str(i)
    p.close()
    p.join()
    print 'All subprocesses done.'
