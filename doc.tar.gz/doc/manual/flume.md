Flume入门
====
## 1. Flume简介
* Flume是一个分布式、可靠、高可用的海量日志收集、聚合以及传输服务。Flume提出了一种简单、灵活的数据流架构，它具备良好鲁棒性、容错性以及错误恢复机制。Flume采用的简单的可扩展数据模型，使得它被经常应用在在线数据分析应用中。


## 2. Flume架构
* Flume包括以下核心概念：
  * Event：最小的数据单元(日志或者消息)，带有一个可选的消息头
  * Flow：Event从源点到达目的点的迁移的抽象
  * Client：操作位于源点处的Event，将其发送到Flume Agent
  * Agent：一个独立的Flume进程，包含组件Source、Channel、Sink
  * Source：用来消费传递到该组件的Event
  * Channel：中转Event的一个临时存储，保存有Source组件传递过来的Event
  * Sink：从Channel中读取并移除Event，将Event传递到Flow Pipeline中的下一个Agent（如果有的话）

**简单的Flume架构图：**

![Flume架构图](img/Flume.png)



* Flume 的数据源可以是web服务器的日志文件，也可以是消息队列(1.6.0支持kafka)，还可以是另外一个flume agent 的sink等等任意的数据事件,可以看做数据流的源头。

* Flume一旦采集到数据，就会存储到一个或者多个Channel，一直到flume sink消费完这条数据才会删除。

* Flume sink会将channel中读取的数据写入外部存储，可以是HDFS，也可以是另外flume source，然后删除该条数据。

## 3. Flume Kafka 配置文件
tdhadoop  离线集群的flume 部署在 C机房 test_001(10.10.122.164)
tdnearline 近线集群的flume 部署在 D机房 基础数据平台_host3（10.19.164.182）

```java

# ------------------- 定义数据流----------------------
# source的名字
agent.sources = kafkaSource
# channels的名字
#agent.channels = memoryChannel
agent.channels = fileChannel
# sink的名字
agent.sinks = hdfsSink

# 指定source使用的channel名字
agent.sources.kafkaSource.channels = fileChannel
# 指定sink需要使用的channel的名字,注意这里是channel
agent.sinks.hdfsSink.channel = fileChannel

#-------- kafkaSource相关配置-----------------
# 定义消息源类型
agent.sources.kafkaSource.type = org.apache.flume.source.kafka.KafkaSource
# 定义kafka所在zk的地址
agent.sources.kafkaSource.zookeeperConnect = ukafka-ghz0cc-1-bj04.service.ucloud.cn:2181,ukafka-ghz0cc-2-bj04.service.ucloud.cn:2181
# 配置消费的kafka topic
agent.sources.kafkaSource.topic = logstash
# 配置消费者组的id
agent.sources.kafkaSource.groupId = flume
# 消费超时时间
agent.sources.kafkaSource.kafka.consumer.timeout.ms = 200



#------- memoryChannel相关配置-------------------------
# channel类型
#agent.channels.memoryChannel.type = memory
# channel存储的事件容量
#agent.channels.memoryChannel.capacity=5000
# 事务容量
#agent.channels.memoryChannel.transactionCapacity=1000

#------- fileChannel相关配置-------------------------
agent.channels.fileChannel.type = file
agent.channels.fileChannel.checkpointDir = /data/flume/k1/checkpoint
agent.channels.fileChannel.dataDirs = /data/flume/k1/data

#---------hdfsSink 相关配置------------------
agent.sinks.hdfsSink.type = hdfs
agent.sinks.hdfsSink.hdfs.path = hdfs://Ucluster/flume/%y-%m-%d/%H
agent.sinks.hdfsSink.hdfs.filePrefix = log_%Y%m%d_%H
agent.sinks.hdfsSink.hdfs.useLocalTimeStamp = true
agent.sinks.hdfsSink.hdfs.writeFormat = Text
#agent.sinks.hdfsSink.hdfs.fileType = CompressedStream
agent.sinks.hdfsSink.hdfs.fileType = DataStream
# 上传文件的编码格式
agent.sinks.hdfsSink.custom.encoding = UTF-8
# 基于时间间隔来进行文件滚动
agent.sinks.hdfsSink.hdfs.rollInterval = 0
# 基于文件大小进行文件滚动
agent.sinks.hdfsSink.hdfs.rollSize = 104857600
# 基于event数量进行文件滚动
agent.sinks.hdfsSink.hdfs.rollCount = 0
# 写入HDFS文件块的最小副本数
agent.sinks.hdfsSink.hdfs.minBlockReplicas = 1
# 写入HDFS文件的压缩格式
agent.sinks.hdfsSink.hdfs.codeC = gzip
# 每个批次刷新到HDFS上的events数量
agent.sinks.hdfsSink.hdfs.batchSize = 1000
# hdfs sink启动的操作HDFS的线程数
agent.sinks.hdfsSink.hdfs.threadsPoolSize= 80
# 最大允许打开的HDFS文件数，当打开的文件数达到该值，最早打开的文件将会被关闭
# 默认一个topic 打开8个文件
agent.sinks.hdfsSink.hdfs.maxOpenFiles = 8


```

**启动命令**
```sh
nohup /home/hadoop/flume/bin/flume-ng agent -n  agent -c /home/hadoop/flume/conf  -f /home/hadoop/flume/conf/kafka.properties &
```


**后面一个agent 是flume agent的名称**


 ### 关键写入HDFS的块大小如何配置！！

Flume 启动时的最大堆内存大小默认是 20M，线上环境很容易 OOM，因此需要你在 flume-env.sh 中添加 JVM 启动参数:

```
JAVA_OPTS="-Xms8192m -Xmx8192m -Xss256k -Xmn2g -XX:+UseParNewGC
-XX:+UseConcMarkSweepGC -XX:-UseGCOverheadLimit"
```
配置java
/usr/lib/jvm/jre-1.7.0-openjdk.x86_64/bin/java

export PATH=$PATH:/usr/lib/jvm/jre-1.7.0-openjdk.x86_64/bin/java

export JAVA_HOME=/usr/lib/jvm/jre-1.7.0-openjdk.x86_64/
export PATH=$PATH:$JAVA_HOME/bin
export CLASSPATH=$JAVA_HOME/jre/lib/ext:$JAVA_HOME/lib/tools.jar

/opt/jdk1.7.0_79/bin/java
export PATH=$PATH:/opt/jdk1.7.0_79/bin/java
export JAVA_HOME=/opt/jdk1.7.0_79/
export PATH=$PATH:$JAVA_HOME/bin
export CLASSPATH=$JAVA_HOME/jre/lib/ext:$JAVA_HOME/lib/tools.jar

备份配置
```java
### HDFS  sink
agent_lxw1234.sinks.sink1.type = hdfs
agent_lxw1234.sinks.sink1.hdfs.path = hdfs://cdh5/tmp/lxw1234/%Y%m%d
agent_lxw1234.sinks.sink1.hdfs.filePrefix = log_%Y%m%d_%H
agent_lxw1234.sinks.sink1.hdfs.fileSuffix = .lzo
agent_lxw1234.sinks.sink1.hdfs.useLocalTimeStamp = true
agent_lxw1234.sinks.sink1.hdfs.writeFormat = Text
agent_lxw1234.sinks.sink1.hdfs.fileType = CompressedStream
agent_lxw1234.sinks.sink1.hdfs.rollCount = 0
agent_lxw1234.sinks.sink1.hdfs.rollSize = 0
agent_lxw1234.sinks.sink1.hdfs.rollInterval = 600
agent_lxw1234.sinks.sink1.hdfs.codeC = lzop
agent_lxw1234.sinks.sink1.hdfs.batchSize = 1000
agent_lxw1234.sinks.sink1.hdfs.threadsPoolSize = 10
agent_lxw1234.sinks.sink1.hdfs.idleTimeout = 0
agent_lxw1234.sinks.sink1.hdfs.minBlockReplicas = 1

The configuration file needs to define the sources,
# the channels and the sinks.
# Sources, channels and sinks are defined per agent,
# in this case called 'agent'

agent.channels = memoryChannel
agent.sinks = hdfsSink

# Each sink's type must be defined
agent.sinks.hdfsSink.type = hdfs
# topic 名称作为上传文件前缀
agent.sinks.hdfsSink.hdfs.filePrefix = %{topic}
# 上传文件的编码格式
agent.sinks.hdfsSink.custom.encoding = UTF-8
# 基于时间间隔来进行文件滚动
agent.sinks.hdfsSink.hdfs.rollInterval = 0
# 基于文件大小进行文件滚动
agent.sinks.hdfsSink.hdfs.rollSize = 104857600
# 基于event数量进行文件滚动
agent.sinks.hdfsSink.hdfs.rollCount = 0
# 写入HDFS文件块的最小副本数
agent.sinks.hdfsSink.hdfs.minBlockReplicas = 1
# 写sequence文件的格式
agent.sinks.hdfsSink.hdfs.writeFormat = Text
# 文件格式
agent.sinks.hdfsSink.hdfs.fileType = DataStream
# 每个批次刷新到HDFS上的events数量
agent.sinks.hdfsSink.hdfs.batchSize = 1000
# hdfs sink启动的操作HDFS的线程数
agent.sinks.hdfsSink.hdfs.threadsPoolSize= 100
# 最大允许打开的HDFS文件数，当打开的文件数达到该值，最早打开的文件将会被关闭
# 默认一个topic 打开一个文件
agent.sinks.hdfsSink.hdfs.maxOpenFiles = 1
# 上传hdfs的地址 默认每天一个文件夹
agent.sinks.hdfsSink.hdfs.path = hdfs://Ucluster/ukafka/%{topic}/%y-%m-%d

agent.sinks.hdfsSink.channel = memoryChannel

# Each channel's type is defined.
agent.channels.memoryChannel.type = memory
agent.channels.memoryChannel.transactionCapacity = 1500
agent.channels.memoryChanne3.keep-alive = 60
agent.channels.memoryChanne3.capacity = 1000000

# For each one of the sources, the type is defined
agent.sources.Src0.type=org.apache.flume.source.kafka.KafkaSource
agent.sources.Src0.zookeeperConnect=ukafka-ghz0cc-1-bj04.service.ucloud.cn:2181,ukafka-ghz0cc-2-bj04.service.ucloud.cn:2181,ukafka-ghz0cc-3-bj04.service.ucloud.cn:2181
agent.sources.Src0.inputCharset=UTF-8
agent.sources.Src0.topic=logstash
agent.sources.Src0.groupId=flume
agent.sources.Src0.interceptors=i1
agent.sources.Src0.interceptors.i1.type=timestamp
agent.sources.Src0.kafka.consumer.timeout.ms=100
agent.sources.Src0.channels=memoryChannel
agent.sources=Src0

```
a1.channels = c1
a1.channels.c1.type = file
a1.channels.c1.checkpointDir = /mnt/flume/checkpoint
a1.channels.c1.dataDirs = /mnt/flume/data
