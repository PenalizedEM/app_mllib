1、简介

- Hadoop Map/Reduce是一个使用简易的软件框架，基于它写出来的应用程序能够运行在由上千个商用机器组成的大型集群上，并以一种可靠容错的方式并行处理上T级别的数据集。
- 一个Map/Reduce 作业（job） 通常会把输入的数据集切分为若干独立的数据块，由 map任务（task）以完全并行的方式处理它们。框架会对map的输出先进行排序， 然后把结果输入给reduce任务。通常作业的输入和输出都会被存储在文件系统中。 整个框架负责任务的调度和监控，以及重新执行已经失败的任务。
- 虽然Hadoop是由java语言实现，但Map/Reduce不一定要由java来写
    - Hadoop Streaming是一种运行作业的实用工具，它允许用户创建和运行任何可执行程序 （例如：Shell工具）来做为mapper和reducer。
    - Hadoop Pipes是一个与SWIG兼容的C++ API （没有基于JNITM技术），它也可用于实现Map/Reduce应用程序。

2、应用场景

- MapReduce最早是由Google提出的分布式数据处理模型,随后受到了业内的广泛关注,并被大量应用到各种商业场景中。比如:
- 搜索:网页爬取、倒排索引、PageRank。
- Web访问日志分析:分析和挖掘用户在web上的访问、购物行为特征,实现个性化推荐;分析用户访问行为。
- 文本统计分析:比如莫言小说的WordCount、词频TFIDF分析;学术论文、专利文献的引用分析和统计;维基百科数据分析等。
- 海量数据挖掘:非结构化数据、时空数据、图像数据的挖掘。
- 机器学习:监督学习、无监督学习、分类算法如决策树、SVM等。
- 自然语言处理:基于大数据的训练和预测;基于语料库构建单词同现矩阵,频繁项集数据挖掘、重复文档检测等。
- 广告推荐:用户点击(CTR)和购买行为(CVR)预测。

3、处理流程

- MapReduce处理数据过程主要分成2个阶段:Map阶段和Reduce阶段。首先执行Map阶段,再执行Reduce阶段。Map和Reduce的处理逻辑由用户自定义实现,但要符合MapReduce框架的约定。
- 在正式执行Map前,需要将输入数据进行”分片”。所谓分片,就是将输入数据切分为大小相等的数 据块,每一块作为单个Map Worker的输入被处理,以便于多个Map Worker同时工作。
- 分片完毕后,多个Map Worker就可以同时工作了。每个Map Worker在读入各自的数据后,进行计 算处理,最终输出给Reduce。Map Worker在输出数据时,需要为每一条输出数据指定一个Key。这 个Key值决定了这条数据将会被发送给哪一个Reduce Worker。Key值和Reduce Worker是多对一的 关系,具有相同Key的数据会被发送给同一个Reduce Worker,单个Reduce Worker有可能会接收 到多个Key值的数据。
- 在进入Reduce阶段之前,MapReduce框架会对数据按照Key值排序,使得具有相同Key的数据彼此 相邻。如果用户指定了”合并操作”(Combiner),框架会调用Combiner,将具有相同Key的数据进 行聚合。Combiner的逻辑可以由用户自定义实现。与经典的MapReduce框架协议不同,在mr中 ,Combiner的输入、输出的参数必须与Reduce保持一致。这部分的处理通常也叫做”洗牌 ”(Shuffle)。
- 接下来进入Reduce阶段。相同的Key的数据会到达同一个Reduce Worker。同一个Reduce Worker会接收来自多个Map Worker的数据。每个Reduce Worker会对Key相同的多个数据进行 Reduce操作。最后,一个Key的多条数据经过Reduce的作用后,将变成了一个值。

4、图解处理流程

- 以WordCount为例,解释MapReduce各个阶段的概念。 假设存在一个文本a.txt,文本内每行是 一个数字,我们要统计每个数字出现的次数。文本内的数字称为Word,数字出现的次数称为Count。如果Mapreduce完成这一功能,需要经历下图描述的几个步骤:

- 首先对文本进行分片,将每片内的数据作为单个Map Worker的输入;
- Map处理输入,每获取一个数字,将数字的Count设置为1,并将此<Word, Count>对输出,此时以 Word作为输出数据的Key;
- 在Shuffle阶段前期,首先对每个Map Worker的输出,按照Key值,即Word值排序。排序后进行 Combine操作,即将Key值(Word值)相同的Count累加, 构成一个新的<Word, Count>对。此过程 被称为合并排序;
- 在Shuffle阶段后期,数据被发送到Reduce端。Reduce Worker收到数据后依赖Key值再次对数据排 序;
- 每个Reduce Worker对数据进行处理时,采用与Combiner相同的逻辑,将Key值(Word值)相同的 Count累加,得到输出结果;

5、Hadoop 2.0 Map/Reduce demo实战

- maven 依赖包配置
    - <repositories>
    <repository>
        <id>cloudera</id>
    -         <url>https://repository.cloudera.com/artifactory/cloudera-repos/</url>
    -     </repository>
</repositories>
<dependencies>
    <dependency>
        <groupId>org.apache.hadoop</groupId>

    -         <artifactId>hadoop-hdfs</artifactId>
    -         <version>2.6.0-cdh5.4.9</version>
    -     </dependency>
    <dependency>
        <groupId>org.apache.hadoop</groupId>

    -         <artifactId>hadoop-common</artifactId>
    -         <version>2.6.0-cdh5.4.9</version>
    -     </dependency>
    <dependency>
        <groupId>org.apache.hadoop</groupId>

    -         <artifactId>hadoop-mapreduce-client-app</artifactId>
    -         <version>2.6.0-cdh5.4.9</version>
    -     </dependency>
</dependencies>
    - hadoop fs -mkdir /user/hadoop/wenlong.zhang/input
    - hadoop fs -put ./wordcount_input.txt /user/hadoop/wenlong.zhang/input
    - hadoop jar wordcount.jar WordCount /user/hadoop/wenlong.zhang/input /user/hadoop/wenlong.zhang/output
    - hadoop fs -cat /user/wenlong.zhang/output/pa*
        - aaa    5
        - bbb    5
        - ccc    5
        - dddd    5
        - eee    5

6、参考
Hadoop MR官方文档 http://hadoop.apache.org/docs/r2.5.2/hadoop-mapreduce-client/hadoop-mapreduce-client-core/MapReduceTutorial.html
