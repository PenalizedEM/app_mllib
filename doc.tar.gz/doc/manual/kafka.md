kafka入门
===
### shipper configer

```sh
input {
file {
    path => [ "/data2/wwwlogs/access.log" ]
    start_position => "beginning"
    codec => json
}
}
filter{
urldecode {field=>"request" }}
output {
kafka {
bootstrap_servers => "ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092,ukafka-ghz0cc-2-bj04.service.ucloud.cn
:9092,ukafka-ghz0cc-3-bj04.service.ucloud.cn:9092,ukafka-ghz0cc-4-bj04.service.ucloud.cn
:9092"
topic_id => "logstash" }
}
```


### indexer configer
起了两个indexer ，consumer thread 之和要等于 kafka集群的topic的分区数
```sh
input {
  kafka {
     zk_connect => "ukafka-ghz0cc-1-bj04.service.ucloud.cn:2181,ukafka-ghz0cc-2-bj04.service.ucloud.cn:2181"
     topic_id => "logstash"
     type => "rs"
     consumer_threads => 6
  }
}
filter {
    if [request] {
        ruby {
            init => "@kname = ['method','uri','verb']"
            code => "event.append(Hash[@kname.zip(event['request'].split(' '))])"
        }
        if [uri] {
            ruby {
                init => "@kname = ['url_path','url_args']"
                code => "event.append(Hash[@kname.zip(event['request'].split('?'))])"
            }
            kv {
                prefix => "u_"
                source => "url_args"
                field_split => "& "
                remove_field => [ "url_args","uri","request","path" ]
            }
        }
    }
mutate {
        convert => ["u_rate", "integer"]
        convert => ["u_percent", "integer"]
        convert => ["u_buffertime", "integer"]
  }
}
output {
elasticsearch {
    hosts=>["10.10.178.40:9200","10.19.67.194:9200","10.19.114.162:9200","10.19.1.22:9200","10.19.47.96:9200","10.10.247.210:9200","10.10.98.103:9200","10.19.177.156:9200","10.19.170.180:9200","10.19.73.83:9200"]
    flush_size => 10000
    idle_flush_time => 60
}
}
```
