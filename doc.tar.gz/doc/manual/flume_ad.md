广告日志收集-版本flume1.6
一、在php服务所在的机器上部署flume
1.修改flume/conf/flume-env.sh

2.编辑ad.properties文件
# Name the components on this agent
flume-avro-sink-agent.sources = exec-source
flume-avro-sink-agent.sinks = avro-sink
flume-avro-sink-agent.channels = memory-channel

# Describe/configure the source
flume-avro-sink-agent.sources.exec-source.type = exec
flume-avro-sink-agent.sources.exec-source.command = tail -F /data2/wwwlogs/adlog.log
flume-avro-sink-agent.sources.exec-source.shell = /bin/bash -c

# Describe the sink
flume-avro-sink-agent.sinks.avro-sink.type = avro
flume-avro-sink-agent.sinks.avro-sink.hostname = 10.19.164.182
flume-avro-sink-agent.sinks.avro-sink.port = 33333

# Use a channel which buffers events in memory
flume-avro-sink-agent.channels.memory-channel.type = memory

# Bind the source and sink to the channel
flume-avro-sink-agent.sources.exec-source.channels = memory-channel
flume-avro-sink-agent.sinks.avro-sink.channel = memory-channel

二、在10.19.164.182机器上部署flume-collecter
1.修改flume/conf/flume-env.sh
2.复制hdfs-site.xml 到flume/conf/ 目录下,并把hdfs-site.xml中的master对应的ip 添加到/etc/hosts里
3.编辑ad.properties文件
#collecter
collecter.sources = s1
collecter.sinks = k1 k2
collecter.channels = c1 c2
#这里的是将同样的数据无差异sink到多个输出端，所以通道是复制模式
collecter.sources.s1.selector.type=replicating 

# Describe/configure the source
collecter.sources.s1.type = avro
collecter.sources.s1.bind = 10.19.164.182
collecter.sources.s1.port = 33333

# Describe the sink k1 -> hdfs
collecter.sinks.k1.type = hdfs
collecter.sinks.k1.hdfs.useLocalTimeStamp=true
collecter.sinks.k1.hdfs.path =  hdfs://Ucluster/ad/%y-%m-%d/%H
#指定文件前缀
collecter.sinks.k1.hdfs.filePrefix = log_%Y%m%d_%H
#不压缩
collecter.sinks.k1.hdfs.fileType = DataStream
#如果压缩指定压缩的方式
#collecter.sinks.k1.hdfs.fileType = CompressedStream
#collecter.sinks.k1.hdfs.codeC = gzip
#不按照条数生成文件
collecter.sinks.k1.hdfs.rollCount = 0
#如果压缩存储的话HDFS上的文件达到64M时生成一个文件注意是压缩前大小为64生成一个文件，然后压缩存储。
collecter.sinks.k1.hdfs.rollSize = 104857600
# 基于时间间隔来进行文件滚动
collecter.sinks.k1.hdfs.rollInterval = 0
collecter.sinks.k1.hdfs.writeFormat = Text
# 上传文件的编码格式
collecter.sinks.k1.custom.encoding = UTF-8
# 写入HDFS文件块的最小副本数
collecter.sinks.k1.hdfs.minBlockReplicas = 1
# 每个批次刷新到HDFS上的events数量
collecter.sinks.k1.hdfs.batchSize = 2000



# Describe the sink k2 -> kafka
collecter.sinks.k2.type = org.apache.flume.sink.kafka.KafkaSink
collecter.sinks.k2.topic =adlog
collecter.sinks.k2.brokerList = ukafka-1qamr5-1-bj04.service.ucloud.cn:9092,ukafka-1qamr5-2-bj04.service.ucloud.cn:9092,ukafka-1qamr5-3-bj04.service.ucloud.cn:9092
collecter.sinks.k1.requiredAcks = 1
collecter.sinks.k2.batchSize = 20


# Use a channel which buffers events in memory
#collecter.channels.c1.type = memory

#collecter.channels.c2.type = memory

# Bind the source and sink to the channel
collecter.sources.s1.channels = c1 c2
collecter.sinks.k1.channel = c1
collecter.sinks.k2.channel = c2

#------- fileChannel相关配置-------------------------
collecter.channels.c1.type = file
collecter.channels.c1.checkpointDir = /data/flume_ad/hdfs_channel/checkpoint
collecter.channels.c1.dataDirs = /data/flume_ad/hdfs_channel/data

collecter.channels.c2.type = file
collecter.channels.c2.checkpointDir = /data/flume_ad/kafka_channel/checkpoint
collecter.channels.c2.dataDirs = /data/flume_ad/kafka_channel/data