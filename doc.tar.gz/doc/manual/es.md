# Elasticsearch 快速入门


## 1、Elasticsearch 是什么

- elastic search 基于Lucene的开源搜索引擎
- 通过RESTful API隐藏Lucene的复杂性，使全文搜索变得简单


- 特性：

  1. 分布式的实时文件存储，每个字段都被索引并可被搜索

  2. 分布式的实时分析搜索引擎

  3. 可以扩展到上百台服务器，处理PB级别的结构化或非结构化数据

  4. 所有功能集成在一个服务里，可通过RESTful API、各类语言客户端、命令行交互

## 2、安装&运行

- 见[http://es.xiaoleilu.com/010_Intro/10_Installing_ES.html](http://es.xiaoleilu.com/010_Intro/10_Installing_ES.html) 
- Marvel —— 监控和管理工具
- Sense —— 控制台

## 3、集群和节点

- 节点（node）是一个运行着的Elasticsearch实例
- 集群（cluster）是一组具有相同cluster.name的节点集合

## 4、API

- Java API [https://www.elastic.co/guide/index.html](https://www.elastic.co/guide/index.html)节点客户端（node client）以无数据节点的身份加入集群传输客户端（Transport client）不加入集群，发送请求到远程集群

- RESTful API

  - 基于HTTP协议，以JSON为数据交互格式

  - 请求协议

  - `curl -X<VERB> '<PROTOCOL>://<HOST>:<PORT>/<PATH>?<QUERY_STRING>' -d '<BODY>’ `

  - VERB HTTP方法： GET，POST，PUT，HEAD，DELETE

  - PROTOCOL http或https协议

  - HOST Elasticsearch集群中任何一个节点的主机名，如果是本地节点就是localhost

  - PATH API路径 （如_count将返回集群中文档的数量）PATH可以包含多个组件，如_cluster/stats 或者 _nodes/stats/jvm

  - QUERY_STRING 一些可选的查询请求参数， 例如 ?pretty参数将使请求返回更加美观易读的JSON数据

  - BODY 一个JSON格式的请求主体

  - 举例：获取集群中文档数量

    - `curl -XGET 'http://localhost:9200/_count?pretty' -d '{    "query": {        "match_all": {}    }}'`
    返回：
    - `{    "count" : 0,    "_shards" : {        "total" : 5,        "successful" : 5,        "failed" : 0    }}`

## 5、面向文档

- Elasticsearch是面向文档的，可以存储整个文档或对象，索引每个文档的内容
- 可以对文档进行索引、搜索、排序、过滤

## 6、索引 index

- 索引（index） 类型（type），类型存在于索引中
- `Relational DB -> Databases -> Tables -> Rows -> Columns`
- `Elasticsearch -> Indices   -> Types  -> Documents -> Fields`
- Elasticsearch集群可以包含多个索引(indices)（数据库），每一个索引可以包含多个类型(types)（表），每一个类型包含多个文档(documents)（行），然后每个文档包含多个字段(Fields)（列）。
- 索引的区分索引（名词） 如上文所述，一个索引(index)就像是传统关系数据库中的数据库，它是相关文档存储的地方，index的复数是indices 或indexes。索引（动词） 「索引一个文档」表示把一个文档存储到索引（名词）里，以便它可以被检索或者查询。这很像SQL中的INSERT关键字，差别是，如果文档已经存在，新的文档将覆盖旧的文档。倒排索引 传统数据库为特定列增加一个索引，例如B-Tree索引来加速检索。Elasticsearch和Lucene使用一种叫做倒排索引(inverted index)的数据结构来达到相同目的。

## 7、搜索

- 文档的检索
  - 通过HTTP方法GET来检索文档
  - 使用DELETE方法删除文档
  - 使用HEAD方法检查某文档是否存在
  - 使用PUT方法更新文档
  - 简单搜索 _search，默认情况会返回前10个结果
  - 特定（ad hoc)搜索——查询字符串（query string）搜索，_search?q=last_name:Smith
- 使用DSL语句查询
  - DSL（Domain Specific Language 特定领域语言）
  - 使用请求体替代查询字符串（query string）等
- 全文搜索
  - 使用相关性评分对结果集进行排序
- 短语搜索
  - match_phrase
- 高亮搜索
  - 用<em></em>来标识匹配到的单词

## 8、聚合

- 常用于数据统计分析
- 聚合 aggressive 类似于 group by

## 9、分布式

- Elastic search致力于隐藏分布式的复杂性，以下操作都是在底层自动完成的
  - 将你的文档分区到不同的容器或者**分片(shards)**中，它们可以存在于一个或多个节点中。
  - 将分片均匀的分配到各个节点，对索引和搜索做负载均衡。
  - 冗余每一个分片，防止硬件故障造成的数据丢失。
  - 将集群中任意一个节点上的请求路由到相应数据所在的节点。
  - 无论是增加节点，还是移除节点，分片都可以做到无缝的扩展和迁移。

## 10、更详细内容和参考

- Elasticsearch权威指南中文版 [http://es.xiaoleilu.com/010_Intro/00_README.html](http://es.xiaoleilu.com/010_Intro/00_README.html)
- Elastic search官方文档——快速开始 [https://www.elastic.co/guide/en/elasticsearch/reference/current/getting-started.html](https://www.elastic.co/guide/en/elasticsearch/reference/current/getting-started.html)
- Elastic search Document APIs [https://www.elastic.co/guide/en/elasticsearch/reference/current/docs.html](https://www.elastic.co/guide/en/elasticsearch/reference/current/docs.html)
