##  糖豆druid集群初体验
1. 可视化平台[pivot](http://pivot.tangdou.com/)
2. overload控制台[overload](http://overload.druid.tangdou.com/)
3. coordinator控制台[coordinator](http://coordinator.druid.tangdou.com/)
+ 注意: 访问前需要修改本地host

|   ip  |   host    |
| :--------: |:--------: |
|   123.59.58.26 |  pivot.tangdou.com   |
|   123.59.58.26 |  overload.druid.tangdou.com |
|   123.59.58.26 |  coordinator.druid.tangdou.com |


## Druid
### 什么是druid?


