GitLab 手册
====
### 1.安装参考
 1. GitLab 简明安装配置指南 https://segmentfault.com/a/1190000002722631
 2. 配置Postfix http://www.cnblogs.com/aleda/articles/CentOS6_4-mail-server-set-up-under.html
 3. 修改源https://mirror.tuna.tsinghua.edu.cn/help/gitlab-ce/
 4. 关注官网
 https://about.gitlab.com/downloads/#centos6

### 2. 简单使用
Create a new repository
>git clone git@gitlab.tangdou.com:vent/doc.git
cd doc  
touch README.md  
git add README.md  
git commit -m "add README"  
git push -u origin master  

Existing folder or Git repository

>cd existing_folder  
git init  
git remote add origin git@gitlab.tangdou.com:data/doc.git  
git add .  
git commit  
git push -u origin master  

OR git - 简明指南  
http://rogerdudler.github.io/git-guide/index.zh.html
