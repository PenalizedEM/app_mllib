账号密码相关
===
外部服务

| 名称      | 域名/ip       |  账号   |  密码  |
| :--------: |:--------: | :------: | :------: |
| 基础设施 | http://www.ucloud.cn | zhout@tangdou.com | Cc_td2016|
| Hadoop工作台 | http://106.75.35.150:8888/jobbrowser/ | hadoop | hadoop@1984|
| 数据查询与可视化平台 | http://106.75.35.150:8088 / | zeppelin / pm | zeppelin@1984 / pm@td2017|
| 注册短信验证 | http://www.mob.com/ | 2090133856@qq.com| cc123456|
| 推送 | http://xg.qq.com/ | 2090133856 | cc123456|
| 友盟统计 | http://www.umeng.com/ | qius@bokecc.com | cc123456_2015|
| CNZZ统计 | http://web.umeng.com/ | cp@tangdou.com | T@tangdou#CC|
| 又拍云(图片、MP3文件、下载包) | http://www.upyun.com/ | ailianwan| bdsdsn1983|
| appadhoc（A/B测试） | http://www.appadhoc.com/ | linjf@tangdou.com |tangdou@2016|
| CC后台 | http://admin.bokecc.com/ | mtangdou@bokecc.com| Tangdou_2011|
| CC后台 | http://admin.bokecc.com/| vcdn@bokecc.com| a123456|
| CC后台 | http://admin.bokecc.com/| bokecc@bokecc.com| Tangdou_2011|


-------------------
主机(eip会变化)

| 主机名      | ip:port       |  账号   |  密码  |
| :--------: |:--------: | :------: | :------: |
| tse_1(线上搜索引擎 1) | 123.59.139.172:12306| data | data@1984|
| Hadoop客户端 | 123.59.58.72:12306 | hadoop | hadoop@1984|
| Hadoop客户端 | 123.59.58.72:12306 | root | root#123centos|
| ts_test_001(搜索引擎测试,gitlab)| 106.75.2.187:22| data | data@1984|
| driud 集群 | 123.59.58.26 | root | root#123centos |
| driud 集群 | 123.59.58.26 | hadoop | hadoop@123 |
| driud 集群 | 10.19.78.105 | zeppelin | zeppelin@1984 |
| dshow 服务/可视化 | 106.75.27.225 | root | root#123centos |
-------------------
数据库

| 主机名      | ip:port       |  账号   |  密码  |
| :--------: |:--------: | :------: | :------: |
|test-test-db | 10.10.120.205| root | tangdouapp#123|

mongo数据库     

| 库    |   ip     |   端口       |  账号   |  密码  |
| :---------: | :-----------: | :-----------: | :---------: | :------------: |
|  admin | 10.10.238.242 |   27017 |  root | tangDOU=-27017 |
