# 基础环境安装
1. 下载[jdk1.7.0_79](http://www.oracle.com/technetwork/java/javase/downloads/jdk7-downloads-1880260.html)并安装
2. 下载[maven3.3.9](http://apache.communilink.net/maven/maven-3/3.3.9/binaries/apache-maven-3.3.9-bin.tar.gz)并安装
3. 下载[apache-tomcat-7.0.69.tar.gz](http://apache.communilink.net/tomcat/tomcat-7/v7.0.69/bin/apache-tomcat-7.0.69.tar.gz)并安装

# maven本地仓库配置
1. 选定仓库所在的目录, 创建文件夹 .m2(默认情况下, maven本地仓库会创建到用户根目录下, 以linux系统为例, 目录为/home/用户名/.m2)
2. 在.m2 目录下, 创建文件夹repository, 用于存放本地仓库中的jar包文件
3. copy manve安装目录下conf/settings.xml 文件到.m2目录下,  找到settings.xml文件中的localRepository, 去掉注释, 并将其值修改为

```
<localRepository>/home/用户名/repository</localRepository>
```

# IDEA开放环境搭建
1. 官网下载[IDEA](https://www.jetbrains.com/idea/)旗舰版
2. 购买License(或者在线破解, 破解方式见[地址](http://idea.lanyus.com/))
3. 配置jdk
4. 配置maven
5. 配置应用服务器
6. 启动应用服务器, 在浏览器中访问 [http://localhost:8080/](http://localhost:8080/)


# Eclipse开发环境配置
+ 官网下载[eclipse]()J2EE配置网
+ 配置jdk

jdk配置

![JDK配置](img/eclipse-jdk.png)

compiler配置

![JDK compiler配置](img/eclipse-jdk-compiler.png)

+ 配置maven

    ![Maven 配置](img/eclipse-maven.png)
+ 配置应用服务器

    ![tomcat 配置](img/eclipse-tomcat.png)
+ 启动应用服务器, 在浏览器中访问 [http://localhost:8080/](http://localhost:8080/)