糖豆服务集群架构
===
1. [架构简述](#TOC-Overview)
2. [php服务层](#TOC-Php)
3. [搜索引擎](#TOC-Search)
4. [视频服务](#TOC-Video)
5. [数据服务](#TOC-Data)

## <a name="TOC-Overview"></a>架构简述
![糖豆服务架构](img/architecture.png)



## 糖豆服务集群架构
![糖豆服务架构图](img/infrastructure.png)


## hadoop自定义集群

| ip      |  host      | 
| :--------: |:--------: | 
| 10.19.138.198 |  thadoop-uelrcx-host1 |
| 10.19.134.88  |  thadoop-uelrcx-host2 |
| 10.19.164.182 |  thadoop-uelrcx-host3 |
| 10.19.78.105  |  thadoop-uelrcx-host4 |
| --------  | -------- | 
| 120.132.50.53 |  thadoop-uelrcx-host1 |
| 123.59.58.26  |  thadoop-uelrcx-host2 |
| 106.75.64.12  |  thadoop-uelrcx-host3 |
| 106.75.64.10  |  thadoop-uelrcx-host4 |
