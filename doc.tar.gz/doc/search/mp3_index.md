# mp3 index update  

## 1. delete index 

## 2. put index 

```json 
mp3  PUT 

{
  "index": {
    "analysis": {
      "filter": {
        "first_letter_pinyin": {
          "padding_char": "",
          "type": "pinyin",
          "first_letter": "only"
        },
        "full_pinyin_no_space": {
          "padding_char": "",
          "type": "pinyin",
          "first_letter": "none"
        }
      },
      "analyzer": {
        "pinyin_szm_analyzer": {
          "filter": [
            "first_letter_pinyin"
          ],
          "tokenizer": "mmseg_maxword"
        },
        "pinyin_analyzer": {
          "filter": [
            "full_pinyin_no_space"
          ],
          "tokenizer": "mmseg_maxword"
        }
      }
    }
  }
}
``` 

## 3. post mapping 

```json 
mp3/_mapping/ustype POST

{
    "properties": {
      "addtime": {
        "format": "strict_date_optional_time||epoch_millis",
        "type": "date"
      },
      "name": {
        "analyzer": "mmseg_maxword",
        "type": "string"
      },
      "id": {
        "type": "long"
      },
      "team": {
        "analyzer": "mmseg_maxword",
        "type": "string"
      },
      "mp3url": {
        "type": "string"
      },
      "userid": {
        "type": "long"
      },
      "uptime": {
        "format": "strict_date_optional_time||epoch_millis",
        "type": "date"
      }
    }
}
```

## 4. ssh data@10.19.126.209 -p 12306

``` shell 
cd /home/data/jdbces/mp3sh 
sh tse-online-mp3-full.sh
``` 

## 5. query 验证 

``` json 
mp3/_search  POST 

{
  "from": 0,
  "size": 200,
  "query": {
    "filtered": {
      "query": {
        "function_score": {
          "query": {
            "multi_match": {
              "fields": [
                "team",
                "name"
              ],
              "query": "我",
              "minimum_should_match": "100%"
            }
          }
        }
      }
    }
  }
}
``` 
