糖豆搜索引擎架构与部署
===
该集群支持糖豆APP在线搜索功能。
Mar 23 2016 支持video搜索。
Apr 14  2016 升级切换新集群
* 支持拼音全拼、首字母搜索
* 加入搜狗词典，热搜词词典，舞队词典
* ~~支持线上热更新词典~~（等待与策略平台上线）
May 12 2016 升级ULB 负载均衡
* 更新热搜词词典，舞队词典
* 升级内网均衡
* 切换index mapping （改成string,pinyin,pinyinszm）
* 修改分词器
* 修改排序算法

遗留问题: title.pinyinszm 慢

### 1. 架构
#### 1.1 Mar 架构
1. 由ts_1,ts_2,ts_3组成，8,24G,1024G. 50%内存用于搜索引擎。使用IK分词 (RTF插件内容),未配置个性化词典，未启用在线词典。
2. 每台都有部署marvel,head,kpof.
3.  test_001测试机部署jdbc 同步.(
4.  需要监控搜索集群可用性.
5. 服务端使用了Elasticsearch—php插件，需要指定集群地址。 

#### 1.2 Apr 架构
1. 由tse_1,tse_2,tse_3组成，16core,48G,500G SSD.
2. 部署在/home/data/es  目录，做镜像
3. 各台机器都部署 head,kpof
4. host004测试机部署jdbc 同步
5. host004
后续需要关闭外网接口

### 2. 部署
* 在数据盘/data2/  建好目录，设好权限
>sudo mkdir es
>sudo chown -R data ./es/
> cd es
> mkdir data
>  mkdir logs

*   修改elasticsearch.in.sh,调整内存到主机内存一半.
>then ES_MIN_MEM=16g
> then ES_MAX_MEM=16g
> export ES_HEAP_SIZE=16g

*  从ts3 向ts1，ts2同步ES安装目录
>scp -P 12306 -r ./elasticsearch-2.2.0/  data@10.10.238.20:/data2/es/
>10.10.241.38,10.10.238.20

* 以nohup形式启动集群（需改进）
* 注意看日志，会出现无法锁定内存和连接数不够
>sudo vi /etc/security/limits.conf
>data             -       nproc           10240
>data             soft    memlock         unlimited
>data             hard    memlock         unlimited
>
> sudo vi /etc/sysctl.conf
> vm.max_map_count=262144 不生效
> sudo sysctl -w vm.max_map_count=262144
>
>sudo vi /etc/fstab
>comment out any contain swap

> 退出并重新登录

### 3. 同步

* 传JDBC到ts2
>scp -P 12306 -r ./elasticsearch-jdbc-2.2.0.0/ data@10.10.238.20:/data2/es/

* 修改脚本文件的bin和lib目录
> vi ts-online-video-full.sh (见脚本小节)
* 向搜索引擎建立索引
>curl -XPUT http://10.10.238.20:9200/tdvideo
* 设置索引对应的mapping(注意kibana可视化需要中文字段not_anaylzed)
> curl -XPOST http://10.10.178.40:9200/dbuser/_mapping/usertype （见脚本小节）

* 启动JDBC同步脚本
>nohup sh ./ts-online-video-full.sh &

### 4.其它备忘

在es 2.2 indexanalyzer 改成 analyzer 。

### 脚本
#### 设置Index的Mapping
```sh
curl -XPOST http://10.10.178.40:9200/dbuser/_mapping/usertype -d '{
  "_all": {
    "analyzer": "ik",
    "searchAnalyzer": "ik",
    "store": "false"
  },
  "properties": {
    "name": {
      "type": "string",
      "analyzer": "ik",
      "searchAnalyzer": "ik",
      "index":  "not_analyzed",
      "store": "no"
    },
    "province": {
      "type": "string",
      "analyzer": "ik",
      "searchAnalyzer": "ik",
      "index":  "not_analyzed",
      "store": "no"
    },
    "city": {
      "type": "string",
      "analyzer": "ik",
      "searchAnalyzer": "ik",
      "index":  "not_analyzed",
      "store": "no"
    }
  }
}'

### Video
curl -XPOST http://10.10.178.40:9200/dbvideo/_mapping/videotype -d '{
  "_all": {
    "analyzer": "ik",
    "searchAnalyzer": "ik",
    "store": "false"
  },
  "properties": {
    "title": {
      "type": "string",
      "analyzer": "ik",
      "searchAnalyzer": "ik",
      "index":  "not_analyzed",
      "store": "no"
    }
  }
}'
```
#### JDBC同步脚本
```sh
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
bin=/data2/es/jdbc/bin
lib=/data2/es/jdbc/lib

echo '
{
    "type" : "jdbc",
    "jdbc" : {
        "schedule" : "0 0-59 0-23 ? * *",
        "statefile" : "statefile.json",
        "url" : "jdbc:mysql://10.10.120.205:3306/tangdouapp",
        "user" : "root",
        "password" : "tangdouapp#123",
        "sql" : "select *, id as _id, \"tdvideo\" as _index, \"vdtype\" as _type from video",
        "index" : "tdvideo",
        "type" : "vdtype",
        "index_settings" : {
            "index" : {
                "number_of_shards" : 2
            }
        },
       "elasticsearch" : {
            "cluster" : "ts",
            "host" : "10.10.238.20",
            "port" : 9300
        },
        "metrics" : {
            "enabled" : true
        }
    }
}
' | java \
    -cp "${lib}/*" \
    -Dlog4j.configurationFile=${bin}/log4j2.xml \
    org.xbib.tools.Runner \
    org.xbib.tools.JDBCImporter
```
#### 搜索查询脚本
```json
{
  "query": {
    "query_string": {
      "fields": [
        "title"
      ],
      "query": "小苹果",
      "minimum_should_match": "80%"
    }
  },
  "sort": [
    {
      "hits_total": {
        "order": "desc"
      }
    },
    {
      "_score": {
        "order": "desc"
      }
    },
    {
      "createtime": {
        "order": "desc"
      }
    }
  ],
  "highlight": {
    "fields": {
      "title": {}
    }
  }
}
```
