# ansj词典更新流程

> 目前ansj词典不支持热更新，每次对词典添加新的词需要依次重启每台机器的es进程
>  
> - todo
>     + 目前的词典添加新词可以通过脚本方式远程批量执行
>     + 后续寻求词典线上热更新的方式

## 更新流程

#### 1.登录es主机

```shell 
ssh data@10.19.143.37 -p 12306  # kopf所在的机器
ssh data@10.19.136.33 -p 12306 
ssh data@10.19.147.41 -p 12306 
```

#### 2.修改词典，添加新词

```shell 

vi /home/data/es/elasticsearch-2.3.3/config/ansj/dic/user/tangdoukey.dic 

```

#### 3.重启es进程

```shell

ps -aux | grep es 

kill -9 xxx  # kill进程前注意 等待上台刚kill进程的机器的切片分布均匀 

/home/data/es/elasticsearch-2.3.3/bin/elasticsearch -d  # 以守护进程方式启动  

```
