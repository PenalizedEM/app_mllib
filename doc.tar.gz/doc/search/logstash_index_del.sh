#!/bin/bash

# 定时删除es logstash集群中的过期索引

#暂定保留过去14天的索引

# 日期处理

datebuf=`date -d "$date -10 day" +"%Y.%m.%d"`
index="logstash-"${datebuf}
echo $index

# # 测试创建一个索引
# 单引号（' '）和双引号类似，但它不允许解释变量引用，在单引号内的字符$的特殊意思无效了
# 因此我们用双引号
# curl -XPUT "http://10.10.190.148:9200/${index}/" -d '{
#     "settings" : {
#         "index" : {
#             "number_of_shards" : 5,
#             "number_of_replicas" : 2
#         }
#     }
# }'

echo "`date` [INFO] ----------- begin delete index: $index"

curl -XDELETE "http://10.10.190.148:9200/${index}/"

echo "`date` [INFO] ----------- delete index: $index end "