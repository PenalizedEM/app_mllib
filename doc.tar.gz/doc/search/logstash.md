```sh
bin/logstash-plugin remove logstash-input-kafka
bin/logstash-plugin remove logstash-output-kafka
bin/logstash-plugin install --version 4.0.0 logstash-input-kafka
bin/logstash-plugin install --version 4.0.1 logstash-output-kafka
```

```conf
input {
  kafka {
bootstrap_servers => "ukafka-ghz0cc-1-bj04.service.ucloud.cn:9092,ukafka-ghz0cc-2-bj04.service.ucloud.cn:9092,ukafka-ghz0cc-3-bj04.service.ucloud.cn:9092"     client_id => "logstash"
     type => "rs"
     consumer_threads => 4
     codec => "json"
     topics => ["logstash"]
     group_id => "logstash"
}}
filter {
if [request] {
ruby {

    code => "event.set('uri',event.get('request').split(' ')[1])"
}}
if [uri] {
ruby {

    code => "event.set('url_args',event.get('uri').split('?')[1])"
}}
kv {
    prefix => "u_"
    source => "url_args"
    field_split => "& "
    remove_field => [ "url_args","uri","request","path" ]
}
}
output {
elasticsearch {
    hosts=>["10.19.131.130:9200","10.19.8.78:9200","10.19.5.120:9200","10.19.59.229:9200","10.19.77.181:9200","10.19.168.167:9200","10.19.126.217:9200","10.19.50.179:9200","10.19.50.143:9200","10.19.86.31:9200"]
    flush_size => 10000
    idle_flush_time => 30
    codec => "json"
}
}
```