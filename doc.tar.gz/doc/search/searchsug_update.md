# searchsug上线 

## 1. delete index 

## 2. put index 

```json 
searchsug  PUT 

{
  "index": {
    "analysis": {
      "analyzer": {
        "pinyin_analyzer": {
          "tokenizer": "mmseg_maxword",
          "filter": [
            "full_pinyin_no_space"
          ]
        },
        "pinyin_szm_analyzer": {
          "tokenizer": "mmseg_maxword",
          "filter": [
            "first_letter_pinyin"
          ]
        }
      },
      "filter": {
        "full_pinyin_no_space": {
          "type": "pinyin",
          "first_letter": "none",
          "padding_char": ""
        },
        "first_letter_pinyin": {
          "type": "pinyin",
          "first_letter": "only",
          "padding_char": ""
        }
      }
    }
  }
}
``` 

## 3. post mapping 

```json 
searchsug/_mapping/vdtype POST

{
  "properties": {
    "titlesug": {
      "type": "completion",
      "analyzer": "mmseg_maxword",
      "payloads": true
    },
    "titlesugpy": {
      "type": "completion",
      "analyzer": "pinyin_analyzer",
      "payloads": true
    }
  }
}
```

## 4. ssh data@10.19.126.209 -p 12306

``` shell 
cd /data/newsugsync 
java -jar geosearch_ready.jar 
rm geosearch.jar 
mv geosearch_ready.jar geosearch.jar 
``` 

## 5. query 验证 

``` json 
searchsug/_suggest  POST 

{
  "titlesug": {
    "text": "糖",
    "completion": [
      {
        "field": "titlesug",
        "size": 10
      }
    ]
  }
}
``` 
