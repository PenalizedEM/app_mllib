搜索提示
====
## 1.旧版评估
* 58%pv不点击sug结果
* 点击sug的平均position 是1.4
* 需评估专辑的播放次数

## 2. 新版sug
### 2.1 需求
* 用户支持包含提示,数据支持user和空间 用户搜索(mysql同步user,playlist,follow_user到Hive，三者join得到userfull)
* 关键词包含舞曲 前缀(playlist 舞曲 join)
* 中间层调用两个接口,合并输出
