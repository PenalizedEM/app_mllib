## ik分词搜索热词词典热更新上线流程：

### 一、任务脚本与环境准备
##### 1、定时每日自动跟新搜索词典任务脚本准备
- 搜索热词定时更新脚本地址：
  `hadoop客户端(10.19.69.164): /home/hadoop/users/wenlong.zhang/crontab/search_hot_keywords.sh `
- 搜索热词更新流程：
 - 脚本每日7点执行；
 - 每隔10分钟检查一次 
    `/user/hadoop/da/search_hot_keywords/dt=${year}-${month}-${day}/_SUCCESS`  
    文件是否存在且文件大小是否不为0;
 - 若不存在或文件大小为0检查60次后（10个小时）仍不存在或文件大小为0直接退出，并发邮件通知，则线上搜索热词词典更新失败，仍为前一日的; 
 - 若最新业务日期的search_hot_keywords存在且不为0，则执行hive sql 抽取业务日期search_hot_keywords与playlist中的关键词并去重; 
 - hive sql结果覆盖写入本地目录文件：
   `/home/hadoop/users/wenlong.zhang/crontab/search_keywords_dic/000000_0 `
 - scp 上述热词结果文件至文件服务器：
   `106.75.9.19:/data/wwwroot/tse/hotkey/000000_0 `
 - 脚本定时执行命令如下：
 
        ```shell 
        # root账号下crontab命令：
        00 07 * * * cd /home/hadoop/users/wenlong.zhang/crontab/ && ./search_hot_keywords.sh >> /home/hadoop/users/wenlong.zhang/crontab/log/search_hot_keywords.log 2>&1 
        ```

### 二、上线操作步骤
##### A、禁用搜索负载均衡tse_3节点
  操作链接:  https://consolev3.ucloud.cn/ulb/ulb/vserver?ULBId=ulb-2hlgfa 
##### B、kill tes_3节点的es进程

```shell
ssh -p 12306 data@10.10.94.53 
ps -aux | grep elastic
kill -9 771
``` 

##### C、修改ik支持远程扩展词典的配置

- 备份IKAnalyzer.cfg.xml 

```shell
cd /home/data/es/elasticsearch-2.2.0/plugins/elasticsearch-analysis-ik-1.8.0/config/ik/ 
cp IKAnalyzer.cfg.xml IKAnalyzer.cfg.xml.bak
```

```xml
/home/data/es/elasticsearch-2.2.0/plugins/elasticsearch-analysis-ik-1.8.0/config/ik/IKAnalyzer.cfg.xml
将
	<!--用户可以在这里配置自己的扩展字典 -->
	<entry key="ext_dict">custom/tangdoukey.dic;custom/teamclean.dic;custom/single_word_low_freq.dic</entry>
	
	<!--用户可以在这里配置远程扩展字典 -->
	<!--<entry key="remote_ext_dict">http://10.10.167.73:99/tdse/test.txt</entry>-->
改为
	<!--用户可以在这里配置自己的扩展字典 -->
	<entry key="ext_dict">custom/single_word_low_freq.dic</entry>
	
	<!--用户可以在这里配置远程扩展字典 -->
	<entry key="remote_ext_dict">http://10.10.117.26:8899/hotkey/000000_0</entry>
```

##### D、启动es进程

```shell 
# nohup方式启动
nohup sh /home/data/es/elasticsearch-2.2.0/bin/elasticsearch >nohup.out 2>&1 & 
``` 

##### E、验证词典生效

```javascript
curl -XGET 'localhost:9200/_analyze?pretty=true' -d '
{
  "analyzer" : "ik_smart",
  "text" : "大王叫我来巡山儿童舞蹈"
}'
```
	
##### F、启用tse_3节点负载均衡

##### G、在  **_tse_2(10.10.88.21)_** 、 **_tse_1(10.10.96.247)_**  节点重复上述A-F步骤

##### H、回滚

- 禁用搜索负载均衡tse节点
- kill tse 节点 es 进程
- 回滚IKAnalyzer.cfg.xml 

    ```shell
    cd /home/data/es/elasticsearch-2.2.0/plugins/elasticsearch-analysis-ik-1.8.0/config/ik/ 
    cat IKAnalyzer.cfg.xml.bak > IKAnalyzer.cfg.xml
    ```

- nohup 启动 es 进程
- 启用负载均衡



