ES问题汇总
===
今天在对同一个数据做分桶计算UV的时候，发现多次分桶，得到的UV是不一样的。然后看了下ElasticSearch的源码。
发现采用的是基数估算来算UV。然后ES暴露了可以控制准确度的接口。一般默认是90%。
#### Apr 4
completion suggestion是根据搜索热词来提示
直接使用title来写入titlesug字段，再使用completion suggestion ，会对title重复提示，提示结果不理想。
采用 对日志，根据热搜词来实现，

#### Apr 11
拼音搜索对需要搜索的字段采用mutli_field
1.index 定义多个分析器,filter
2. mapping 的字段采用mutil_field
#### Apr 12
Term Vectors ？
无法准确获取拼音搜索的结果
分析器已经合理将中文转化成相应的拼音
分析器的原因：使用ik分词，切成了词典里有的词
需要更新舞曲到词典中
分析器由三部分组成：
1. 字符过滤器
2. 分词器
3. 标志过滤器
### Apr 13
测试了["word_delimiter","nGram"] 过滤器以及拼音tokenizer，查询全部拼音能够生效，但是分词效果不好，命中结果不佳，放弃使用。拼音依然使用ik作为tokenizer。通过修改词典来处理。

单查raw的时候无法命中，原因？

能够把中文


关键是mapping
分词器结合词典已经能够顾准确命中
拼音搜索依赖词典
搞清楚
  "term_vector": "with_positions_offsets",

suggest输入：
``` json
PUT music/song/1?refresh=true
{
    "titlesug" : [
        {
            "input": "Nevermind",
            "weight" : 10
        },
        {
            "input": "Nirvana",
            "weight" : 3
        }
    ]
}

{
    "titlesug" :
        {
            "input": "Nevermind",
            "weight" : 10
        },
         "titlesugszm" :
        {
            "input": "Nevermind",
            "weight" : 10
        }
}
```
使用ES Bulk API 注意 json串本身不可使用 \n
它本身就是用\n来分割每条doc。
NOTE: the final line of data must end with a newline character \n

看源码才是王道

更新词典流程：
1. 原材料：
* 搜索关键词Top10000
* playlist 舞队
* team 限制条件
2. 对比原词典
team 没融合好
3. 生产suggest collection

得搞好词典和suggest更新机制

min_score 是可以限制分数
但是无法限制_score
network.bind_host: 0.0.0.0
network.publish_host: 10.10.178.40
fuzzy无法直接上线

* Q: fuzzy=1 在关键词长度比较短，问题比较大
