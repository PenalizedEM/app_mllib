ANSJ分词
====
## 1. 部署
wget http://xbib.org/repository/org/xbib/elasticsearch/importer/elasticsearch-jdbc/2.3.3.1/elasticsearch-jdbc-2.3.3.1-dist.zip

>./elasticsearch/bin/plugin install lmenezes/elasticsearch-kopf/2.0

wget --no-cookies --no-check-certificate --header "Cookie: gpw_e24=http%3A%2F%2Fwww.oracle.com%2F; oraclelicense=accept-securebackup-cookie" "http://download.oracle.com/otn-pub/java/jdk/8u91-b14/jdk-8u91-linux-x64.tar.gz"

tar xzf jdk-8u91-linux-i586.tar.gz
cd ./jdk1.8.0_91/
sudo alternatives --install /usr/bin/java java /home/data/jdk1.8.0_91/bin/java 2

## 2.词典位置
$es：/home/data/es/elasticsearch-2.3.3/
用户词典：$es/config/ansj/dic/user
停用词词典：$es/ansj/dic/stopLibrary.dic
默认词典：$es/plugins/elasticsearch-analysis-ansj/default.dic


```
[2016-07-12 14:30:30,429][INFO ][ansj-initializer         ] regedit analyzer named : index_ansj
[2016-07-12 14:30:30,431][INFO ][ansj-initializer         ] regedit analyzer named : query_ansj
[2016-07-12 14:30:30,431][INFO ][ansj-initializer         ] regedit analyzer named : to_ansj
[2016-07-12 14:30:30,431][INFO ][ansj-initializer         ] regedit analyzer named : dic_ansj
[2016-07-12 14:30:30,431][INFO ][ansj-initializer         ] regedit analyzer named : user_ansj
[2016-07-12 14:30:30,431][INFO ][ansj-initializer         ] regedit analyzer named : search_ansj
```

### 3. Mapping

```json
curl -XPUT http://106.75.12.26:9200/videos/ -d'
{
    "index" : {
        "analysis" : {
            "analyzer" : {
                "pinyin_analyzer" : {
                    "tokenizer" : "index_ansj",
                    "filter" : ["full_pinyin_no_space"]
                },
                "pinyin_szm_analyzer" : {
                    "tokenizer" : "index_ansj",
                    "filter" : ["first_letter_pinyin"]
                }
            },
            "filter" :{
                "full_pinyin_no_space" : {
                    "type" : "pinyin",
                    "first_letter" : "none",
                    "padding_char" : ""
                },
                    "first_letter_pinyin" : {
                        "type" : "pinyin",
                        "first_letter" : "only",
                        "padding_char" : ""
                }
        }
        }
    }
}'

curl -XPOST http://106.75.12.26:9200/videos/_mapping/vdtype -d '{
    "properties": {
      "title": {
     "type": "multi_field",
     "fields": {
         "pinyinszm": {
             "type": "string",
             "term_vector": "with_positions_offsets",
             "analyzer": "pinyin_szm_analyzer",
             "store": "no"
         },
         "title": {
             "type": "string",
             "analyzer": "index_ansj",
             "search_analyzer" : "query_ansj",
             "store": "no"

         }
         ,
         "pinyin": {
             "type": "string",
             "term_vector": "with_positions_offsets",
             "analyzer": "pinyin_analyzer",
             "store":"no"

         }
     }
 },
        "tag":  { "type" : "string", "analyzer" : "index_ansj", "search_analyzer" : "query_ansj" }
    }
}
'
curl -XGET http://10.19.126.209:9200/videos/
```
### 4.同步数据

```json
    "type_mapping": {
        "vdtype": {
            "properties": {
                "title": {
                    "type": "multi_field",
                    "fields": {
                        "pinyinszm": {
                            "type": "string",
                            "term_vector": "with_positions_offsets",
                            "analyzer": "pinyin_szm_analyzer",
                            "store": "no"
                        },
                        "title": {
                            "type": "string",
                            "analyzer": "index_ansj",
                            "search_analyzer": "query_ansj",
                            "store": "no"
                        },
                        "pinyin": {
                            "type": "string",
                            "term_vector": "with_positions_offsets",
                            "analyzer": "pinyin_analyzer",
                            "store": "no"
                        }
                    }
                },
                "tag": {
                    "type": "string",
                    "analyzer": "index_ansj",
                    "search_analyzer": "query_ansj"
                }
            }
        }
    }
   ```
需要使用JDK8,JDBC 2.3.3.1

### 5.Query

```json
{
  "from": 0,
  "size": 6,
  "query": {
    "filtered": {
      "query": {
        "function_score": {
          "functions": [
            {
              "script_score": {
                "script": "if (_score < 0.6) { return sqrt(doc['hits_total'].value)*0.8  };return  _score*3 + doc['user_share'].value*0.12 +doc['comment_total'].value*0.2 +sqrt(doc['hits_total'].value)*1.1+max(0.0,0.5*(30-((DateTime.now().getMillis()-doc['createtime'].date.getMillis())/86400000)))"
              }
            }
          ],
          "query": {
            "multi_match": {
              "fields": [
                "title^5"
              ],
              "query": "你是我的妞",
              "minimum_should_match": "80%"
            }
          }
        }
      },
      "filter": {
        "bool": {
          "must": [
            {
              "terms": {
                "status": [
                  0,
                  1,
                  2
                ]
              }
            }
          ]
        }
      }
    }
  },
  "highlight": {
    "fields": {
      "title": {}
    }
  }
}
```