实时数仓集群构建(ES5.3)
=====
1. 根据搜索引擎2镜像生成,java8
2. 下载,解压ES5.3
> wget  https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-5.3.0.zip
> unzip elasticsearch-5.3.0.zip

3. 配置虚拟网卡
```yml
  ##使用root
  touch /etc/sysconfig/network-scripts/ifcfg-lo:1
  vi /etc/sysconfig/network-scripts/ifcfg-lo:1
  ## 填入以下：
  DEVICE=lo:1
  IPADDR=10.10.190.148
  NETMASK=255.255.255.255
  ##执行
  ifup lo:1
```

4. 修改配置文件

[对照官网文档的配置](https://www.elastic.co/guide/en/elasticsearch/reference/current/bootstrap-checks.html)

* vi elasticsearch.yml(参考elastic.yml)

```yml
discovery.zen.ping.unicast.hosts:
bootstrap.memory_lock: true
bootstrap.system_call_filter: false
network.bind_host: 0.0.0.0
network.publish_host: 10.19.131.130
```

* vi jvm.options(设置内存为机器内存一半)

 ```yml
 -Xms24g
 -Xmx24g
 ```

 5. 启动
 nohup /home/data/es/elasticsearch-5.3.0/bin/elasticsearch >/dev/null 2>&1 &

 6. 启动Kibana(10.19.126.209)
 tar -xzf kibana-5.3.0-linux-x86_64.tar.gz
 nohup /data/kibana/bin/kibana >/dev/null 2>&1 &


7. 启动logstash
ukafka-ghz0cc-1-bj04.service.ucloud.cn
ukafka-ghz0cc-1-bj04.service.ucloud.cn:2181,ukafka-ghz0cc-2-bj04.service.ucloud.cn:2181,ukafka-ghz0cc-3-bj04.service.ucloud.cn:2181"
