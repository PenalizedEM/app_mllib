## 搜索ansj分词上线操作记录

### 一、环境准备&&插件安装

> * jdk 1.8
> * es 2.3.3
> * plugin
>     - elasticsearch-analysis-ansj 2.3.3
>     - elasticsearch-analysis-pinyin 1.7.3
>     - elasticsearch-analysis-ik 1.9.3
>     - elasticsearch-analysis-mmseg 1.9.3 
>     - elasticsearch-kopf 2.0 
>     - elasticsearch-jdbc 2.3.3 
> * plugin install
>     - pinyin && ik && mmseg 
>     - 下载github上对应tags版本的源码zip包并解压
>     - 编译：mvn package 
>     - 复制并解压 
>         + `target/releases/elasticsearch-analysis-xx-{version}.zip to your-es-root/plugins/`
>     - kopf 
>         + ` ./elasticsearch/bin/plugin install lmenezes/elasticsearch-kopf/{branch|version}
>       open http://localhost:9200/_plugin/kopf`       
>     - ansj 
>         + `./bin/plugin install http://maven.nlpcn.org/org/ansj/elasticsearch-analysis-ansj/2.3.3.3/elasticsearch-analysis-ansj-2.3.3.3-release.zip`
>         + ansj停顿词词典默认没有空格，需要手动加入

### 二、制作镜像

> * 将搭建环境与插件的主机停机
> * 保证环境搭建与es安装目录是在系统盘非数据盘
> * 在ucloud控制台创建镜像即可

### 三、配置负载均衡 

> * 新建3台云主机，配置选择：16core，48GRAM，300GSSD，系统镜像选择上面创建的镜像
> * 在ucloud新创建负载均衡，网络模式选择内网模式。  
> * 创建VServer，监听器类型选：报文转发(内网)，端口:9200，协议端口：TCP，负载均衡算法：一致性哈希，连接保持时间：60S，节点健康检查：端口检查 
> * 在VServer中添加服务节点，将上面新建的3台云主机加入服务节点，加入后节点健康状态显示无效是因为新建的云主机上es进程还没起来，9200端口未启用。
> * 分别进入3台主机，修改并配置并启动es进程
>     -  进入es_home，修改config/elasticsearch.yml ，改动项如下：
>         +  `cluster.name: tse-new`
>         +  `node.name: tsenew-00X`
>         +  `discovery.zen.ping.unicast.hosts: ["10.19.147.41", "10.19.143.37","10.19.136.33"]`
>     -  修改bin/elasticsearch.in.sh ，改动项如下：
>         +  `ES_MIN_MEM=24g`(节点内存的一半)
>         +  `ES_MAX_MEM=24g`(节点内存的一半)
>     -  以守护模式启动es进程 `./bin/elasticsearch -d`
>  * 做完以上步骤会看到负载均衡VServer中服务节点监控状态变为正常
>  * 打开http://xxxx:9200/_plugin/kopf  es集群状态为GREEN，三台节点可用
>  * 接下来要设置后端服务节点的虚拟网卡
>      - 创建虚拟网卡配置文件 ：  `touch /etc/sysconfig/network-scripts/ifcfg-lo:1`
>      - 运行命令获取网卡配置： `curl rsconf.service.ucloud.cn/ulb4int/$IP`
>      - 将命令中得到的内容添加进 `/etc/sysconfig/network-scripts/ifcfg-lo:1`中，即如下内容：`DEVICE=lo:1  IPADDR=$VIP(负载均衡器的内网IP)  NETMASK=255.255.255.255 `
>      - 启动虚拟网卡： `ifup lo:1`
> * 验证负载均衡是否生效 
>     - `curl 'http://10.10.153.110:9200'`
>     - 多换几个ip请求上面接口,查看返回的节点name是否在3个es节点轮换

### 四、新建索引，MAPPING，同步数据

#### 1. 建索引

在kopf的rest client中新建索引

1.1 videos

```json 
curl -XPUT 'localhost:9200/videos?pretty' -d '
{
  "index": {
    "analysis": {
      "analyzer": {
        "pinyin_analyzer": {
          "tokenizer": "index_ansj",
          "filter": [
            "full_pinyin_no_space"
          ]
        },
        "pinyin_szm_analyzer": {
          "tokenizer": "index_ansj",
          "filter": [
            "first_letter_pinyin"
          ]
        }
      },
      "filter": {
        "full_pinyin_no_space": {
          "type": "pinyin",
          "first_letter": "none",
          "padding_char": ""
        },
        "first_letter_pinyin": {
          "type": "pinyin",
          "first_letter": "only",
          "padding_char": ""
        }
      }
    }
  }
}'
```

1.2 user

```json 
curl -XPUT http://localhost:9200/user/ -d'
{
  "index": {
    "analysis": {
      "analyzer": {
        "pinyin_analyzer": {
          "tokenizer": "index_ansj",
          "filter": [
            "full_pinyin_no_space"
          ]
        },
        "pinyin_szm_analyzer": {
          "tokenizer": "index_ansj",
          "filter": [
            "first_letter_pinyin"
          ]
        }
      },
      "filter": {
        "full_pinyin_no_space": {
          "type": "pinyin",
          "first_letter": "none",
          "padding_char": ""
        },
        "first_letter_pinyin": {
          "type": "pinyin",
          "first_letter": "only",
          "padding_char": ""
        }
      }
    }
  }
}'
```

1.3 searchsug

```json 
curl -XPUT http://localhost:9200/searchsug/ -d'
{
  "index": {
    "analysis": {
      "analyzer": {
        "pinyin_analyzer": {
          "tokenizer": "mmseg_maxword",
          "filter": [
            "full_pinyin_no_space"
          ]
        },
        "pinyin_szm_analyzer": {
          "tokenizer": "mmseg_maxword",
          "filter": [
            "first_letter_pinyin"
          ]
        }
      },
      "filter": {
        "full_pinyin_no_space": {
          "type": "pinyin",
          "first_letter": "none",
          "padding_char": ""
        },
        "first_letter_pinyin": {
          "type": "pinyin",
          "first_letter": "only",
          "padding_char": ""
        }
      }
    }
  }
}'
```

#### 2.创建mapping

2.1 videos

```json 
curl -XPUT http://106.75.12.26:9200/videos/_mapping/vdtype -d '{
  "properties": {
    "title": {
      "type": "multi_field",
      "fields": {
        "pinyinszm": {
          "type": "string",
          "term_vector": "with_positions_offsets",
          "analyzer": "pinyin_szm_analyzer",
          "store": "no"
        },
        "title": {
          "type": "string",
          "analyzer": "index_ansj",
          "search_analyzer": "query_ansj",
          "store": "no"
        },
        "pinyin": {
          "type": "string",
          "term_vector": "with_positions_offsets",
          "analyzer": "pinyin_analyzer",
          "store": "no"
        }
      }
    },
    "tag": {
      "type": "string",
      "analyzer": "index_ansj",
      "search_analyzer": "query_ansj"
    }
  }
}
'
```

2.2 user 

```json 
curl -XPOST http://localhost/user/_mapping/ustype -d '{
  "properties": {
    "name": {
      "type": "string",
      "analyzer": "mmseg_maxword",
      "search_analyzer": "mmseg_maxword"
    },
    "keyword": {
      "type": "string",
      "analyzer": "mmseg_maxword",
      "search_analyzer": "mmseg_maxword"
    }
  }
}
'
```

2.3 searchsug

```json
curl -XPOST http://localhost:9200/searchsug/_mapping/vdtype -d '{
  "properties": {
    "titlesug": {
      "type": "completion",
      "analyzer": "mmseg_maxword",
      "payloads": true
    },
    "titlesugpy": {
      "type": "completion",
      "analyzer": "pinyin_analyzer",
      "payloads": true
    }
  }
}
'
```

#### 3. 同步数据

jdbc同步数据，需要先修改同步脚本的配置，重点关注以下几个地方
* bin lib 目录 v3.3插件需要jdk8
* sql 语句，注意增量同步与全量同步的参数设置
* jdbcurl 注意同步的库地址和库名变更
* es设置，修改cluster, host 
* 修改type_mapping，注意analyzer和tag字段的mapping
* 首次跑全量更新脚本时，注意删掉statejsonw(记录上次运行脚本的时间，便于增量更新获取上次运行时间)文件

*videos索引的完整同步数据脚本如下*

```shell
!/bin/sh

R="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
bin=/home/data/jdbces/bin
lib=/home/data/jdbces/lib

echo '
{
  "type": "jdbc",
  "jdbc": {
    "statefile": "statefile.json",
    "url": "jdbc:mysql://10.10.120.205:3306/tangdouapp",
    "user": "root",
    "password": "tangdouapp#123",
    "sql": "select *, id as _id, \"videos\" as _index, \"vdtype\" as _type from video",
    "index": "videos",
    "type": "vdtype",
    "index_settings": {
      "index": {
        "number_of_shards": 1
      }
    },
    "elasticsearch": {
      "cluster": "tse-new",
      "host": "10.19.147.41",
      "port": 9300
    },
    "metrics": {
      "enabled": true
    },
    "type_mapping": {
      "vdtype": {
        "properties": {
          "title": {
            "type": "multi_field",
            "fields": {
              "pinyinszm": {
                "type": "string",
                "term_vector": "with_positions_offsets",
                "analyzer": "pinyin_szm_analyzer",
                "store": "no"
              },
              "title": {
                "type": "string",
                "analyzer": "index_ansj",
                "search_analyzer": "query_ansj",
                "store": "no"
              },
              "pinyin": {
                "type": "string",
                "term_vector": "with_positions_offsets",
                "analyzer": "pinyin_analyzer",
                "store": "no"
              }
            }
          },
          "tag": {
            "type": "string",
            "analyzer": "index_ansj",
            "search_analyzer": "query_ansj"
          }
        }
      }
    }
  }
}
' | java \
    -cp "${lib}/*" \
    -Dlog4j.configurationFile=${bin}/log4j2.xml \
    org.xbib.tools.Runner \
    org.xbib.tools.JDBCImporter
```

*videos索引的增量同步脚本json配置如下*

```json
{
  "sql": [
    {
      "statement": "select *, id as _id, \"videos\" as _index, \"vdtype\" as _type from video where uptime > ? or createtime> ? ",
      "parameter": [
        "$metrics.lastexecutionstart",
      ]
    }
  ]
}
```

*user索引的增量同步脚本如下*

```shell
#!/bin/sh

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
bin=/home/data/jdbces/bin
lib=/home/data/jdbces/lib

echo '
{
    "type" : "jdbc",
    "jdbc" : {
        "statefile" : "statefile.json",
        "url" : "jdbc:mysql://10.10.244.34:3306/search",
        "user" : "root",
        "password" : "tangdouapp#123",
        "sql" :
        [
            {
                "statement" : "select *,id as _id, \"user\" as _index, \"ustype\" as _type from user_full where regtime > ?  ",
                "parameter" : [ "$metrics.lastexecutionstart"]
            }
        ],
        "index" : "user",
        "type" : "ustype",
        "index_settings" : {
            "index" : {
                "number_of_shards" : 1
            }
        },
       "elasticsearch" : {
            "cluster" : "tse-new",
            "host" : "10.19.147.41",
            "port" : 9300
        },
        "metrics" : {
            "enabled" : true
        },
        "type_mapping": {
            "ustype" : {
                "properties": {
                    "name": {
                        "type": "string",
                        "analyzer": "mmseg_maxword",
                        "search_analyzer": "mmseg_maxword"
                    },
                    "keyword": {
                        "type": "string",
                        "analyzer": "mmseg_maxword",
                        "search_analyzer": "mmseg_maxword"
                    }
                }
            }
        }
    }
}
' | java \
    -cp "${lib}/*" \
    -Dlog4j.configurationFile=${bin}/log4j2.xml \
    org.xbib.tools.Runner \
    org.xbib.tools.JDBCImporter
```

#### 4.crontabd定时同步脚本

```shell
--- new tse sync
00 04 * * *  /bin/bash /data/geosearch/geosearch.sh
*/4 * * * *  cd /home/data/jdbces/videoinsh/ && ./tse-online-video-in.sh >> invideo.log 2>&1
00 11 * * * cd /home/data/jdbces/userinsh/ && ./tse-online-user-in.sh >> inuser.log 2>&1
38 11 * * * cd /data/newsugsync/ && java -jar geosearch.jar >> allsug.log 2>&1
```

### 五、测试环境BAD CASE发现与验证

| ID | CASE | STATE |
| -------- | -------- | -------- |
| 1   | 美好广场舞   | CLOSED |
| 2   | 小平果   | OPEN |

