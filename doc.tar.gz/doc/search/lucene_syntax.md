## Apache Lucene 查询语法

Apache Lucene 提供两种查询方式：通过其API查询；通过基于Query Parser（JavaCC实现的能够将查询字符串解释为Lucene Query）的查询语言查询。

使用Lucene查询语言之前，建议考虑以下原则：

1. Lucene查询语言是为人工输入的查询文本设计的，如果程序产生的查询文本建议使用Lucene Query API
2. 不能分词的字段，如程序生成的日期字段、关键词等字段，最好使用API查询
3. 在设计查询表单时，一般的文本可以使用查询解析器（Query Parser)；诸如日期范围，关键词的查询建议直接使用查询API；对于有有限个值的字段，建议使用下拉菜单

本文将详细介绍Lucene查询语言的查询语法。通过本文的介绍，最终希望读者能够在Kibana中快速查询到想要的日志。




### 词项（Terms)

一条查询语句会被分解成词项(terms)和运算符(operators). 有两种类型的词项：单词项(single terms)和词组(phrases).

单词项就是一个单个的汉字或英语单词，如"test","hello","字"。

词组是用双引号括起来的一组汉字或英语单词，如"hello world","你好".

多个词项可以通过布尔运算符组合起来拼成一个复杂的查询。

 **注意：**
 由于在查询语句中的词项和词组是由分词器(analyzer)分词而来的(该分词器同样用于创建索引)，所以选择一个不会影响查询语句中词项的分词器十分重要。




### 字段(fields)

Lucene支持查询字段数据。查询时，可以指定字段名查询也可以使用默认的字段查询。

查询字段的格式为：字段名:字段值

例如：假设Lucene索引中包含两个字段：title和text,其中text是默认字段。
如果你要找title为"The Right Way",且text包含"don't go this way"的Document,可以这样查询：

```
title:"The Right Way" AND text:go 
or 
title:"The Right Way" AND go 
```
由于text是默认字段，所以第二个查询语句中，text不用显式指定

**注意：**
```
title:Do it right
```
上面的查询将检索title值为"Do" 且 默认字段text中包含"it"和"right"的Document




### 通配符查询(Wildcard Searches)

Lucene支持在单个词项(不含词组phrase)中结合一个或多个通配符查询。

单个字符通配符为"?"
0个或多个字符通配符为"*"

例如
``` 
tes?t
``` 
能够匹配到包 "test" "text"等；
```
test*
```
能够匹配到"test" "tester" "tests"等
```
tes*t
```
能够匹配到"test" "tesat"等

kibana默认情况下，搜索框中就是一个通配符"*"，意为默认情况下将匹配所有文档




### 模糊查询(Fuzzy Searches)

Lucene支持基于编辑距离(Levenshtein Distance / Eidit Distance)算法的模糊查询.
只需在要查询的词项后加上"~"即可进行fuzzy查询。
```
roam~
```
会匹配到"foam" "roams",fuzzy查询是根据相似度来匹配的。
在"~"后可指定一个0到1的数字(可选参数)来指定相似度，默认此参数值为 0.5，越接近1，会匹配相似度越高的结果。




### 近邻(距离)查询(Proximity Searches)

Lucene支持在指定的字符距离内查询词项。查询方法和fuzzy查询类似，需要在待查询的词项后面加上"~"，不同的是，近似查询要指定字符距离。
如：
```
hello world~10
``` 
将会匹配距离10个字符以内的"hello"和"world"的文档。




### 范围查询(Range Searches)

范围查询可以查询介于指定的最大值和最小值之间的文档。
闭区间的范围查询用方括号"[]"
开区间的范围查询用花括号"{}"

```
mod_date:[20020101 TO 20030101]
```
可以查询mod_date值大于等于20020101且小于等于20030101间的文档。
```
title:{Aida TO Carmen}
```
可以查询title介于Aida与Carmen之间的文档，但不包括Aida与Carmen




### 加强词项的匹配权重(Boosting a Term)

基于找到的词项，Lucene可以对匹配到的文档划分相关水平。
在要查询的词项结尾处，用插入符"^"和提权因子(数字)来提示匹配该词项的相关水平。提权因子(数字)越大，查询词的相关性越大。
默认的提权因子是1，提权因子必须是正数，也可以小于1，如0.1

通过调节查询词项的提权因子，就可以控制匹配到的文档与查询词项的相关程度。
如
```
hello^4 world
```
含有"hello"的文档的相关性会提示，更容易匹配到。
提升查询词组的权重：
```
"hello world"^4 "aha moment"
```




### 布尔运算符(Boolean Operators)

布尔运算符可以组合查询词项。Lucene支持的布尔运算符有:   
> AND,"&&" (且)  
> "+"   
> OR,"|","||" (或)   
> NOT,"!",-" (非)   

布尔运算符必须是大写字母。


**OR**   
等价于"||"
OR是默认的连接符，即:如果两个查询词项间没有显式指定布尔运算符，就用OR作为运算符。
```
"hello world" hello
``` 
<=> 
```
"hello world" OR hello
```


**AND**   
等价于"&&"
```
"hello world" AND hello
``` 
会匹配到同时含有"hello world"与hello的文档。


**+**   
"+"为强制符。查询的结果文档中，必须保留含有出现在"+"后的词项的文档。
```
+jakarta lucene
``` 
结果文档中必须含有jakarta，可能含有lucene
对比
```
jakarta lucene
``` 
结果文档中含有jakarta或含有lucene即可


**NOT**   
等价于"!"
NOT运算符后面的词项，不能出现在查询结果文档中。
```
"jakarta apache" NOT "Apache Lucene"
```
查询的结果文档中含有"jakarta apache"，但不能包含"Apache Lucene"

_注意:_当查询语句中只有一个词项时，NOT运算符不能使用。
~~```NOT "jakarta apache"```~~ **将不会返回任何结果** 


**-**   
"-"为禁止符。最终的查询的结果文档，需要排除掉出现"-"后词项的文档。
```
"jakarta apache" -"Apache Lucene"
``` 
含有"jakarta apache",不能含有"Apache Lucene" 
等价于
```
"jakarta apache" NOT "Apache Lucene"
```




### 组合(Grouping)  
Lucene支持用小括号()将查询从句括起来合并成一个子查询。方便在查询中控制布尔逻辑，消除歧义。
```
(jakarta OR apache) AND website
``` 
含有jakarta或apache 且含有website




### 字段组合(Field Grouping)
Lucene支持使用小括号()将多个查询从句组合成一个字段查询。
```
title:(+return +"pink panther")
```  
title字段的值必须含有return 和 "pink panther" 




### 转义字符(Escaping Special Characters)
Lucene支持对转义字符的转移。
目前需要转义的特殊字符有：
```
+ - && || ! ( ) { } [ ] ^ " ~ * ? : \
``` 
举例：查询包含"(1+1):2"的文档：```\(1\+1\)\:2```




### 综合实战
有了上面的多种查询手段，我们在kibana中可以进行一些复杂查询。
如，我们想查询APP和PC端视频的播放总量：
```
u_mod:top AND (u_ac:hits OR u_ac:hits_pc)
```
<=>
```
u_mod:top AND u_ac:(hits hits_pc)
```

安卓端v4.7.1以上(含)版本的视频下载失败次数：
```
u_mod:emptylog AND u_ac:download_fail AND u_div:[4.7.1 TO 4.8.0] AND u_client=2
```




### 参考：
[Apache Lucene - Query Parser Syntax](https://lucene.apache.org/core/2_9_4/queryparsersyntax.html) 






