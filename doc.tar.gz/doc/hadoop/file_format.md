# HADOOP/HIVE文件存储格式

### 1、基于行存储

> 基于Hadoop系统行存储结构的优点在于快速数据加载和动态负载的高适应能力，这是因为行存储保证了相同记录的所有域都在同一个集群节点，即同一个 HDFS块。不过，行存储的缺点也是显而易见的，例如它不能支持快速查询处理，因为当查询仅仅针对多列表中的少数几列时，它不能跳过不必要的列读取；此 外，由于混合着不同数据值的列，行存储不易获得一个极高的压缩比，即空间利用率不易大幅提高。

HDFS块内行存储的例子：
![alt text](img/row.png)

#### Textfile 

>默认格式，数据不做压缩，磁盘开销大，数据解析开销大。
 文本格式除了会占用更多磁盘资源外，对它的解析开销一般会比二进制格式高，因此强烈不建议在生产系统中使用这些格式进行储存。 
 如果需要输出这些格式，请在客户端做相应的转换操作。 
 文本格式经常会用于日志收集，数据库导入，Hive默认配置也是使用文本格式，而且常常容易忘了压缩，所以请确保使用了正确的格式。 

 ```sql
> create table test1(str STRING)  
> STORED AS TEXTFILE;   
OK  
Time taken: 0.786 seconds  
#写脚本生成一个随机字符串文件，导入文件：  
> LOAD DATA LOCAL INPATH '/home/work/data/test.txt' INTO TABLE test1;  
Copying data from file:/home/work/data/test.txt  
Copying file: file:/home/work/data/test.txt  
Loading data to table default.test1  
OK  
Time taken: 0.243 seconds
 ```

#### SequenceFile 

> SequenceFile是Hadoop API 提供的一种二进制文件，它将数据以<key,value>的形式序列化到文件中。这种二进制文件内部使用Hadoop 的标准的Writable 接口实现序列化和反序列化。
> Hive 中的SequenceFile 继承自Hadoop API 的SequenceFile，不过它的key为空，使用value 存放实际的值， 这样是为了避免MR 在运行map 阶段的排序过程。

1. 其具有使用方便、可分割、可压缩的特点。 
2. 支持三种压缩选择：NONE, RECORD, BLOCK。 Record压缩率低，一般建议使用BLOCK压缩。

```sql
CREATE EXTERNAL TABLE IF NOT EXISTS da.test_sequencefile(
  ...
)
COMMENT 'test_sequencefile'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS SEQUENCEFILE
;
 
```


### 2、基于列存储

>查询时列存储能够避免读不必要的列， 并且压缩一个列中的相似数据能够达到较高的压缩比。然而，由于元组重构的较高开销，它并不能提供基于Hadoop系统的快速查询处理。列存储不能保证同一 记录的所有域都存储在同一集群节点，行存储的例子中，记录的4个域存储在位于不同节点的3个HDFS块中。因此，记录的重构将导致通过集群节点网络的大 量数据传输。尽管预先分组后，多个列在一起能够减少开销，但是对于高度动态的负载模式，它并不具备很好的适应性。

HDFS块内列存储的例子：
![alt text](img/column.jpg)


### 3、基于行列存储

#### RCFile 

>RCFile是Hive推出的一种专门面向列的数据格式。 它遵循“先按列划分，再垂直划分”的设计理念。当查询过程中，针对它并不关心的列时，它会在IO上跳过这些列。需要说明的是，RCFile在map阶段从远端拷贝仍然是拷贝整个数据块，并且拷贝到本地目录后RCFile并不是真正直接跳过不需要的列，并跳到需要读取的列， 而是通过扫描每一个row group的头部定义来实现的，但是在整个HDFS Block 级别的头部并没有定义每个列从哪个row group起始到哪个row group结束。所以在读取所有列的情况下，RCFile的性能反而没有SequenceFile高。

- RCFile结合行存储查询的快速和列存储节省空间的特点：
    1. 首先，RCFile保证同一行的数据位于同一节点，因此元组重构的开销很低；
    2. 其次，像列存储一样，RCFile能够利用列维度的数据压缩，并且能跳过不必要的列读取。

HDFS块内RCFile方式存储的例子：


RCFILE是一种行列存储相结合的存储方式。首先，其将数据按行分块，保证同一个record在一个块上，避免读一个记录需要读取多个block。其次，块数据列式存储，有利于数据压缩和快速的列存取。RCFILE文件示例：

```sql
CREATE EXTERNAL TABLE IF NOT EXISTS da.test_rcfile(
   ...
)
COMMENT 'test_rcfile'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS RCFILE 
;

```

### 6、ParquetFile

>源自于google Dremel系统（可下载论文参阅），Parquet相当于Google Dremel中的数据存储引擎，而Apache顶级开源项目Drill正是Dremel的开源实现。
Apache Parquet 最初的设计动机是存储嵌套式数据，比如Protocolbuffer，thrift，json等，将这类数据存储成列式格式，以方便对其高效压缩和编码，且使用更少的IO操作取出需要的数据，这也是Parquet相比于ORC的优势，它能够透明地将Protobuf和thrift类型的数据进行列式存储，在Protobuf和thrift被广泛使用的今天，与parquet进行集成，是一件非容易和自然的事情。 除了上述优势外，相比于ORC, Parquet没有太多其他可圈可点的地方，比如它不支持update操作（数据写成后不可修改），不支持ACID等。

ParquetFile 的详细介绍参考 [深入分析Parquet列式存储格式](http://www.infoq.com/cn/articles/in-depth-analysis-of-parquet-column-storage-format)

```sql
CREATE EXTERNAL TABLE IF NOT EXISTS da.test_parquet(
 ...
)
COMMENT 'test_parquet'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET 
;

```

![alt text](img/parquet.jpg)


### 5、ORCFile

>ORC（OptimizedRC File）存储源自于RC（RecordColumnar File）这种存储格式，RC是一种列式存储引擎，对schema演化（修改schema需要重新生成数据）支持较差，而ORC是对RC改进，但它仍对schema演化支持较差，主要是在压缩编码，查询性能方面做了优化。
RC/ORC最初是在Hive中得到使用，最后发展势头不错，独立成一个单独的项目。Hive 1.x版本对事务和update操作的支持，便是基于ORC实现的（其他存储格式暂不支持）。ORC发展到今天，已经具备一些非常高级的feature，比如支持update操作，支持ACID，支持struct，array复杂类型。你可以使用复杂类型构建一个类似于parquet的嵌套式数据架构，但当层数非常多时，写起来非常麻烦和复杂，而parquet提供的schema表达方式更容易表示出多级嵌套的数据类型。

ORCFile的详细介绍参考 [ORC 2015: Faster, Better, Smaller](http://www.slideshare.net/Hadoop_Summit/orc-2015-faster-better-smaller-49481231)

```sql
CREATE EXTERNAL TABLE IF NOT EXISTS da.test_orcfile(
 ...
)
COMMENT 'test_orcfile'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS ORCFILE 
;

```

![alt text](img/orcfile.jpg)


**Parquet与ORC对比**

|   |  Parquet |  ORC |  
| ------    | ----------------- |  -------------------- |
|   |  Apache顶级项目 开源 列式存储引擎 |  Apache顶级项目 开源 列式存储引擎 |  
| 主导公司 | Twitter/Cloudera |  Hortonworks | 
| 开发语言 | Java |  Java | 
| 嵌套式结构 | 支持多种编码，字典，RLE，delta编码等 | 支持主流编码，与parquet类似 |  
| ACID | 不支持 | 支持 | 
| Update操作（delete，update等）|  不支持 |  支持 |   
| 支持索引（实际上是统计信息）|  粗粒度索引，block/group/chunk级别统计信息 |  粗粒度索引，file/stripe/row级别统计信息，不能精确到列建索引 | 
| 查询性能 | ORC稍高 |    | 
| 数据压缩能力 | ORC稍高 |    |  
| 支持的查询引擎 | Drill Impala Hive .... |  Hive |   


### 6、自定义格式

>当用户的数据文件格式不能被当前 Hive 所识别的时候，可以自定义文件格式。
用户可以通过实现inputformat和 outputformat来自定义输入输出格式

```sql  
> create table test4(str STRING)  
> stored as  
> inputformat 'org.apache.hadoop.hive.contrib.fileformat.base64.Base64TextInputFormat'  
> outputformat 'org.apache.hadoop.hive.contrib.fileformat.base64.Base64TextOutputFormat'; 
```

### 7、不同格式文件的性能测试

- 写入性能

```sql
--TextFile
create table test_textfile like dw.user_action ;
set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
INSERT OVERWRITE table test_textfile PARTITION(dt='2016-09-20')
SELECT u_timestamp, u_backtime, u_responsetime, u_host, u_xff, u_status, u_size, u_div, u_dic, u_diu, u_diu2, u_diu3, u_uid, u_startid, u_stepid, u_time, u_mod, u_ac, u_client, u_ver, u_uuid, u_hash, u_xinge, u_token, u_agent, u_method, u_new_activity, u_old_activity, u_key, u_client_module, u_source, u_page, u_position, u_vid, u_type, u_percent, u_rate, u_user_role, u_isnew_user, u_isdownload, u_isonline, u_buffertime, u_action, u_ishigh, u_cdn_source, u_download_start, u_download_stop, u_fail_cdn_source, u_new_cdn_source, u_width, u_height, u_lon, u_lat, u_province, u_city, u_netop, u_nettype, u_sdkversion, u_model, u_device, u_manufacture, u_reverse0, u_reverse1, u_reverse2, u_reverse3, u_reverse4, u_reverse5, u_reverse6, u_reverse7, u_reverse8, u_reverse9, u_bigger_json
 FROM dw.user_action WHERE dt='2016-09-20';

--SquenceFile
set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
set io.seqfile.compression.type=BLOCK;
INSERT OVERWRITE table test_sequencefile PARTITION(dt='2016-09-20')
SELECT  ...
 FROM dw.user_action WHERE dt='2016-09-20';

--RCFile
set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
INSERT OVERWRITE table test_rcfile PARTITION(dt='2016-09-20')
SELECT  ...
 FROM dw.user_action WHERE dt='2016-09-20';

--ParquetFile
set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
INSERT OVERWRITE table test_parquet PARTITION(dt='2016-09-20')
SELECT  ...
 FROM dw.user_action WHERE dt='2016-09-20';

 --ORCFile
set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;
INSERT OVERWRITE table test_orcfile PARTITION(dt='2016-09-20')
SELECT  ...
 FROM dw.user_action WHERE dt='2016-09-20';

```

记录数 120195204
源文件大小 **58.5 G** （textfile 未压缩）

| 类型      | insert耗时(S)  | 存储空间(G) |
| -------   |  -----------  | ---------  |
| ORCFile  |  318.197       |  15.6 G     |
| Parquet  |  361.207       |  16.2 G     |
| RCFile    |  232.284      | 17.1 G     |
| Sequence  |  283.8       | 47.5 G    |
| TextFile  |  236.187      | 22.0 G     |

- 查询性能

```sql 
-- 方案一，测试整行记录的查询效率：
select * from dw.user_action where dt='2016-09-20' and u_diu='869436020507709' ;  
select * from test_textfile where u_diu='869436020507709' ;  
select * from test_sequencefile where u_diu='869436020507709' ;   
select * from test_rcfile where u_diu='869436020507709' ;  
select * from test_parquet where u_diu='869436020507709' ;  
select * from test_orcfile where u_diu='869436020507709' ;  

-- 方案二，测试特定列的查询效率：
select u_diu,u_xinge from dw.user_action where dt='2016-09-20' and u_diu='869436020507709' ;  
select u_diu,u_xinge from test_textfile where u_diu='869436020507709' ;  
select u_diu,u_xinge from test_sequencefile where u_diu='869436020507709' ;   
select u_diu,u_xinge from test_rcfile where u_diu='869436020507709' ;  
select u_diu,u_xinge from test_parquet where u_diu='869436020507709' ;  
select u_diu,u_xinge from test_orcfile where u_diu='869436020507709' ;  
```


| 文件格式   | 查询整行记录耗时（S）|  查询特定列记录耗时（S） |
| ------    | ----------------- |  -------------------- |
| text(未压缩) | 77.911            |    76.12             |
| text      | 64.373            |    65.867             |
| sequence  | 104.282            |  84.249               |
| rcfile    | 42.22            |   36.359             |
| parquet    | 75.876            |   37.206              |
| orcfile    | 57.094            |   34.228              |


#### 参考 
1. [浅析Hadoop文件格式](http://www.infoq.com/cn/articles/hadoop-file-format)
2. [Hive文件存储格式的测试比较](http://yugouai.iteye.com/blog/1851606) 
3. [Hive文件存储格式](http://yugouai.iteye.com/blog/1851157) 
4. [深入分析Parquet列式存储格式](http://www.infoq.com/cn/articles/in-depth-analysis-of-parquet-column-storage-format)
5. [大数据开源列式存储引擎Parquet和ORC](http://dongxicheng.org/mapreduce-nextgen/columnar-storage-parquet-and-orc/)
6. [Dremel: Interactive Analysis of Web-Scale Datasets](http://research.google.com/pubs/pub36632.html)
7. [ORC 2015: Faster, Better, Smaller](http://www.slideshare.net/Hadoop_Summit/orc-2015-faster-better-smaller-49481231)



