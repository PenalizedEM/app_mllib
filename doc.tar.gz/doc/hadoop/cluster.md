糖豆Hadoop集群与客户端环境部署
====
### 1.集群环境
1. Master 2台 Core 8台
2. Hue 第一次登录时会提示输入任意的用户名，密码作为超级用户 hadoop/hadoop@1984
3. ~~缺乏 oozie,~~impala

### 2.UHost上安装Hadoop客户端
1.安装hadoop客户端，从集群master1节点上拷贝：

> scp -r root@10.10.126.2:/home/hadoop/.versions/hadoop-*  ./

> scp -r root@10.10.126.2:/home/hadoop/hive  ./

> scp -r root@10.10.126.2:/home/hadoop/hbase  ./

2.修改配置
增加hosts映射，从集群master1节点上copy。
> scp root@10.10.126.2:/etc/hosts /tmp/hosts
> cat /tmp/hosts >> /etc/hosts
查看java home
> update-alternatives --display java

3.修改环境变量
修改vi ~/.bashrc，增加以下内容：
拷贝过来的hadoop可能有多个版本，选一个当前master正在使用的版本(查看maser的/home/hadoop/bin的软连接指向的版本)。

```java
#### Environment variables required by hadoop
# Java
   export JAVA_HOME=/usr/lib/jvm/jre-1.7.0-openjdk.x86_64/
#HDFS：
    export HADOOP_HOME_WARN_SUPPRESS=true
    export HADOOP_HOME=/home/hadoop/hadoop-2.6.0
    export HADOOP_PREFIX=$HADOOP_HOME
    export HADOOP_MAPRED_HOME=$HADOOP_HOME
    export HADOOP_YARN_HOME=$HADOOP_HOME
    export HADOOP_COMMON_HOME=$HADOOP_HOME
    export HADOOP_HDFS_HOME=$HADOOP_HOME
    export YARN_HOME=$HADOOP_HOME
    export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
    export YARN_CONF_DIR=$HADOOP_HOME/etc/hadoop
    export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
    export PATH=$PATH:$HADOOP_HOME/sbin:$HADOOP_HOME/bin
    export HADOOP_CLASSPATH=$JAVA_HOME/lib/tools.jar

# zookeeper
    export ZOOKEEPER_HOME=/home/hadoop/zookeeper
    export ZOOKEEPER_CONF_DIR=$ZOOKEEPER_HOME/conf

# Hive
   export HIVE_HOME=/home/hadoop/hive
   export HIVE_CONF_DIR=$HIVE_HOME/conf
   export PATH=$PATH:$HIVE_HOME/sbin:$HIVE_HOME/bin

# HBase
  export HBASE_HOME=/home/hadoop/hbase
  export HBASE_CONF_DIR=$HBASE_HOME/conf
  export PATH=$PATH:$HBASE_HOME/sbin:$HBASE_HOME/bin


# spark
  export SPARK_HOME=/home/hadoop/spark
  export SPARK_CONF_DIR=$SPARK_HOME/conf

# sqoop
  export SQOOP_HOME=/home/hadoop/sqoop
  export PATH=$SQOOP_HOME/bin:$PATH

# flume
    export FLUME_HOME=/home/hadoop/flume
    export PATH=$PATH:$FLUME_HOME/sbin:$FLUME_HOME/bin

  export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HIVE_HOME/bin:$HBASE_HOME/bin:$SPARK_HOME/bin:$PATH
  umask 022

# Cuda
	export LD_LIBRARY_PATH=$HADOOP_HOME/lib/native:/usr/lib64:/usr/local/cuda/lib64:/usr/local/cuda/lib:$LD_LIBRARY_PATH
  export PATH=/usr/local/cuda/bin:$PATH

```


4.使配置文件生效 source ~/.bashrc

Log：
http://uhadoop-uelrcx-master2:23188/cluster


### 3.修改历史
May 10
* 尝试logstash indexer 端
> vi /data/elk/logstash-2.2.2/Gemfile
* 改成 http
 > ./bin/plugin install logstash-output-webhdfs
* 安装gem, ruby
> * sudo yum install ruby
> * sudo yum install rubygems
* 要使用hadoop 用户  在test_001
* 修改/etc/hosts 加入hadoop 集群 host
* 不同indexer从redis list 能消费几次？只能消费一次，list rpush，往多个output写即可。

### 4. Logstash插件-webhdfs

### Error
* Retry max_retry times. This can solve problems like leases being hold by another process. Sadly this is no

* KNOWN_ERROR in rubys webhdfs client.
          if write_tries < @retry_times
            @logger.warn("Retrying webhdfs write for multiple times. Maybe you should increase retry_interval or reduce number of workers.")
            sleep(@retry_interval * write_tries)

### Shell            
```sh
input {
file {
    path => [ "/data2/wwwlogs/access.log" ]
    start_position => "beginning"
    codec => json
}
}
filter {
    urldecode {field=>"request" }
    if [request] {
        ruby {
            init => "@kname = ['method','uri','verb']"
            code => "event.append(Hash[@kname.zip(event['request'].split(' '))])"
        }
        if [uri] {
            ruby {
                init => "@kname = ['url_path','url_args']"
                code => "event.append(Hash[@kname.zip(event['request'].split('?'))])"
            }
            kv {
                prefix => "u_"
                source => "url_args"
                field_split => "& "
                remove_field => [ "url_args","uri","request" ]
            }
        }
    }
mutate {
        convert => ["u_rate", "integer"]
        convert => ["u_percent", "integer"]
        convert => ["u_buffertime", "integer"]
  }
}
output {
stdout { codec => rubydebug }
webhdfs {
   host => "10.10.126.2"
   path => "/user/data/logstash/%{+YYYY-MM-dd}/%{+HH}/%{+mm}.log"
   user => "data"
   flush_size => 10000
   idle_flush_time => 20
   open_timeout => 90
   read_timeout => 90
   retry_interval => 30
   retry_times => 8
   codec => json
 }
elasticsearch {
    hosts=>["10.10.247.210:9200","10.10.178.40:9200","10.10.198.49:9200","10.10.163.218:9200","10.10.212.137:9200","10.10.98.103:9200"]
    index=>"multipletest-%{+YYYY.MM.dd}"
}
}
```
