# HADOOP与HDFS数据压缩格式

#### 1、[cloudera 数据压缩的一般准则](http://www.cloudera.com/content/www/zh-CN/documentation/enterprise/5-3-x/topics/admin_data_compression_performance.html#)

**一般准则**

> - 是否压缩数据以及使用何种压缩格式对性能具有重要的影响。在数据压缩上，需要考虑的最重要的两个方面是 MapReduce 作业和存储在 HBase 中的数据。在大多数情况下，每个的原则都类似。
> - 您需要平衡压缩和解压缩数据所需的能力、读写数据所需的磁盘 IO，以及在网络中发送数据所需的网络带宽。正确平衡这些因素有赖于集群和数据的特征，以及您的
> - 使用模式。

- 如果数据已压缩（例如 JPEG 格式的图像），则不建议进行压缩。事实上，结果文件实际上可能大于原文件。
- GZIP 压缩使用的 CPU 资源比 Snappy 或 LZO 更多，但可提供更高的压缩比。GZIP 通常是不常访问的冷数据的不错选择。而 Snappy 或 LZO 则更加适合经常访问的热数据。
- BZip2 还可以为某些文件类型生成比 GZip 更多的压缩，但是压缩和解压缩时会在一定程度上影响速度。HBase 不支持 BZip2 压缩。
- Snappy 的表现通常比 LZO 好。应该运行测试以查看您是否检测到明显区别。
- 对于 MapReduce，如果您需要已压缩数据可拆分，BZip2、LZO 和 Snappy 格式都可拆分，但是 GZip 不可以。可拆分性与 HBase 数据无关。
- 对于 MapReduce，您可压缩中间数据、输出或二者。相应地调整您为 MapReduce 作业提供的参数。以下示例压缩中间数据和输出。MR2 先显示，然后显示 MR1。

```java
MR2
hadoop jar hadoop-examples-.jar sort "-Dmapreduce.compress.map.output=true"
      "-Dmapreduce.map.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec"
      "-Dmapreduce.output.compress=true"
      "-Dmapreduce.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec" -outKey
      org.apache.hadoop.io.Text -outValue org.apache.hadoop.io.Text input output
MR1
hadoop jar hadoop-examples-.jar sort "-Dmapred.compress.map.output=true"
      "-Dmapred.map.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec"
      "-Dmapred.output.compress=true"
      "-Dmapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec" -outKey
      org.apache.hadoop.io.Text -outValue org.apache.hadoop.io.Text input output
```

#### 2、[Hadoop 压缩实现分析](https://www.ibm.com/developerworks/cn/opensource/os-cn-hadoop-compression-analysis/)

**压缩简介**

>Hadoop 作为一个较通用的海量数据处理平台，每次运算都会需要处理大量数据，我们会在 Hadoop 系统中对数据进行压缩处理来优化磁盘使用率，提高数据在磁盘和网络中的传输速度，从而提高系统处理数据的效率。在使用压缩方式方面，主要考虑压缩速度和压缩文件的可分割性。综合所述，使用压缩的优点如下：
1. 节省数据占用的磁盘空间；
2. 加快数据在磁盘和网络中的传输速度，从而提高系统的处理速度。

**压缩格式**

1. Hadoop 对于压缩格式的是自动识别。如果我们压缩的文件有相应压缩格式的扩展名（比如 lzo，gz，bzip2 等）。
2. Hadoop 会根据压缩格式的扩展名自动选择相对应的解码器来解压数据，此过程完全是 Hadoop 自动处理，我们只需要确保输入的压缩文件有扩展名。
3. Hadoop 对每个压缩格式的支持, 详细见下表：

| 压缩格式  | 工具  | 算法  | 扩展名 | 多文件 | 可分割性 |
| -------- | --- | ------ | ----  | ----  | ------- |
| DEFLATE | 无   | DEFLATE | .deflate | 不 |  不    |
| GZIP    | gzip | DEFLATE | .gzp    | 不  |   不   |
| ZIP     | zip  | DEFLATE | .zip    | 是  | 是，在文件范围内 |
| BZIP2   | bzip2|   BZIP2 | .bz2    | 不  | 是   |
| LZO     | lzop |   LZO   | .lzo    | 不   |是  |

4. 如果压缩的文件没有扩展名，则需要在执行 MapReduce 任务的时候指定输入格式。

```java
hadoop jar /usr/home/hadoop/hadoop-0.20.2/contrib/streaming/
  hadoop-streaming-0.20.2-CD H3B4.jar -file /usr/home/hadoop/hello/mapper.py -mapper /
  usr/home/hadoop/hello/mapper.py -file /usr/home/hadoop/hello/
  reducer.py -reducer /usr/home/hadoop/hello/reducer.py -input lzotest -output result4 -
  jobconf mapred.reduce.tasks=1*-inputformatorg.apache.hadoop.mapred.LzoTextInputFormat*
```

**性能对比**

1. Hadoop 下各种压缩算法的压缩比，压缩时间，解压时间见下表:

| 压缩算法 | 原始文件大小 | 压缩文件大小 | 压缩速度  | 解压速度 |
| ------  |  ---------  | --------  | -------   | ------ |
| gzip    | 8.3GB       |  1.8GB     | 17.5MB/s |  58MB/s |
| bzip2   | 8.3GB       |  1.1GB     | 2.4MB/s  | 9.5MB/s
| LZO-bset |    8.3GB   |  2GB       |  4MB/s    |  60.6MB/s |
| LZO     |  8.3GB      |  2.9GB     | 49.3MB/s  |  74.6MB/s

因此我们可以得出：
1) Bzip2 压缩效果明显是最好的，但是 bzip2 压缩速度慢，可分割。
2) Gzip 压缩效果不如 Bzip2，但是压缩解压速度快，不支持分割。
3) LZO 压缩效果不如 Bzip2 和 Gzip，但是压缩解压速度最快！并且支持分割！

>这里提一下，文件的可分割性在 Hadoop 中是很非常重要的，它会影响到在执行作业时 Map 启动的个数，从而会影响到作业的执行效率！

所有的压缩算法都显示出一种时间空间的权衡，更快的压缩和解压速度通常会耗费更多的空间。在选择使用哪种压缩格式时，我们应该根据自身的业务需求来选择。

#### 3、[4种常用压缩格式在Hadoop中的应用](http://www.linuxidc.com/Linux/2014-05/101230.htm)

>目前在Hadoop中用得比较多的有lzo，gzip，snappy，bzip2这4种压缩格式，笔者根据实践经验介绍一下这4种压缩格式的优缺点和应用场景，以便大家在实践中根据实际情况选择不同的压缩格式。

1.**gzip压缩**

- 优点：
    1. 压缩率比较高，而且压缩/解压速度也比较快；
    2. hadoop本身支持，在应用中处理gzip格式的文件就和直接处理文本一样；
    3. 有hadoop native库；
    4. 大部分linux系统都自带gzip命令，使用方便。
- 缺点：不支持split。
- 应用场景：
    1. 当每个文件压缩之后在130M以内的（1个块大小内），都可以考虑用gzip压缩格式。譬如说一天或者一个小时的日志压缩成一个gzip文件，运行mapreduce程序的时候通过多个gzip文件达到并发。
    2. hive程序，streaming程序，和java写的mapreduce程序完全和文本处理一样，压缩之后原来的程序不需要做任何修改。

2.**lzo压缩**

- 优点：
    1. 压缩/解压速度也比较快，合理的压缩率；
    2. 支持split，是hadoop中最流行的压缩格式；
    3. 支持hadoop native库；
    4. 可以在linux系统下安装lzop命令，使用方便。
- 缺点：
    1. 压缩率比gzip要低一些；
    2. hadoop本身不支持，需要安装；
    3. 在应用中对lzo格式的文件需要做一些特殊处理（为了支持split需要建索引，还需要指定inputformat为lzo格式）。
- 应用场景：
    一个很大的文本文件，压缩之后还大于200M以上的可以考虑，而且单个文件越大，lzo优点越明显。

3.**snappy压缩**

- 优点：
    1. 高速压缩速度和合理的压缩率；
    2. 支持hadoop native库。
- 缺点：
    1. 不支持split；
    2. 压缩率比gzip要低；
    3. hadoop本身不支持，需要安装；
    4. linux系统下没有对应的命令。
- 应用场景：
    1. 当mapreduce作业的map输出的数据比较大的时候，作为map到reduce的中间数据的压缩格式；
    2. 或者作为一个mapreduce作业的输出和另外一个mapreduce作业的输入。

4.**bzip2压缩**

- 优点：
    1. 支持split；
    2. 具有很高的压缩率，比gzip压缩率都高；
    3. hadoop本身支持，但不支持native；
    4. 在linux系统下自带bzip2命令，使用方便。
- 缺点：
    1. 压缩/解压速度慢；
    2. 不支持native。
- 应用场景：
    1. 适合对速度要求不高，但需要较高的压缩率的时候，可以作为mapreduce作业的输出格式；
    2. 或者输出之后的数据比较大，处理之后的数据需要压缩存档减少磁盘空间并且以后数据用得比较少的情况；
    3. 或者对单个很大的文本文件想压缩减少存储空间，同时又需要支持split，而且兼容之前的应用程序（即应用程序不需要修改）的情况。

5.**4种压缩格式的特征的比较**

| 压缩格式  |  split   |  native  | 压缩率 | 速度 |  是否hadoop自带 | linux命令 |  换成压缩格式后，原来的应用程序是否要修改 |
| -------  |  -----   |  ------  | ----- | ---- |  ------------- | -------- |  ---------------------------------- |
| gzip     | 否       |  是       |  很高 | 比较快 |  是，直接使用  |  有       | 和文本处理一样，不需要修改 |
| lzo      | 是       |  是       | 比较高 |  很快 |  否，需要安装  |  有       | 需要建索引，还需要指定输入格式 |
| snappy   | 否       |  是       | 比较高 |  很快 |  否，需要安装  |  没有     |  和文本处理一样，不需要修改 |
| bzip2    | 是       |  否       |  最高  |  慢  |   是，直接使用  |   有     | 和文本处理一样，不需要修改 |

**目前CDH集群一般都可选安装 Hadoop_Lzo,ucloud集群目前是集成了lzo的**
