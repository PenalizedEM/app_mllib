# HDFS Snapshots 

> HDFS Snapshots 是hadoop文件系统的一个时间点副本。在hadoop的整个文件系统中或者某个子文件系统都可以使用快照。HDFS快照的常见用户案例是，数据备份，防止用户误操作和灾难恢复。
> 
> HDFS快照的实现非常高效：
>  1. 快照的创建时瞬时的，时间成本只有O(1),不包含索引节点的查找时间
>  2. 快照不会复制节点中的数据块(block)，快照只会记录block list 和 文件大小。
>  3. 快照不会影响常规的HDFS操作，修改操作会以时间倒序记录，最新的数据可以直接访问。快照数据就是当前最新的数据减去修改的数据。

任何目录一旦被设置为snapshottable，就可以制作快照。一个snapshottable的目录可以同时容纳65536份快照。snapshottable的目录个数没有限制。管理员可以设置任意目录为snapshottable。如果某snapshottable目录中快照存在，那么在这个目录既不能被删除，也不能被重命名，除非此目录中所有的快照都被删除掉。

目前不支持嵌套式的snapshottable目录。

在snapshottable目录中，快照目录路径中包含 ".snapshot" ， 假设/foo是一个snapshottable目录，/foo/bar是一个子目录，/foo目录中有一个快照s0，那么 `/foo/.snapshot/s0/bar` 就是/foo/bar的快照版本。

通常的API和CLI可以操作".snapshot"目录,例如：
- 列出snapshottable目录下的所有快照

    ```
    hdfs dfs -ls /foo/.snapshot
    ```
    
- 列出快照s0下的所有文件

    ```
    hdfs dfs -ls /foo/.snapshot/s0
    ```
    
- 拷贝快照s0中的文件
    
    ```
    hdfs dfs -cp -ptopax /foo/.snapshot/s0/bar /tmp
    ```

## 快照操作命令：

### 1.管理员操作命令

以下命令需要超级用户权限


#### 1.允许创建快照 -> Allow Snapshots


- 此命令将目录创建为snapshottable 

    ```
    hdfs dfsadmin -allowSnapshot <path>
    ```

- 参数 path -> 待snapshottable的目录路径


#### 2.不允许快照 -> Disallow Snapshots


- 此命令将使已创建的快照目录失效，使用此命令前，snapshottable目录下的快照版本必须全部已经删除

    ```
    hdfs dfsadmin -disallowSnapshot <path>
    ```
    
- 参数 path -> 待失效的snapshottable的目录路径


### 2.用户操作命令


超级管理员可以操作所用的普通用户命令


#### 1.创建快照 -> Create Snapshots


- 此命令可以在snapshottable目录中创建快照。此命令需要snapshottable目录的owner权限。

    ```
    hdfs dfs -createSnapshot <path> [<snapshotName>]
    ```
    
- 参数 
    + path -> 待创建快照的snapshottable的目录路径   
    + snapshotName -> 快照名，非必须参数，默认快照名会以创建时的时间戳命名yyyyMMdd-HHmmss.SSS", e.g. "s20130412-151029.033"


#### 2.删除快照 -> Delete Snapshots


- 此命令可以在snapshottable目录中删除快照。此命令需要snapshottable目录的owner权限。

    ```
    hdfs dfs -deleteSnapshot <path> <snapshotName>
    ```
    
- 参数 
    + path -> 待删除快照的snapshottable的目录路径   
    + snapshotName -> 快照名

#### 3.重命名快照 -> Rename Snapshots


- 此命令可以在snapshottable目录中重命名快照。此命令需要snapshottable目录的owner权限。

    ```
    hdfs dfs -renameSnapshot <path> <oldName> <newName>
    ```
    
- 参数 
    + path -> 待重命名快照的snapshottable的目录路径   
    + oldName -> 旧快照名
    + newName -> 新快照名


#### 4.获取可创建快照的目录列表 -> Get Snapshottable Directory Listing

- 此命令会列出当前用户用权限的所有的可创建快照的(snapshottable)目录列表。

    ```
    hdfs lsSnapshottableDir
    ```

#### 5.获取快照差异报告 -> Get Snapshots Difference Report

- 此命令可以两个快照的差异。此命令需要两个快照下所有目录和文件的read权限。

    ```
    hdfs snapshotDiff <path> <fromSnapshot> <toSnapshot>
    ```
    
- 参数 
    + path -> 待比较快照所在的snapshottable的目录路径   
    + fromSnapshot -> 起始版本的快照名
    + toSnapshot -> 结束版本的快照名
- 结果：
    + + -> 文件或目录被新建
    + -  -> 文件或目录被删除
    + M -> 文件或目录被修改
    + R -> 文件或目录被重命名 
- 备注：
    + R 表示文件或目录已经被重命名，但他们让然在snapshottable目录下。
    + 如果文件或目录被重命名且被移出snapshottable目录，则这些文件或目录将会认为是 - (已删除)
    + 如果snapshottable目录外的文件被重命名到snapshottable目录内，则这些文件或目录会被认为是 + (新创建的)
- `注意`：
    + 快照差异报告并不保证操作序列的一致性。例如，我们把"/foo" 重命名为 "/foo2"，随后向 "/foo2/bar"中追加新数据，那么差异报告将呈现如下：
    
    ```shell 
        R. /foo -> /foo2
        M. /foo/bar
    ```
    即，重命名目录后追加数据的修改会被报告为在重命名目录之前操作的。


## 参考 ：
1. [HDFS Snapshots ](http://hadoop.apache.org/docs/r2.6.4/hadoop-project-dist/hadoop-hdfs/HdfsSnapshots.html)