
##同步flower video
import --connect jdbc:mysql://10.10.43.15:3306/tduser?tinyInt1isBit=false --username root --password tangdouapp#123 --table flower_video --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir  --target-dir /olap/db/flower_video/ -m 1
/user/hue/oozie/workspaces/hue-oozie-1474784874.49/lib/mysql-connector-java-5.1.39-bin.jar

use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS flower_video (
id int COMMENT '主键自增',
uid int  COMMENT '送花用户id',
vid bigint  COMMENT '送花视频id',
num int   COMMENT '送花朵数',
cancel int  COMMENT '取消空间喜欢'
)
COMMENT'视频送花表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/flower_video/';


##同步playlistvideo
import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table playlistvideo --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/playlistvideo/ -m 1
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS playlistvideo (
id int COMMENT '主键自增',
vid bigint  COMMENT '视频id',
pid int  COMMENT '专辑id',
createtime string   COMMENT '创建时间',
position int  COMMENT '权重'
)
COMMENT'专辑视频关联表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/db/playlistvideo/';
