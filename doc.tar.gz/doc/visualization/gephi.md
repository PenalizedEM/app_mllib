# Gephi使用简介

> Gephi是一款开源免费跨平台基于JVM的复杂网络分析软件,，其主要用于各种网络和复杂系统，动态和分层图的交互可视化与探测开源工具。

## 使用流程：

### 1、数据准备

这里准备的是csv格式的数据，还可以使用键盘输入、gml或者gexf文件、程序生成。

格式如下图所示，这里表示的是一个有权有向图，Source为源节点，Target为目标节点，Weight为权重。我这里认为权重都是一样的，所以只保留了source和target两列。


<img src="/image/gephi_data_pre.png"   />


### 2、Gephi软件准备

（1）下载地址：Gephi官网  <https://gephi.org/>	

（2）打开“数据资料”选项卡，点击“输入电子表格”，导入的csv文件

<img src="/image/gephi_data_input1.png"  />

（3）设置要导入的csv文件

设置正确的分隔符（如果不知道，将csv用记事本打开查看每列之间的分隔符号），注意第二项，这里选择的是“边表格”，这里的格式选择“GB2312”，选择别的编码方式，如果数据包含中文你可能会看到的乱码。设置完成后，点击下一步直至完成。

<img src="/image/gephi_data_input2.png"   />

<img src="/image/gephi_data_input3.png"  />

（4）在概览界面看到初始网络效果

<img src="/image/gephi_pic_display.png"  />

（5）根据节点特性为节点设置渐变色（可选）

 注意，设置后一定要点击“应用”
 
 <img src="/image/gephi_node_color.png"  />

（6）按照节点特性设置节点大小（可选）

<img src="/image/gephi_node_size.png" />

（7）使用同样的方法，可以调节边的颜色和大小

（8）调整布局，有多种布局方式，点击相应的名字，点击“运行”按钮；直到图像变化相对稳定，点击“停止”按钮(可以通过滚动鼠标的滚轮，来放大、缩小图片；通过右键点击图片，可以移动图片在视野中的位置)

<img src="/image/gephi_layout.png"  />


（9）为图中节点增加标签
点击增加标签的图中的点，右键---“数据实验室中选择”；点击“数据资料标签”，然后再“数据资料”中，光标自动选中的行，就是该节点所在行，手动输入Label值即可

<img src="/image/gephi_node_label.png"  />

增加标签

<img src="/image/gephi_node_label_add.png" />


添加后，如下图所示

<img src="/image/gephi_node_label_show.png" />

（10）预览界面保存图片
点击“预览”界面中的“输出：，保存成png格式，选择路径并输入图片名称

<img src="/image/gephi_pic_save.png"  />






## 参考

1、[Gephi官网](https://gephi.org/)

2、[Gephi中文教程](https://www.udemy.com/gephi/)

3、[Gephi官方项目展示](http://forum.gephi.org/)



