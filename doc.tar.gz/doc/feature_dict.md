特征字典
====

### item特征

|  特征字段  | 特征释义      | 特征取值   | 日志接口 |
| :--------: |:--------: | :------: |:------: |
| vid  | 视频ID | 1500653224987 |u_vid|
| f_vid  | 哈希后的视频id | 1392178808 |hash(vid)|
| hits_total  | 视频点击总数 | 448 |concat(u\_mod,'-',u\_ac)='top-hits'|
| comment_total  | 视频评论总数 | 10 |concat(u\_mod,'-',u\_ac) in ('message-video\_comment\_add','message-video\_comment\_reply')|
| share  | 视频分享总数 | 2 |concat(u\_mod,'-',u_ac) in ('user-share')|
| duration  | 视频时长 | 38 |video表(sql)|
| coderate  | 视频码率 码率/256 | 1 |video表(sql)|
| definition  | 清晰度 | 2 |video表(sql)|
| uid  | 视频作者id | 1309850 |video表(sql)|
| type  |  视频类型 | 10 |video表(sql)|
| chid_category  | 视频小类 | 12 |video表(sql)|
| degree  | 难度: 1简单 2适中 3稍难 | 2 |video表(sql)|
| genren  | 曲风 | 2 |video表(sql)|
| fav_count  | 视频收藏人数 | 24 |fav表(sql)|
| flower_uv  | 视频送花人数 | 4 |flower\_video表(sql)|
| createhour  | 视频发布时间距离现在时间(精确到小时) | 21.32 |根据video表(sql)的createtime计算|
| onedayctr  |最近一天视频点击率 | 14.35 |根据点击接口concat(u\_mod,'-',u\_ac)='top-hits'和曝光接口concat(u\_mod,'-',u\_ac)='emptylog-video_display'计算|
| onedayclick |最近一天视频点击数 | 18 |concat(u\_mod,'-',u\_ac)='top-hits'|
| onedaygood  |最近一天视频点赞数 | 102 |concat(u\_mod,'-',u\_ac) in ('user-fav','flower-good')|
| onedaycomment  |最近一天视频评论数 | 10 |concat(u\_mod,'-',u\_ac) in ('message-video\_comment_add','message-video\_comment\_reply')|
| onedayshare  |最近一天视频分享数 | 6 |concat(u\_mod,'-',u\_ac) in ('user-share')|
| allctr  |vid累计点击率 | 7.321 |根据点击接口concat(u\_mod,'-',u\_ac)='top-hits'和曝光接口concat(u\_mod,'-',u\_ac)='emptylog-video\_display'计算|
| sevendayctr  |最近七天视频点击率 | 6.01 |根据点击接口concat(u\_mod,'-',u\_ac)='top-hits'和曝光接口concat(u\_mod,'-',u\_ac)='emptylog-video\_display'计算|
| sevendayclick  |最近七天视频点击数 | 37 |concat(u\_mod,'-',u\_ac)='top-hits'|
| sevendaygood  |最近七天视频点赞数 | 7 |concat(u\_mod,'-',u\_ac) in ('user-fav','flower-good')|
| sevendaycomment  |最近七天视频评论数 | 3 |concat(u\_mod,'-',u\_ac) in ('message-video\_comment\_add','message-video\_comment\_reply')|
| sevendayshare  |最近七天视频分享数 | 2 |concat(u\_mod,'-',u\_ac) in ('user-share')|
| u\_exavgtime  |过去7天视频跳出平均时长 | 39.34|concat(u\_mod,'-',u\_ac)='emptylog-video\_play\_speed'下，get\_json\_object(u\_bigger\_json,'$.u\_playtime')|
| u\_exavgpre |过去7天视频跳出平均进度 | 36.5 |concat(u\_mod,'-',u\_ac)='emptylog-video\_play\_speed'下，u\_percent字段|

### user特征

|  特征字段  | 特征释义      | 特征取值   |日志接口 |
| :--------: |:--------: | :------: | :------: |
| u_act\_status  | 用户活跃度 | 5 |da.user_profile表(hive)|
| u_actperiod  | 用户活跃时段 | 2 |da.user_profile表(hive)|
| u_citylevel  | 用户活跃城市级别 | 2 |da.user_profile表(hive)|
| u_wvdur  | 用户最近30天日均观看视频时长 | 410.39 |da.user\_profile表(hive)|
| u_wvcnts  | 用户最近30天日均观看视频数量 | 8.11 |da.user\_profile表(hive)|
| u_cc  | 最近30天最常观看视频的小类   | 22 |da.user\_profile表(hive)|
| cc_2  | 最近30天第二最常观看视频的小类  | 12 |da.user\_profile表(hive)|
| u_osv  | 用户操作系统版本  | 1 |da.user\_profile表(hive)|
| u_client  | 用户客户端类型  | 2 |da.user\_profile表(hive)|
| u_fresh  | 设备已激活天数  | 169 |da.user\_profile表(hive)|
| u_active  | 设备累计活跃天数  | 135 |da.user_profile表(hive)|
| comments | 用户7天内日均评论次数 | 2 |concat(u\_mod,'-',u\_ac) in ('message-video\_comment\_add','message-video\_comment_reply')|
| shares | 用户7天内日均分享次数 | 1 |concat(u\_mod,'-',u\_ac) in ('user-share')|
| likes | 用户7天内日均点赞次数 | 1.5 |concat(u\_mod,'-',u\_ac) in ('user-fav','flower-good')|
| starts | 用户7天内日均启动次数 | 2.3 |u\_startid|
| lite_avg\_pt | 用户7天日均观看小视频时长 | 23.5 |concat(u\_mod,'-',u\_ac)='emptylog-video\_play\_speed'下, u\_playtime|
| normal_avg\_pt | 用户7天日均观看大视频时长 | 23.5 |concat(u\_mod,'-',u\_ac)='emptylog-video\_play\_speed'下, u\_playtime|
| lite_avg\_cnt | 用户7天内日均观看小视频个数 | 2 |u_vid|
| normal_avg\_cnt | 用户7天内日均观看大视频个数 | 2 |u_vid|
| lite_avg\_ctr | 用户7天内每天对小视频的平均点击率 | 9.3 |根据点击接口concat(u\_mod,'-',u\_ac)='top-hits'和曝光接口concat(u\_mod,'-',u\_ac)='emptylog-video\_display'计算|
| normal_avg\_ctr | 用户7天内每天对大视频的平均点击率 | 9.3 |根据点击接口concat(u\_mod,'-',u\_ac)='top-hits'和曝光接口concat(u\_mod,'-',u\_ac)='emptylog-video\_display'计算|
| rsource1_ctr | 用户7天对rsource为1的平均点击率 | 10.3 |get\_json\_object(u\_bigger\_json,'$.u\_rsource')|
| rsource14_ctr | 用户7天对rsource为14的平均点击率 | 1.2 |get\_json\_object(u\_bigger\_json,'$.u\_rsource')|
| rsource15_ctr | 用户7天对rsource为15的平均点击率 | 3.6 |get\_json\_object(u\_bigger\_json,'$.u\_rsource')|
| dv_vm1  |用户7天内曝光的第一常用功能 | 1 |u_client\_module|
| dv_cm2  |用户7天内曝光的第二常用功能 | 3 |u_client\_module|
| vv_cm1  |用户7天内播放的第一常用功能 | 6 |u_client\_module|
| vv_cm2  |用户7天内曝光的第二常用功能 | 1 |u_client\_module|

备注：大视频和小视频根据video表中的type来区分，type=10是小视频，type不等于10是大视频