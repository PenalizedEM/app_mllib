# 2017-08-03

| 启动时间              | 任务列表                           | 任务类型       | 备注                                       |
| ----------------- | ------------------------------ | ---------- | ---------------------------------------- |
| `00:30 -> 00:15`  | `Spark_Raw2UA`                 | spark      | 原始日志-ETL                                 |
| 00:30             | Mysql2Hdfs                     | sqoop      | 业务数据库同步                                  |
| `01:00 -> 00:45`  | `DW_EDW`                       | hive       | 数据仓库——uabigger拆分user ilog elog blog; video数据集市表生产：video_vv video_dv video_pt |
|                   | `Spark_UA2UI`                  | spark      | 全量设备信息表 uibigger生成                       |
| 01:30             | Search_User                    | hive       | 搜索引擎——搜用户，数据生成及导入mysql                   |
| `01:30 -> 08:30`  | `adm/coordinator.sh`           | hive       | 数据仓库——数据集市各业务主体层生成：推荐、关注、小视频等zeppelin底层表生成 |
|                   | ~~mid_crontab.sh~~             | ~~hive~~   |                                          |
| ~~01:35~~         | ~~coordinator_profile_pop.sh~~ | ~~spark~~  |                                          |
| `01:45  -> 01:15` | `./recy_als.sh`                | spark      | 推荐系统——离线推荐工作流                            |
| ~~02:30~~         | ~~NewUser_Identify~~           | ~~hive~~   | ~~客户端新激活用户识别~~                           |
| 05:30             | Recy_PopCat                    | hive sqoop | 相关推荐抄底数据——分类热门导入Mysql                    |
| `06:00 -> 12:00`  | Talent_Fans_Push               | hive sqoop | 直播达人粉丝推送                                 |
| ~~06:20~~         | ~~Recy_Cold_Eval~~             | ~~hive~~   |                                          |
| `07:00 -> 09:30`  | Anti_Cheating                  | hive       | 渠道反作弊——数据准备                              |
| 07:30 ->          | user_profile                   | hive       | 用户画像工作流                                  |
| ~~07:40~~         | ~~ctr.sh~~                     | ~~hive~~   |                                          |
| ~~08:00~~         | ~~mid_video_all.sh~~           | ~~hive~~   |                                          |
| 08:00             | lrrank/start.sh                | mr         | 推荐线上排序-模型同步                              |
| `08:10 -> 10:10`  | CDN_Quality                    | hive       | CDN质量邮件日报                                |
|                   | ~~Churn_User~~                 | ~~hive~~   | ~~每日新增流失设备&活跃流失设备&次日留存~~                 |
| `08:50 -> 09:50`  | DM_AC_RF_PREDICTION            | spark      | 渠道反作弊——模型训练与预测                           |
| `09:10 -> 10:10`  | Idfa_Activate_Check            | hive sqoop | ios diu2 激活实时结算校对                        |
| `10:00 -> 03:00`  | Search_Sug                     | hive sqoop | 搜索引擎——搜索提示，数据生成以及导入mysql                 |
| ~~10:10~~         | ~~First_Upload_Retention~~     | ~~hive~~   |                                          |




