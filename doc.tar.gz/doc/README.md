糖豆文档规划
===

先按照目录 写markdown
后续 拆分成不同 project，生成GitBook

### [日志相关](log/SUMMARY.md)
1. [日志规范](log/log.md)
2. [日志流](log/pipeline.md)
3. [日志事故汇总](log/issue.md)
4. [用户行为仓库](log/ua.md)
5. [用户设备仓库](log/ui.md)
6. [用户档案](log/us.md)
7. [用户事件与埋点](log/event.md)
8. [实时数据大屏](log/realtime.md)
9. [日志接口释义](log/api.md)

### [入门手册](manual/SUMMARY.md)
1. [账号体系](manual/passwd.md)
2. [集群架构](manual/cluster.md)
3. [开发环境](manual/ide.md)
4. [GitLab入门](manual/gitlab.md)
5. [ES入门](manual/es.md)
6. [Hadoop入门](manual/hadoop.md)
7. [druid入门](manual/druid.md)
8. [kafka入门](manual/kafka.md)
9. [redis实例梳理](recy/redis_instances.md)

### 糖豆服务
1. [糖豆服务底层DDL](service/ddl.md)
2. [糖豆服务底层缓存分布](service/cache.md)
3. [糖豆TV服务及性能指标](service/tv.md)

### 搜索引擎
1. [糖豆搜索引擎研发计划](search/develop.md)
2. [糖豆搜索引擎架构与部署](search/online.md)
3. [ElasticSearch 问题汇总](search/q&a.md)
4. [ELK 实践](search/elk.md)
5. [ANSJ版上线部署](search/ansj.md)
6. [ik版词典热更新流程](search/ikdic_hotupdate.md)
7. [搜索Q&A](search/q&a.md)
8. [搜索提示](search/sug.md)

### 数据仓库
1. [数仓模型](dataware/tddw.md)
2. [数据集市表说明](dataware/adm.md)

### 推荐系统
1. [推荐架构](recy/architecture.md)
2. [推荐服务](recy/service.md)
3. [推荐算法]
4. [近线流程](recy/near_realtime.md)
5. [在线推荐实现](recy/realtime.md)
6. [机器学习排序](recy/ltr.md)
7. [排序特征字典](recy/feature_dict.md)
8. [二期研发规划](recy/dev2.md)

### 用户画像
1. [画像一期规划](profile/phase_1.md)
2. [用户活跃度](profile/act_status.md)
3. [用户画像一期产出报告](profile/out_report.md)

### 用户增长
1. [核心数据指标](growth/coredata.md)
2. [增长指数](growth/share.md)
3. [个性化推送系统](growth/personalpush.md)
4. [渠道反作弊算法报告](growth/anticheating.md)

### KOL评分
1. [KOL评分模型V1.0说明](kol/phase.md)

### 数据报告
1. [不同CDN源的视频播放质量对比](report/vpquality.md)

### 业务恢复备忘
1. [用户信息表(user info)恢复](accident_recovery/user_info_recovery.md)
2. [用户行为表(user action)恢复](accident_recovery/user_action_recovery.md)
3. [搜索-用户搜索恢复](accident_recovery/search_user_full_recovery.md)
4. [搜索-搜索提示恢复](accident_recovery/search_sug_recovery.md)
5. [CDN质量日报恢复](accident_recovery/cdn_quality_recovery.md)
6. [Mysql数据同步恢复](accident_recovery/db_sync_recovery.md)
7. [idfs推广结算恢复]
8. [个推恢复]
9. [1日7日新用户与流失用户推送恢复]
10. [留存与流失日报恢复]
11. [出事老集群已有hdfs数据与部分物理恢复数据转移](accident_recovery/data_recovery.md)

### 数据技术

#### 1. OLAP相关
+   [druid](olap/druid.md)
+   [apache kylin]()
+   [linkedin pinot]()

#### 2. Hdoop相关
+ [Hdfs Snapshots](hadoop/sanpshots.md)
+ [HADOOP与HDFS数据压缩格式](hadoop/compress.md)
+ [HADOOP/HIVE文件存储格式](hadoop/file_format.md)


#### 3. 数据可视化相关
 + [Gephi使用简介](visualization/gephi.md)
