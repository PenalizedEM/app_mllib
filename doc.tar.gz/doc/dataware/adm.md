# 数据集市层各业务主题表使用说明

> 数据集市层,顾名思义,就是各种数据的大卖场;各种各样的数据在这里被下游数据应用方拿去使用，同一份数据会以不同的维度、不同的聚合程度，“卖”给不同的业务部门使用。数据集市是数据仓库中面向各业务线的最重要一层,几乎所有的BI指标,评估指标都要从数据集市层中产出。

下面将以用户操作APP的行为的不同区分不同的业务主题。按主题介绍现阶段数据集市层的各事实表。并给出使用时候应该注意的事项。

## 1、视频主题


> 视频主题是用户操作视频相关的行为日志集合,在数据集市层,我们按照一定的公共维度做了较轻的聚合。

---

- **f_video_vv 用户播放或点击视频次数**

  此事实表描述的是用户在某时间，某版本，某渠道，某客户端，某城市，点击或播放app内某个页面，某个模块第几页，某个位置的某视频的次数。

  ```sql
  CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_vv(
      d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
      d_hour int COMMENT '时间-小时',
      d_minute int COMMENT '时间-分钟',
      d_div STRING COMMENT '客户端版本号',
      d_dic STRING COMMENT '客户端渠道代码',
      d_uid int COMMENT '注册用户id',
      d_client int COMMENT '客户端类型',
      d_city STRING COMMENT '城市',
      d_source STRING COMMENT '客户端页面',
      d_module STRING COMMENT '客户端模块',
      d_examid STRING COMMENT 'AB实验ID',
      d_bucketid STRING COMMENT '分桶ID',
      d_abtag STRING COMMENT 'ABTag',
      d_gtag STRING COMMENT 'gTag',
      d_page int COMMENT '页码',
      d_position int COMMENT '位置',
      d_vid bigint COMMENT '视频的id',
      m_vv int COMMENT '视频播放次数'
  )
  COMMENT '数据集市层——事实表——用户播放视频(videoviewtimes),字符型字段默认值为-,数值型默认为-1'
  PARTITIONED BY(dt STRING)
  ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\001'
  STORED AS PARQUET
  LOCATION '/dw/adm/f_video_vv';
  ```

  `维度`：设备id、时间、版本、渠道、注册用户id、客户端、城市、视频所在页面、视频所在模块、AB测试实验id、AB测试分桶ID，AB测试分桶tag，做增长AB实验的gtag(已弃用)，视频所在的页面，视频所在的位置，视频id
  
  `度量`：视频被播放的次数

  `使用举例`：
  
  要查所有版本、城市下视频被播放的次数和人数和视频被播放的去重个数

  ```sql
  select 
      d_div, 
      d_city, 
      sum(m_vv) m_vv,
      count(distinct d_diu) m_uv,
      count(distinct d_vid) m_vcnt
  from 
      adm.f_video_vv
  where 
      dt='${datebuf}'
  group by 
      d_div, 
      d_city
  ```

  `注意事项`:
  
  此表中一个diu一天之内可能有多个版本，多个城市，多个渠道等维度属性。所以现根据这些维度聚合计算出这些维度下的去重设备数之后，再把设备数求和汇总，会得到错误的去重设备数。因为同一台设备在多个维度下被数重复计算了。

---

- **f_video_dv 视频被用户浏览或曝光的次数**

  此事实表描述的是一个视频在某时间，某版本，某渠道，某客户端，某城市，某个页面，某个模块被用户浏览或曝光的次数。

  ```sql
  use adm;
  CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_dv(
      d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
      d_hour int COMMENT '时间-小时',
      d_minute int COMMENT '时间-分钟',
      d_div STRING COMMENT '客户端版本号',
      d_dic STRING COMMENT '客户端渠道代码',
      d_uid int COMMENT '注册用户id',
      d_client int COMMENT '客户端类型',
      d_city STRING COMMENT '城市',
      d_source STRING COMMENT '客户端页面',
      d_module STRING COMMENT '客户端模块',
      d_examid STRING COMMENT 'AB实验ID',
      d_bucketid STRING COMMENT '分桶ID',
      d_abtag STRING COMMENT 'ABTag',
      d_gtag STRING COMMENT 'gTag',
      d_vid bigint COMMENT '视频的id',
      m_dv int COMMENT '视频展现次数'
  )
  COMMENT '数据集市层——事实表——视频被浏览或曝光(displayvideo),字符型字段默认值为-,数值型默认为-1'
  PARTITIONED BY(dt STRING)
  ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\001'
  STORED AS PARQUET
  LOCATION '/dw/adm/f_video_dv';
  ```

  `维度`：设备id、时间、版本、渠道、注册用户id、客户端、城市、视频所在页面、视频所在模块、AB测试实验id、AB测试分桶ID，AB测试分桶tag，做增长AB实验的gtag(已弃用)，视频id
  
  `度量`：视频被浏览或曝光的次数

  `使用举例`：
  
  要查某几个视频在所有的页面、所有的模块下被浏览或曝光的次数和人数

  ```sql
  select 
    d_vid,
      d_source, 
      d_module, 
      sum(m_dv) m_dv,
      count(distinct d_diu) m_uv 
  from 
      adm.f_video_dv
  where 
      dt='${datebuf}'
    and d_vid in ('xx','xx')
  group by 
    d_vid,
      d_source, 
      d_module
  ```

  `注意事项`:
  
  由于用户在一次浏览行为中会看到多个视频，所以在本表中视频被曝光的次数、人数只能分开查询。本表只能用来查询视频的曝光次数或人数，如果要查模块的曝光，请用 f_vide_cmdv；要查页面的曝光，请用 f_video_pagedv 

---

- **f_video_cmdv 模块被用户浏览或曝光的次数**

  此事实表描述的是一个模块在某时间，某版本，某渠道，某客户端，某城市，某个页面被用户浏览或曝光的次数。

  ```sql
  CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_cmdv(
      d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
      d_hour int COMMENT '时间-小时',
      d_minute int COMMENT '时间-分钟',
      d_div STRING COMMENT '客户端版本号',
      d_dic STRING COMMENT '客户端渠道代码',
      d_uid int COMMENT '注册用户id',
      d_client int COMMENT '客户端类型',
      d_city STRING COMMENT '城市',
      d_source STRING COMMENT '客户端页面',
      d_module STRING COMMENT '客户端模块',
      d_examid STRING COMMENT 'AB实验ID',
      d_bucketid STRING COMMENT '分桶ID',
      d_abtag STRING COMMENT 'ABTag',
      d_gtag STRING COMMENT 'gTag',
      m_dv int COMMENT '模块展现次数'
  )
  COMMENT '数据集市层——事实表——用户浏览模块(client—module displayvideo),字符型字段默认值为-,数值型默认为-1'
  PARTITIONED BY(dt STRING)
  ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\001'
  STORED AS PARQUET
  LOCATION '/dw/adm/f_video_cmdv';
  ```

  `维度`：设备id、时间、版本、渠道、注册用户id、客户端、城市、视频所在页面、视频所在模块、AB测试实验id、AB测试分桶ID，AB测试分桶tag，做增长AB实验的gtag(已弃用) 
  
  `度量`：模块被浏览或曝光的次数

  `使用举例`：

  要查某几个模块在所有的页面下被浏览或曝光的次数和人数

  ```sql
  select 
      d_module, 
      d_source, 
      sum(m_dv) m_dv,
      count(distinct d_diu) m_uv 
  from 
      adm.f_video_dv
  where 
      dt='${datebuf}'
    and d_d_module in ('xx','xx')
  group by 
      d_module, 
      d_source
  ```

  `注意事项`:
  
  本表只能用来查询模块的曝光。

---

- **f_video_pagedv 模块被用户浏览或曝光的次数**

  此事实表描述的是某页面在某时间，某版本，某渠道，某客户端，某城市 被用户浏览或曝光的次数。

  ```sql
  CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_pagedv(
      d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
      d_hour int COMMENT '时间-小时',
      d_minute int COMMENT '时间-分钟',
      d_div STRING COMMENT '客户端版本号',
      d_dic STRING COMMENT '客户端渠道代码',
      d_uid int COMMENT '注册用户id',
      d_client int COMMENT '客户端类型',
      d_city STRING COMMENT '城市',
      d_source STRING COMMENT '客户端页面',
      d_module STRING COMMENT '客户端模块',
      d_examid STRING COMMENT 'AB实验ID',
      d_bucketid STRING COMMENT '分桶ID',
      d_abtag STRING COMMENT 'ABTag',
      d_gtag STRING COMMENT 'gTag',
      m_dv int COMMENT '页面内模块展现次数'
  )
  COMMENT '数据集市层——事实表——页面内模块曝光次数,与模块曝光表cmdv的区别在于,如果一次曝光涉及多个模块,在cmdv表中,每个模块都会有一条记录,在pagedv中只有一条记录, pagedv用来统计页面的曝光和点击率,cmdv用来统计模块的点击率。字符型字段默认值为-,数值型默认为-1'
  PARTITIONED BY(dt STRING)
  ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\001'
  STORED AS PARQUET
  LOCATION '/dw/adm/f_video_pagedv';
  ```

  `维度`：设备id、时间、版本、渠道、注册用户id、客户端、城市、AB测试实验id、AB测试分桶ID，AB测试分桶tag，做增长AB实验的GTG(已弃用) 
  
  `度量`：页面被浏览或曝光的次数

  `使用举例`和`注意事项`同f_video_cmdv 

---

- **f_video_pt 用户播放视频的时长**

  此事实表描述的是用户一天之内在某版本，某渠道，某客户端，某城市，累计播放app内某个页面，某个模块某视频的时长与最大播放完整度。

  ```sql
  CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_video_pt(
      d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
      d_div STRING COMMENT '客户端版本号',
      d_dic STRING COMMENT '客户端渠道代码',
      d_uid int COMMENT '注册用户id',
      d_client int COMMENT '客户端类型',
      d_city STRING COMMENT '城市',
      d_source STRING COMMENT '客户端页面',
      d_module STRING COMMENT '客户端模块',
      d_examid STRING COMMENT 'AB实验ID',
      d_bucketid STRING COMMENT '分桶ID',
      d_abtag STRING COMMENT 'ABTag',
      d_gtag STRING COMMENT 'gTag',
      d_vid bigint COMMENT '视频的id',
      m_pp bigint COMMENT '视频最大播放进度',
      m_pt bigint COMMENT '视频播放时长'
  )
  COMMENT '数据集市层——事实表——视频播放时长与进度(playtime),字符型字段默认值为-,数值型默认为-1'
  PARTITIONED BY(dt STRING)
  ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\001'
  STORED AS PARQUET
  LOCATION '/dw/adm/f_video_pt';
  ```

  `维度`：设备id、时间、版本、渠道、注册用户id、客户端、城市、视频所在页面、视频所在模块、AB测试实验id、AB测试分桶ID，AB测试分桶tag，做增长AB实验的gtag(已弃用)，视频id
  
  `度量`：一天内累计播放视频的时长，一天内播放视频的最大完整度

  `使用举例`：

  要查某视频在所有模块下的播放时长最大播放进度

  ```sql
  select 
      d_source, 
      d_module, 
      sum(m_pt) m_pt,
      max(m_pp) m_pp 
  from 
      adm.f_video_pt
  where 
      dt='${datebuf}'
    and d_vid in ('xx')
  group by 
      d_source, 
      d_module
  ```

  `注意事项`:

  - 本表只能用来查询视频的播放时长。如果要查视频的播放人数，需要从 f_video_vv表中查。因为在某些情况下，比如用户点开视频后迅速退出播放页，这时算一次播放行为，但是用于监控上报视频播放时长的接口还没来得及调起，f_vdieo_pt表中就不会有用户的此次播放行为。
  - 由于统计播放时长逻辑比较复杂，一天之内，该表中同一用户如果有不同的版本、渠道、城市等维度，为了保证播放时长不被重复计算，只取各个维度的最大值，即在此表中，一个用户各个维度的取值只有一条。

## 2、用户主题

> 用户主题是用户活跃行为相关的日志集合,在数据集市层,我们尽量保留用户在一天内活跃的各个维度属性的取值。用户的新增、活跃相关的统计指标可以从主题的表中获得。

---

- **f_user_act 用户活跃行为**

  此事实表描述的是用户在某版本，某渠道，某客户端，某城市等维度下，观看、下载、收藏、送花、关注、分享、上传并调用有效接口(不包括日志埋点接口)的次数或数量。

  ```sql
  CREATE EXTERNAL TABLE IF NOT EXISTS adm.f_user_act(
      d_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
      d_div STRING COMMENT '客户端版本号',
      d_dic STRING COMMENT '客户端渠道代码',
      d_uid int COMMENT '注册用户id',
      d_client int COMMENT '客户端类型',
      d_city STRING COMMENT '城市',
      d_abtag STRING COMMENT 'ABTag',
      m_isnew int COMMENT '是否为当日新增用户—— 0 否, >0 是',
      m_vv int COMMENT '观看普通视频个数—— 0 无观看, >0 有观看',
      m_litevv int COMMENT '观看小视频个数—— 0 无观看, >0 有观看',
      m_down int COMMENT '下载了视频/舞曲的次数—— 0 无下载, >0 有下载',
      m_fav int COMMENT '收藏视频的个数—— 0 无, >0 有',
      m_flower int COMMENT '给视频送花的数量—— 0 无, >0 有',
      m_follow int COMMENT '关注用户的个数—— 0 无, >0 有',
      m_share int COMMENT '分享视频的次数—— 0 无, >0 有',
      m_localup int COMMENT '从本地上传视频的次数—— 0 无, >0 有',
      m_showup int COMMENT '上传秀舞视频的次数—— 0 无, >0 有',
      m_liteucnt int COMMENT '上传小视频的次数—— 0 无, >0 有',
      m_cnt int COMMENT '调用有效服务接口的次数'
  )
  COMMENT '数据集市层——事实表——活跃用户,字符型字段默认值为-,数值型默认为-1'
  PARTITIONED BY(dt STRING)
  ROW FORMAT DELIMITED
  FIELDS TERMINATED BY '\001'
  STORED AS PARQUET
  LOCATION '/dw/adm/f_user_act';
  ```

  `维度`：设备id、版本、渠道、注册用户id、客户端、城市、AB测试分桶tag
  
  `度量`：是否为新增用户，观看普通视频个数、观看小视频个数、下载视频/舞曲次数、收藏视频个数、给视频送花数量、关注用户个数、分享视频次数、上传视频次数、发布秀舞视频次数、发布小视频次数、调用服务接口次数

  `使用举例`：

  要查一天内有播放视频(含小视频)的用户的比例

  ```sql
  select
    count(distinct d_diu) m_dau,
    count(distinct if((m_litevv + m_vv)>0,d_diu,null)) m_vu,
    round( count(distinct if((m_litevv + m_vv)>0,d_diu,null))/count(distinct d_diu)*100,1) m_vvrate
  from adm.f_user_act
  where dt='${datebuf}'
  ;
  ```

  `注意事项`:

  - 本表的活跃用户主要指，用户使用app并与服务器发生了有效数据交换请求。在线埋点日志上报接口不包括在内。因此，如果一个用户一天之内除了调用初始化、推送等非用户主动触发的接口外，还调用了日志接口但是无有效的业务接口，不算做日活。
  - 由于同一设备一天之内可能有多个AB测试分桶tag，如，原来标记为A的设备升级后tag变为了20。当统计各tag下的去重活跃设备，并将不同tag的去重活跃设备加和将大于当日日活设备。因为有多个tag的设备会被重复计算。

## 3、推荐主题

​   未完待续…

## 4、搜索主题

​   未完待续…

## 5、其他

### 1、ABTag取值说明

ABTag是做AB测试的tag标记。在之前的版本只有A/B两个取值。A为有猜你喜欢的版本,B为无的版本。
在随后的版本,上线了新的AB实验分桶功能,在新版本中,ABTag的取值为0~99.
