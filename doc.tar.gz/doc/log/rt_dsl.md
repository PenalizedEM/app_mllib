#### Table of contents
- [实时数据ES JSON请求串](#实时数据ES-JSON请求串)
        - [1.KPI数据(中上)](#1.KPI数据(中上))
            - [1.1 uv 日活](#1.1-uv-日活)
            - [1.2 pv 总请求次数（QPS的话需要确定统计口径）](#1.2-pv-总请求次数（QPS的话需要确定统计口径）)
            - [1.3 vv 视频播放次数](#1.3-vv-视频播放次数)
        - [2.用户数据(中下)](#2.用户数据(中下))
            - [2.1 实时用户星点图(热力图)](#2.1-实时用户星点图(热力图))
        - [3.互动数据(左上)](#3.互动数据(左上))
            - [3.1 评论数 comment_cnt](#3.1-评论数-comment_cnt)
            - [3.2 分享数 share_cnt](#3.2-分享数-share_cnt)
            - [3.3 收藏数 fav_cnt](#3.3-收藏数-fav_cnt)
            - [3.4 送花数 flower_cnt](#3.4-送花数-flower_cnt)
            - [3.5 点赞数 praise_cnt](#3.5-点赞数-praise_cnt)
        - [4.搜索数据(右下)](#4.搜索数据(右下))
            - [4.1 搜索关键词云 keywords](#4.1-搜索关键词云-keywords)
## 实时数据ES JSON请求串

#### 1.KPI数据(中上)

##### 1.1 uv 日活

`Warn: 日活计算不过滤main-start接口：(u_mod=main AND u_ac=start)` 

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "*",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "uv": {
      "cardinality": {
        "field": "u_diu.raw"
      }
    }
  }
}
'
```

##### 1.2 pv 总请求次数（QPS的话需要确定统计口径）

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "*",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "pv": {
      "value_count": {
        "field": "_id"
      }
    }
  }
}
'
```

##### 1.3 vv 视频播放次数

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:top AND u_ac:[hits hits_pc]",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "vv": {
      "value_count": {
        "field": "u_vid.raw"
      }
    }
  }
}
'
```

#### 2.用户数据(中下)

##### 2.1 实时用户星点图(热力图) 

`Todo: 过滤非中国区域的无效坐标；时间区间确认`

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "size": 0,
  "query": {
    "filtered": {
      "query": {
        "query_string": {
          "query": "*",
          "analyze_wildcard": true
        }
      },
      "filter": {
        "bool": {
          "must": [
            {
              "range": {
                "@timestamp": {
                  "gte": "2016-08-18 00:00:00",
                  "lt": "2016-08-18 00:01:00",
                  "format": "yyyy-MM-dd HH:mm:ss"
                }
              }
            }
          ]
        }
      }
    }
  },
  "aggs": {
    "lat": {
      "terms": {
        "field": "u_lat.raw",
        "size": 1000,
        "order": {
          "_count": "desc"
        }
      },
      "aggs": {
        "lon": {
          "terms": {
            "field": "u_lon.raw",
            "size": 1000,
            "order": {
              "_count": "desc"
            }
          }
        }
      }
    }
  }
}
'
```

#### 3.互动数据(左上)

##### 3.1 评论数 comment_cnt

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:message AND u_ac:[video_comment_add video_comment_reply]",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "comment_cnt": {
      "value_count": {
        "field": "_id"
      }
    }
  }
}
'
```

##### 3.2 分享数 share_cnt

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:user AND u_ac:share",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "share_cnt": {
      "value_count": {
        "field": "_id"
      }
    }
  }
}
'
```

##### 3.3 收藏数 fav_cnt

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:user AND u_ac:fav",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "fav_cnt": {
      "value_count": {
        "field": "_id"
      }
    }
  }
}
'
```

##### 3.4 送花数 flower_cnt

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:user AND u_ac:fav",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "flower_cnt": {
      "sum": {
        "field": "u_num"
      }
    }
  }
}
'
```

##### 3.5 点赞数 praise_cnt

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:message AND u_ac:video_praise",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "praise_cnt": {
      "value_count": {
        "field": "_id"
      }
    }
  }
}
'
```

#### 4.搜索数据(右下)

##### 4.1 搜索关键词云 keywords

`搜索大搜接口: search-all_video`

```json
curl -XPOST 'http://123.59.51.44:9200/logstash-2016.08.18,logstash-2016.08.19/_search?pretty=true' -d '
{
  "from": 0,
  "size": 0,
  "query": {
      "filtered": {
          "query": {
              "query_string": {
                  "query": "u_mod:search AND u_ac:all_video",
                  "analyze_wildcard": true
              }
          },
          "filter": {
              "bool": {
                  "must": [
                      {
                          "range": {
                              "@timestamp": {
                                  "gte": "2016-08-18 00:00:00",
                                  "lt": "2016-08-19 00:00:00",
                                  "format": "yyyy-MM-dd HH:mm:ss"
                              }
                          }
                      }
                  ]
              }
          }
      }
  },
  "aggs": {
    "kewords":  {
      "terms": {
        "field": "u_key.raw",
        "size": 10,
        "order": {
          "_count": "desc"
        }
      }
    }
  }
}
'
```


