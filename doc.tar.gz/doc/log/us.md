用户档案
===
1. [用户轨迹](#TOC-User_Seesion)
2. [用户信息](#TOC-User_Profile)
  * [用户静态信息](#TOC-User_Info)
  * [用户核心交互行为](#TOC-User_Coreact)
  * [用户核心交互表](#TOC-User_Coreact_Table)
  * [接口码表](#TOC-Dict_InterMapping_Table)
  * [接口码表内容](#TOC-Dict_InterMapping_Content)
3. [开发规划](#TOC-Dev_Plan-Dance)
4. [时间线备忘](#TOC-Time_Line)
5. [效果预估](#TOC-Display)


## <a name="TOC-User_Seesion"></a> 1.用户轨迹
### 1.1 数据格式:
> diu|uid|start|time,activity,infos;time,activity,infos|end|

疑惑：
* infos不一定能拿到。有没有更好的数据结构？json。
* 如何构建session？
* 如何在服务端日志定义事件？

diu+startid+time+stepid+mod-ac/activity.

### 1.2 数据结构：
1. 不聚合(服务端使用HBase，数据端不聚合)
  * {"diu":"869043026602292","startid":"13789600","stepid":"1","activity":"首页"}
  * {"diu":"869043026602292","startid":"13789600","stepid":"2","activity":"播放页"}

~~2. 按照session聚合
  *~~ ~~{"diu":"869043026602292","startid":"13789600","dt":"2016-07-01","infos":[{"stepid":"1","activity":"首页","time":"1465368430127"},{"stepid":"2","activity":"播放页","time":"1465368430127"}]}~~

### 1.3 用户核心轨迹表(user_core_track)：

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :-------- |:-------- |  :------ | :------ | :------ |
| d_diu | 设备唯一号,android--imei, ios--IDFV | STRING | 是 | 867490026819636 |
| d_session | 用户session id | STRING | 是 | 13280012 |
| d_step | 客户端的操作步骤| INT | 是 | 1 |
| d_time | 客户端时间戳 |STRING | 是 | 1464862074390(单位 毫秒) |
| d_event | 客户端当前页面(应该用客户端event)| STRING | 是 | 首页 |


```sql
-- create user core act table
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS user_core_track(
	d_diu STRING COMMENT '设备标示',
  d_session    STRING COMMENT '用户session',
  d_step    STRING COMMENT '客户端的操作步骤',
  d_time    STRING COMMENT '客户端时间戳',
  d_event    STRING COMMENT '客户端当前event'
)
COMMENT '糖豆用户核心轨迹表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hadoop/dw/uct/';
```

### 1.4 用户核心轨迹信息表(user_core_track_info)：

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :-------- |:-------- |  :------ | :------ | :------ |
| d_diu | 设备唯一号,android--imei, ios--IDFV | STRING | 是 | 867490026819636 |
| d_session | 用户session id | STRING | 是 | 13280012 |
| d_dic | 渠道号| STRING | 是 | gf |
| d_div | 版本号 |STRING | 是 | 4.7.0 |
| d_client | 客户端类型 |STRING | 是 | ios|


```sql
-- create user core act table
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS user_core_track_info(
	d_diu STRING COMMENT '设备标示',
  d_session    STRING COMMENT '用户session',
  d_dic    STRING COMMENT '渠道号',
  d_div    STRING COMMENT '版本号',
  d_client    STRING COMMENT '客户端类型'
)
COMMENT '糖豆用户核心轨迹信息表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hadoop/dw/ucti/';
```

### 1.5 初步效果预估
![用户轨迹图1](img/usersession1.png)

参考growingio的样式

![用户轨迹图2](img/usersession2.png)

## <a name="TOC-User_Profile"></a>  2.用户信息
### <a name="TOC-User_Info"></a> 2.1 用户静态信息：
集合user info 和数据库 user 表

![用户信息概览](img/userprofile.png)

### <a name="TOC-User_Coreact"></a> 2.2 用户核心交互行为:
  * 搜索:top,radar,tag
  * 在线看
  * 离线看
  * 评论
  * 上传
  * 下载
  * 收藏
  * 点赞
  * 分享
  * 糖小豆
  * 空间页
  * 拍摄
  * 舞队：加入舞队，退出，查找舞队

![用户行为汇总](img/usersummary.png)

### <a name="TOC-User_Coreact_Table"></a> 2.3 用户核心交互表(user_core_act)

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :-------- |:-------- |  :------ | :------ | :------ |
| d_diu | 设备唯一号,android--imei, ios--IDFV | STRING | 是 | 867490026819636 |
| d_dt | 时间分区，供druid使用 | STRING | 是 | 2016-07-01 |
| m_interface_count | 接口次数| INT | 是 | 123 |
| m_interface_distinct | 接口个数 | INT | 是 | 42 |
| m_search_all | 搜索总计| INT | 是 | 123 |
| m_searh_top | 框搜 | INT | 是 | 42 |
| m_searh_radar | 附近搜 | INT | 是 | 42 |
| m_searh_tag | 标签搜 | INT | 是 | 42 |
| m_online_play | 在线播放次数 | INT | 是 | 42 |
| m_offline_play | 离线播放次数 | INT | 是 | 42 |
| m_comment | 评论次数 | INT | 是 | 42|
| m_upload | 上传次数 | INT | 是 | 42|
| m_download | 下载次数 | INT | 是 | 42|
| m_like | 收藏 | INT | 是 | 42 |
| m_praise | 点赞 | INT | 是 | 42 |
| m_share | 分享 | INT | 是 | 42 |
| m_txd | 糖小豆 | INT | 是 | 42 |
| m_space | 空间页 | INT | 是 | 42 |
| m_shot | 拍摄 | INT | 是 | 42 |
| m_team_all | 舞队总计 | INT | 是 | 42 |
| m_follow | 关注 | INT | 是 | 42 |
| m_unfollow | 取消关注 | INT | 是 | 42 |
| m_reverse0 | 保留字段 | INT | 是 | 42 |
| m_reverse1 | 保留字段 | INT | 是 | 42 |
| m_reverse2 | 保留字段 | INT | 是 | 42 |
| m_reverse3 | 保留字段 | INT | 是 | 42 |
| m_reverse4 | 保留字段 | INT | 是 | 42 |
| m_reverse5 | 保留字段 | INT | 是 | 42 |
| m_reverse6 | 保留字段 | INT | 是 | 42 |
| m_reverse7 | 保留字段 | INT | 是 | 42 |
| m_reverse8 | 保留字段 | INT | 是 | 42 |
| m_reverse9 | 保留字段 | INT | 是 | 42 |

#### <a name="TOC-Coreact_Hive"></a>Hive建表语句

```sql
-- create user core act table
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS user_core_act(
	d_diu STRING COMMENT '设备标示',
  d_dt    STRING COMMENT '日期',
	m_interface_count INT COMMENT '接口次数',
  m_interface_distinct INT COMMENT '接口个数',
  m_search_all INT COMMENT '搜索总计',
  m_searh_top INT COMMENT '框搜',
  m_searh_radar INT COMMENT '附近搜',
  m_searh_tag INT COMMENT '标签搜',
  m_online_play INT COMMENT '在线播放次数',
  m_offline_play INT COMMENT '离线播放次数',
  m_comment INT COMMENT '评论次数',
  m_upload INT COMMENT '上传次数',
  m_download INT COMMENT '下载次数',
  m_like INT COMMENT '收藏',
  m_praise INT COMMENT '点赞',
  m_share INT COMMENT '分享',
  m_txd INT COMMENT '糖小豆',
  m_space INT COMMENT '空间页',
  m_shot INT COMMENT '拍摄',
  m_team_all INT COMMENT '舞队总计',
  m_follow INT COMMENT '关注',
  m_unfollow INT COMMENT '取消关注',
	m_reverse0 STRING COMMENT '保留字段',
	m_reverse1 STRING COMMENT '保留字段',
	m_reverse2 STRING COMMENT '保留字段',
	m_reverse3 STRING COMMENT '保留字段',
	m_reverse4 STRING COMMENT '保留字段',
	m_reverse5 STRING COMMENT '保留字段',
	m_reverse6 STRING COMMENT '保留字段',
	m_reverse7 STRING COMMENT '保留字段',
	m_reverse8 STRING COMMENT '保留字段',
	m_reverse9 STRING  COMMENT '保留字段'
)
COMMENT '糖豆用户核心行为表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/user/hadoop/dw/uca/';
```
```sql
ALTER TABLE user_core_act ADD COLUMNS (dt STRING )
```
### <a name="TOC-Dict_InterMapping_Table"></a>  2.4 接口码表(dict_interface)

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :-------- |:-------- |  :------ | :------ | :------ |
| d_mod | 接口次数| INT | 是 | 123 |
| d_ac | 接口个数 | INT | 是 | 42 |
| d_para | 搜索总计| INT | 是 | 123 |
| d_type | 框搜 | INT | 是 | 42 |

### <a name="TOC-Dict_InterMapping_Content"></a> 2.5 接口码表内容(dict_interface)

| type      | mod       | ac | para   |
| :-------- |:-------- |  :------ | :------ |
| 搜索 | search| * | 无 |
| 大搜 | search | all_video | 无  |
| 附近搜 | search| radar | 无 |
| 标签、舞曲搜 | search| vtag_teach | 无 |
| 在线播放 | top| hits,hits_pc | 无 |
| 离线播放 | emptylog | video_play_speed | "m_new_activity": "离线播放页"  |
| 评论 | message| video_comment_add· | 无 |
| 上传 | video_upload| add | 无 |
| 下载 | video| count_video | 无|
| 收藏 | user| fav | 无 |
| 评论点赞 | message| video_praise | 无 |
| 分享 | user | share | 无 |
| 糖小豆 | message | txdfeed | 无 |
| 空间页| user | space_user | 无 |
| 拍摄| video_upload | mp3_rank |无 （点击拍摄会掉mp3排序接口） |
| 舞队总计| myteam | teamInfo |无 （点击我的舞队会调用舞队信息） |

## <a name="TOC-Dev_Plan"></a> 3.开发规划
### 3.1 Jul 1 ~ Jul 7
- [x] 用户信息模块开发。

### 3.2 Jul 8 ~ Jul 15
- [x]Druid 导入集成。
- [x]用户轨迹数据预研。

### 3.2 Jul 16 ~ Jul 23
- [ ]数据工作流调度。
- [ ]数据服务与前端。

## <a name="TOC-Time_Line"></a> 4. 时间线备忘

## <a name="TOC-Display"></a> 5. 效果预估

![用户档案效果预估1](img/userabout.png)

![用户档案效果预估2](img/userabout1.png)
