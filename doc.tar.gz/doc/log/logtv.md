电视版日志规范
====

1. [接口](#TOC-Api)
2. [主版更新](#TOC-Ver)
  * [主版需求](#TOC-Main-Demand)
        - [播放页监控](#TOC-Video_Play_Speed)
  * [主版检查点](#TOC-Main-Check)
3. [日志配置](#TOC-Log-Configuration)
  * [位置](#TOC-Log-Path)
  * [格式](#TOC-Log-Format)
4. [必传字段](#TOC-Must-Filed)
  * [原有](#TOC-Old-Filed)
  * [新增](#TOC-New-Filed)

## <a name="TOC-Api"></a>接口
地址: http://123.59.76.200:9890/index.php?act=api&tag=6

账号密码：apptangdou tdapp

## <a name="TOC-Ver"></a>主版更新
### <a name="TOC-Main-Demand"></a>主版需求
----
#### <a name="TOC-Video_Play_Speed"></a>播放页监控

* 模块(mod)：emptylog
* 接口(ac)：video_play_speed
* 触发时间：操作播放器行为时


| 名称      | 含义       |  参数   |  取值  |
| :--------: |:--------: | :------: | :------: |
| **播放完整度**  | 页面停留时间/视频播放时间| percent | 0~5000|
| 播放进度  |视频播放进度（百分比)|rate |0~100整数|
| 跳转来源 |跳转过来页面名称|old_activity | 页面中文名称  |
| 跳转终点  |跳转到页面名称(当前页)|new_activity | 页面中文名称  |
| **首播缓冲时间**    |进入播放页到视频开始播放的时间|buffertime| 0到无穷大 毫秒 |
| 操作播放器行为    |对播放器的操作|action|  快进 ff,快退 fb,退出 exit,完成 complete  |
| 视频id  |视频的id|vid | 用户点击的视频id  |
| 视频码率类型  |视频分辨率各个类型|ishigh | 1 低清 2 高清 3 720p 4 1080p   |
| cdn名称 | 播放视频属于哪个CDN的名称| cdn_source | 服务端分发的cdn名称，目前有cc,ucloud|
