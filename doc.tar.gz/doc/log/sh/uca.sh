#!/bin/bash
#riqizizeng
#set -X

#input arguments cannot be null
if [ -z "$1" ] || [ -z "$2" ] ;then
echo "parameter error! please input the parameter!
para format YYYY-MM-DD"
exit 0
else

datebeg=$1
dateend=$2
#read datebeg
#read dateend
beg_s=`date -d "$datebeg" +%s`
end_s=`date -d "$dateend" +%s`

#database=dw
#database=da

#table=user_info
#table=user_core_act

#path=dw/ui
path=dw/uca

# echo -n "use $database;
# ALTER TABLE ${table} ADD IF NOT EXISTS
# ">add_partition.sql

while [ "$beg_s" -le "$end_s" ]
do
year=`date -d @$beg_s +"%Y"`
month=`date -d @$beg_s +"%m"`
day=`date -d @$beg_s +"%d"`
partition="${year}-${month}-${day}"
#hadoop jar dw.jar com.xiaotang.data.job.UIStatJob $partition
hive -d datebuf=$partition -f uca.sql

beg_s=$((beg_s+86400))
done

# hive -f ./add_partition.sql

# hive -e "use $database; show partitions $table;"

fi
