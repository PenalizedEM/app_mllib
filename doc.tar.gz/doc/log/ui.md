用户行为表
====
## <a name="TOC-Para"></a>参数与含义

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :-------- |:-------- |  :------ | :------ | :------ |
|u_diu | 设备唯一号,android--imei, ios--IDFV | STRING | 是 | 867490026819636 |
| u_diu2 | 广告ID,android--mac, ios--IDFA | STRING | 是 | 04021f19876e |
| u_diu3 | GUID,android--guid, ios--guid | STRING | 是 | fdd83e5fd6564e71b370f7a96a637889 |
| u_uid | 注册用户id | STRING | 是 | 1100432 |
| u_uuid | 用户设备号(md5) | STRING | 是 | 439f14616af06262957cd01392c81afc |
| u_hash | 加密验证串 | STRING | 是 | e6b1ed63193875d38ff568bc582bcd5b |
| u_xinge | 信鸽token | STRING | 是 | 298a32a355dac2db48aab4afe1c136a14322fc8e |
| u_token | 用户单点登录token | STRING | 否 | f0fcaebaa959bec0615f75ad3ca4d5c7(和服务端确认下) |
| u_div_f | 首次激活时的客户端版本号 | STRING | 是 | 4.5.0|
| u_div | 当前客户端版本 | STRING | 是 | 4.5.6|
| u_dic_f | 首次激活时的客户端渠道号 | STRING | 是 | gf |
| u_dic | 当前客户端渠道号 | STRING | 是 | gf |
| u_client | 客户端类型 | STRING | 是 | 1 ios，2 android |
| u_timestamp_f | 首次激活时的请求时间 | TIMESTAMP | 是 | YYYY-MM-DD HH:MM:SS |
| u_timestamp | 当前请求时间 | TIMESTAMP | 是 | YYYY-MM-DD HH:MM:SS |
| u_netop_f | 首次激活时的网络运营商 | STRING | 是 | 中国电信 |
| u_netop | 当前网络运营商 | STRING | 是 | 中国电信 |
| u_province_f | 首次激活时用户所在省份 | STRING | 是 | 广东省 |
| u_province | 用户所在省份 | STRING | 是 | 湖北省 |
| u_city_f | 首次激活时用户所在城市 | STRING | 是 | 湛江市 |
| u_city | 用户所在城市 | STRING | 是 | 武汉市 |
| u_manufacture | 生产厂家 | STRING | 是 | Xiaomi |
| u_model | ios:固件版本; android:手机模型  | STRING | 是 | Lenovo+A820t |
| u_device | ios:设备型号; android:设备 | STRING | 是 | hwG620-L75 |
| u_width | 屏幕尺寸——宽 | INT | 是 | 1080 |
| u_height | 屏幕尺寸——高 | INT | 是 | 1920 |
| u_fresh | 用户新鲜度(当天减去激活天数) | INT | 是 | 12 |
| u_active | 用户累计活跃天数 | INT | 是 | 40 |
| u_tag | 用户标签 | STRING | 是 | 帅气 |
| u_bigger_json | 最后的大json | STRING | 否 | 空字段 |

## <a name="TOC-Hive"></a>Hive建表语句
