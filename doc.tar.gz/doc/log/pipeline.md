日志管道流
===
### 1.日志类型

### 2. 日志采集架构
* 收集  Logstash Agent,Beat,Flume……
* 路由  Redis Cluster, Kafka……
* 清洗 Logstah Indexer , Java, SH……
* 消费 实时  Storm, Spark Streaming…… / 离线 logstash plugin、MR

td_new004 td_new003 写入 test_001
td_new002 td_new001 写入 test_002
[root@test logstash]# echo “java -jar /data/logstash/logstash-1.1.0-monolithic.jar agent -f /data/logstash/etc/shipper.conf &” >>/etc/rc.local
