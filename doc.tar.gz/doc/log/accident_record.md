
### 事故复原：

> 在测试sqoop的时候，尝试从mysql导入hdfs数据之前，先删除指定目录的数据，hue中在配置sqoop节点时，有一个配置界面，可以添加导数据之前要删除的目录路径，如果添加了要删除的目录，但是没有输入具体路径的话，hue默认就删除<delete path="${nameNode}/user/${wf:user()}/"/> ，保存任务后，提交sqoop，转换为mr，mr直接删除了/user/hadoop用户根目录，由于是mr删除，删除的数据不会进入.Trash，导致所有数据开始逐一被彻底删除。

### 事故影响：

1. 丢失了自4月份以来所有原始日志数据，以及日志中累计的用户信息数据。
2. 影响线上每日个推(只能使用最近20天的数据)、1~7天新用户推送（diu xinge fresh act lastactivetime）、ios渠道推广实时结算系统（idfa createtime）
3. 线上搜索-search-sug的更新  
4. 9月财报数据 

### 事故补救：

1. ucloud磁盘恢复
2. 补救user info表，只有 diu xinge fresh actiive lastactivetime 最终能得到 diu xinge createtime lastacctivetime fresh  active 
3. 补救日志，只能拿到8月31日到现在的日志
4. 补救个推，用户推送的历史数据没了，只能给最近20天的用户推送最近最新的视频，过一段时间后，等待用户忘却后，再放开待推送视频列表
5. 1~7天新用户推送，根据补救的user info， 滚动 diu fresh active createtime  lastactivetime
6. ios渠道推广实时结算系统 （idfa creattime） 根据每日日志补充 diu对应的idfa，根据存量idfa和日志里面的新idfa累计更新difa
7. 线上搜索 search-sug， 根据 search-sug数据累计更新。
8. 9月财报数据，依赖最近20天日志的恢复。