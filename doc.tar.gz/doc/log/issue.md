日志事故汇总
====
## 1.问题时间线备忘
### 1.1 Jun/22/2016事故

ES集群连续宕机两台，凌晨宕机ES3，由于无自动重启机制，数据内部均衡，导致写入缓慢，数据堆积在消息队列Redis上。64G内存的Redis大致可以存储3800w条日志。消息队列堆满，导致无法解析消费。由于实时读取access文件，22日当天无法消费完，次日启动新的pipeline写入templog-june20160622。scp数据到新机器。

解决方法：
  * 加大内存
  * 停止logstash shipper写入
  * 停止logstash indexer在同一机器的解析
  * 加大ES集群，使用SSD机器

改进方案：
  * ES实例自启动
  * 扩大ES集群，使用全SSD机器
  * 迁移到Kafka集群
  * logstash实例自启动

遗留问题：
  * 后续涉及到22日的原始日志的任务，需使用Temp_ES2HDFS和Temp_Raw2UA，指定输入时间2016-06-22.
  数据目录:

  > /user/hadoop/test/logstatsh/2016-06-21/part*,/user/hadoop/test/logstatsh/templog-june20160622/part*

同时暴露了目前的工作流缺陷，时区导致昨日的index要今天八点之后才会写入完。需要加入次日中午12点，再拉取一次ES数据。
目前indexer都部署在gitlab这台机器上，onlineidtest01.conf需要修改ip。

## 2.零级事故
### 2.1 Sep/22/2016 事故
2016-09-22 18:10 HDFS数仓整体被删。原因oozie配置sqoo任务时候，没有填入删除目录，默认删除用户根目录。


改进方案：
  * 原始日志不在和数仓放在同一根目录。
    * /raw/es/ 原始日志  
    * /raw/ui/ 20160401~20160921的diu表  
    * /olap/dw/  dw日志  
    * /olap/da/  da日志
    * /olap/db/  db备份
  * Hue 独立部署
  * 启动堡垒机，启动审计日志。
  
事故复原：

> 在测试sqoop的时候，尝试从mysql导入hdfs数据之前，在hue中在配置sqoop节点时，有一个配置界面，可以添加导数据之前要删除的目录路径，如果添加了要删除的目录，但是没有输入具体路径的话，hue默认就删除用户根目录（这一点之前不知道）<delete path="${nameNode}/user/${wf:user()}/"/> ，保存任务后，提交sqoop，转换为mr，mr直接删除了/user/hadoop用户根目录，由于是mr删除，删除的数据不会进入.Trash，导致所有数据开始逐一被彻底删除。

事故影响：

1. 丢失了自4月份以来所有原始日志数据，以及日志中累计的用户信息数据。
2. 影响线上每日个推(只能使用最近20天的数据)、1~7天新用户推送（diu xinge fresh act lastactivetime）、ios渠道推广实时结算系统（idfa createtime）
3. 线上搜索-search-sug的更新  
4. 9月财报数据 

事故补救：

1. ucloud磁盘恢复
2. 补救user info表，只有 diu xinge fresh actiive lastactivetime 最终能得到 diu xinge createtime lastacctivetime fresh  active （`db中userinfo的备份业务日期为2016-09-21`）
3. 补救日志，只能拿到8月31日到现在的日志
4. 补救个推，用户推送的历史数据没了，只能给最近20天的用户推送最近最新的视频，过一段时间后，等待用户忘却后，再放开待推送视频列表
5. 1~7天新用户推送，根据补救的user info， 滚动 diu fresh active createtime  lastactivetime
6. ios渠道推广实时结算系统 （idfa creattime） 根据每日日志补充 diu对应的idfa，根据存量idfa和日志里面的新idfa累计更新difa
7. 线上搜索 search-sug， 根据 search-sug数据累计更新。
8. 9月财报数据，依赖最近20天日志的恢复。


