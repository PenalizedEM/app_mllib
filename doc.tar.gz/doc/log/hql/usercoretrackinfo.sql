----用户轨迹信息(根据第一步获得)
insert overwrite table dw.user_core_track_info partition (dt='${datebuf}')
select
  u_diu d_diu,
  u_startid d_session,
  u_dic d_dic,
  u_div d_div,
  if(u_client=1,'ios','android') d_client
from
  dw.user_action
 where
  dt='${datebuf}' and u_mod='emptylog' and
  u_ac in ('user_role','video_play_speed') and u_startid <>1 and
  u_stepid = 1 and u_diu rlike '^[\\w-]{5,75}?$';

dfs -touchz /user/hadoop/dw/ucti/dt=${datebuf}/_SUCCESS;
