set hive.auto.convert.join=false
select /*+ MAPJOIN(c) */  b.id,b.name,a.u_active from (select u_uid,u_province,u_active from dw.user_info where dt="2016-10-27" and u_province="重庆市" order by u_active desc limit 1000)a
join (select id,name from dw.user)b on a.u_uid=b.id limit 200;


/*+ MAPJOIN(c) */

select id,name,`sign` from dw.user where `sign` > 365 and province="重庆市";

desc dw.video;

select a.uid,b.name,a.pv from (select uid,count(1)pv from dw.video where type='8' and to_date(`createtime`)>="2016-08-28" group by uid order by pv desc limit 200)a join (select id,name from dw.user)b on a.uid=b.id;
select uid,count(1)pv from comment where   date(`time`)>="2016-08-28" group by uid order by pv desc limit 200;
