
insert overwrite table dw.user_core_act partition (dt='${datebuf}')
select
 u_diu d_diu,
 dt d_dt,
 count(concat(u_mod,u_ac)) m_interface_count,
 count(distinct concat(u_mod,u_ac)) m_interface_distinct,
 sum(if(concat(u_mod)='search',1,0)) m_search_all,
 sum(if(concat(u_mod,'|',u_ac)='search|all_video',1,0)) m_searh_top,
 sum(if(concat(u_mod,'|',u_ac)='search|radar',1,0)) m_searh_radar,
 sum(if(concat(u_mod,'|',u_ac)='search|vtag_teach',1,0)) m_searh_tag,
 sum(if(concat(u_mod,'|',u_ac) in ('top|hits','top|hits_pc'),1,0)) m_online_play,
 sum(if(concat(u_mod,'|',u_ac,'|',u_new_activity)='emptylog|video_play_speed|离线播放页',1,0)) m_offline_play,
 sum(if(concat(u_mod,'|',u_ac)='message|video_comment_add',1,0)) m_comment,
 sum(if(concat(u_mod,'|',u_ac)='video_upload|add',1,0)) m_upload,
 sum(if(concat(u_mod,'|',u_ac)='video|count_video',1,0)) m_download,
 sum(if(concat(u_mod,'|',u_ac)='user|fav',1,0)) m_like,
 sum(if(concat(u_mod,'|',u_ac)='message|video_praise',1,0)) m_praise,
 sum(if(concat(u_mod,'|',u_ac)='top|ushare',1,0)) m_share,
 sum(if(concat(u_mod,'|',u_ac)='message|txdfeed',1,0)) m_txd,
 sum(if(concat(u_mod,'|',u_ac)='user|space_user',1,0)) m_space,
 sum(if(concat(u_mod,'|',u_ac)='video_upload|mp3_rank',1,0)) m_shot,
 sum(if(concat(u_mod,'|',u_ac)='myteam|teamInfo',1,0)) m_team_all,
 sum(if(concat(u_mod,'|',u_ac)='user|follow_user',1,0)) m_follow,
 sum(if(concat(u_mod,'|',u_ac)='user|unfollow_user',1,0)) m_unfollow,
 '' m_reverse0,
 '' m_reverse1,
 '' m_reverse2,
 '' m_reverse3,
 '' m_reverse4,
 '' m_reverse5,
 '' m_reverse6,
 '' m_reverse7,
 '' m_reverse8,
 '' m_reverse9
from dw.user_action
where dt='${datebuf}' and u_diu rlike '^[\\w-]{5,75}?$'
group by u_diu,dt;

dfs -touchz /user/hadoop/dw/uca/dt=${datebuf}/_SUCCESS;
