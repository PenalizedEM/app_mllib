实时数据大屏
====
实时大屏主要反映糖豆实时核心数据，主要由六个部分组成，反映糖豆产品，内容，社区等核心数据。
### 1. 单指标:
  * 总DAU/总DV，总VV，总点击率
  * 小视频DAU/小视频生产者DAU/小视频生产个数/
  * 小视频DV，VV，点击率、总观看时长、人均观看时长

### 2. 同期曲线对比
  * 分模块曝光、点击、CTR(个性化、运营、数据库热门)
  * 分功能曝光、点击、CTR(推荐流、关注流)
  * 分业务曝光、点击、CTR(小视频、正常视频)

## 3. 指标对应计算方法表

注: 日志接口由 concat(u_mod,'-',u_ac) 来定义。
### 单指标:
| 指标      | 数据来源/日志接口       | 计算方法   |
| :-------- |:-------- |  :------ | :------ |
| 总DAU | 过滤这些接口 ('main-start', 'top-count_plush', 'emptylog-push_arrival', 'main-update', 'video-ab_start', 'emptylog-count_plush', 'top-isnew_diu','video-gtag','top-test','top-hits_pc','top-abtest') | 对u_diu字段去重统计(建议采用HyperLogLog算法) |
| 总DV | 使用 'emptylog-video_display'| 需拆分u_vid内的vids，逗号分隔 |
| 总VV | 使用 'top-hits' | count(vid) |
| 总点击率 | 无 | 总VV/总DV |
| 小视频DAU | 使用 'top-hits' | 使用vid 去关联video表,取type=10,count(distinct u_diu) |
| 小视频生产者DAU | 使用video表(数据库/reids) | 取createtime=当天,count(distinct uid),where type=10|
| 小视频生产个数 | 使用video表(数据库/reids) | 取createtime=当天,count(1) ,where type=10|
| 小视频DV | 使用 'emptylog-video_display' | 使用vid 去关联video表,取type=10,count(1) |
| 小视频VV | 使用 'top-hits' | 使用vid 去关联video表,取type=10,count(1) |
| 小视频点击率 | 无 | 小视频VV/小视频DV |
| 小视频总观看时长 | 使用 'emptylog-video_play_speed' | 使用vid 去关联视频信息表(video),取type=10,sum(u_playtime) |
| 小视频人均观看时长 | 无 | 小视频总观看时长/小视频DAU |

### 同期曲线对比:

| 指标      | 数据来源/日志接口       | 计算方法   |
| :-------- |:-------- |  :------ | :------ |
| 分模块曝光 | 使用 'emptylog-video_display'| group by u_rsource(需拆分) 指定三个|
| 分模块点击 | 使用 'top-hits'| 带上u_rsource|
| 分模块CTR |无 | 分模块点击/分模块曝光 |
| 分功能曝光 | 使用 'emptylog-video_display'| group by u_client_module ("推荐/推荐流" ==推荐流)|
| 分功能点击 | 使用 'top-hits'| 带上u_client_module|
| 分功能CTR |无 | 分功能点击/分功能曝光 |
| 分业务曝光 | 使用 'emptylog-video_display'| vid关联video表,type=10为小视频|
| 分业务点击 | 使用 'top-hits'| vid关联video表,type=10为小视频|
| 分模块CTR |无 | 分业务点击/分业务曝光 |



-------------OLD-------------
## 1. KPI数据(中上)
### 1.1 具体指标
* UV : 日活
* PV(QPS) : 请求数
* VV : 视频播放次数

### 1.2 Data Flow
数据源: ES

## 2. 用户数据(中下)
### 2.1 具体指标
* 实时用户星点图(热力图)

### 2.2 Data Flow
数据源: ES

## 3.互动数据(左上)
### 3.1 具体指标
* 评论数
* 分享数
* 收藏数
* 送花数
* 点赞数

### 3.2 Data Flow
数据源: ES

## 4.社区网络(左下)
### 4.1 具体指标
* 粉丝数总数 ？
* 大V排行
* 增粉最快
* ？？？

### 4.2 Data Flow
数据源: Mysql

## 5.内容数据(右上)
### 5.1 具体指标
* 热门视频排行
* 上升最快视频排行
* 是否区分pgc,ugc

### 5.2 Data Flow
数据源: Mysql

### 6.搜索数据(右下)
### 6.1 具体指标
* 搜索关键词标签云

### 6.2 Data Flow
数据源: ES

### 7.具体DSL语句
[实时数据大屏语句](log/rt_dsl.md)
