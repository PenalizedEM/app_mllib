用户行为表
===
* *注意：在hive表中u_buffertime等非string字段可能会由于数据类型强制转换而变为NULL（目前hdfs中所有字段默认取值为空字符串）*
* *在hive表查询中，注意过滤字段为空字符串和null的情况：` where $field<>'' and $field is not null`*

--- 
- **特别注意**

`在从用户行为仓库中抽取数据进行后续业务相关的计算和统计时，注意剔除以下和用户主动行为无关接口的影响`

```
1. main-start 
2. top-count_plush
3. emptylog-push_arrival
4. main-update
5. emptylog-count_plush
6. video-ab_start
7. top-isnew_diu
8. video-gtag 
9. top-test
10.top-abtest
```

```sql
-- 剔除的hive sql

concat(u_mod,'-',u_ac) not in 
(
'main-start',
'top-count_plush',
'emptylog-push_arrival',
'main-update',
'video-ab_start',
'emptylog-count_plush',
'top-isnew_diu',
'video-gtag',
'top-test',
'top-abtest'
)
```

---------
## <a name="TOC-Para"></a>参数与含义

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :-------- |:-------- |  :------ | :------ | :------ |
| u_timestamp | 东八区时间 | TIMESTAMP | 是 | YYYY-MM-DD HH:MM:SS需兼容 |
| u_backtime | php层响应时间 | FLOAT | 是 | 34 毫秒(ES的单位为秒) |
| u_responsetime | 完整服务响应时间 | FLOAT | 是 | 30 毫秒(ES的单位为秒) |
| u_host | 服务器内网ip | STRING | 是 | 10.10.47.46 |
| u_xff | 客户端ip | STRING | 是 | 120.195.191.253 |
| u_status | http状态 | STRING | 是 | 200 |
| u_size | http返回大小 | INT | 是 | 2780 byte |
| u_div | 客户端版本号,用于标志客户端产品的不同软件版本 | STRING | 是 | 4.5.0(注意:历史原因，同时存在version和div字段) |
| u_dic | 客户端渠道代码 | STRING | 是 | gf |
| u_diu | 设备唯一号,android--imei, ios--IDFV | STRING | 是 | 867490026819636 |
| u_diu2 | 广告ID,android--mac, ios--IDFA | STRING | 是 | 04021f19876e |
| u_diu3 | GUID,android--guid, ios--guid | STRING | 是 | fdd83e5fd6564e71b370f7a96a637889 |
| u_uid | 注册用户id | STRING | 是 | 1100432 |
| u_startid | 启动标识号(距离2016年1月1号0点0分0秒这时刻有多少秒） | STRING | 是 | 13280012 |
| u_stepid | 客户端的操作步骤 | INT | 是 | 9（由于旧版安卓写成了setpid 需兼容) |
| u_time | 客户端时间戳 | STRING | 是 | 1464862074390(单位 毫秒) |
| u_mod | 服务端接口模块 | STRING | 是 | search |
| u_ac | 服务端具体接口 | STRING | 是 | radar |
| u_client | 客户端类型 | STRING | 是 | 1 ios，2 android |
| u_ver | 服务端版本 | STRING | 是 | v2 |
| u_uuid | 用户设备号(md5) | STRING | 是 | 439f14616af06262957cd01392c81afc |
| u_hash | 加密验证串 | STRING | 是 | e6b1ed63193875d38ff568bc582bcd5b |
| u_xinge | 信鸽token | STRING | 是 | 298a32a355dac2db48aab4afe1c136a14322fc8e |
| u_token | 用户单点登录token | STRING | 否 | f0fcaebaa959bec0615f75ad3ca4d5c7(和服务端确认下) |
| u_agent | 客户端agent | STRING | 是 | Dalvik/1.6.0 (Linux; U; Android 4.4.4; HM NOTE 1LTE MIUI/V7.3.1.0.KHICNDD) |
| u_method | http方法 | STRING | 是 | POST |
| u_new_activity | 跳转到页面名称(当前页) | STRING | 否 | 首页 |
| u_old_activity | 跳转过来页面名称 | STRING | 否 | 分类 |
| u_key | 搜索关键词 | STRING | 否 | 步子舞 |
| u_client_module | 用户客户端搜索模块 | STRING | 否 | top |
| u_source | 用户搜索调用的接口 | STRING | 否 | all_video |
| u_page | 用户点击第几页的搜索结果 | INT | 否 | 1 |
| u_position | 用户点击第几条的搜索结果 | INT | 否 | 2 |
| u_vid | 视频的id | STRING | 否 | 5429114 |
| u_type | 搜索排序类型 | STRING | 否 | 1(有可能和其他参数冲突，需要在转换时限定接口) |
| u_percent | 页面停留时间/视频播放时间 | INT | 否 | 22 |
| u_rate | 视频播放进度（百分比) | INT | 否 | 32 |
| u_user_role | 用户在舞队内的角色 | STRING | 否 | 1 |
| u_isnew_user | 当天注册为新用户 | STRING | 否 | 0 |
| u_isdownload | 是否点击了播放页的下载按钮 | STRING | 否 | 1 |
| u_isonline | 是否在线播放 | STRING | 否 | 0 |
| u_buffertime | 进入播放页到视频开始播放的时间 | FLOAT | 否 | 2212 毫秒 |
| u_action | 操作播放器行为 | STRING | 否 | seek |
| u_ishigh | 是否高清视频 | STRING | 否 | 0 |
| u_cdn_source | cdn名称 | STRING | 否 | ucloud |
| u_download_start | 下载开始 | TIMESTAMP | 否 | 1464922269 |
| u_download_stop | 下载结束 | TIMESTAMP | 否 | 1464922611 |
| u_fail_cdn_source | 失败cdn源 | STRING | 否 | ucloud |
| u_new_cdn_source | 切换cdn源 | STRING | 否 | ucloud |
| u_width | 屏幕尺寸——宽 | INT | 是 | 1080 |
| u_height | 屏幕尺寸——高 | INT | 是 | 1920 |
| u_lon | 用户位置——经度 | STRING | 是 | 116.927914 |
| u_lat | 用户位置——纬度 | STRING | 是 | 30.217354 |
| u_province | 用户省份 | STRING | 是 | 广东省 |
| u_city | 用户城市| STRING | 是 | 湛江市 |
| u_netop | 网络运营商 | STRING | 是 | 中国电信（注意在wifi情况下也是拿的sim卡的运营商) |
| u_nettype | 网络类型 | STRING | 是 | WIFI |
| u_sdkversion | android 系统版本号 | STRING | 是 | 4.3(注意:在ES字段名是SDKVersion) |
| u_model | ios:固件版本; android:手机模型 | STRING | 是 | Lenovo+A820t |
| u_device | ios:设备型号; android:设备 | STRING | 是 | hwG620-L75(注意:在ES字段名是device_s) |
| u_manufacture | 厂商 | STRING | 是 | 空值 |
| u_reverse0 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse1 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse2 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse3 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse4 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse5 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse6 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse7 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse8 | 保留字段 | STRING | 否 | 空字段 |
| u_reverse9 | 保留字段 | STRING | 否 | 空字段 |
| u_bigger_json | 最后的大json | STRING | 否 | 空字段 |

## <a name="TOC-Hive"></a>Hive建表语句

```sql
-- create user action table
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS user_action(
	u_timestamp TIMESTAMP COMMENT '东八区时间',
	u_backtime FLOAT COMMENT 'php层响应时间',
	u_responsetime FLOAT COMMENT '完整服务响应时间',
	u_host STRING COMMENT '服务器内网ip',
	u_xff STRING COMMENT '客户端ip',
	u_status STRING COMMENT 'http状态',
	u_size INT COMMENT 'http返回大小',
	u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
	u_dic STRING COMMENT '客户端渠道代码',
	u_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
	u_diu2 STRING COMMENT '广告ID,android--mac, ios--IDFA',
	u_diu3 STRING COMMENT 'GUID,android--guid, ios--guid',
	u_uid STRING COMMENT '注册用户id',
	u_startid STRING COMMENT '启动标识号(距离2016年1月1号0点0分0秒这时刻有多少秒）',
	u_stepid INT COMMENT '客户端的操作步骤',
	u_time STRING COMMENT '客户端时间戳',
	u_mod STRING COMMENT '服务端接口模块',
	u_ac STRING COMMENT '服务端具体接口',
	u_client STRING COMMENT '客户端类型',
	u_ver STRING COMMENT '服务端版本',
	u_uuid STRING COMMENT '用户设备号(md5)',
	u_hash STRING COMMENT '加密验证串',
	u_xinge STRING COMMENT '信鸽token',
	u_token STRING COMMENT '用户单点登录token',
	u_agent STRING COMMENT '客户端agent',
	u_method STRING COMMENT 'http方法',
	u_new_activity STRING COMMENT '跳转到页面名称(当前页)',
	u_old_activity STRING COMMENT '跳转过来页面名称',
	u_key STRING COMMENT '搜索关键词',
	u_client_module STRING COMMENT '用户客户端搜索模块',
	u_source STRING COMMENT '用户搜索调用的接口',
	u_page INT COMMENT '用户点击第几页的搜索结果',
	u_position INT COMMENT '用户点击第几条的搜索结果',
	u_vid STRING COMMENT '视频的id',
	u_type STRING COMMENT '搜索排序类型',
	u_percent INT COMMENT '页面停留时间/视频播放时间',
	u_rate INT COMMENT '视频播放进度（百分比)',
	u_user_role STRING COMMENT '用户在舞队内的角色',
	u_isnew_user STRING COMMENT '当天注册为新用户',
	u_isdownload STRING COMMENT '是否点击了播放页的下载按钮',
	u_isonline STRING COMMENT '是否在线播放',
	u_buffertime FLOAT COMMENT '进入播放页到视频开始播放的时间',
	u_action STRING COMMENT '操作播放器行为',
	u_ishigh STRING COMMENT '是否高清视频',
	u_cdn_source STRING COMMENT 'cdn名称',
	u_download_start TIMESTAMP COMMENT '下载开始',
	u_download_stop TIMESTAMP COMMENT '下载结束',
	u_fail_cdn_source STRING COMMENT '失败cdn源',
	u_new_cdn_source STRING COMMENT '切换cdn源',
	u_width INT COMMENT '屏幕尺寸——宽',
	u_height INT COMMENT '屏幕尺寸——高',
	u_lon STRING COMMENT '用户位置——经度',
	u_lat STRING COMMENT '用户位置——纬度',
	u_province STRING COMMENT '用户省份',
    u_city STRING COMMENT '用户城市',
	u_netop STRING COMMENT '网络运营商',
	u_nettype STRING COMMENT '网络类型',
	u_sdkversion STRING COMMENT 'android 系统版本号',
	u_model STRING COMMENT 'ios:固件版本, android:手机模型',
	u_device STRING COMMENT 'ios:设备型号, android:设备',
	u_manufacture STRING COMMENT '厂商',
	u_reverse0 STRING COMMENT '保留字段',
	u_reverse1 STRING COMMENT '保留字段',
	u_reverse2 STRING COMMENT '保留字段',
	u_reverse3 STRING COMMENT '保留字段',
	u_reverse4 STRING COMMENT '保留字段',
	u_reverse5 STRING COMMENT '保留字段',
	u_reverse6 STRING COMMENT '保留字段',
	u_reverse7 STRING COMMENT '保留字段',
	u_reverse8 STRING COMMENT '保留字段',
	u_reverse9 STRING COMMENT '保留字段',
	u_bigger_json STRING COMMENT '最后的大json'
)
COMMENT '糖豆用户行为表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/user/hadoop/dw/ua/';
```
