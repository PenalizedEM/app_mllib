运营活动指标
===

banner曝光： u_ac:txdbanner

banner点击: u_ac:obj_click AND u_type:2

活动扎堆页曝光 : u_ac:video_display AND u_client_module::"扎堆"

活动扎堆页视频点击: u_ac:hits AND u_source:"H5活动页" AND u_client_module:"扎堆"

活动页拍摄上传成功: u_ac:cdn_upload_speed AND u_source:'活动页扎堆' && u_client_module:'小视频拍摄'
