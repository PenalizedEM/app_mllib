## LTR
机器学习排序，目前使用PointWise将推荐排序问题，转为分类或者回归问题。

### 目前LTR特征选择  
Item特征:

+ f\_vid 视频id  
+ floweruv\_level 送花人数，分段[0,1,5,10,20,40,80,150,150+]  
+ fav\_count_level 收藏人数 分段[0,1,10,20,50,100,500,500+]  
+ hits\_level 点击分成5级，根据点击的20,40,80,99分位数来划分，取定[0,50,100,500,40000]  
+ comment\_level 评论分成5级，根据评论的60,80,90,99分位来划分，确定 [0,5,10,60,300]   
+ share\_level 分享分成5级，根据分享的40,80,90,95分类来划分，确定[0,5,10,20,50]    
+ duration 时长分成三级,确定[0,90,300]   
+ coderate 码率 码率/256  
+ definition 清晰度  
+ uid 作者id  
+ type 视频类型 视频类型 1：CC上传 11：56上传 7：CC复制 8:秀舞  
+ chid\_category 视频小类
+ degree 难度 难度: 1简单 2适中 3稍难  
+ genren 曲风

------TODO-------    

+ 视频总点击率(allctr)
+ mp3id(mp3id)
+ 视频发布时间距离现在时间(精确到小时)(createhour)
+ duration 时长分成四级,确定[0,15,90,300] (duration)
+ 最近一天视频点击率(onedayctr)
+ 最近七天视频点击率(sevendayctr)
+ 最近一天视频点击数(onedayclick)
+ 最近七天视频点击数(sevendayclick)
+ 最近一天视频点赞数(onedaygood)
+ 最近七天视频点赞数(sevendaygood)
+ 最近一天视频评论数(onedaycomment)
+ 最近七天视频评论数(sevendaycomment)
+ 最近一天视频分享数(onedayshare)
+ 最近七天视频分享数(sevendayshare)

(需要爬虫，暂时不做)

+ mp3相关特征，曲风，年代，场景等等
+ 标题分词


User特征：根据用户画像，先人工选择覆盖率高指标。

+ 活跃度(u\_act\_status >5&<-5).   
+ 活跃时段(u\_actperiod).   
+ 城市级别 (u\_citylevel).   
+ 最近30天日均观看视频数量级别 (u\_wvcnts\_range)   
+ 最近30天日均观看视频时长级别（u\_wvdur\_range）   
+ 最近30天最常观看视频的小类 (cc)
+ 最近30天第二最常观看视频的小类 (cc\_2)  
+ 操作系统版本:1:安卓4.3.0及以下,2:安卓4.3.0以上或苹果系统(u\_osv)  
+ 客户端类型: 1:安卓,2:ios,3:未知(u\_client)  
+ 设备已激活天数(u\_fresh,分段[0,7,30,90,180,360,360+])  
+ 设备累计活跃天数(u\_active,分段[0,1,7,14,30,90,180,180+])  

-----TODO------  

+ adcode/geohash-商圈级别(city级别)
+ (一段时间)用户看正常视频/小视频的总时长
+ (一段时间)用户看正常视频/小视频的个数
+ (一段时间)用户对正常视频/小视频的点击率
+ (一段时间)用户点赞/分享/评论个数
+ (一段时间)用户对不同rsource的点击率
+ (一段时间)用户每天启动次数
+ (一段时间)用户功能分布(client_module)

Context特征(反馈特征、有部分后验):

1. 视频展现推荐位
2. 请求id
3. 请求时间
4. 视频为该用户展示次数
4. 视频跳出时长
5. 视频跳出进度
6. 后验（点赞与否,评论与否,分享与否）

其中连续的特征为f\_vid和uid,其余特征已进行离散化处理    
曝光点击则label为1  
曝光未点击则为0

### 交叉特征
+ discrete_feature_6441_27=discrete(combine(uid,f_diu))      # uid f_diu
+ discrete(combine(child_category,f_diu))     # f_diu child_category
+ discrete(combine(f_vid,u_cc2))     # f_vid u_cc2
+ discrete(combine(child_category,floweruv_level,f_diu))     # floweruv_level f_diu child_category
+ discrete(combine(comment_level,child_category,floweruv_level,f_diu))     # floweruv_level comment_level f_diu child_category
+ discrete(combine(comment_level,uid,f_diu))     # uid comment_level f_diu
+ discrete(combine(f_vid,u_wvcnts_range,u_cc2))     # f_vid u_cc2 u_wvcnts_range
+ discrete(combine(duration_level,child_category,floweruv_level,f_diu))     # floweruv_level duration_level f_diu child_category
+ discrete(combine(child_category,genre,floweruv_level,f_diu))     # floweruv_level genre f_diu child_category
+ discrete(combine(f_vid,u_wvcnts_range,u_cc2,u_active_level))     # u_active_level f_vid u_cc2 u_wvcnts_range
+ discrete(combine(hits_level,child_category,floweruv_level,f_diu))     # floweruv_level f_diu child_category hits_level
+ discrete(combine(type,child_category,floweruv_level,f_diu))     # floweruv_level type f_diu child_category
+ discrete(combine(definition,type,child_category,floweruv_level,f_diu))     # floweruv_level definition type f_diu child_category
+ discrete(combine(definition,child_category,floweruv_level,f_diu))     # floweruv_level definition f_diu child_category
+ discrete(combine(definition,child_category,floweruv_level,f_diu,u_client))     # floweruv_level u_client definition f_diu child_category
+ discrete(combine(definition,child_category,floweruv_level,f_diu,u_act_status))     # floweru

### LTR效果评估
+ AUC:以False Positive Rate为Y轴和True Positive Rate为Z轴，得到ROC曲线。ROC曲线下面积就是AUC值。  
+ AUCPR:以Precision为y轴，Recall为X轴，得到PR曲线，PR曲线在正负样本比例悬殊较大时更能反映分类的性能.曲线下面积为AUCPR值。

###  实验方案
#### 添加用户画像特征
+ 用户7天内日均评论次数
+ 用户7天内日均分享次数
+ 用户7天内日均点赞次数
+ 用户7天内日均启动次数
+ 用户7天内日均观看小视频时长
+ 用户7天内日均观看大视频时长
+ 用户7天内日均观看小视频个数
+ 用户7天内日均观看大视频个数
+ 用户7天内每天对小视频的平均点击率
+ 用户7天内每天对大视频的点击率
+ 用户对rsource为1的点击率
+ 用户对rsource为14的点击率
+ 用户对rsource为15的点击率
+ 用户7天内曝光模块top1
+ 用户7天内曝光模块top2
+ 用户7天内播放模块top1
+ 用户7天内播放模块top1

使用2017-09-10的数据，AUC=0.675335312098  AUCPR=0.805706719233

#### 添加视频相关特征
+ 视频总点击率(allctr)
+ 视频发布时间距离现在时间(精确到小时)(createhour)
+ duration 时长分成四级,确定0,15,90,300
+ 最近一天视频点击率(onedayctr)
+ 最近七天视频点击率(sevendayctr)
+ 最近一天视频点击数(onedayclick)
+ 最近七天视频点击数(sevendayclick)
+ 最近一天视频点赞数(onedaygood)
+ 最近七天视频点赞数(sevendaygood)
+ 最近一天视频评论数(onedaycomment)
+ 最近七天视频评论数(sevendaycomment)
+ 最近一天视频分享数(onedayshare)
+ 最近七天视频分享数(sevendayshare)

使用2017-09-14的数据，AUC=0.699235042463  AUCPR=0.823498731063


#### 训练数据限制在推荐流
将训练数据限制在推荐流，diu不为空。使用3天的数据训练模型。
使用2017-10-26的数据，AUC=0.732698162756  AUCPR=0.794697629837

#### 添加position bias特征
+ item在展示列表中的位置，对item的点击概率和下单概率是有非常大影响的，排名越靠前的item，越容易被点击和下单，这就是position bias的含义。在抽取特征和训练模型的时候，就需要很好去除这种position bias。
+ 美团的处理方式：一个是在计算item的历史ctr和历史cvr的时候，首先要计算出每个位置的历史平均点击率ctr\_p，和历史平均下单率cvr\_p，然后在计算item的每次点击和下单的时候，都根据这个item被展示的位置，计算为ctr\_0/ctr\_p及cvr\_0/ctr\_p；一个是在产生训练样本的时候，把展示位置作为特征放在样本里面，并且在使用模型的时候，把展示位置特征统一置为0。

糖豆现状：

+ 目前提供视频位置的字段有rank和position。position是客户端上报的用户点击视频的位置，没有上报视频曝光position。rank服务接口提供的每批视频的排序位置，曝光和点击都有rank值,但是服务需要过滤掉曝光过和看过的视频，因此rank值不是连续的。
+ 一个item展示位置在前十的ctr记为：ctr\_less10,位置为前10的ctr记为：ctr\_p\_less10,位置为大于10的ctr记为：ctr\_p\_greater10。根据rank值，把位置分为小于10的和大于10的，position bias分别取ctr\_less10/ctr\_p\_less10和ctr\_less10/ctr\_p\_greater10。
+ 取2017-12-10的数据进行训练， 结果如下

| 2017-12-10| 不添加position bias | 添加position bias |
| :---: | :---: |:---:|
| AUC | 0.696924819955 | 0.695949305288  |
| AUCPR | 0.830596364847 | 0.830138633259 |

+ 分析添加的position bias 没有起到正向作用的原因为，将位置分为前10和后10的粒度太大，而且rank并不是视频真正展示的位置。















