
# 准实时（近线）推荐计算流程

> 准实时计算新启用独立集群，初始5个节点。每日将业务日（昨日）的ALS模型以及ICF相似视频结果从数仓集群distcp过来。另外，kafka会按小时切分业务日志，持久化到新集群hdfs。
> 
> 计算以小时为计算时间单元，当前时刻计算上一小时的数据。以此经过ETL、ALS候选集准备、对用户观看过的视频打分、分别计算不同算法推荐结果、融合推荐结果并排序、导出到DB等步骤。

## 大体流程如下图：

![](http://ol5qowkge.bkt.clouddn.com/recommend/%E6%8E%A8%E8%8D%90%E7%B3%BB%E7%BB%9F%E2%80%94%E2%80%94%E8%BF%91%E7%BA%BF%28%E5%87%86%E5%AE%9E%E6%97%B6%29%E8%AE%A1%E7%AE%97%E6%B5%81%E7%A8%8B.png)

其中，除用户观看过的视频打分计算，需要累计计算外，其他计算都仅限于1小时内的数据。
另外，需要每个小时从mysql中同步线上最新的video表。

## 具体数据表如下：

```shell 
|--rawlog
    |--dw.uamini
    |--dm.user_video
|--db.video
        |--dm.user_video_index
            |--dm.user_video_bias1
            |--dm.user_video_bias2
                |--dm.user_video_rating
|--dm.recy_icf_similarity_topn
                |--dm.recy_icf_recommend_pre
                    |--dm.recy_icf_recommend
                |--dm.recy_als_candy_similar
                    |--dm.recy_als_candy_final
|--recy_als_model
                        |__dm.recy_als_prediction
```

- [rawlog](http://120.132.50.53:8888/filebrowser/#/flume)
- [dw.uamini](http://120.132.50.53:8888/metastore/table/dw/uamini)
- [dm.user_video](http://120.132.50.53:8888/metastore/table/dm/user_video)
- [dm.user_video_bias1](http://120.132.50.53:8888/metastore/table/dm/user_video_bias1)
- [dm.user_video_bias2](http://120.132.50.53:8888/metastore/table/dm/user_video_bias2)
- [db.video](http://120.132.50.53:8888/metastore/table/db/video)
- [dm.user_video_index](http://120.132.50.53:8888/metastore/table/dm/user_video_index)
- [dm.user_video_rating](http://120.132.50.53:8888/metastore/table/dm/user_video_rating)
- [dm.recy_icf_similarity_topn](http://120.132.50.53:8888/metastore/table/dm/recy_icf_similarity_topn)
- [dm.recy_icf_recommend_pre](http://120.132.50.53:8888/metastore/table/dm/recy_icf_recommend_pre)
- [dm.recy_icf_recommend](http://120.132.50.53:8888/metastore/table/dm/recy_icf_recommend)
- [dm.recy_als_candy_similar](http://120.132.50.53:8888/metastore/table/dm/recy_als_candy_similar)
- [dm.recy_als_candy_final](http://120.132.50.53:8888/metastore/table/dm/recy_als_candy_final)
- [recy_als_model](http://120.132.50.53:8888/filebrowser/#/olap/dm/recy_als_model)
- [dm.recy_als_prediction](http://120.132.50.53:8888/metastore/table/dm/recy_als_prediction)

## 表之间的血缘关系如下：

![](http://ol5qowkge.bkt.clouddn.com/recommend/%E5%87%86%E5%AE%9E%E6%97%B6%E6%8E%A8%E8%8D%90%E8%BF%87%E7%A8%8B%E8%A1%A8%E8%A1%80%E7%BC%98%E5%85%B3%E7%B3%BB.png)



