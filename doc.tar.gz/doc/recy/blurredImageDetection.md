# 图像模糊检测研究进展

**摘要**:图像是人类最重要的信息源，通过各种观测系统从客观中获得，
图像容易受到像噪声或对焦而产生失真和模糊。近年来，随着人工智能和大数据的研究和应用取得较大的进展，一系列图像和视频的处理技术上也产生了大量的新算法和策略。本文针对图像模糊检测这个研究分支，简述图像模糊检测之前的方法，重点介绍近年来在该方向上的新方法和新技术，以及深度学习在此应用。
## 1. 引言
随着网络和智能手机的广泛使用，这导致图像数据的急剧增加。当前图像在我们的生活中扮演着非常重要的作用，比如短视频app、微信、Facebook和Twitter时刻记录着我们分享的视频或者图像。然而由于光线，拍摄者的抖动等影响导致大量的图像质量不高，图像模糊度是图像质量的一个重要的参考因素，因此开发一种图像模糊检测的技术显得非常必要。

当前随着人工智能和大数据急剧的发展和应用，之前一些传统的应用在图像识别与图像处理领域的算法正在逐渐被深度学习中相关的算法给替代，所以调研深度学习在图像模糊检测中的应用的可行性是有必要的。
## 2. 相关工作
之前的文献中图像模糊检测一般分为两种方法直接法和间接法[1]，间接法是用一个线性方程来描述模糊图像：，其中代表原始图像，代表未知的模糊函数，N代表噪声函数，代表现实看到的图像。

间接法是通过使用多种方法来估计模糊函数，Rooms等人[2]提出了在小波域中通过观察边缘棱角来估算模糊函数。在论文[3]中，作者通过Lipschitz指数来计算最尖锐的边缘和相关系数，该相关系数是通过高斯点扩散函数的方差和Lipschitz指数的梯度来计算得到的，Lipschitz指数取决于图像中存在的模糊，而不依赖图像内容.

直接法是通过检测和识别图像中一些具有特定属性的特征，比如边缘和拐角。当模糊事件发生之后，图像中的边缘类型和边缘的尖锐度都发生变化。通过检测这些交错分量的缺失可以辨别图像的模糊度。Marichal等人[4]通过非零DCT(Discrete Cosine Tranform离散余弦变换)系数的直方图来判别MPEG或者JPEG的模糊度，该算法考虑整个图像的DCT信息，这是基于一个重要的假设就是任何类型的边缘中图像中的尺度至少是8X8的块。文献[1]使用2D小波变换，该方法是基于假设模糊对四种不同类型的边缘有不一样的影响效果。

随着近年来深度学习的快速发展，很多文献中应用深度学习算法来评估图像，文献[5]中，作者采用二层深度置信网络(two-stage deep belief network)进行模糊类型的分类和参数识别，首先进行傅立叶变换，然后进行训练阶段采用无监督的方式以及做一些权重的调整，这样训练得到的分类器的好处是不需要像其他算法[1]那样进行手动设置特征值计算。文献[6]通过DNN来预测局部图像的质量，最终通过联合BS(Binocular Self-similarity)和BI(Binocular integration)得到图像最终的评价分数。文献[7]基于CNN提出NR IQA评测图像质量，通过CNN学习到图像局部的细节结构并被组合起来表征高层次的图像属性。和传统的特征提取算法SIFT、HOG、GIST等相比，CNN特征提取不需要进行人工设计图像中目标的特征，在文献[8]中，作者就是通过CNN特征和分类器SVM进行图像的分类。文献[9][10]中，作者展示出从事先训练好的CNN模型中提取的特征能够作为图像的通过特征，比如应用中图像分类或者识别的特征。还有一些其他的图像模糊检测的算法[11][12]。
## 3. CNN特征
以前模糊分类算法都是计算人工设计好的特征，这样计算的特征不能很好的表征大量失真图片的特性。最近很多研究人员将注意力转移到提取图片的深层次的特征结构。在论文[9][10][13]都是利用CNN(Convolutional Neural Network)抽取的特征，结果显示非常有效，并且适合多种图像分类和目标识别中，可以尝试中图像模糊检测中的应用。
## 4. CNN模型
在深度学习中，卷积神经网络CNN是最常用的一种，目前常用的CNN模型有：AlexNet[14]、VGGNet[15]、GoogleNet[16]和ResNet[17]模型。在数据库ImageNet都取得很好的效果。

这些CNN模型都可以在深度学习框架TensorFlow和Caffe上实现，网上也很方便找到相关的代码。有个基于tensorflow实现的开源工程yadlt[23]里面实现了多种深度学习算法，比如CN、RBM、DBN以及逻辑回归等等。
## 5. 现存的工具
腾讯优图开放平台提供图像识别的接口以及接口说明。比如模糊检测：fuzzydetect(self, image_path, data_type=0, seq=’’)参数：image_path 标识图片信息，data_type 表示image_path是图片还是url，0代表图片，1代表url。利用该api的python版做了一些图像模糊检测的实验[24]，输出格式如下。

检测的输出结果：{u'errorcode': 0, u'errormsg': u'OK', u'fuzzy_confidence': 0.0, u'fuzzy': False}。该检测结果显示输入的图片不是模糊的，计算得到的模糊度fuzzy_confidence为0.

Facebook开源的DeepMask[18]、SharpMask[19][21]和MultiPathNet[20][22]能够精确检测图像中物体并准确勾画出来物体的轮廓。商汤科技，网易易盾等也提供相关图像识别相关的解决方案。
## 6. 试验
本文主要使用糖豆app产生的图像数据，通过编辑人员事先手到给图像打上模糊和清晰的标签，收集到的模糊图片集有301张，清晰图片集有1585张。

### 1. 腾讯优图
采用腾讯优图提供的模糊检测api，在数据集上得到的结果如下。

做了三组试验，第一组是表1利用该api默认的参数，对每个检测图像得到的分数大于阈值0.2判断为模糊图片；第二组是表2将图片得分数设置为大于阈值0.1判断为模糊图像；第三组表3做了两次检测，第一次检测是得分大于0.1判定为模糊图像，如果得分低于0.1，裁剪出图像中间部分再检测一次，如果得分大于阈值0.08那么该图片判定为模糊图像，这个检测策略针对运动模糊场景很实用。

表1 threshold=0.2

| 名称        | True           | False |
| ------------- |:-------------:| -----:|
| Positive      | 1064| 521|
| Negative      | 128      |   173|
表2 threshold=0.1

| 名称        | True           | False |
| ------------- |:-------------:| -----:|
| Positive      | 828| 757|
| Negative      | 150      |   151|
表3 threshold1=0.1, threshold2=0.08

| 名称        | True           | False |
| ------------- |:-------------:| -----:|
| Positive      | 629| 956|
| Negative      | 196      |   105|

表4 

| 名称        | FPR           | TNR |
| ------------- |:-------------:| -----:|
|  组一    | 32.9%| 42.5%|
|  组二    | 47.8%| 49.8%|
|  组三    | 60.3%| 65.1%|


Positive指清晰图片，Negative指模糊图像，Ture指正确分类，Flase指错误分类。表1和表2当调整阈值从0.2调整到0.1的时候，对模糊图片的检测效果提升了0.07个点，如表4所示，效果不明显，当对图像进行两次检测的时候，对模糊图片的检测率提升到0.651，如表4中TNR所示。由于试验采用的清晰和模糊图片集是通过人工标注的，没有统一的标准误差会很大，所以当降低阈值的时候，从清晰图片中更加容易检测到模糊的图片，见表4中FPR。

综上所述，采用两次检测策略可以更加识别出模糊的图片。

利用组三中的检测方法，在公开图像数据集上进行测试，使用公开的测试图片数据库Corel和Caltech 101，随机选取了4153张清晰的图片，同时利用高斯模糊对这图像进行不同参数radius的模糊处理，来测试该算法的准确率。试验数据如下。

表5 正样本的检测

| 名称        | True           | False |
| ------------- |:-------------:| -----:|
| Positive      | 586| 3567|
| Rate      | 14.1%| ／ |

表6 负样本的检测

| 名称        | True           | False | TNR |
| ------------- |:-------------:| -----:| -----:|
| radius=2      | 4100| 53| 98.7%|
| radius=1.5      | 4093| 60| 98.5%|
| radius=1      | 4081| 72| 98.2%|

注：
TNR(True Negative Rate)=TN(True Negative)/TN+FN(False Negative)

FPR(False Positive Rate)=FP(False Positive)/FP+TP(True Positive)

### 2. 联合laplace和haar-wavelet
采用laplace和haar-wavelet变换[25]进行模糊检测。检测的结果比腾讯优图的效果好。采用糖豆app产生的模糊图像288张（负样本），清晰图像1583张（正样本），试验数据如下表5和表6。

表7

| 名称        | True           | False |
| ------------- |:-------------:| -----:|
| Positive      | 1129| 221|
| Negative      | 1456      |   67|

表8

| 名称        | TP           | TNR |
| ------------- |:-------------:| -----:|
| Rate      | 71.3%| 76.7%|

使用公开的测试图片数据库Corel和Caltech 101，随机选取了4153张清晰的图片，同时利用高斯模糊对这图像进行不同参数radius的模糊处理，来测试该算法的准确率。试验数据如下。

表9 正样本的检测

| 名称        | True           | False |
| ------------- |:-------------:| -----:|
| Positive      | 946| 3207|
| Rate      | 22.7%| ／ |

表10 负样本的检测

| 名称        | True           | False | TNR |
| ------------- |:-------------:| -----:| -----:|
| radius=3      | 4153| 0| 100%|
| radius=2      | 4126| 27| 99.3%|
| radius=1.5      | 3936| 217| 94.7%|
| radius=1      | 2712| 1441| 65%|


试验结果表明，在糖豆app产生的图像数据集上，联合laplace和haar-wavelet的算法要比腾讯优图模糊检测api的效果好；通过对比表5，6和表9，10，在公开图像数据集上，laplace和haar-wavelet对正样本的识别率比腾讯优图好，对负样本随着图像高斯模糊参数的变化识别也在波动很大，而腾讯优图对高斯模糊产生的负样本的识别率比较稳定。由于糖豆app产生的模糊图像由多种因素导致的，很大一部分是运动模糊和对焦模糊，比高斯模糊要复杂很多，所以我们选取laplace和haar-wavelet的方法。

### 3. CNN
根据文献[26]使用6层的卷积网络，该方法主要是针对运动模糊的识别，该6层CNN结构如下图1所示。该结构图来源文献中。
![](img/six_layers_cnn.png)
作者使用PASCAL VOC 2010数据集，自己合成不同参数的运动模糊类型图像构成训练集。关于该方法github上有一个类似的代码实现[27]。由于我们的模糊图像是由于很多种因素导致的，不仅仅是运动模糊的一种，可以利用我们的模糊图像和人工合成的运动模糊图像构成训练集。


### 4. DBN
根据文献[5]使用DBN进行模糊检测，从网上找到一个单机版的DBN和基于tensorflow版[23]的，基于tensorflow版的需要调节很多flags参数信息，未完成该版DBN的在模糊检测上的应用。

使用单机版的DBN，根据文献[5]中流程利用傅立叶变换转换到频域中再输入到DBN进行训练学习，但是在学习的过程中一直处于死循环状态，可能是傅立叶变换后的数据组合形式不对导致的，目前没有找到原因；然后重新将图像转换到小波域中再输入到DBN的时候能够训练成功，但是检测图片的时候检测结果明显不对，这两者错误都是样本数据处理的不当，目前没有找到解决办法。（待续）
## 7. 结束
本文主要简述图像模糊检测的一些算法，介绍CNN在图像模糊检测以及图像分类识别中应用，以及目前存在的工具。
	
**参考文献：**

[1] Tong, H., Li, M., Zhang, H., and Zhang, C. "Blur detection for digital images using wavelet transform," In Proceedings of the IEEE International Conference on Multimedia and Expo, vol.1, pp. 27-30, June 2004. doi: 10.1109/ICME.2004.1394114.

[2] Rooms, F., Pizurica, A., Philips, W. “Estimating image blur in the wavelet domain.” In Proc. of IEEE Int. Conf. on Acoustics and Signal Processing, vol. 4, pp.4190- 4195, IEEE, 2002.

[3] Wanqing, S., Qing, L., Yuming, W. “Tool wear detection using Lipschitz exponent and harmonic wavelet.” Mathematical Problems in Engineering, August 2013, Article ID 489261, http://dx.doi.org/10.1155/2013/489261. 

[4] Panchapakesan, K., Sheppard, D.G., Marcellin, M.W., and Hunt, B.R. “Blur identification from vector quantizer encoder distortion.” In Proc. of the 1998 International Conference on Image Processing (ICIP 98), pp. 751-755, 4-7 Oct. 1998, Chicago, IL., USA.

[5] Y.Ruomei, S.Ling: “Image Blur Classification and Parameter Identification using Two-stage Deep Belief Networks,” British Machine Vision Conference , 2013 :70.1-70.11.

[6] Yaqi Lv, Mei Yu, Gangyi Jiang , Feng Shao, Zongju Peng, Fen Chen:“No-reference Stereoscopic Image Quality Assessment Using Binocular Self-similarity and Deep Neural Network,” Signal Processing: Image Communication 2017 346-357.

[7] Wei Zhang a, Chenfei Qu a, Lin Ma b,n, Jingwei Guan c, Rui Huang “Learning structure of stereoscopic image for no-reference quality assessment with convolutional neural network,” Pattern Recognition 2016 176–187.

[8] H.Yan,X.Liu,R.Hong “Image Classification via fusing the latent deep CNN ” ICIMCS 2016 19-21.

[9] A. S. Razavian, H. Azizpour, J. Sullivan, et al. CNN featur- es off-the-shelf: An astounding baseline for recognition. arXiv preprint arXiv:1403.6382, 2014.

[10] Hirokatsu Kataoka, Kenji Iwata, Yutaka Satoh. Feature Evaluation of Deep Convolutional Neural Networks for Object Recognition and Detection. CoRR. 2015. arXiv: 1509.07627.

[11] Till Sieberth, Rene Wackrow, Jim H. “Chandler Automatic detection of blurred images in UAV image sets,” ISPRS Journal of Photogrammetry and Remote Sensing 122 (2016) 1–16.

[12] Lelégard, L., Delaygue, E., Brédif, M., Vallet, B., 2012. Detecting and correcting motion blur from images shot with channel-dependent exposure time. ISPRS Ann Photogramm. Rem. Sens. Spatial Inform. Sci. I (3), 341–346.

[13] Xiaona Song, Ting Rui, Zhengjun Zha, Xinqing Wang, Husheng Fang “The AdaBoost algorithm for vehicle detection based on CNN features,” ICIMCS 2015.

[14] Alex Krizhevsky Ilya Sutskever Geoffrey E. Hinton “ImageNet Classification with Deep Convolutional Neural Networks,” NIPS 2012.

[15] K.Simonyan, A.Zisserman “Very Deep Convolutional Networks for Large-scale Image Recognition,” ICLR 2015.

[16] Christian Szegedy, Wei Liu, Yangqing Jia, et “Going Deeper with Convolutions,” CVPR 2015.

[17] K.He, X.Zhang, S.Ren, J.Sun “Deep Residual Learning for Image Recognition,” LSVRC 2015.

[18] DeepMask: Learning to Segment Object Candidates . Pedro O. Pinheiro, Ronan Collobert, Piotr Dollár (NIPS 2015).

[19] SharpMask: Learning to Refine Object Segments . Pedro O. Pinheiro, Tsung-Yi Lin, Ronan Collobert, Piotr Dollàr (ECCV 2016).

[20] MultiPathNet:  A Multipath Network for Object Detection . Sergey Zagoruyko, Adam Lerer, Tsung-Yi Lin, Pedro O. Pinheiro, Sam Gross, Soumith Chintala, Piotr Dollár (BMVC 2016).

[21] https://github.com/facebookresearch/deepmask

[22] https://github.com/facebookresearch/multipathnet

[23] https://github.com/blackecho/Deep-Learning-TensorFlow

[24] https://github.com/Tencent-YouTu/Python_sdk

[25] Tong H, Li M, Zhang H, et al. Blur detection for digital images using wavelet transform[C]// IEEE International Conference on Multimedia and Expo. IEEE, 2004:17-20 Vol.1.

[26] Sun J, Cao W, Xu Z, et al. Learning a convolutional neural network for non-uniform motion blur removal[J]. 2015(CVPR):769-777.

[27] https://github.com/Sibozhu/MotionBlur-detection-by-CNN
