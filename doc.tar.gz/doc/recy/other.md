1. maven 打出来一个war包，然后替换/data/www/tos.recommend/webapps/ROOT/ 目录下的原有的war
使用 jar -xvf tos.recommend-1.0.0.war 替换原有 META-INF WEB-INF 目录
2. tomcat服务重启
/data/www/tos.recommend/bin/catalina.sh stop
/data/www/tos.recommend/bin/catalina.sh start
3. 服务请求地址
curl http://10.19.188.20:8080/recommend/videos/45C7EF12-8175-4AE8-978D-303941C1B6BA

curl http://10.19.168.240:8080/recommend/videos/45C7EF12-8175-4AE8-978D-303941C1B6BA


curl http://10.19.171.28:8080/recommend/videos/45C7EF12-8175-4AE8-978D-303941C1B6BA
curl http://10.19.154.104:8080/recommend/videos/45C7EF12-8175-4AE8-978D-303941C1B6BA

负载均衡
curl http://10.10.225.235:8080/recommend/videos/45C7EF12-8175-4AE8-978D-303941C1B6BA
