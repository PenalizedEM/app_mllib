## 多臂赌博机调研报告

Bandit算法来源于历史悠久的赌博学，一个赌徒，要去摇老虎机，走进赌场一看，一排老虎机，外表一模一样，但是每个老虎机吐钱的概率可不一样，他不知道每个老虎机吐钱的概率分布是什么，那么每次该选择哪个老虎机可以做到最大化收益呢？这就是多臂赌博机问题（Multi-armed bandit problem, K-armed bandit problem, MAB）。


### 算法简介

#### ε-Greedy  
选一个(0,1)之间较小的数ε，每次决策以概率ε去勘探Exploration，1-ε的概率来开发Exploitation，基于选择的item及回报，更新item的回报期望（见“增量更新期望回报”），不断循环下去。

#### SoftMax  
SoftMax利用softmax函数来确定各item的回报的期望概率排序，进而在选择item时考虑该信息，减少exploration过程中低回报率item的选择机会，同时收敛速度也会较ε-Greedy更快。

#### UCB  
Upper Confidence Bound，步骤如下：
初始化：先对每一个臂都试一遍；
按照如下公式计算每个臂的分数，然后选择分数最大的臂作为选择：  
<img src="workmemo/yinfeng/img/ucb.jpeg" width = "200" height = "100" alt="ucb" align= "center" />  
其中，x_j是item_j的平均回报，n_j是item_j截至当前被选择的次数，n为当前选择所有item的次数。上式反映了，均值越大，标准差越小，被选中的概率会越来越大，起到了exploit的作用；同时哪些被选次数较少的item也会得到试验机会，起到了explore的作用。

#### LinUCB
UCB没用充分利用上下文信息Contextual，而LinUCB的基本思想是对每个item的回报估计及其置信区间同时建模，然后每次选择回报的估计值与其标准差的和最大的那个item，因此LinUCB在推荐系统中，能够较好地平衡显示用户已经喜欢的某类文章和对其他没怎么看过的类别的文章，从而引导用户对未知类别的探索。

#### Thompson sampling  
假设每个item有一个产生回报的概率p，我们通过不断试验来估计一个置信度较高的概率p的概率分布。如何估计概率p的概率分布呢？ 假设概率p的概率分布符合beta(wins, lose)分布，它有两个参数: wins, lose， 每个item都维护一个beta分布的参数。每次试验选中一个item，有回报则该item的wins增加1，否则lose增加1。每次选择item的方式是：用每个item现有的beta分布产生一个随机数b，选择所有item产生的随机数中最大的那个item。  
<img src="workmemo/yinfeng/img/TomSampling.jpeg" width = "550" height = "220" alt="ucb" align= "center" /> 


### 算法评估
定义累积遗憾（regret）：  
<img src="workmemo/yinfeng/img/regret.jpeg" width = "200" height = "150" alt="ucb" align= "center" />   
这里我们讨论的每个臂的收益非0即1，也就是伯努利收益。每次选择后，计算和最佳的选择差了多少，然后把差距累加起来就是总的遗憾。wB(i)是第i次试验时被选中臂的期望收益， w*是所有臂中的最佳那个。

### 算法比较
<img src="workmemo/yinfeng/img/result.jpeg" width = "550" height = "300" alt="ucb" align= "center" />     
10000次模拟试验的方式对比了其效果如上图，可以看出，UCB算法和Thompson采样算法更好一些。  
Thompson sampling算法比较简单，可以优先考虑。


### 实验方案
 先使用Thompson sampling算法，实时给用户推荐K个视频。用户点击则回报为1，未点击则回报为0。    
 评估指标使用CTR，累计遗憾值。
 
### 参考文献
1. [推荐系统的EE问题及Bandit算法](http://x-algo.cn/index.php/2016/12/15/ee-problem-and-bandit-algorithm-for-recommender-systems/)  
2. [Bandit算法与推荐系统](http://www.xfyun.cn/share/?p=2606)  
3. [专治选择困难症——bandit算法](https://zhuanlan.zhihu.com/p/21388070)
 
















