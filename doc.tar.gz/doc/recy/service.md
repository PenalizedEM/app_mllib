推荐服务架构设计与实现
====
## 数据服务

### 服务流程
个性化推荐系统服务会在app首页打开后被调用，具体步骤如下：

1. 通过用户DIU获取推荐模型导出的数据列表
2. 判断推荐的数据列表是否为空
3. 推荐的数据列表如果不为空，则执行5
4. 推荐的数据列表如果为空，则获取兜底的推荐列表，然后执行5
5. 从推荐的数据列表中过滤点目前首页已经展现的视频
6. 根据推荐的分数将列表进行排序
7. 返回结果

![流程图](img/flow.png)
### 数据字段
由于推荐列表需要在首页展示，展现风格需要与之前首页其他类目一致，所需标示字段如下
+ **vid** 视频ID(max_length = 13 ~ 16)
+ **title**  视频名称(max_length = 94 ~ 128)
+ **pic**  图片(max_length = 100 ~ 128)
+ **short_title** 引导语(max_length = 11 ~ 16)
+ **hits_total** 总播放量(max_length = 7 ~ 8)
+ **comment_total** 评论数量(max_length = 4 ~ 8)


### 存储选型
**假定用户每天最多推荐视频条数为``N``, 单条推荐结果最大为 (16+128+128+16+8+8) = ``304``， 则每个用户推荐结果所占大小为304N，
按全网用户``1000w``来算，推荐结果数据占用大小为 ``3N`` g**


推荐系统每天出一次推荐结果， 因此``推荐结果需要按天区分``, 同时需要按diu来快速查询，可以采用的存储有``hbase``，``redis``等键值对数据库，``mongodb``等文档型数据库，或者
``mysql``等传统关系型数据库

+ **hbase** 键值对存储，存储量大，查询速度快，稳定性取决于集群是否高可用，如高可用，可优先选择
+ **redis** 键值对存储，存储量较大，热数据基于内存存储，查询速度快，可以考虑，不过当每个人的推荐结果N较大时，要考虑存储大小
+ **mongodb** 文档型数据库，存储量大，热数据同样存储在内存，索引速度接近于redis， 结构化，易维护，可以考虑
+ **mysql** 关系型数据库， 存储量较大，基于文件索引机制，查询速度较上述存储来说，理论值较低，可以作为备选。

** 由于目前暂定每个用户的推荐数N=20， 存储占用``60g`` 采用redis成本较高，考虑采用mongodb存储推荐数据和兜底数据**

### 数据结构
##### mongodb方案

date | diu  |vid     |  score  |  title     | pic         | short_title      |      hits_total | comment_total
-----|------|--------|---------|------------|-------------|------------------|-----------------|-----------------
日期  | diu  | 视频ID |分数     | 视频标题    |  图片        |     引导语        |      总播放量    |      评论数量

``date,diu,vid`` 做唯一索引
``date,diu`` 做联合索引
``score`` 做单独索引

这样存放，每天的数据量有``1000w * (N = 20) = 2亿``， 数据会保存``三天``的时间, 占用存储总大小为 ``2亿 * 304byte * 3 = 180g``

##### hbase方案

<table>
  <thead>
  <tr>
    <th>rowkey</th>
    <th colspan="6">f</th>
  </tr>
 </thead>
 <tbody>
   <tr>
    <td>{diu}_{date}_{vid}</td>
    <td>score</td>
    <td>title</td>
    <td>pic</td>
    <td>short_title</td>
    <td>hits_total</td>
    <td>comment_total</td>
   </tr>
 </tbody>
</table>

表的设计与mongdb类似，hbase 根据rowkey字段做索引， 当我们指定``diu``和``date``时，会快速返回rowkey在该范围内的结果，每天的数据量
为``2亿``, 可以考虑``保留更长时间的数据``

hbase存储推荐模型每天推荐的数据，mysql存储用户兜底数据

**修改hbase 表的TTL(单位为秒)**

```
hbase(main):005:0> disable 'dm_recommend_video'
0 row(s) in 3.2270 seconds

hbase(main):008:0> alter 'dm_recommend_video', NAME=> 'f', TTL => '259200'
Updating all regions with the new schema...
2/2 regions updated.
Done.
0 row(s) in 5.6700 seconds

hbase(main):010:0> enable 'dm_recommend_video'
0 row(s) in 2.1180 seconds

```


### 线上环境

<table>
  <thead>
    <tr>
      <th>业务</th>
      <th>负载均衡</th>
      <th>端口</th>
      <th>内部ip</th>
      <th>外部ip</th>
      <th>目录</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td rowspan="2">推荐服务</td>
      <td rowspan="2">10.10.225.235</td>
      <td rowspan="2">8080</td>
      <td>10.19.154.104</td>
      <td>106.75.17.74</td>
      <td rowspan="2">/data/www/tos.recommend</td>
    </tr>
    <tr>
      <td>10.19.171.28</td>
      <td>106.75.11.227</td>
    </tr>
    <tr>
      <td rowspan="2">配置中心服务</td>
      <td rowspan="2">10.10.224.55</td>
        <td rowspan="2">8080</td>
      <td>10.19.168.240</td>
      <td>106.75.64.142</td>
      <td rowspan="2">/data/www/tos.config</td>
    </tr>
    <tr>
      <td>10.19.188.20</td>
      <td>106.75.18.40</td>
    </tr>
  </tbody>
</table>

### 接口说明

#### 推荐接口

<table>
  <thead>
    <tr>
      <th>接口</th>
      <th>描述</th>
      <th>参数</th>
      <th>说明</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td rowspan="2">/recommend/videos/{diu}?date={date}</td>
      <td rowspan="2">获取用户的推荐数据</td>
      <td>diu</td>
      <td>必填， 用户diu(用户唯一标识)</td>
    </tr>
    <tr>
      <td>date</td>
      <td>非必填， 格式``yyyyMMdd``, 不填时默认为当天日期</td>
    </tr>
  </tbody>
</table>

**返回值**

```
{
    status: "success",
    result: [
      {
        "vid": "1482277823",
        "title": "冬至除了吃饺子你还需要注意这些",
        "pic": "/public/video/2016/1221/20161221075023.jpg!260",
        "shortTitle": "",
        "score": null,
        "hitsTotal": 13076,
        "commentTotal": 90
      },
      ......
    ],
    code: 1,
    size: 50
}
```

#### 配置中心接口

<table>
  <thead>
    <tr>
      <th>接口</th>
      <th>描述</th>
      <th>参数</th>
      <th>说明</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>/config/ab/tag/{diu}</td>
      <td>获取ab测试配置标识</td>
      <td>diu</td>
      <td>必填， 用户diu(用户唯一标识)</td>
    </tr>
  </tbody>
</table>

**返回值**

```
  {
  "result": "B",
  "status": "success",
  "code": 1
  }

```
