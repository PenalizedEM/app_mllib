### 一、正式环境

| 内网IP  | 外网IP  | 机器名 |
| :------------: |:---------------:| :-----:|
| 10.19.90.47      | 120.132.67.203 | jstorm001 |
| 10.19.182.153      | 120.132.66.194 |   jstorm002 |
| 10.19.4.249 | 120.132.67.239  |    jstorm003 |
| 10.19.10.250 | 120.132.68.53  |    jstorm004 |
| 10.19.62.8 | 106.75.84.23  |   jstorm005 |
| 10.19.13.103 | 120.132.70.13  |    jstorm006 |

### 二、测试环境
| 内网IP  | 外网IP  | 机器名 |
| :------------: |:---------------:| :-----:|
|10.19.61.77| 123.59.86.114  |stormTest| 

**密码全部为Dspdn1234!**

### 三、部署

1、 安装java8

```
yum install java-1.8.0-openjdk-devel.x86_64
```
2、 安装zookeeper

```
wget https://mirrors.tuna.tsinghua.edu.cn/apache/zookeeper/stable/zookeeper-3.4.10.tar.gz
解压:tar -xzvf zookeeper-3.4.10.tar.gz
编辑zoo.cfg ,for instance

tickTime=2000
initLimit=10
syncLimit=5
dataDir=/root/zookeeper
clientPort=2181

server.1=jstorm001:2888:3888  
server.2=jstorm002:2888:3888  
server.3=jstorm003:2888:3888
server.4=jstorm004:2888:3888
server.5=jstorm005:2888:3888

在zookeeper工作目录新建myid文件，后面对应上面server的编号
```
3、 安装jstorm

```
wget https://github.com/alibaba/jstorm/releases/download/2.2.1/jstorm-2.2.1.zip
解压 unzip jstorm-2.2.1.zip
编辑storm.yaml

需要修改如下地方：
storm.zookeeper.servers
storm.zookeeper.root
cluster.name
nimbus.host
storm.local.dir
jstorm.log.dir

for example

 storm.zookeeper.servers:
     - "10.19.90.47"
     - "10.19.182.153"
     - "10.19.4.249"
     - "10.19.10.250"
     - "10.19.62.8"

 storm.zookeeper.root: "/jstorm"

 cluster.name: "tangdou"

 nimbus.host: "10.19.90.47, 10.19.4.249, 10.19.62.8"
 storm.local.dir: "%JSTORM_HOME%/data"
 jstorm.log.dir: "/data/log"

```
4、 配置环境变量：

```
vim ~／.bashrc
添加如下信息
export JSTORM_HOME=/root/jstorm-2.2.1
export PATH=$PATH:$JSTORM_HOME/bin
```
5、 部署tomcat

```
下载tomcat7
在~下,新建 .jstorm 目录
将storm.yaml 拷贝到该目录下
将jstorm目录下的jstorm-ui-2.2.1.war 拷贝到 tomcat／webapp 下面。
```
6、 配置hosts

```
vim /etc/hosts
删除真实IP到localhost的映射。(ucloud 的ECS 默认有该映射，必须删除之)

for example

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6

10.19.13.103 10-19-13-103

10.19.90.47   jstorm001
10.19.182.153   jstorm002
10.19.4.249   jstorm003
10.19.10.250    jstorm004
10.19.62.8      jstorm005
10.19.13.103    jstorm006

```
7、 服务启动

```
Jstorm服务包括nimbus和supervisor，启动方式如下：
根据jstorm的配置，启动nimbus，即在 10.19.90.47, 10.19.4.249, 10.19.62.8 下，执行 nohup jstorm nimbus &
在所有节点，启动supervisor，即执行 nohup jstorm supervisor &
```
8、 Topology启动与结束

```
启动
jstorm jar streaming-1.0-SNAPSHOT.jar com.tangdou.NewEtlTopology
结束
jstorm kill NewEtlTopology
```

### 四、运维注意事项

1. zookeeper无法自动清理日志，一旦日志占满磁盘，进程将退出。手动清理方法：（保留最新的30个文件）
```
进入/root/zookeeper/version-2目录
ls -t log.*|tail -n +30 |xargs rm -f
ls -t snapshot.*|tail -n +30 |xargs rm -f
```

2. jstorm的日志在/data/log下，jstorm会自动清理（一般会稳定在34G左右）

### 五、streaming 工程介绍

* EtlBolt 老逻辑，负责处理Kafka Spout发出的所有数据。与spark streamming 的结构完全一致
* KVBolt 将Kafka Spout发送的每行数据解析，转换为LogMsg实体发出
* RecyBolt 基于收到的LogMsg，写watchset、recyedset等
* CTRBolt 计算CTR，定时同步到redis里


### 六、kafka介绍

由于jstorm改了spout的基类，导致开源的kafka spout不能使用，所以将开源的代码扒出，放到了kafka包下。
这部分代码基于kafka SimpleConsumer。low-level的，使用比较复杂，需要自己管理offset等。
使用时需要设置以下信息
```
props.setProperty("kafka.topic",topic);   kafka标题

props.setProperty("kafka.broker.hosts",borkers);   kafka borker列表

props.setProperty("kafka.zookeeper.hosts",zookeepers);     zookeeper 地址列表

props.setProperty("kafka.client.id","logstashforjstormtest");    Kafka consumer id

props.setProperty("kafka.broker.partitions","1");      Kafka broker 分区数量，正式环境为16个
```
### 七、运维程序

1、 JAVA运维程序

```
JAVA运维程序
在工程tods下，该工程分5个模块
tods 为父工程，仅有pom文件。maven依赖的版本号，统一在该文件管理。
tods_commons为公共库模块，提供公共及工具类方法。属于独立模块。
tods_mybatis为数据库访问模块，属于独立模块。
tods_akka为集群管理模块，属于独立模块。提供集群的节点发现、移除、leader选举等
tods_web为web应用模块，依赖上面两个模块。
tods_boot为微服务模块，依赖commons模块等，执行后台定时任务等。

运维微服务程序在tods_boot里。
核心类在RedisCleaner里，负责清理3天前推荐过的数据。
该bean需要配置信息redis.ip。正式环境和测试环境的配置信息分别在application-prod.properties和application-dev.properties里。application.properties 中的spring.profiles.active控制哪个配置生效。切换环境重新打包时需要修改该值。
```

2、 Python运维程序

```
python运维程序在streaming工程里，为独立的python脚本—guarder.py
disktick 定时检测磁盘可用空间，目前暂时不使用
zktick 定时清理zookeeper，保留最新的30个文件
proctick 检测关键进程是否存在，并自动启动
Apscheduler 的使用可见：http://debugo.com/apscheduler/
```