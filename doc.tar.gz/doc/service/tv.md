## 糖豆TV服务及性能

#### 接口详情
详情请查看[api接口管理工具](http://123.59.76.200:9890/index.php?act=api&tag=6)

#### 接口性能(单机性能)

1  首页类目接口

```
concurrency   50
requests      20000

Requests per second:    6322.41 [#/sec] (mean)
Time per request:       7.908 [ms] (mean)
Time per request:       0.158 [ms] (mean, across all concurrent requests)
Transfer rate:          14608.16 [Kbytes/sec] received


Percentage of the requests served within a certain time (ms)
  50%      8
  66%      9
  75%     10
  80%     10
  90%     11
  95%     12
  98%     13
  99%     16
 100%     39 (longest request)
 
```
 由于目前视频类目量较少，在并发为50， 发起2w的请求的时候，99%的rt为20ms以内， 100%的请求rt为30ms之内。 qps 为6000左右。
 
2  获取每个专辑下的视频列表接口

``` 
concurrency   50
requests      20000
 
Requests per second:    3257.06 [#/sec] (mean)
Time per request:       15.351 [ms] (mean)
Time per request:       0.307 [ms] (mean, across all concurrent requests)
Transfer rate:          16362.93 [Kbytes/sec] received

 Percentage of the requests served within a certain time (ms)
  50%      7
  66%     27
  75%     30
  80%     31
  90%     33
  95%     34
  98%     36
  99%     39
 100%     55 (longest request)
``` 
在并发为50， 发起2w的请求的时候，99%的rt为50ms以内， 100%的请求rt为60ms之内。 qps 为3000左右。

3  获取专辑列表接口

```
concurrency   50
requests      20000

Requests per second:    7332.30 [#/sec] (mean)
Time per request:       6.819 [ms] (mean)
Time per request:       0.136 [ms] (mean, across all concurrent requests)
Transfer rate:          19754.23 [Kbytes/sec] received

Percentage of the requests served within a certain time (ms)
  50%      7
  66%      8
  75%      8
  80%      8
  90%      9
  95%      9
  98%     10
  99%     12
 100%     29 (longest request)
``` 

 在并发为50， 发起2w的请求的时候，99%的rt为20ms以内， 100%的请求rt为30ms之内。 qps 为7000左右。

4  最新视频列表获取接口

```
concurrency   50
requests      20000

Requests per second:    5144.90 [#/sec] (mean)
Time per request:       9.718 [ms] (mean)
Time per request:       0.194 [ms] (mean, across all concurrent requests)
Transfer rate:          36316.69 [Kbytes/sec] received

Percentage of the requests served within a certain time (ms)
  50%     10
  66%     13
  75%     13
  80%     14
  90%     15
  95%     16
  98%     17
  99%     20
 100%     34 (longest request)
``` 
  在并发为50， 发起2w的请求的时候，99%的rt为30ms以内， 100%的请求rt为30ms之内。 qps 为5000左右。

5 首页推荐视频获取接口

```
concurrency   50
requests      20000

Requests per second:    4470.74 [#/sec] (mean)
Time per request:       11.184 [ms] (mean)
Time per request:       0.224 [ms] (mean, across all concurrent requests)
Transfer rate:          14364.51 [Kbytes/sec] received

Percentage of the requests served within a certain time (ms)
  50%     13
  66%     14
  75%     14
  80%     15
  90%     15
  95%     16
  98%     18
  99%     22
 100%     32 (longest request)

```
  在并发为50， 发起2w的请求的时候，99%的rt为30ms以内， 100%的请求rt为40ms之内。 qps 为4500左右。
  

***在整个压测过程中，服务器cpu占用40%， 内存占用不到一半， load 不足0.1***

```
ab -c 50 -n 20000 "http://localhost:8080/tors.tv/v1/category/show?channel=tv&sign=123123&pid=2685&page=0&pageSize=2"
ab -c 50 -n 20000 "http://localhost:8080/tors.tv/v1/video/for/playlist?channel=tv&sign=123123&pid=2685&page=0&pageSize=2"
ab -c 50 -n 20000 "http://localhost:8080/tors.tv/v1/playlist/all?channel=tv&sign=123123&pid=2685&count=10"
ab -c 50 -n 20000 "http://localhost:8080/tors.tv/v1/video/lasted?channel=tv&sign=123123"
ab -c 50 -n 20000 "http://localhost:8080/tors.tv/v1/video/recommend?channel=tv&sign=123123&count=20"
```