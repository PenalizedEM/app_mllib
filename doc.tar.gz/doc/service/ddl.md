### 糖豆APP各模块对应数据表

| 模块名     |  相关表 | 
| :--------: |:--------: | 
|	焦点图   		|	home_banner		|
|	精选    			|	video_recommend  首页		|
|	视频列表			|	视频表 	video     	视频分类 video_category 		视频区分 video_genre	|
|	mp3管理 			|	mp3  |
|	推荐舞曲舞队  	|	playlist_recommend  | 
|	舞曲列表			|	playlist&type=1   |
|	达人列表			|	playlist&type=2  |
|	每日推送管理     	|	push   |
|	专题推荐管理		|	playlist_banner  |
|	评论管理   		|	comment   |
|	用户管理			|	user   |
|	用户反馈			|	feedback   |
|	糖小豆			|	txdfeed_user  反馈用户   txdfeed 反馈   |
|	舞队管理			|	team  舞队   team_user 舞队成员	team_video_list 舞队舞单   |
|	分类管理			|	tag_recommend  |
|	舞曲缺失管理		|	video status = VIDEO_STATUS_DEFAULT  |
|	阿拉丁			|	ald_video 阿拉丁视频	ald_tags 维度   |
|	视频审核        | 	video  |
|	主题背景管理		|	video_theme  主题   |
|	用户推送管理		|	push_list 推送列表   |
|	同步空间视频		|	binduid_log   |
|	系统消息管理		|	sysmsg   系统消息  |
|	关键词纠错		|	keywords 关键词    |
|	屏蔽关键字		|	setting|
|	关注排行榜		|	team_video_list  视频列表		follow_user 关注用户   |
|	糖龄福利订单		|	orders 订单   |
|	视频分类管理		|	video_category  |

### DDL
```sql
-- phpMyAdmin SQL Dump
-- version 3.5.3
-- http://www.phpmyadmin.net
--
-- 主机: 10.10.120.205:3306
-- 生成日期: 2016 年 06 月 14 日 10:54
-- 服务器版本: 5.5.24-ucloudrel1-log
-- PHP 版本: 5.4.41

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `tangdouapp`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `user` varchar(10) NOT NULL COMMENT '账号',
  `pwd` varchar(32) NOT NULL COMMENT '密码',
  `phone` char(11) NOT NULL COMMENT '手机号',
  `appuid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '移动UID',
  `weight` int(10) NOT NULL DEFAULT '5' COMMENT '权重',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

-- --------------------------------------------------------

--
-- 表的结构 `ald_tags`
--

CREATE TABLE IF NOT EXISTS `ald_tags` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父分类id',
  `name` varchar(100) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL COMMENT ' 1 舞曲 2舞队 3泛需求',
  `plid` int(10) unsigned NOT NULL COMMENT 'PC专辑id',
  `rank` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `uid` int(10) unsigned NOT NULL COMMENT '操作用户 ',
  `addtime` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6089 ;

-- --------------------------------------------------------

--
-- 表的结构 `ald_video`
--

CREATE TABLE IF NOT EXISTS `ald_video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL COMMENT '视频VID',
  `tagid` int(10) unsigned NOT NULL COMMENT '分类ID',
  `rank` int(10) unsigned NOT NULL COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid_tagid` (`vid`,`tagid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41871 ;

-- --------------------------------------------------------

--
-- 表的结构 `binduid_log`
--

CREATE TABLE IF NOT EXISTS `binduid_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `pc_uid` int(11) unsigned NOT NULL DEFAULT '0',
  `app_uid` int(11) unsigned NOT NULL DEFAULT '0',
  `pid` int(11) unsigned NOT NULL DEFAULT '0',
  `addtime` int(8) unsigned NOT NULL DEFAULT '0',
  `synctime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '同步时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2843 ;

-- --------------------------------------------------------

--
-- 表的结构 `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(11) unsigned NOT NULL COMMENT '评论用户ID',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '评论的内容',
  `time` datetime NOT NULL COMMENT '评论的时间',
  `vid` int(11) unsigned NOT NULL COMMENT '内容ID',
  `reply` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `retime` datetime NOT NULL,
  `up` int(11) NOT NULL DEFAULT '0' COMMENT '置顶',
  `reuid` int(11) NOT NULL DEFAULT '0' COMMENT '回复id',
  `hot` int(11) NOT NULL DEFAULT '0' COMMENT '热度',
  `praise` int(11) NOT NULL DEFAULT '0' COMMENT '总赞数',
  `upid` int(10) NOT NULL COMMENT '评论id',
  `recontent` varchar(300) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '引入内容',
  `is_ad` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否广告 1 是 0 否',
  PRIMARY KEY (`id`),
  KEY `vid` (`vid`),
  KEY `uid` (`uid`),
  KEY `up` (`up`),
  KEY `time` (`time`),
  KEY `reuid` (`reuid`),
  KEY `is_ad` (`is_ad`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3384617 ;

-- --------------------------------------------------------

--
-- 表的结构 `comment_report`
--

CREATE TABLE IF NOT EXISTS `comment_report` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL COMMENT '评论ID',
  `num` int(10) NOT NULL COMMENT '举报次数',
  `vid` int(10) NOT NULL COMMENT '视频VID',
  `is_del` int(10) NOT NULL DEFAULT '0' COMMENT '0 未处理 1 已处理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cid` (`cid`,`num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25951 ;

-- --------------------------------------------------------

--
-- 表的结构 `comment_report_log`
--

CREATE TABLE IF NOT EXISTS `comment_report_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论id',
  `userid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `createtime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '举报时间',
  `type` smallint(2) NOT NULL DEFAULT '0' COMMENT '类型 1 恶意攻击谩骂2滥发广告3评论质量差 0 其它',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid_userid` (`cid`,`userid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4996 ;

-- --------------------------------------------------------

--
-- 表的结构 `errorlist`
--

CREATE TABLE IF NOT EXISTS `errorlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `vid` int(10) unsigned NOT NULL COMMENT '视频ID',
  `type` tinyint(3) unsigned NOT NULL COMMENT '报错类型：1已删除，2信息错误，3其它',
  `time` datetime NOT NULL COMMENT '报错时间',
  `uuid` varchar(50) NOT NULL COMMENT '设备号',
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15906 ;

-- --------------------------------------------------------

--
-- 表的结构 `fav`
--

CREATE TABLE IF NOT EXISTS `fav` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `vid` int(10) unsigned NOT NULL COMMENT '视频ID',
  `time` datetime NOT NULL COMMENT '收藏时间',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11201445 ;

-- --------------------------------------------------------

--
-- 表的结构 `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '反馈内容',
  `contact` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '联系方试',
  `time` datetime NOT NULL COMMENT '反馈时间',
  `client` tinyint(3) unsigned NOT NULL COMMENT '1ios,2android',
  `version` varchar(50) NOT NULL COMMENT '版本号',
  `device` varchar(50) NOT NULL COMMENT '机型',
  `uid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户ID',
  `is_del` tinyint(1) NOT NULL DEFAULT '0',
  `uuid` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4450 ;

-- --------------------------------------------------------

--
-- 表的结构 `follow`
--

CREATE TABLE IF NOT EXISTS `follow` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(10) unsigned NOT NULL COMMENT '观注用户',
  `reuid` int(10) unsigned NOT NULL COMMENT '被观注用户',
  `time` datetime NOT NULL COMMENT '观注时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_2` (`uid`,`reuid`),
  KEY `uid` (`uid`),
  KEY `reuid` (`reuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1395591 ;

-- --------------------------------------------------------

--
-- 表的结构 `follow_user`
--

CREATE TABLE IF NOT EXISTS `follow_user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(10) unsigned NOT NULL COMMENT '观注用户',
  `reuid` int(10) unsigned NOT NULL COMMENT '被观注用户',
  `time` datetime NOT NULL COMMENT '观注时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_2` (`uid`,`reuid`),
  KEY `uid` (`uid`),
  KEY `reuid` (`reuid`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4704261 ;

-- --------------------------------------------------------

--
-- 表的结构 `gooddance`
--

CREATE TABLE IF NOT EXISTS `gooddance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `issue` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '期号',
  `vid` int(10) unsigned NOT NULL COMMENT '视频VID',
  `title` varchar(255) NOT NULL COMMENT '视频标题',
  `share` varchar(50) NOT NULL COMMENT '分享率',
  `pay` int(11) NOT NULL DEFAULT '0' COMMENT '已付的款项',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`),
  KEY `share` (`share`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=128 ;

-- --------------------------------------------------------

--
-- 表的结构 `gooddance_copr`
--

CREATE TABLE IF NOT EXISTS `gooddance_copr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `vid` int(10) unsigned NOT NULL COMMENT '视频VID',
  `uid` int(8) unsigned NOT NULL COMMENT '用户ID',
  `title` varchar(255) NOT NULL COMMENT '视频标题',
  `share` decimal(5,2) unsigned NOT NULL DEFAULT '0.00' COMMENT '分享率',
  `pay_share` int(11) NOT NULL DEFAULT '0' COMMENT '分享得款',
  `copr` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否原创',
  `is_show` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否显示',
  `createtime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`),
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1680 ;

-- --------------------------------------------------------

--
-- 表的结构 `gooddance_pay`
--

CREATE TABLE IF NOT EXISTS `gooddance_pay` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `issue` int(8) unsigned NOT NULL COMMENT '期号',
  `uid` int(8) unsigned NOT NULL COMMENT '用户ID',
  `pay` int(11) NOT NULL DEFAULT '0' COMMENT '付款金额',
  `createtime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '发布时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `issue` (`issue`,`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=56 ;

-- --------------------------------------------------------

--
-- 表的结构 `home_banner`
--

CREATE TABLE IF NOT EXISTS `home_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `pic` varchar(255) NOT NULL COMMENT '图片',
  `type` tinyint(1) unsigned NOT NULL COMMENT '推荐位类型',
  `stype` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '1舞曲2舞队',
  `url` varchar(255) NOT NULL COMMENT '网页地址',
  `position` tinyint(1) unsigned NOT NULL COMMENT '位置',
  `uptime` datetime NOT NULL COMMENT '更新时间',
  `is_del` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  `is_share` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否显示分享 1显示 0不显示',
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=116 ;

-- --------------------------------------------------------

--
-- 表的结构 `keywords`
--

CREATE TABLE IF NOT EXISTS `keywords` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `oldkey` varchar(200) NOT NULL COMMENT '原关键词',
  `newkey` varchar(200) NOT NULL COMMENT '新关键词',
  `time` datetime NOT NULL COMMENT '时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `oldkey` (`oldkey`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1793 ;

-- --------------------------------------------------------

--
-- 表的结构 `kills`
--

CREATE TABLE IF NOT EXISTS `kills` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `uuid` varchar(100) NOT NULL COMMENT 'UUID',
  `time` datetime NOT NULL COMMENT '封禁时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=302 ;

-- --------------------------------------------------------

--
-- 表的结构 `live_user`
--

CREATE TABLE IF NOT EXISTS `live_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `phone` char(11) NOT NULL COMMENT '手机号',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1 王广成 2 杨丽萍',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4889 ;

-- --------------------------------------------------------

--
-- 表的结构 `mp3`
--

CREATE TABLE IF NOT EXISTS `mp3` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL COMMENT '舞曲名子',
  `team` varchar(256) NOT NULL COMMENT '舞队名子',
  `mp3url` varchar(255) NOT NULL,
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `userid` int(10) NOT NULL DEFAULT '0' COMMENT '用户UID',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12017 ;

-- --------------------------------------------------------

--
-- 表的结构 `mp3video`
--

CREATE TABLE IF NOT EXISTS `mp3video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL COMMENT 'PC端视频ID',
  `mp3id` int(10) unsigned NOT NULL COMMENT 'mp3ID',
  `createtime` datetime NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`mp3id`),
  KEY `vid_2` (`vid`),
  KEY `mp3id` (`mp3id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28722 ;

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `sign` smallint(5) unsigned NOT NULL COMMENT '领取时需要的糖龄',
  `title` varchar(255) NOT NULL COMMENT '领取的商品',
  `mobile` varchar(11) NOT NULL COMMENT '手机号',
  `address` varchar(255) NOT NULL COMMENT '地址',
  `name` varchar(200) NOT NULL COMMENT '姓名',
  `note` varchar(200) NOT NULL DEFAULT '' COMMENT '备注',
  `time` datetime NOT NULL COMMENT '领取时间',
  `kuaidi` varchar(40) NOT NULL DEFAULT '' COMMENT '快递公司简称',
  `number` varchar(40) NOT NULL COMMENT '快递单号',
  `uptime` datetime NOT NULL COMMENT '更新时间',
  `province` varchar(50) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `kuaidi_time` datetime NOT NULL COMMENT '邮寄日期',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid_2` (`uid`,`sign`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11251 ;

-- --------------------------------------------------------

--
-- 表的结构 `pc_link_app`
--

CREATE TABLE IF NOT EXISTS `pc_link_app` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pc_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `app_uid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pc_uid` (`pc_uid`),
  UNIQUE KEY `app_uid` (`app_uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=684 ;

-- --------------------------------------------------------

--
-- 表的结构 `playlist`
--

CREATE TABLE IF NOT EXISTS `playlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '专辑ID主键自增',
  `master_uid` int(10) unsigned NOT NULL COMMENT '达人UID',
  `title` varchar(255) NOT NULL COMMENT '专辑名称',
  `charclass` varchar(1) NOT NULL COMMENT '专辑首字母',
  `uid` int(10) unsigned NOT NULL COMMENT '专辑作者id',
  `uname` varchar(50) NOT NULL COMMENT '专辑作者用户名',
  `type` tinyint(1) unsigned NOT NULL COMMENT '舞曲1 舞队2',
  `keyword` varchar(50) NOT NULL COMMENT '关键字',
  `pid` int(10) unsigned NOT NULL COMMENT 'PC专辑ID',
  `top` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '权重',
  `info` varchar(255) NOT NULL COMMENT '关键词全文索引',
  `pic` varchar(200) NOT NULL DEFAULT '',
  `groupid` tinyint(1) NOT NULL DEFAULT '0' COMMENT '达人级别 1达人 2超级达人',
  `video_num` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '专辑视频数量',
  `userid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '移动端达人UID',
  `username` varchar(50) NOT NULL COMMENT '移动端达人昵称',
  `is_prompt` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否搜索提示 0提示 1不提示  ',
  `level` tinyint(2) NOT NULL DEFAULT '0' COMMENT '达人等级',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pid` (`pid`),
  KEY `top` (`top`),
  KEY `is_prompt` (`is_prompt`),
  KEY `userid` (`userid`),
  KEY `groupid` (`groupid`),
  KEY `keyword` (`keyword`),
  FULLTEXT KEY `info` (`info`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10390 ;

-- --------------------------------------------------------

--
-- 表的结构 `playlistvideo`
--

CREATE TABLE IF NOT EXISTS `playlistvideo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '专辑视频关联表ID自增',
  `vid` int(10) unsigned NOT NULL COMMENT 'PC端视频ID',
  `pid` int(10) unsigned NOT NULL COMMENT 'PC端专辑ID',
  `createtime` datetime NOT NULL COMMENT '创建时间',
  `position` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '权重由高到低',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`,`pid`),
  KEY `vid_2` (`vid`),
  KEY `pid` (`pid`),
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=195634 ;

-- --------------------------------------------------------

--
-- 表的结构 `playlist_banner`
--

CREATE TABLE IF NOT EXISTS `playlist_banner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `pic` varchar(255) NOT NULL COMMENT '图片',
  `pid` varchar(255) NOT NULL COMMENT '网页地址',
  `position` tinyint(1) unsigned NOT NULL COMMENT '位置',
  `uptime` datetime NOT NULL COMMENT '更新时间',
  `is_del` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

-- --------------------------------------------------------

--
-- 表的结构 `playlist_recommend`
--

CREATE TABLE IF NOT EXISTS `playlist_recommend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(2) unsigned NOT NULL COMMENT '1热门舞曲 2 最新舞曲 3 热门舞队 4搜索排行 5推荐舞曲  6推荐达人',
  `pid` int(10) unsigned NOT NULL COMMENT '专辑ID',
  `keyword` varchar(50) NOT NULL COMMENT '关键词（舞曲or舞队）',
  `position` tinyint(3) unsigned NOT NULL COMMENT '位置',
  `pic` varchar(200) NOT NULL COMMENT '图片',
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1779 ;

-- --------------------------------------------------------

--
-- 表的结构 `praise`
--

CREATE TABLE IF NOT EXISTS `praise` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(11) unsigned NOT NULL COMMENT '点赞用户',
  `cid` int(11) unsigned NOT NULL COMMENT '评论id',
  `reuid` int(11) unsigned NOT NULL COMMENT '评论所属用户',
  `time` datetime NOT NULL COMMENT '点赞时间',
  PRIMARY KEY (`id`),
  KEY `uid_cid` (`uid`,`cid`),
  KEY `reuid` (`reuid`),
  KEY `time` (`time`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11903080 ;

-- --------------------------------------------------------

--
-- 表的结构 `push`
--

CREATE TABLE IF NOT EXISTS `push` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(11) unsigned NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `sys` varchar(10) NOT NULL,
  `url` varchar(200) NOT NULL COMMENT 'h5页面链接',
  `is_android` smallint(2) NOT NULL DEFAULT '999' COMMENT '999未推送 0 成功 推送错误码 ',
  `is_ios` smallint(2) NOT NULL DEFAULT '999' COMMENT '999未推送 0 成功 推送错误码',
  PRIMARY KEY (`id`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=553 ;

-- --------------------------------------------------------

--
-- 表的结构 `push_list`
--

CREATE TABLE IF NOT EXISTS `push_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content` varchar(200) NOT NULL COMMENT '推送内容',
  `vid` int(10) NOT NULL COMMENT '视频VID',
  `uid` int(10) NOT NULL COMMENT '推送UID关注者',
  `user_num` int(10) NOT NULL COMMENT '推送用户数',
  `success_num` int(10) NOT NULL COMMENT '推送成功数',
  `addtime` int(10) NOT NULL COMMENT '推送时间',
  `push_time` int(10) NOT NULL COMMENT '推送时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- 表的结构 `push_user_list`
--

CREATE TABLE IF NOT EXISTS `push_user_list` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `content` varchar(200) NOT NULL COMMENT '推送内容',
  `vid` int(10) NOT NULL COMMENT '视频VID',
  `uid` int(10) NOT NULL COMMENT '推送UID关注者',
  `success_num` int(10) NOT NULL COMMENT '推送成功数',
  `addtime` int(10) NOT NULL COMMENT '添加时间',
  `push_time` int(10) NOT NULL COMMENT '推送时间',
  `title` varchar(100) NOT NULL COMMENT '专辑标题',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=791 ;

-- --------------------------------------------------------

--
-- 表的结构 `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '课程表id',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '移动uid',
  `vid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '视频id',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '状态 0:学习中 1:已学会 5:删除',
  `addtime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '添加时间',
  `overtime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '已学会时间',
  PRIMARY KEY (`id`),
  KEY `uid_stat` (`uid`,`status`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=51041 ;

-- --------------------------------------------------------

--
-- 表的结构 `sem`
--

CREATE TABLE IF NOT EXISTS `sem` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `channel` int(10) unsigned NOT NULL COMMENT '渠道号',
  `keyword` varchar(255) NOT NULL COMMENT '关键词',
  `total` int(11) NOT NULL COMMENT '安装量',
  `money` float NOT NULL DEFAULT '0' COMMENT '消费',
  `addtime` date NOT NULL COMMENT '时间',
  `exhibit` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '展现',
  `click` int(10) unsigned NOT NULL COMMENT '点击',
  `cost` float NOT NULL COMMENT '消费',
  `click_rate` float NOT NULL COMMENT '点击率',
  `click_price` float NOT NULL COMMENT '平均点击价格',
  `rank` float NOT NULL COMMENT '平均排名',
  PRIMARY KEY (`id`),
  KEY `channel` (`channel`),
  KEY `keyword` (`keyword`),
  KEY `addtime` (`addtime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76978 ;

-- --------------------------------------------------------

--
-- 表的结构 `sysmsg`
--

CREATE TABLE IF NOT EXISTS `sysmsg` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `name` varchar(100) NOT NULL COMMENT '后台登录用户',
  `reuid` int(10) unsigned NOT NULL COMMENT '消息接受用户ID',
  `reuname` varchar(200) NOT NULL COMMENT '消息接受用户昵称',
  `content` text NOT NULL COMMENT '消息内容',
  `time` datetime NOT NULL COMMENT '发送时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3672 ;

-- --------------------------------------------------------

--
-- 表的结构 `tag_recommend`
--

CREATE TABLE IF NOT EXISTS `tag_recommend` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `background` char(7) NOT NULL,
  `color` char(7) NOT NULL,
  `position` smallint(4) NOT NULL COMMENT '权重从大到小',
  `style` tinyint(2) NOT NULL COMMENT '样式',
  `border` char(7) NOT NULL COMMENT '边框颜色',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

-- --------------------------------------------------------

--
-- 表的结构 `tag_video`
--

CREATE TABLE IF NOT EXISTS `tag_video` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vid` int(10) NOT NULL,
  `tag` char(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `vid` (`vid`),
  KEY `tag` (`tag`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15335 ;

-- --------------------------------------------------------

--
-- 表的结构 `tdvideosug`
--

CREATE TABLE IF NOT EXISTS `tdvideosug` (
  `title` varchar(255) NOT NULL,
  `uv` int(255) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COMMENT='热搜与舞队的提示' AUTO_INCREMENT=7674 ;

-- --------------------------------------------------------

--
-- 表的结构 `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `number` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '舞队编号',
  `name` varchar(100) NOT NULL COMMENT '舞队名称',
  `photo` varchar(100) NOT NULL COMMENT '舞队照片',
  `regtime` datetime NOT NULL COMMENT '创建时间',
  `reguid` int(10) unsigned NOT NULL COMMENT '领队UID',
  `total_video` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '视频数',
  `total_user` int(11) unsigned NOT NULL DEFAULT '1' COMMENT '成员数',
  `address` varchar(255) NOT NULL COMMENT '舞队场地',
  `lon` varchar(50) NOT NULL COMMENT '经度',
  `lat` varchar(50) NOT NULL COMMENT '纬度',
  `province` varchar(100) NOT NULL COMMENT '省份',
  `city` varchar(100) NOT NULL COMMENT '城市',
  `search` text NOT NULL COMMENT '检索',
  PRIMARY KEY (`id`),
  UNIQUE KEY `reguid` (`reguid`),
  KEY `number` (`number`),
  FULLTEXT KEY `search` (`search`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=41913 ;

-- --------------------------------------------------------

--
-- 表的结构 `team_user`
--

CREATE TABLE IF NOT EXISTS `team_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teamid` int(10) unsigned NOT NULL COMMENT '舞队编号',
  `uid` int(10) unsigned NOT NULL COMMENT '用户UID',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否领队',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=198692 ;

-- --------------------------------------------------------

--
-- 表的结构 `team_video_list`
--

CREATE TABLE IF NOT EXISTS `team_video_list` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `teamid` int(10) unsigned NOT NULL COMMENT '舞队编号',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `vid` int(10) unsigned NOT NULL COMMENT '视频VID',
  PRIMARY KEY (`id`),
  KEY `teamid` (`teamid`),
  KEY `vid` (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=580116 ;

-- --------------------------------------------------------

--
-- 表的结构 `tmp`
--

CREATE TABLE IF NOT EXISTS `tmp` (
  `vid` int(10) NOT NULL,
  UNIQUE KEY `vid` (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `txdbanner`
--

CREATE TABLE IF NOT EXISTS `txdbanner` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `pic` varchar(255) NOT NULL COMMENT '图片',
  `type` tinyint(1) unsigned NOT NULL COMMENT '推荐位类型',
  `url` varchar(255) NOT NULL COMMENT '网页地址',
  `position` tinyint(1) unsigned NOT NULL COMMENT '位置',
  `uptime` datetime NOT NULL COMMENT '更新时间',
  `is_del` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否隐藏',
  PRIMARY KEY (`id`),
  KEY `position` (`position`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

-- --------------------------------------------------------

--
-- 表的结构 `txdfeed`
--

CREATE TABLE IF NOT EXISTS `txdfeed` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(11) unsigned NOT NULL COMMENT '所属用户id',
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否管理员发布',
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '发布内容',
  `time` datetime NOT NULL COMMENT '发布的时间',
  `rename` varchar(50) CHARACTER SET utf8mb4 NOT NULL COMMENT '管理员用户名',
  `client` tinyint(3) unsigned NOT NULL COMMENT '1ios,2android',
  `version` varchar(50) NOT NULL COMMENT '版本号',
  `device` varchar(50) NOT NULL COMMENT '机型',
  `uuid` varchar(200) NOT NULL,
  `is_del` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0未处理 1已处理',
  `appuid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`time`),
  KEY `is_admin` (`is_admin`),
  KEY `appuid` (`appuid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=229320 ;

-- --------------------------------------------------------

--
-- 表的结构 `txdfeed_user`
--

CREATE TABLE IF NOT EXISTS `txdfeed_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL COMMENT '用户UID',
  `admin_uid` int(10) NOT NULL COMMENT '管理员UID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`,`admin_uid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=42379 ;

-- --------------------------------------------------------

--
-- 表的结构 `user_payinfo`
--

CREATE TABLE IF NOT EXISTS `user_payinfo` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `uid` int(8) unsigned NOT NULL COMMENT '用户ID',
  `username` varchar(50) NOT NULL DEFAULT '' COMMENT '姓名',
  `idcard` varchar(50) NOT NULL DEFAULT '' COMMENT '身份证',
  `bank` varchar(100) NOT NULL DEFAULT '' COMMENT '开户行',
  `bankcard` varchar(50) NOT NULL DEFAULT '' COMMENT '卡号',
  `mobile` varchar(11) NOT NULL DEFAULT '' COMMENT '手机号',
  `qq` varchar(20) NOT NULL DEFAULT '' COMMENT 'QQ',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=117 ;

-- --------------------------------------------------------

--
-- 表的结构 `video`
--

CREATE TABLE IF NOT EXISTS `video` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '视频ID自增',
  `title` varchar(255) NOT NULL COMMENT '视频标题',
  `pic` varchar(200) NOT NULL COMMENT '图片',
  `ald_pic` varchar(200) NOT NULL,
  `hits_total` int(11) unsigned NOT NULL COMMENT '总播放量',
  `hits_week` int(11) unsigned NOT NULL COMMENT '周播放量',
  `hits_month` int(11) unsigned NOT NULL COMMENT '月播放量',
  `good_total` int(11) unsigned NOT NULL COMMENT '总点赞',
  `good_week` int(11) unsigned NOT NULL COMMENT '周点赞',
  `good_month` int(11) unsigned NOT NULL COMMENT '月点赞',
  `recommend` int(11) unsigned NOT NULL COMMENT '推荐星级',
  `definition` tinyint(1) unsigned NOT NULL COMMENT '清晰度',
  `coderate` varchar(20) NOT NULL COMMENT '码率',
  `videourl` varchar(50) NOT NULL COMMENT '视频地址',
  `duration` smallint(6) unsigned NOT NULL COMMENT '时长',
  `speed` tinyint(1) unsigned NOT NULL COMMENT '速度	1慢 2中 3快',
  `degree` tinyint(1) unsigned NOT NULL COMMENT '难度	1简单 2适中 3稍难',
  `teach` tinyint(1) unsigned NOT NULL COMMENT '1教学	2表演',
  `beach` tinyint(1) unsigned NOT NULL COMMENT '步数	1：16步	2：32步	3 ：64步',
  `best` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '优质视频',
  `type` tinyint(1) unsigned NOT NULL COMMENT '视频类型 1：CC上传  11：56上传  7：CC复制  8:秀舞',
  `vid` int(11) unsigned NOT NULL COMMENT 'PC端视频ID',
  `search` text NOT NULL COMMENT '标题全文索引',
  `siteid` varchar(16) NOT NULL,
  `sitekey` varchar(24) NOT NULL,
  `is_special` tinyint(4) NOT NULL,
  `createtime` datetime NOT NULL COMMENT '创建时间',
  `uptime` datetime NOT NULL COMMENT '更新时间',
  `share` int(11) NOT NULL DEFAULT '0' COMMENT '分享次数',
  `mp3url` varchar(200) NOT NULL COMMENT 'mp3',
  `user_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '播放人数',
  `user_share` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '分享人数',
  `pc_uid` int(11) NOT NULL DEFAULT '0',
  `uid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '移动端用户id',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0正常 1处理中 2审核中 5删除',
  `tag` varchar(300) NOT NULL,
  `parent_category` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '大分类',
  `child_category` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '小分类',
  `genre` smallint(4) unsigned NOT NULL DEFAULT '0' COMMENT '曲风',
  `hobby` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '学舞兴趣推荐',
  `sync` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否同步到云',
  `comment_total` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '评论数量',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`),
  KEY `degree` (`degree`),
  KEY `teach` (`teach`),
  KEY `hits_total` (`hits_total`),
  KEY `good_total` (`good_total`),
  KEY `createtime` (`createtime`),
  KEY `ald_pic` (`ald_pic`),
  KEY `status` (`status`),
  KEY `uid` (`uid`),
  KEY `hobby` (`hobby`),
  KEY `videourl` (`videourl`),
  FULLTEXT KEY `search` (`search`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=288801 ;

-- --------------------------------------------------------

--
-- 表的结构 `video_category`
--

CREATE TABLE IF NOT EXISTS `video_category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父分类id',
  `name` varchar(100) NOT NULL,
  `rank` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `uid` int(10) unsigned NOT NULL COMMENT '操作用户 ',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

-- --------------------------------------------------------

--
-- 表的结构 `video_genre`
--

CREATE TABLE IF NOT EXISTS `video_genre` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `rank` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  `uid` int(10) unsigned NOT NULL COMMENT '操作用户 ',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- --------------------------------------------------------

--
-- 表的结构 `video_recommend`
--

CREATE TABLE IF NOT EXISTS `video_recommend` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键自增',
  `vid` int(10) unsigned NOT NULL COMMENT 'PC视频ID',
  `type` tinyint(2) unsigned NOT NULL COMMENT '1 每日精选 2最新发布 3 本周热门 4最多分享 5原创 6达人秀 7入门舞蹈 8舞艺深造 9kk成人组 10 kk儿童组 11汤臣倍健 12中国队长',
  `uptime` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `type` (`type`),
  KEY `vid` (`vid`),
  KEY `uptime` (`uptime`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15982 ;

-- --------------------------------------------------------

--
-- 表的结构 `video_report`
--

CREATE TABLE IF NOT EXISTS `video_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '视频id',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0未处理  1已处理',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid` (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1484 ;

-- --------------------------------------------------------

--
-- 表的结构 `video_report_log`
--

CREATE TABLE IF NOT EXISTS `video_report_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '视频id',
  `userid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '用户id',
  `createtime` int(8) unsigned NOT NULL DEFAULT '0' COMMENT '举报时间',
  `type` smallint(2) NOT NULL DEFAULT '0' COMMENT '类型 1 盗版、抄袭2滥发广告 0 其它',
  PRIMARY KEY (`id`),
  UNIQUE KEY `vid_userid` (`vid`,`userid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2054 ;

-- --------------------------------------------------------

--
-- 表的结构 `video_source`
--

CREATE TABLE IF NOT EXISTS `video_source` (
  `vid` int(11) unsigned NOT NULL COMMENT '视频id',
  `cc` varchar(100) NOT NULL COMMENT 'ccvid',
  `cc_siteid` varchar(20) NOT NULL,
  `ucloud_1` varchar(200) NOT NULL COMMENT '普清',
  `ucloud_2` varchar(200) NOT NULL COMMENT '高清',
  `upyun_1` varchar(200) NOT NULL COMMENT '普清',
  `upyun_2` varchar(200) NOT NULL COMMENT '高清',
  PRIMARY KEY (`vid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `video_theme`
--

CREATE TABLE IF NOT EXISTS `video_theme` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(200) NOT NULL COMMENT '图片地址',
  `theme_url` char(200) NOT NULL COMMENT '主题包地址',
  `addtime` datetime NOT NULL COMMENT '添加时间',
  `admin_uid` int(10) NOT NULL COMMENT '管理员',
  `weight` smallint(5) NOT NULL COMMENT '权重从大到小',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0显示 1删除',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT ' 0后置背景   1前置背景',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=49 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

```