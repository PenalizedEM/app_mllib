---
title: 列表缓存及分页问题
notebook: 糖豆
tags:缓存,分页
---

## 缓存分布

### REDIS_MESSAGE

----------------------------------------

#### 用户缓存
+ key      user:info
+ value    hash(id: $user) (用户ID: 用户信息)

#### 用户操作是否过期
+ key   message:user_fuse
+ value  hash($uid, $curr_second) (用户ID：时间)

#### 视频评论
+ key     comment:info
+ value   hash(id: $comment) (评论ID： 评论信息)


#### 评论个数
+ key      comment:num
+ value    hash(vid: $num)  (视频ID： 评论个数)

#### 点赞
+ key      message:praise_hits
+ value    hash(id: $num)  (评论ID： 点赞个数)

#### 是否已经点赞
+ key      message:praised
+ value    hash($cid_$uid: value) （评论ID_用户ID： 1） 

#### 用户鲜花个数
+ key      flower:user
+ value	   hash(uid: $num) (用户ID: 鲜花个数)


#### 视频鲜花个数
+ key      flower:video
+ value    hash(vid: $num) (视频ID: 鲜花个数)

#### 消息气泡
+ key      message:bubble
+ value    hash($uid_txdfeed: count, $uid_fans: count, $uid_comment: count, $uid_praise: count) (用户ID_消息类型： 0)

####  评论内容
+ key      message:flood_wall:$uid_$type 
+ value	   string($content) (评论内容)

####  评论时间
+ key     message:flood_wall:$uid
+ value   $time （评论时间）

#### 手机号验证码
+ key  verify:phone:$mobile
+ value  验证码（1000~9999）

#### 手机通讯录匹配
+ key $uid_md5($phones)
+ value 

#### 用户关注数
+ key    user:follow
+ value   sortedset($uid)

#### 用户粉丝数
+ key   user:fans
+ value   sortedset($userid)

#### 用户收藏
+ key   user:fav
+ value  sortedset($uid)

#### 视频收藏
+ key    video:fav
+ value  sortedset($vid)

##### 推广每小时总数
+ key  sem:{$date}
+ value  count

#### 推广渠道每小时总数
+ key   sem:{$channel}:{$date}
+ value   count

#### 推送点击总数
+ key  count_plush_click:$vid
+ value  count

#### 推送删除总数
+ key  count_plush_del:$vid
+ value  count

#### 推送每天点击数
+ key  plush:$date:$type:click
+ value  count

#### 推送每天删除数
+ key  plush:$date:$type:del
+ value  count

#### 每天视频播放总量
+ key   allvideo:play_vv
+ value   hash($date, count)

#### 每天每个视频的播放量
+ key   video:play_vv
+ value  sortedset($vid) 

#### 所有视频每天的播放人数
+ key 	allvideo:play_uv
+ value  hash($date: count)

#### 每个视频的播放人数
+ key video:play_uv
+ value  sortedset($vid)

#### 视频每天的分享次数
+ key  allvideo:share_vv
+ vlaue hash($date: count)

#### 每个视频的分享次数
+ key video:share_vv
+ value sortedset($vid)


#### 视频每天的分享人数
+ key  allvideo:share_uv
+ vlaue hash($date: count)

#### 每个视频的分享人数
+ key video:share_uv
+ value sortedset($vid)

#### 问题缓存
+ key  question:$issue
+ vlaue hash($uuid, $type)

#### 问题缓存
+ key  question:all
+ vlaue hash($uuid, $type)


#### 
+ key active:vote:$uuid
+ value string($uuid)



### REDIS_NEWCACHE

------------------------------------------

#### 没有舞曲的视频？
+ key  nomusic_cancel
+ value  set(vid列表)

#### 没有的舞曲？
+ key  nomusic
+ value  sortedset($vid, score)

#### 没有舞曲的视频？
+ key  nomusic_showdance
+ value  set(vid列表)

#### 没有的舞曲？
+ key nomusic
+ value  sortedset($music.' '.$team,  score)

#### 手机号缓存
+ key     all_phone_h
+ value   hash(phone: 1) （手机号： 1）

#### 重试次数
+ key    pcbind_try_${手机号}
+ value   1  (重试次数)

#### 上传视频时mp3_rank
+ key    show_mp3_rank:$date
+ value  sortedset(map3id)

#### mp3 搜索
+ key  mp3_search:$key
+ value  hash(id, name, team, mp3url, userid)

####  mp3 粉丝数
+  user:fans
+  hash(userid, score)

#### 视频分类组目
+ key   video_category
+ value  string(id: $name) （分类ID： 分类名称）

#### 空间舞队信息
+ key   teamid_$teamid  
+ value 

#### 我的关注缓存
+ key    cache:follow_$uid
+ value 

#### 粉丝列表
+ key  fans_list:$uid
+ value set($uid)

#### 舞队缓存
+ key  cache:teamid_{$teamid}
+ value   

#### 舞队视频列表缓存
+ key  cache:teamvideo_{$teamid}_1
+ value   

#### 舞队队员缓存
+ key cache:space_team_$uid  
+ value 

#### 用户空间缓存
+ key  cache:space_user${uid}
+ value 

#### 用户收藏缓存
+ key  cache:fav_$uid_1
+ value 

#### 专辑列表
+ cache:spacelist:$pid_1   
+ value 


#### 最新评论
+ key   cache:comment_v2new_$vid    评论缓存
+ value  hash($vid, $content)

#### 热门评论
+ key   cache:comment_vhot_$vid 		评论缓存
+ value hash($vid, $content)

#### 用户评论数
+ key   cache:comment_$uid	
+value   hash($uid,   $content)

    



### REDIS_RECOMMEND

-------------------------------------------

#### 用户rank排序？
+ key   user:$user:rank
+ value  hash(rank, date, device, version, load(拉取次数))

#### 历史播放记录
+ key   user:$user:play
+ value  set($vid)

#### 用户拉取排行
+ key list:uload
+ value  sortedset(user:{$uid})

#### 用户或者设备记录
+ key   list:user
+ value   set(user:{$uid})


#### 
+ key  recommend:good
+ value  set

#### 
+ key user:{$uid}:history
+ value   set


#### 
+ key  recommend:{$degree}004
+ value    set


####
+ key  recommend:{$degree}003
+ value   set


####
+ key  recommend:{$degree}002
+ value  set

#### 
+ key  recommend:{$degree}001
+ value   set



#### 权值变化日志
+ key user:$user:log:$y-m-d 
+ value  list(vid, 类型，难度，播放比，rank， date)




### REDIS_CACHE_HOST

----------------------------------------------

#### 播放统计总量
+ key   uplay_hash:{$vid}:{$uuid}
+ value  hash(client, device, version, time)


#### 分享统计总量
+ key  ushare_hash:{$vid}:{$uuid}
+ value  hash(uid, client ,device, version, time)



#### 视频信息缓存
+ key  video:info
+ value  hash(vid: $video) (视频ID： 视频信息)


















