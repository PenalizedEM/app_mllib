

# 用户活跃度



## 1、活跃度状态 

| 状态码  | 活跃状态            |
| ---- | --------------- |
| -1   | 已流失1周用户         |
| -2   | 已流失2周用户         |
| -3   | 已流失3周用户         |
| -4   | 已流失4周用户         |
| -5   | 沉默用户（流失5周及以上用户） |
| 5    | 忠实用户（连续活跃5周及以上） |
| 4    | 连续活跃4周用户        |
| 3    | 连续活跃3周用户        |
| 2    | 连续活跃2周天用户       |
| 0    | 本周回流用户          |
| 1    | 本周新增用户          |



## 2、活跃状态更新



每天的全量用户可划分为三个基本状态：

- 活跃
- 新增
- 流失(未活跃)

以上三种状态间的转换关系：

- 活跃 —> 活跃
- 活跃 —> 流失
- 流失 —> 活跃
- 流失 —> 流失
- 新增 —> 活跃
- 新增 —> 流失

![](http://ol5qowkge.bkt.clouddn.com/userprofile/act_status.png)

- 可直接递增递减的状态
  - 新增 + 活跃 —> 连续活跃2周  <=>  1 + 1 = 2 
  - 活跃 + 活跃 —> 连续活跃2周  <=>  1 + 1 = 2 
  - 流失 + 流失 —> 已流失2周  <=>  -1 -1 = -2 
  - 已流失1周 + 活跃 —> 本周回流  <=>  -1 +1 = 0 
- 跳跃状态
  - 新增 + 流失—> 已流失1周 <=>  1 -1 = -1 
  - 活跃 + 流失—> 已流失1周 <=>  n(n>=1) -1 = -1 
  - 已流失n(n<=-2)周 + 活跃 —> 本周回流 <=>  n(n<=-2) +1 = 0 
  -  本周回流 + 活跃—> 连续活跃2周 <=>  0 +1 = 2 

举例：

|  第一周  |    第二周     |    第三周    |    第四周    |   第五周    |
| :---: | :--------: | :-------: | :-------: | :------: |
| 1（新增） | 2（连续活跃2周 ） | 3（连续活跃3周） | 4（连续活跃4周） | 5（忠实用户）  |
| 1（新增） | 2（连续活跃2周）  | 3（连续活跃3周） | 4（连续活跃4周） | -1（流失1周） |
| 1（新增） | 2（连续活跃2周）  | 3（连续活跃3周） | -1（流失1周）  | 0（本周回流）  |
| 1（新增） | 2（连续活跃2周）  | 3（连续活跃3周） | -1（流失1周）  | -2（流失2周） |
| 1（新增） | 2（连续活跃2周）  | -1（流失1周）  | -2（流失2周）  | -3（流失2周） |
| 1（新增） | 2（连续活跃2周）  | -1（流失1周）  |  0（本周回流）  | -1（流失1周） |
| 1（新增） |  -1（流失1周）  |  0（本周回流）  | 2（连续活跃2周） | -1（流失1周） |
|  ...  |    ...     |    ...    |    ...    |   ...    |
| 1（活跃） | 2（连续活跃2周）  | 3（连续活跃3周） | 4（连续活跃4周） | 5（忠实用户）  |



## 3、活跃度计算

### 3.1 用户活跃度/活跃状态计算  

```sql
-- user_profile_act_status.sql

CREATE EXTERNAL TABLE IF NOT EXISTS da.user_profile_act_status(
	u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
	u_client  STRING  COMMENT '客户端类型',
	u_timestamp_f STRING COMMENT '首次激活时间',
	u_timestamp STRING COMMENT '最近一次请求时间',
	u_fresh INT COMMENT '用户已激活天数',
	u_active  INT COMMENT '用户累计活跃天数',
	u_act_status  INT COMMENT '用户活跃度/活跃状态'
)
COMMENT '用户活跃度/活跃状态计算'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/olap/da/user_profile_act_status/';

-- 以自然周计算(周一至周日)
-- 第一周初始化(2016-09-02~2016-09-04）

-- insert overwrite table da.user_profile_act_status partition(dt='2016-09-04')
-- select u_diu,
--        u_client,
--        u_timestamp_f,
--        u_timestamp,
--        u_fresh,
--        u_active,
--        if(to_date(u_timestamp_f)>='2016-09-02'
--           and to_date(u_timestamp_f)<='2016-09-04',1,if(to_date(u_timestamp)>='2016-09-02'
--                                                         and to_date(u_timestamp)<='2016-09-04',1,-1)) u_act_status
-- from
--   (select u_diu,
--           max(u_client) u_client,
--           min(u_timestamp_f) u_timestamp_f,
--           max(u_timestamp) u_timestamp,
--           max(u_fresh) u_fresh,
--           max(u_active) u_active
--    from dw.user_info
--    where dt>='2016-09-02'
--      and dt<='2016-09-04'
--    group by u_diu) a

-- 第二周以后，累计滚动更新状态

insert overwrite table da.user_profile_act_status partition(dt='${datebuf}') 
select 
	a.u_diu,
	a.u_client,
	a.u_timestamp_f,
	a.u_timestamp,
	a.u_fresh,
	a.u_active,
	case when b.u_act_status>=1 and a.u_act_status=-1 then -1 
		when b.u_act_status<=-2 and a.u_act_status=1 then 0 
		when b.u_act_status=0 and a.u_act_status=1 then 2 
	else if(b.u_act_status is null,0,b.u_act_status)+a.u_act_status 
	end as u_act_status 
from 
	(
	select u_diu,
	       u_client,
	       u_timestamp_f,
	       u_timestamp,
	       u_fresh,
	       u_active,
	       if(to_date(u_timestamp_f)>=date_sub('${datebuf}',6)
	          and to_date(u_timestamp_f)<='${datebuf}',1,if(to_date(u_timestamp)>=date_sub('${datebuf}',6)
	                                                        and to_date(u_timestamp)<='${datebuf}',1,-1)) u_act_status
	from
	  (select u_diu,
	          max(u_client) u_client,
	          min(u_timestamp_f) u_timestamp_f,
	          max(u_timestamp) u_timestamp,
	          max(u_fresh) u_fresh,
	          max(u_active) u_active
	   from dw.user_info
	   where dt>=date_sub('${datebuf}',6)
	     and dt<='${datebuf}'
	   group by u_diu) a
	) a 
left outer join 
	(select * from da.user_profile_act_status where dt=date_sub('${datebuf}',7)) b 
on
	(a.u_diu=b.u_diu)



```



### 3.2 补数据 

- 每周一调度，执行上周一到上周日的任务

``` shell 
#!/bin/bash
# loop.sh 

#input arguments cannot be null
if [ -z "$1" ] || [ -z "$2" ] ;then
	echo "parameter error! please input the parameter!
	para format YYYY-MM-DD"
	exit 0
else
	datebeg=$1
	dateend=$2
	beg_s=`date -d "$datebeg" +%s`
	end_s=`date -d "$dateend" +%s`

	n=1

	while [ "$beg_s" -le "$end_s" ]
		do
			year=`date -d @$beg_s +"%Y"`
			month=`date -d @$beg_s +"%m"`
			day=`date -d @$beg_s +"%d"`
			datebuf="${year}-${month}-${day}"

			echo "datebuf: " $datebuf
			# bef_datebuf=`date -d "$datebuf -1 day" +"%Y-%m-%d"`
			# echo "bef_datebuf:" $bef_datebuf


			# hive -e ""
 			hive   --hivevar datebuf=${datebuf}  -f ./temp/user_profile_act_status.sql

			# if [ $(($n%3)) == 0 ]; then
			#	echo $n
			#	wait
			# fi

			let n=n+1
			beg_s=$((beg_s+86400*7))
		done
fi

```

