Spark入门
===
## 1.基础概念
### 1.1 RDD
一个RDD代表一系列的record或者对象，被分发到多个节点。有容错性，能够自动重建。
RDD可以从多种数据源中生成,
* Parallelized Collections
* External Datasets，包括支持HDFS,HBase,textFile.

```scala
val collection = List("a","v")
val rddFromCol = sc.parallelize(collection)
```

返回RDD对象，其中包含每条记录为一个string对象。

### 1.2 Spark操作
* 传递函数与了解闭包
 * 使用lambda
 * 长代码定义本地方法
* 输出RDD元素
> rdd.collect().foreach(println).
> rdd.take(100).foreach(println).

* tranformation
转变没有实际的操作，只有action服务器才正式执行
* action
hdfs://Ucluster/user/hadoop/README.md

## 2. Spark IO
### 2.1 Spark 支持的文件格式：

| 格式名称      | 结构化       | 备注 |
| :--------: |:--------: |  :------: |
| text | 否	 | 普通文本文件，每行一条记录 |
| json | 半结构化 | 大部分数据库要求每行一条记录 |
| csv | 是| 常见基于文本的格式 |  
| SequenceFiles | 是 	 | 一种键值对常见Hadoop文件格式 |
| ProtocolBuffer  |  是	 | google跨语言格式 |
| 对象文件  |  是	 | 用于spark作业的数据存储格式 |
### 2.2 读写示例代码
```python
#textFile可以读取目录,文件，以及通配符
input = sc.textFile("hdfs://Ucluster/temp/app/16-10-15/02/")
#whole方法返回pairRDD,key为文件名
inputAll = sc.wholeTextFiles("hdfs://Ucluster/wc/")
```
## 3. 调试与部署
PySpark ./pyspark --master yarn-client --num-executors 6 --executor-cores 6

/home/hadoop/spark/bin/spark-submit  --master yarn --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 4 /home/hadoop/user/vent/logetl.py

/home/hadoop/spark/bin/spark-submit  --master yarn --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/raw2ua.py 2016-10-01


/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 12 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/ua2ui.py 2016-10-29

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 6 --executor-memory 12g /home/hadoop/user/vent/ua2uis.py 2016-10-29

/home/hadoop/spark/bin/spark-submit  --master yarn  --py-files /home/hadoop/user/vent/dateutil.zip,/home/hadoop/user/vent/six.py --num-executors 10 --executor-cores 6 --executor-memory 6g /home/hadoop/user/vent/uvaction.py 2016-10-29

UA
root
 |-- u_active: long (nullable = true)
 |-- u_bigger_json: string (nullable = true)
 |-- u_city: string (nullable = true)
 |-- u_city_f: string (nullable = true)
 |-- u_client: string (nullable = true)
 |-- u_device: string (nullable = true)
 |-- u_dic: string (nullable = true)
 |-- u_dic_f: string (nullable = true)
 |-- u_diu: string (nullable = true)
 |-- u_diu2: string (nullable = true)
 |-- u_diu3: string (nullable = true)
 |-- u_div: string (nullable = true)
 |-- u_div_f: string (nullable = true)
 |-- u_fresh: long (nullable = true)
 |-- u_hash: string (nullable = true)
 |-- u_height: string (nullable = true)
 |-- u_manufacture: string (nullable = true)
 |-- u_model: string (nullable = true)
 |-- u_netop: string (nullable = true)
 |-- u_netop_f: string (nullable = true)
 |-- u_province: string (nullable = true)
 |-- u_province_f: string (nullable = true)
 |-- u_tag: string (nullable = true)
 |-- u_timestamp: string (nullable = true)
 |-- u_timestamp_f: string (nullable = true)
 |-- u_token: string (nullable = true)
 |-- u_uid: string (nullable = true)
 |-- u_uuid: string (nullable = true)
 |-- u_width: string (nullable = true)
 |-- u_xinge: string (nullable = true)

UI
root
 |-- u_diu: string (nullable = true)
 |-- u_diu2: string (nullable = true)
 |-- u_diu3: string (nullable = true)
 |-- u_uid: string (nullable = true)
 |-- u_uuid: string (nullable = true)
 |-- u_hash: string (nullable = true)
 |-- u_xinge: string (nullable = true)
 |-- u_token: string (nullable = true)
 |-- u_div_f: string (nullable = true)
 |-- u_div: string (nullable = true)
 |-- u_dic_f: string (nullable = true)
 |-- u_dic: string (nullable = true)
 |-- u_client: string (nullable = true)
 |-- u_timestamp_f: timestamp (nullable = true)
 |-- u_timestamp: timestamp (nullable = true)
 |-- u_netop_f: string (nullable = true)
 |-- u_netop: string (nullable = true)
 |-- u_province_f: string (nullable = true)
 |-- u_province: string (nullable = true)
 |-- u_city_f: string (nullable = true)
 |-- u_city: string (nullable = true)
 |-- u_manufacture: string (nullable = true)
 |-- u_model: string (nullable = true)
 |-- u_device: string (nullable = true)
 |-- u_width: integer (nullable = true)
 |-- u_height: integer (nullable = true)
 |-- u_fresh: integer (nullable = true)
 |-- u_active: integer (nullable = true)
 |-- u_tag: string (nullable = true)
 |-- u_bigger_json: string (nullable = true)
 |-- dt: string (nullable = true)




## 12. MovieLen Recommend in Action
```python
##数据格式:
userid::itemid:rate
>1::122::5::838985046
>1::185::5::838983525

##读入movielen 数据
data = sc.textFile("hdfs://Ucluster/temp/app/16-10-15/02")
ratings = data.map(lambda l: l.split('::'))\
    .map(lambda l: Rating(int(l[0]), int(l[1]), float(l[2])))

    / temp/ app/ 16-10-15/ 02


# Build the recommendation model using Alternating Least Squares
rank = 10
numIterations = 10
model = ALS.train(ratings, rank, numIterations)

# Evaluate the model on training data
testdata = ratings.map(lambda p: (p[0], p[1]))
predictions = model.predictAll(testdata).map(lambda r: ((r[0], r[1]), r[2]))
ratesAndPreds = ratings.map(lambda r: ((r[0], r[1]), r[2])).join(predictions)
MSE = ratesAndPreds.map(lambda r: (r[1][0] - r[1][1])**2).mean()
print("Mean Squared Error = " + str(MSE))

# Save and load model
model.save(sc, "target/tmp/myCollaborativeFilter")
sameModel = MatrixFactorizationModel.load(sc, "target/tmp/myCollaborativeFilter")

##查看数据
ratings.first()
##跳过第一行
header = rawData.first
rows = rawData.filter(lambda line: line != header)
```

## 13. Spark SQL

```python
# Import SQLContext and data types
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
import json
sc.stop()
conf = SparkConf()
sc = SparkContext('yarn-client', 'raw2ua', conf=conf)
# sc is an existing SparkContext.
#sqlContext = SQLContext(sc)

# Load a text file and convert each line to a tuple.
linesRDD = sc.textFile("hdfs://Ucluster/raw/es/2016-08-30/part-r-00000")
jsonData = linesRDD.map(lambda x : json.loads(x))

jsonData.first()
#lnRDD = sc.textFile("hdfs://Ucluster/raw/es/2016-10-16/")
#lnRDD.count()
# The schema is encoded in a string.
#schemaString = "line"

#fields = [StructField(field_line, StringType(), True) for field_line in schemaString.split()]
#schema = StructType(fields)
#schema = StructType([StructField("line",StringType(),True)])
# Apply the schema to the RDD.
#schemaLine = sqlContext.createDataFrame(linesRDD, schema)

# Register the DataFrame as a table.
#schemaLine.registerTempTable("linesRDD")

# SQL can be run over DataFrames that have been registered as a table.
#results = sqlContext.sql("SELECT line FROM linesRDD")
#results.count()
#results.write.save("hdfs://Ucluster/temp/txt2par",format='parquet')

```
