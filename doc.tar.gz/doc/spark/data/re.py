#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 24
import re

# 将正则表达式编译成Pattern对象，注意hello前面的r的意思是“原生字符串”
if __name__ == "__main__":
	ng = "GET /api.php?mod=user&ac=login&uid=&device=iPhone7,1/9.3.5&pwd= 225131&lon=&diu=5250BD1D-1CD7-44C9-89A0-2D5F00FFC50F&version=5.0.5&diu2=4D5E67F4-80F1-4CC8-8CAB-162A06D3FBDE&stepid=4&uuid=25ab1d0add58c7e775fe997c5039a49b&type=3&div=5.0.5&netop=&client=1&startid=25325887&name=&diu3=5250BD1D-1CD7-44C9-89A0-2D5F00FFC50F&height=667&model=9.3.5&city=&avatar=&SDKVersion=9.3.5&mobile=13795347767&province=&lat=&openid=&xinge=&devices=iPhone7,1&token=&ver=v2&time=1476903504122&nettype=WiFi&dic=appstore&width=375&manufacture=APPLE&hash=530557f5dc63172f03d8e3ee8044c34c HTTP/1.1"
	nc = "GET HTTP/1.1"
	nd = "HEAD /favicon.ico HTTP/1.0"
	s = '((\"(GET|POST))(?P<url>.+)(http\/1\.1"))'
	pattern = re.compile(r'(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.1)')
	mat =re.match(pattern,ng).group(3)
	print  mat
	pattern = re.compile('(\w+)\=(.*)+')
	ua =re.findall(pattern,mat)
	print ua
	#print ua.groups()
	# print mat.group(1)
	# print mat.group(2)
	# print mat.group(3)
	# print mat.group(4)
	# print len(mat.groups())
	r"(?=(AAA(?:\w{3})*?CCC))"