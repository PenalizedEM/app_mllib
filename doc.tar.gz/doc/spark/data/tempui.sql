use da;
CREATE EXTERNAL TABLE IF NOT EXISTS temp_user_info(
u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_diu2  STRING  COMMENT '广告ID,android--mac, ios--IDFA',
u_diu3  STRING  COMMENT 'GUID,android--guid, ios--guid',
u_uid STRING  COMMENT '注册用户id',
u_uuid  STRING  COMMENT '用户设备号(md5)',
u_hash  STRING  COMMENT '加密验证串',
u_xinge STRING  COMMENT '信鸽token',
u_token STRING  COMMENT '用户单点登录token',
u_div_f STRING  COMMENT '首次激活时的客户端版本号',
u_div STRING  COMMENT '当前客户端版本',
u_dic_f STRING  COMMENT '首次激活时的客户端渠道号',
u_dic STRING  COMMENT '当前客户端渠道号',
u_client  STRING  COMMENT '客户端类型',
u_timestamp_f TIMESTAMP COMMENT '首次激活时的请求时间',
u_timestamp TIMESTAMP COMMENT '当前请求时间',
u_netop_f STRING  COMMENT '首次激活时的网络运营商',
u_netop STRING  COMMENT '当前网络运营商',
u_province_f  STRING  COMMENT '首次激活时用户所在省份',
u_province  STRING  COMMENT '用户所在省份',
u_city_f  STRING  COMMENT '首次激活时用户所在城市',
u_city  STRING  COMMENT '用户所在城市',
u_manufacture STRING  COMMENT '生产厂家',
u_model STRING  COMMENT 'ios:固件版本; android:手机模型',
u_device  STRING  COMMENT 'ios:设备型号; android:设备',
u_width STRING COMMENT '屏幕尺寸——宽',
u_height  STRING COMMENT '屏幕尺寸——高',
u_fresh INT COMMENT '用户新鲜度(当天减去激活天数)',
u_active  INT COMMENT '用户累计活跃天数',
u_tag STRING  COMMENT '用户标签',
u_bigger_json STRING  COMMENT '最后的大json' 
)
COMMENT '糖豆用户设备表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS PARQUET
LOCATION '/temp/test/ui/';