#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 19
import json
import dateutil.parser
from datetime import datetime
from dateutil import tz
import re
#import urllib 
#读入JSON到Dict
def readJson(fileName):
    with open(fileName) as data_file:
        i=0
        j=0
        for line in data_file:
            data = json.loads(line)
            pattern = re.compile(r'(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.1)')
            mat =re.match(pattern,data)
            print mat


#主入口
def excuteM():
    f1 = "/Users/vent/gitlab/doc/spark/data/log1.json"
    #f4 = "../dic/dancekey.csv"
    d1 = readJson(f1)

excuteM()
#isoStr2utc8Str('2016-10-18T15:59:58.000Z')
