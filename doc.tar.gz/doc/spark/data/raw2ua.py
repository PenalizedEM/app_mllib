#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 19
import dateutil.parser
import json
from datetime import datetime,date, timedelta
from dateutil import tz
from pyspark.sql import SQLContext
from pyspark.sql.types import *
from pyspark import SparkContext, SparkConf
from pyspark.sql import Row
import re
import sys
from collections import OrderedDict
#读入JSON到Dict
def readJson(line):
    global allLines,jpeLines,uaList,uaIntList
    #uaList = ['u_timestamp','u_backtime','u_responsetime','u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_stepid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_page','u_position','u_vid','u_type','u_percent','u_rate','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_download_start','u_download_stop','u_fail_cdn_source','u_new_cdn_source','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
    uaDict = dict((el,"") for el in uaList)
    #uaDict['u_timestamp'] = datetime.datetime('1984','6','4','0','0','0')
    data = json.loads(line)
	#处理Logstash codec错误的数据
    if data.get('tags',""):
        regex = re.compile(r'\\(?![/u"])')
        fixed = regex.sub(r"\\\\", data['message'])
        data = json.loads(fixed)
        jpeLines +=1
    #只处理正确编码日志
    #生成 request dictionary
    #else:
    data.pop('path',None)
    data.pop('@version',None)
    reqStr=data.pop('request',None)
    uaDict = etlOther(data,uaDict)
    uaDict = etlRequest(reqStr,uaDict)
    #uaDict = castFiled(uaDict)
    allLines += 1
    return uaDict
	#return data

# #初始化UASchema
# def initUA(uaDict):
#     uaList = ['u_timestamp','u_backtime','u_responsetime','u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_stepid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_page','u_position','u_vid','u_type','u_percent','u_rate','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_download_start','u_download_stop','u_fail_cdn_source','u_new_cdn_source','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
#     for uaEle in uaList:
#         uaDict[uaEle] = ""
#     return uaDict
#解析、清洗、转换日志的非request部分
def etlOther(otherDict,uaDict):
    #cleanOtherDict = dict()
    #将ISO8601时间转换成本地时间
    global opeLines
    try:
        otherDict['timestamp']=isoStr2utc8Str(otherDict.pop('@timestamp'))
        #print otherDict['timestamp']
        #相应时间转换成毫秒
        if  otherDict['backtime'] !='-':
            otherDict['backtime']= str(float(otherDict['backtime'])*1000)
            otherDict['responsetime']= str(float(otherDict['responsetime'])*1000)
        else:
            otherDict['backtime']= str(0.0)
        #遍历字典，更换新key,有更干净做法？
        for key in otherDict:
            newKey = "u_"+key.lower()
            uaDict[newKey]= otherDict[key]
        #清空旧字典
        otherDict.clear()
        #print cleanOtherDict
    except ValueError as ve:
        #print "\skipping otherDict ve:", json.dumps(otherDict['backtime'])
        opeLines +=1
    except TypeError as te:
        #print te
        #print "\skipping uaDict te: ", uaDict
        opeLines +=1
    finally:
        return uaDict

#解析、清洗、转换日志的request部分
def etlRequest(reqItem,uaDict):
    #reqDict = dict()
    global rpeLines
    bigjsonDict = dict()
    #1. request值先按照空格分割得到四部分: (http_method) (http_uri)?(http_para) (http_verb)
    #每条日志都应该匹配上并正确切分成4部分。
    #TODO : 加上else累计器
    try:
        pattern = re.compile('(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.1)')
        mat =re.match(pattern,reqItem)
        if mat is not None and len(mat.groups())==4:
            uaDict['u_method'] = mat.group(1)
            uaDict['u_url'] = mat.group(2)
            uaDict['u_verb'] = mat.group(4)
            #for mustUa in flatList:
            #uaDict[mustUa] = ""
            #2. 对实际参数做分割,强制转换为小写，加上前缀u_
            reqList = mat.group(3).split('&')
            for reqEle in reqList:
                #if len(reqEle.split('='))==2:
                kvList = reqEle.split('=',2)
                if len(kvList) < 2:
                    kvList.append("")
                uaEle = 'u_'+kvList[0].lower()
                #将u_channel,u_version,u_setpid使用lambda转换成预定义的filed名
                tf = lambda rf:{'u_channel': 'u_dic','u_version': 'u_div','u_setpid':'u_stepid'}.get(rf,rf)
                cleanEle = tf(uaEle)
                if cleanEle in uaDict:
                    uaDict[cleanEle]=kvList[1]
                else:
                    bigjsonDict[cleanEle]=kvList[1]
            uaDict['u_bigger_json']=json.dumps(bigjsonDict)
    except TypeError as te:
        #print "\skipping te:", mat.group(1)
        rpeLines +=1
    finally:
        return uaDict
    # else:
    #     return uaDict
    #uaDict['u_province'] = uaDict['u_province'].decode('utf-8')
    #else:
    #print reqDict
    #print "bigger: "+json.dumps(bigjsonDict)

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat):
    if len(dateList) ==1:
        # yes = date.today() - timedelta(1)
        datePath = (date.today() - timedelta(1)).strftime(dateFormat)
        # print datePath
    elif len(dateList) ==2:
        datePath = datetime.strptime(dateList[1],'%Y-%m-%d').strftime(dateFormat)
        #print datePath
    return datePath

#将传入的ISO8601 时间字符串，转成成指定格式的Local时区字(UTC+8)符串
def isoStr2utc8Str(isoStr):
    #暂时不理解spark 读取 py-files的原理.dateutil.parse没有正确读取(取出timestamp，解析转成iso8601 datetime)
    #isoTime = dateutil.parser.parse(isoStr)
    #iso datetime类型转成本地时间datetime，然后转换成指定格式字符串
    #utc8Time = isoTime.astimezone(tz.tzlocal()).strftime('%Y-%m-%d %H:%M:%S')
    #取出timestamp，解析转成iso8601 navie datetime
    utc= datetime.strptime(isoStr,'%Y-%m-%dT%H:%M:%S.%fZ')
    #utc navie datetime设置时区，再换成本地时区，最后解析成字符串。时区可以硬编码。
    utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
    #utc8Time = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).replace(tzinfo=None)
    return utc8Time

#初始化Spark conf，貌似yarn和pyfile没生效
def initSC(inDate):
	conf = SparkConf()
	sc = SparkContext('yarn-client', 'Spark-Raw2UA:'+inDate, conf=conf)
	sc.addPyFile('hdfs://Ucluster/user/hadoop/pyspark/dateutil.zip')
	sc.addPyFile('hdfs://Ucluster/user/hadoop/pyspark/six.py')
	return sc
#定义好UASchema
def conUASchema():
    global uaList
    uaDict = OrderedDict()
    for ua in uaList:
        uaDict[ua] = StructField(ua, StringType(), True)
    schema = StructType(list(uaDict.values()))
    return schema

#判断字段是否合法
def cleanFiled(patStr,cleanStr):
    global numberLines
    cleanPat = re.compile(patStr)
    try:
        if re.match(cleanPat,cleanStr):
            return True
    except TypeError as te:
        print te
        numberLines += 1
    else:
        return False

##显式转化成int型
def castFiled(uaDict):
    global uaIntList,timeLines
    if not uaDict['u_timestamp']:
        uaDict['u_timestamp'] = datetime.strptime('1984-1-1 00:00:00.198964','%Y-%m-%d %H:%M:%S.%f')
        timeLines += 1
    numberPat = '^-?[0-9]+$'
    for ua in uaIntList:
            if uaDict[ua] is not None and cleanFiled(numberPat,uaDict[ua]):
                try:
                    uaDict[ua] = int(uaDict[ua])
                except ValueError:
                    uaDict[ua] = int(-1024.0)
                    # 报错：-6984074900 按说应该是 32 位机器2147483647 64位机器，范围应该是 9223372036854775807
                    # spark sql IntegerType 32 位
            else:
                uaDict[ua] = -1
    return uaDict
#主入口
if __name__ == "__main__":
        # if len(sys.argv) > 2:
        # 	print "Usage: Only YYYY-mm-dd format accpeted. Without data input will run yesterday's data"
        # 	exit(-1)
        print sys.argv
        reload(sys)
        sys.setdefaultencoding('utf-8')
        #处理输入输出目录的日期格式
        inDate=handleDatePath(sys.argv,'%y-%m-%d')
        inPath = "hdfs://Ucluster/flume/"+inDate+"/**/"
        print "InPut HDFS Path: ",inPath
        outDate=handleDatePath(sys.argv,'%Y-%m-%d')
        #outPath = "hdfs://Ucluster/olap/dw/uabigger/"+outDate+"/"
        outPath = "hdfs://Ucluster/olap/dw/uabigger/"+outDate+"/"
        print "OutPut HDFS Path: ",outPath
        uaList = ['u_timestamp','u_backtime','u_responsetime','u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_size','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_stepid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_page','u_position','u_vid','u_type','u_percent','u_rate','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_download_start','u_download_stop','u_fail_cdn_source','u_new_cdn_source','u_width','u_height','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
        #strTypeArr = ['u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_vid','u_type','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_fail_cdn_source','u_new_cdn_source','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
        #uaIntList = ['u_backtime','u_responsetime','u_size','u_stepid','u_page','u_position','u_percent','u_rate','u_width','u_height']
        uaIntList = ['u_size','u_stepid','u_page','u_position','u_percent','u_rate','u_width','u_height']
        uaTimeList = ['u_timestamp']
        #print conUASchema()
        sc = initSC(outDate)
        #print sc
        #sc = SparkContext('yarn-client', 'Spark-Raw2ua'+inDate, conf=conf)
        sqlContext = SQLContext(sc)
        linesRDD = sc.textFile(inPath)
        allLines = sc.accumulator(0)
        #json parse error line count
        jpeLines = sc.accumulator(0)
        #request parse error line
        rpeLines = sc.accumulator(0)
        opeLines = sc.accumulator(0)
        timeLines = sc.accumulator(0)
        numberLines = sc.accumulator(0)
        uaRDD= linesRDD.map(lambda x : readJson(x))
        print uaRDD.take(2)
        uaDF = sqlContext.createDataFrame(uaRDD.coalesce(160),conUASchema())
        uaDF.printSchema()
        uaDF.write.mode('overwrite').save(outPath, format="parquet")
        #uaDF.write.json('hdfs://Ucluster/olap/dw/uabigger/test.json')
        print "all line: ",allLines
        print "json parse error line : ",jpeLines
        print "request parse error line: ",rpeLines
        print "other parse error line: ",opeLines
        print "timestamp empty line", timeLines
        print "number error line", numberLines
        sc.stop()
        # Infer the schema, and register the DataFrame as a table.
        #uaRDD.coalesce(50)
        # uaSchema = StructType([ StructField("u_timestamp", StringType(), True),
        #     StructField("Packsize", StringType(), True),
        #     StructField("Name", StringType(), True)])
        #uaDF = sqlContext.createDataFrame(uaRDD.coalesce(300),conUASchema())
        #uaDF.select('u_timestamp').write.csv('hdfs://Ucluster/olap/dw/uabigger/mycsv.csv')
        #uaDF.coalesce(200)
        #uaSchema.printSchema()
        #uaSchema.registerTempTable("testuabigger")
        #findFriend = sqlContext.sql("SELECT u_diu,u_client FROM testuabigger")
        #ff_diu = findFriend.rdd.map(lambda p: p.u_diu).collect()
        #for diu in ff_diu:
        	#print(diu)
        #print uaRDD.first()
