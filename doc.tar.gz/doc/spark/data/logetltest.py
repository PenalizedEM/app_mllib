#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 19
import json
import dateutil.parser
from datetime import datetime, date, timedelta
import time
from dateutil import tz
import re
from collections import OrderedDict
# import urllib
# 读入JSON到Dict


def readJson(fileName):
    uaList = ['u_timestamp', 'u_backtime', 'u_responsetime',
                'u_host', 'u_http_host', 'u_clientip',
                'u_referer', 'u_xff', 'u_status', 'u_size',
                'u_div', 'u_dic', 'u_diu', 'u_diu2', 'u_diu3',
                'u_uid', 'u_startid', 'u_stepid', 'u_time',
                'u_mod', 'u_ac', 'u_client', 'u_ver',
                'u_uuid', 'u_hash', 'u_xinge', 'u_token', 'u_agent',
                'u_method', 'u_new_activity', 'u_old_activity', 'u_key',
                'u_client_module', 'u_source', 'u_page', 'u_position', 'u_vid',
                'u_type', 'u_percent', 'u_rate', 'u_user_role', 'u_isnew_user',
                'u_isdownload', 'u_isonline', 'u_buffertime', 'u_action',
                'u_ishigh', 'u_cdn_source', 'u_download_start',
                'u_download_stop', 'u_fail_cdn_source', 'u_new_cdn_source',
                'u_width', 'u_height', 'u_lon', 'u_lat', 'u_province',
                'u_city', 'u_netop', 'u_nettype', 'u_sdkversion',
                'u_model', 'u_device', 'u_manufacture', 'u_bigger_json']
    with open(fileName) as data_file:
        i = 0
        j = 0
        for line in data_file:
            uaDict = dict((el, "") for el in uaList)
            data = json.loads(line)
            # 处理Logstash codec错误的数据
            if data.get('tags', ""):
                regex = re.compile(r'\\(?![/u"])')
                fixed = regex.sub(r"\\\\", data['message'])
                data = json.loads(fixed)
                i += 1
            # 只处理正确编码日志
            # 生成 request dictionary
            else:
                j += 1
            reqStr = data.pop('request', None)
            uaDict = etlOther(data, uaDict)
            uaDict = etlRequest(reqStr, uaDict)
            print i
            print j

# 解析、清洗、转换日志的非request部分
def etlOther(otherDict, uaDict):
    # cleanOtherDict = dict()
    # 将ISO8601时间转换成本地时间
    try:
        otherDict['timestamp'] = isoStr2utc8Str(otherDict.pop('@timestamp'))
        # 相应时间转换成毫秒
        if otherDict['backtime'] != '-':
            otherDict['backtime'] = float(otherDict['backtime'])*1000
            otherDict['responsetime'] = float(otherDict['responsetime'])*1000
        else:
            otherDict['backtime'] = 0.0
        # 遍历字典，更换新key,有更干净做法？
        for key in otherDict:
            newKey = "u_"+key.lower()
            uaDict[newKey] = otherDict[key]
        # 清空旧字典
        otherDict.clear()
        # print cleanOtherDict
    except ValueError as ve:
        print "\skipping otherDict ve:", json.dumps(otherDict['backtime'])
    except TypeError as te:
        print te
        print "\skipping uaDict te: ", uaDict
    finally:
        return uaDict

# 解析、清洗、转换日志的request部分
def etlRequest(reqItem, uaDict):
    #reqDict = dict()
    bigjsonDict = dict()
    #1. request值先按照空格分割得到四部分: (http_method) (http_uri)?(http_para) (http_verb)
    #每条日志都应该匹配上并正确切分成4部分。
    #TODO : 加上else累计器
    try:
        pattern = re.compile('(GET|POST)\s(\/.*)\?(.*)\s(HTTP\/1\.1)')
        mat =re.match(pattern,reqItem)
        if mat is not None and len(mat.groups())==4:
            uaDict['u_method'] = mat.group(1)
            uaDict['u_url'] = mat.group(2)
            uaDict['u_verb'] = mat.group(4)
            #for mustUa in flatList:
            #uaDict[mustUa] = ""
            #2. 对实际参数做分割,强制转换为小写，加上前缀u_
            reqList = mat.group(3).split('&')
            for reqEle in reqList:
                #if len(reqEle.split('='))==2:
                kvList = reqEle.split('=',2)
                if len(kvList) < 2:
                    kvList.append("")
                uaEle = 'u_'+kvList[0].lower()
                #将u_channel,u_version,u_setpid使用lambda转换成预定义的filed名
                tf = lambda rf:{'u_channel': 'u_dic','u_version': 'u_div','u_setpid':'u_stepid'}.get(rf,rf)
                cleanEle = tf(uaEle)
                if cleanEle in uaDict:
                    uaDict[cleanEle]=kvList[1]
                else:
                    bigjsonDict[cleanEle]=kvList[1]
            uaDict['u_bigger_json']=json.dumps(bigjsonDict)
    except TypeError as te:
        print "\skipping te:", mat.group(1)
    finally:
        return uaDict
    # else:
    #     return uaDict
    #uaDict['u_province'] = uaDict['u_province'].decode('utf-8')
    #else:
    #print reqDict
    #print "bigger: "+json.dumps(bigjsonDict)

#接受命令行输入的时间参数，指定输入输出目录
def handleDatePath(dateList,dateFormat,days):
    if len(dateList) ==1:
        #yes = date.today() - timedelta(1)
        days +=1
        datePath =  (date.today() - timedelta(days)).strftime(dateFormat)
        #print datePath
    elif len(dateList) ==2:
        datePath = (datetime.strptime(dateList[1],'%Y-%m-%d') - timedelta(days)).strftime(dateFormat)
        #print datePath
    return datePath
#时间转化
def timeCon(dateIn,inFormat):
    print int(time.mktime(time.strptime(dateIn, inFormat)))*1000
    #print datetime.strptime(dateIn,inFormat).strftime(outFormat)
#将传入的ISO8601 时间字符串，转成成指定格式的Local时区字(UTC+8)符串
def isoStr2utc8Str(isoStr):

    #isoStr = '2016-10-18T15:59:58.000Z'
    utc= datetime.strptime(isoStr,'%Y-%m-%dT%H:%M:%S.%fZ')
    #print utc
    central = utc.replace(tzinfo=tz.tzutc()).astimezone(tz.tzlocal()).replace(tzinfo=None)
    #central = datetime.strptime(central,"%Y-%m-%d %H:%M:%S.%f")
    #central = utc.astimezone(to_zone)
    #print central
    #取出timestamp，解析转成iso8601 datetime
    #isoTime=dateutil.parser.parse(isoStr)
    #iso datetime类型转成本地时间datetime，然后转换成指定格式字符串
    #utc8Time = isoTime.astimezone(tz.tzlocal()).strftime('%Y-%m-%d %H:%M:%S')
    #print utc8Time
    #datetime.strptime(nuiDict['u_timestamp'], "%Y-%m-%d %H:%M:%S.%f")
    return central
#parse hive txt
def readHive(line):
    uaList = ['u_diu','u_diu2','u_diu3','u_uid','u_uuid','u_hash','u_xinge','u_token','u_div_f','u_div','u_dic_f','u_dic','u_client','u_timestamp_f','u_timestamp','u_netop_f',
                'u_netop','u_province_f','u_province','u_city_f','u_city','u_manufacture','u_model','u_device','u_width','u_height','u_fresh','u_active','u_tag','u_bigger_json']
    #print len(uaList)
    valList = line.split("\001",30)
    #print len(valList)
    #print valList
    result = OrderedDict(zip(uaList, valList))
    #print result
def cleanFiled():
    diu='45C7EF12-8175-4AE8-978D-303941C1B6BA'
    uid='419013'
    diuPattern=re.compile("^[\\w-]{5,75}?$")
    numberPattern=re.compile("^[\\d]{1,30}$")
    #enPattern=re.compile("^[\\w-_@#]{3,75}?$")
    if not re.match(diuPattern,diu):
        print "diu not match"
    if not re.match(numberPattern,uid):
        print "uid not match"

# def cleanFiled(patStr,cleanStr):
#     #cleanPat = re.compile("^[\\w-]{5,75}?$")
#     #cleanPat = re.compile("^[\\d]{1,30}$")
#     cleanPat = re.compile(patStr)
#     if re.match(cleanPat,cleanStr):
#         print "True"
#         return True
#     else:
#         print "False"
#         return False

def cleanFiled(cleanStr):
    numberPat = '^-?[0-9]+$'
    cleanPat = re.compile(numberPat)
    if re.match(cleanPat,cleanStr):
        print 'True'
        return True
    else:
        print 'False'
        return False

def testMyAss():
    print 'myass'
#初步清洗UA的DIU,抛弃非用户主动触发接口
def cleanUA(x):
    modAC = x.u_mod+"-"+x.u_ac;
    filterArray=['main-start','top-count_plush','emptylog-push_arrival']
    if modAC not in filterArray:
        x.u_diu = cleanFiled('diu',x.u_diu)
        if not x.u_diu:
            return x
#reduce by key to aggreate each key's first & last record
def mergeDict(x,y):
    x.update(y)
    return x

# StructType([
#     StructField("Id", StringType(), True),
#     StructField("Packsize", StringType(), True),
#     StructField("Name", StringType(), True)
# ])
def conUASchema():
    strTypeArr = ['u_host','u_http_host','u_clientip','u_referer','u_xff','u_status','u_url','u_verb','u_div','u_dic','u_diu','u_diu2','u_diu3','u_uid','u_startid','u_time','u_mod','u_ac','u_client','u_ver','u_uuid','u_hash','u_xinge','u_token','u_agent','u_method','u_new_activity','u_old_activity','u_key','u_client_module','u_source','u_vid','u_type','u_user_role','u_isnew_user','u_isdownload','u_isonline','u_buffertime','u_action','u_ishigh','u_cdn_source','u_fail_cdn_source','u_new_cdn_source','u_lon','u_lat','u_province','u_city','u_netop','u_nettype','u_sdkversion','u_model','u_device','u_manufacture','u_bigger_json']
    intTypeArr = ['u_size','u_stepid','u_page','u_position','u_percent','u_rate','u_width','u_height']
    timeTypeArr = ['u_timestamp','u_download_start','u_download_stop']
    fields = [StructField(filed, StringType(), True) for filed in strTypeArr]
    fields = fields.extend([StructField(filed, IntegerType(), True) for filed in intTypeArr])
    fields = fields.extend([StructField(filed, TimestampType(), True) for filed in timeTypeArr])
    schema = StructType(fields)
    return schema

#主入口
def excuteM():
    f1 = "/Users/vent/gitlab/doc/spark/data/log1.json"
    #f4 = "../dic/dancekey.csv"
    d1 = readJson(f1)


#logEcoph=int(time.mktime(time.strptime('2016-10-18 15:59:58.000','%Y-%m-%d %H:%M:%S.%f')))*1000
#print logEcoph
#print cleanFiled('^[\\w-]{5,75}?$','2222')
cleanFiled('')
print datetime.strptime('2016-10-18 15:59:58.005','%Y-%m-%d %H:%M:%S.%f')
print isoStr2utc8Str('2016-10-18T15:59:58.005Z')
#excuteM()
#datelist = ['log',"2016-11-01"]
#print handleDatePath(datelist,'%Y-%m-%d',0)
#print isoStr2utc8Str('2016-10-18T15:59:58.005Z')
#print conUASchema()
#line1 ='00000000ccb3d1ab009f625f5f45e1714c78b5412b2409162e036e352016-05-03 00:00:002016-05-03 22:47:21001781'
#line = '00000000c259bc9d5cffff5bb1a3437ba50b135a4fc684784dadd054c6e426b3263049252dfb232251970e96dba60fa57f738b487085ca49f166f84ff23eAq1PzwVEyKfHap3bhAHEqhhQ8Qw-6iHD6LdrBuLgcBP05.0.55.0.5wandoujiawandoujia22016-10-12 16:49:272016-10-12 16:49:27UNKNOWNUNKNOWNTVBAOFENG_TV+AML_T866BAOFENG_TV+AML_T866-Android:4.4.219201080161'
#readHive(line)
#timeCon("2016-10-18 15:59:58.000",'%Y-%m-%d %H:%M:%S.%f')
