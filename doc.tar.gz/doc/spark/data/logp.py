#!/usr/bin/python
# -*- coding: UTF-8 -*-
# create  by vent @ Oct 19
import json
import dateutil.parser
from datetime import datetime
from dateutil import tz

#读入JSON到Dict
def readJson(fileName):
    with open(fileName) as data_file:
        i=0
        j=0
        for line in data_file:
            data = json.loads(line)
            #去掉没用的字段
            data.pop('path',None)
            data.pop('@version',None)
            alist = data['request'].split('?')
            #生成 request dictionary
            if len(alist)==2:
                i+=1
            else:
                print json.dumps(data)
                j+=1
        print i
        print j

#主入口
def excuteM():
    f1 = "/Users/vent/gitlab/doc/spark/data/log1.json"
    #f4 = "../dic/dancekey.csv"
    d1 = readJson(f1)

excuteM()
