# 用户信息表(user info)恢复

>同步DB中的user info(DB中数据的业务日期2016-09-20)

## 1、从db同步 push_userinfo_lightweight 到raw/ui

```shell 
sqoop import --connect jdbc:mysql://10.10.243.51:3306/2016hd --username root --password 'tangdouapp#123' --table push_userinfo_lightweight --fields-terminated-by '\001' --hive-delims-replacement ',' --target-dir '/raw/ui/'  -m 1

or 

import --connect jdbc:mysql://10.10.243.51:3306/2016hd --username root --password tangdouapp#123 --table push_userinfo_lightweight --fields-terminated-by \001 --hive-delims-replacement , --target-dir /raw/ui/  -m 1
```

## 2、建表 raw_ui 

```sql
use dw;
drop table raw_ui;
CREATE EXTERNAL TABLE IF NOT EXISTS raw_ui(
id int COMMENT '自增id',
u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_xinge STRING  COMMENT '信鸽token',
u_fresh INT COMMENT '用户新鲜度(当天减去激活天数)',
u_active  INT COMMENT '用户累计活跃天数',
u_timestamp TIMESTAMP COMMENT '当前请求时间' 
)
COMMENT '20160401~20160921糖豆用户设备表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/raw/ui/';
```

## 3、修正hive表元数据中文乱码情况 

- 在hive-site.xml中找到元数据mysql的链接串，以root账号登录hive所在的master，进入mysql修改

    ```shell 
    <value>jdbc:mysql://uhadoop-jhr2pf-master1:3306/hive?createDatabaseIfNotExist=true&amp;autoReconnect=true&amp;characterEncoding=UTF-8</value>
    ```

- 执行 
    
    ```sql 
    GRNAT ALTER ON COLUMNS_V2 TO hive WITH GRANT OPTION;
    alter table COLUMNS_V2 modify column COMMENT varchar(256) character set utf8;
    alter table TABLE_PARAMS modify column PARAM_VALUE varchar(4000) character set utf8;
    alter table PARTITION_PARAMS  modify column PARAM_VALUE varchar(4000) character set utf8 ;
    alter table PARTITION_KEYS  modify column PKEY_COMMENT varchar(4000) character set utf8;
    alter table  INDEX_PARAMS  modify column PARAM_VALUE  varchar(4000) character set utf8;
    ```

## 4、用hue账号建dw.user_info表

```sql 
-- create userinfo table
use dw;
drop table user_info;
CREATE EXTERNAL TABLE IF NOT EXISTS user_info(
u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_diu2  STRING  COMMENT '广告ID,android--mac, ios--IDFA',
u_diu3  STRING  COMMENT 'GUID,android--guid, ios--guid',
u_uid STRING  COMMENT '注册用户id',
u_uuid  STRING  COMMENT '用户设备号(md5)',
u_hash  STRING  COMMENT '加密验证串',
u_xinge STRING  COMMENT '信鸽token',
u_token STRING  COMMENT '用户单点登录token',
u_div_f STRING  COMMENT '首次激活时的客户端版本号',
u_div STRING  COMMENT '当前客户端版本',
u_dic_f STRING  COMMENT '首次激活时的客户端渠道号',
u_dic STRING  COMMENT '当前客户端渠道号',
u_client  STRING  COMMENT '客户端类型',
u_timestamp_f TIMESTAMP COMMENT '首次激活时的请求时间',
u_timestamp TIMESTAMP COMMENT '当前请求时间',
u_netop_f STRING  COMMENT '首次激活时的网络运营商',
u_netop STRING  COMMENT '当前网络运营商',
u_province_f  STRING  COMMENT '首次激活时用户所在省份',
u_province  STRING  COMMENT '用户所在省份',
u_city_f  STRING  COMMENT '首次激活时用户所在城市',
u_city  STRING  COMMENT '用户所在城市',
u_manufacture STRING  COMMENT '生产厂家',
u_model STRING  COMMENT 'ios:固件版本; android:手机模型',
u_device  STRING  COMMENT 'ios:设备型号; android:设备',
u_width INT COMMENT '屏幕尺寸——宽',
u_height  INT COMMENT '屏幕尺寸——高',
u_fresh INT COMMENT '用户新鲜度(当天减去激活天数)',
u_active  INT COMMENT '用户累计活跃天数',
u_tag STRING  COMMENT '用户标签',
u_bigger_json STRING  COMMENT '最后的大json' 
)
COMMENT '糖豆用户设备表'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/dw/ui/';

alter table user_info drop partition(dt='2016-09-21');
alter table user_info add if not exists partition(dt='2016-09-21') LOCATION '/olap/dw/ui/2016-09-21';
```

## 5、填充2016-09-21日user_info表数据

```sql 
use dw;
insert overwrite table dw.user_info partition(dt='2016-09-21') 
select 
u_diu,
'' u_diu2,
'' u_diu3,
'' u_uid,
'' u_uuid,
'' u_hash,
u_xinge,
'' u_token,
'' u_div_f,
'' u_div,
'' u_dic_f,
'' u_dic,
'' u_client,
cast(cast (date_sub('2016-09-21',u_fresh) as date) as TIMESTAMP) u_timestamp_f,
u_timestamp,
'' u_netop_f,
'' u_netop,
'' u_province_f,
'' u_province,
'' u_city_f,
'' u_city,
'' u_manufacture,
'' u_model,
'' u_device,
0 u_width,
0 u_height,
u_fresh,
u_active,
'' u_tag,
'' u_bigger_json 
from 
dw.raw_ui 
;
``` 

## 6、从8月31号开始回滚user info，先填充8月30日user info数据

```sql

alter table dw.user_info drop if exists partition(dt='2016-08-30') ;

alter table dw.user_info add if not exists partition(dt='2016-08-30') location '/olap/dw/ui/2016-08-30';

use dw;
insert overwrite table dw.user_info partition(dt='2016-08-30') 
select 
u_diu,
'' u_diu2,
'' u_diu3,
'' u_uid,
'' u_uuid,
'' u_hash,
u_xinge,
'' u_token,
'' u_div_f,
'' u_div,
'' u_dic_f,
'' u_dic,
'' u_client,
cast(cast (date_sub('2016-09-21',u_fresh) as date) as TIMESTAMP) u_timestamp_f,
u_timestamp,
'' u_netop_f,
'' u_netop,
'' u_province_f,
'' u_province,
'' u_city_f,
'' u_city,
'' u_manufacture,
'' u_model,
'' u_device,
0 u_width,
0 u_height,
u_fresh,
u_active,
'' u_tag,
'' u_bigger_json 
from 
dw.raw_ui 
where date_sub('2016-09-21',u_fresh)<='2016-08-30' 
;
```

## 6、补充后来找到的7月28日的全量user info数据

```sql

-- 7月28日的全量userinfo表

-- create userinfo table
use dw;
CREATE EXTERNAL TABLE IF NOT EXISTS user_info_20160728(
rowkey STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_diu STRING  COMMENT '设备唯一号,android--imei, ios--IDFV',
u_diu2  STRING  COMMENT '广告ID,android--mac, ios--IDFA',
u_diu3  STRING  COMMENT 'GUID,android--guid, ios--guid',
u_uid STRING  COMMENT '注册用户id',
u_uuid  STRING  COMMENT '用户设备号(md5)',
u_hash  STRING  COMMENT '加密验证串',
u_xinge STRING  COMMENT '信鸽token',
u_token STRING  COMMENT '用户单点登录token',
u_div_f STRING  COMMENT '首次激活时的客户端版本号',
u_div STRING  COMMENT '当前客户端版本',
u_dic_f STRING  COMMENT '首次激活时的客户端渠道号',
u_dic STRING  COMMENT '当前客户端渠道号',
u_client  STRING  COMMENT '客户端类型',
u_timestamp_f TIMESTAMP COMMENT '首次激活时的请求时间',
u_timestamp TIMESTAMP COMMENT '当前请求时间',
u_netop_f STRING  COMMENT '首次激活时的网络运营商',
u_netop STRING  COMMENT '当前网络运营商',
u_province_f  STRING  COMMENT '首次激活时用户所在省份',
u_province  STRING  COMMENT '用户所在省份',
u_city_f  STRING  COMMENT '首次激活时用户所在城市',
u_city  STRING  COMMENT '用户所在城市',
u_manufacture STRING  COMMENT '生产厂家',
u_model STRING  COMMENT 'ios:固件版本; android:手机模型',
u_device  STRING  COMMENT 'ios:设备型号; android:设备',
u_width INT COMMENT '屏幕尺寸——宽',
u_height  INT COMMENT '屏幕尺寸——高',
u_fresh INT COMMENT '用户新鲜度(当天减去激活天数)',
u_active  INT COMMENT '用户累计活跃天数',
u_tag STRING  COMMENT '用户标签',
u_bigger_json STRING  COMMENT '最后的大json' ,
dt STRING  COMMENT 'dt' 
)
COMMENT '糖豆用户设备表'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/old/user/hadoop/dw/user_info_20160728'
;

select count(1) from dw.user_info_20160728;
-- 7620807

insert overwrite table dw.user_info partition(dt='2016-11-01') 
select 
a.u_diu,
if(a.u_diu2 is null or a.u_diu2 ='', if(b.u_diu2 is null,'',b.u_diu2), a.u_diu2) u_diu2,
if(a.u_diu3 is null or a.u_diu3 ='', if(b.u_diu3 is null,'',b.u_diu3), a.u_diu3) u_diu3,
if(a.u_uid is null or a.u_uid ='', if(b.u_uid is null,'',b.u_uid), a.u_uid) u_uid,
if(a.u_uuid is null or a.u_uuid ='', if(b.u_uuid is null,'',b.u_uuid), a.u_uuid) u_uuid,
if(a.u_hash is null or a.u_hash ='', if(b.u_hash is null,'',b.u_hash), a.u_hash) u_hash,
if(a.u_xinge is null or a.u_xinge ='', if(b.u_xinge is null,'',b.u_xinge), a.u_xinge) u_xinge,
if(a.u_token is null or a.u_token ='', if(b.u_token is null,'',b.u_token), a.u_token) u_token,
if(b.u_div_f is null , a.u_div_f, b.u_div_f) u_div_f,
if(a.u_div is null or a.u_div ='', if(b.u_div is null,'',b.u_div), a.u_div) u_div,
if(b.u_dic_f is null, a.u_dic_f, b.u_dic_f) u_dic_f,
if(a.u_dic is null or a.u_dic ='', if(b.u_dic is null,'',b.u_dic), a.u_dic) u_dic,
if(a.u_client is null or a.u_client ='', if(b.u_client is null,'',b.u_client), a.u_client) u_client,
if(b.u_timestamp_f is null , a.u_timestamp_f, b.u_timestamp_f) u_timestamp_f,
if(a.u_timestamp is null,b.u_timestamp, a.u_timestamp) u_timestamp,
if(b.u_netop_f is null , a.u_netop_f, b.u_netop_f) u_netop_f,
if(a.u_netop is null or a.u_netop ='', if(b.u_netop is null,'',b.u_netop), a.u_netop) u_netop,
if(b.u_province_f is null, a.u_province_f, b.u_province_f) u_province_f,
if(a.u_province is null or a.u_province ='', if(b.u_province is null,'',b.u_province), a.u_province) u_province,
if(b.u_city_f is null , a.u_city_f, b.u_city_f) u_city_f,
if(a.u_city is null or a.u_city ='', if(b.u_city is null,'',b.u_city), a.u_city) u_city,
if(a.u_manufacture is null or a.u_manufacture ='', if(b.u_manufacture is null,'',b.u_manufacture), a.u_manufacture) u_manufacture,
if(a.u_model is null or a.u_model ='', if(b.u_model is null,'',b.u_model), a.u_model) u_model,
if(a.u_device is null or a.u_device ='', if(b.u_device is null,'',b.u_device), a.u_device) u_device,
if(a.u_width is null or a.u_width ='', if(b.u_width is null,'',b.u_width), a.u_width)  u_width,
if(a.u_height is null or a.u_height ='', if(b.u_height is null,'',b.u_height), a.u_height)  u_height,
a.u_fresh,
a.u_active,
a.u_tag,
a.u_bigger_json 
from 
(select * from dw.user_info where dt='2016-11-01') a 
left outer join 
dw.user_info_20160728 b 
on(a.u_diu=b.u_diu)
;





```