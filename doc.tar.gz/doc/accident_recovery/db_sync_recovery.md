# 恢复每日db数据的同步

>由于sqoop创建的hive表在hive默认仓库中 Hive’s warehouse directory ，而且创建的hive表不会引入db中的表和字段注释。所以提前建好表，指定hive建表的目录。
另外，sqoop的hive-overwrite，需要hive表文件是在hive默认warehouse目录中的。 
- import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table video --hive-import --create-hive-table --hive-table dw.video --fields-terminated-by \001 --hive-delims-replacement , --target-dir /olap/db/video/ -m 1 
- import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table video --hive-import --hive-overwrite --hive-table dw.video --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/video/ -m 1 

## 一、 video表

>- 原来的导入，导入hdfs
- import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table video --fields-terminated-by \001 --hive-delims-replacement , --split-by vid  --target-dir /olap/db/video/ -m 1

- a、首次需要创建hive表，

    ```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS video(
        id int COMMENT '视频ID自增',
        title string COMMENT '视频标题',
        pic string COMMENT '图片',
        ald_pic string,
        hits_total int  COMMENT '总播放量',
        hits_week   int COMMENT '周播放量',
        hits_month  int COMMENT '月播放量',
        good_total  int COMMENT '总点赞',
        good_week   int COMMENT '周点赞',
        good_month  int COMMENT '月点赞',
        recommend   int COMMENT '推荐星级',
        definition  int COMMENT '清晰度',
        coderate    string  COMMENT '码率',
        videourl    string  COMMENT '视频地址',
        duration    int COMMENT '时长',
        speed   int COMMENT '速度:1慢 2中 3快',
        degree  int COMMENT '难度: 1简单 2适中 3稍难',
        teach   int COMMENT '1教学 2表演',
        beach   int COMMENT '步数：1-16步 2-32步 3-64步',
        best    int COMMENT '优质视频',
        type    int COMMENT '视频类型 1：CC上传  11：56上传  7：CC复制  8:秀舞',
        vid bigint  COMMENT 'PC端视频ID', -- 注意vid可能超过int
        search  string  COMMENT '标题全文索引',
        siteid  string  COMMENT '',
        sitekey string  COMMENT '',
        is_special  int COMMENT '',
        createtime  string  COMMENT '创建时间',
        uptime  string  COMMENT '更新时间',
        share   int COMMENT '分享次数',
        mp3url  string  COMMENT 'mp3',
        user_hits   int COMMENT '播放人数',
        user_share  int COMMENT '分享人数',
        pc_uid  int COMMENT '',
        uid int COMMENT '移动端用户id',
        status  int COMMENT '0正常 1处理中 2审核中 5删除',
        tag string  COMMENT '',
        parent_category int COMMENT '大分类',
        child_category  int COMMENT '小分类',
        genre   int COMMENT '曲风',
        hobby   int COMMENT '学舞兴趣推荐',
        sync    int COMMENT '是否同步到云',
        comment_total   int COMMENT '评论数量'
    )
    COMMENT '视频字典表'
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY '\001'
    STORED AS TEXTFILE
    LOCATION '/olap/db/video/';
    ```

- b、后续导入hive表所在的hdfs，直接在语句中写死delete-target-dir，不在使用hue中prepare delete dir，以防误删灾难。

    ```shell 
    import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table video --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/video/ -m 1 
    ```

## 二、 playlist_recommen表

>- 原导入语句，直接导入hdfs
- import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table playlist_recommend --fields-terminated-by \001 --hive-delims-replacement ,  --delete-target-dir --target-dir /user/hadoop/db/playlist_recommend/ -m 1 

- a、首次需要创建hive表 

    ```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS playlist_recommend
    (
    id int COMMENT'ID主键自增',
    type int COMMENT'1热门舞曲 2 最新舞曲 3 热门舞队 4搜索排行 5推荐舞曲  6推荐达人',
    pid int COMMENT'专辑ID',
    keyword string COMMENT'关键词（舞曲or舞队）',
    position int COMMENT'位置',
    pic string COMMENT'图片'
    )
    COMMENT'推荐专辑字典表'
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY'\001'
    STORED AS TEXTFILE
    LOCATION '/olap/db/playlist_recommend/';
    ```

- b、后续导入hive表所在的hdfs，直接在语句中写死delete-target-dir，不在使用hue中prepare delete dir，以防误删灾难。

    ```shell 
    import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table playlist_recommend --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/playlist_recommend/ -m 1 
    ```

## 三、 playlist表

> - import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table playlist --fields-terminated-by \001 --hive-delims-replacement , --target-dir /olap/db/playlist/ -m 1 

- a、首次需要创建hive表
    
    ```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS playlist
    (
    id int COMMENT'专辑ID主键自增',
    master_uid int COMMENT'达人UID',
    title string COMMENT'专辑名称',
    charclass string COMMENT'专辑首字母',
    uid int COMMENT'专辑作者ID',
    uname string COMMENT'专辑作者用户名',
    type int COMMENT'舞曲1舞队2',
    keyword string COMMENT'关键字',
    pid int COMMENT'PC专辑ID',
    top int COMMENT'权重',
    info string COMMENT'关键词全文索引',
    pic string COMMENT'',
    groupid int COMMENT'达人级别1达人2超级达人',
    video_num int COMMENT'专辑视频数量',
    userid int COMMENT'移动端达人UID',
    username string COMMENT'移动端达人昵称',
    is_prompt int COMMENT'是否搜索提示0提示1不提示',
    level int COMMENT'达人等级'
    )
    COMMENT'专辑字典表'
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY'\001'
    STORED AS TEXTFILE
    LOCATION '/olap/db/playlist/';
    ```

- b、后续导入hive表所在的hdfs，直接在语句中写死delete-target-dir，不在使用hue中prepare delete dir，以防误删灾难。

    ```shell 
    import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table playlist  --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir --target-dir /olap/db/playlist/ -m 1 
    ```


## 四、user表 

>- import --connect jdbc:mysql://10.10.43.15:3306/tduser?tinyInt1isBit=false --username root --password tangdouapp#123 --table user --fields-terminated-by \001 --hive-delims-replacement ,  --target-dir /olap/db/user/ -m 1

- a、首次需要创建hive表

    ```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS user (
    id int COMMENT '主键自增',
    name STRING  COMMENT '昵称',
    avatar STRING  COMMENT '头像',
    client tinyint   COMMENT '设备：1、ios，2、android',
    regtime STRING  COMMENT '注册时间',
    regip STRING  COMMENT '注册ip',
    loginip STRING  COMMENT '最后登录IP',
    version STRING  COMMENT '该用户使用的版本号',
    type tinyint   COMMENT '账号类型：1微信，2QQ，3手机',
    account STRING  COMMENT '账号唯一标识：微信Openid，QQid，手机号',
    pwd STRING  COMMENT '手机用户密码',
    token STRING  COMMENT '验证串',
    mobile STRING,
    sign int  COMMENT '签到次数',
    signdate STRING  COMMENT '最后签到日期',
    iskill tinyint  COMMENT '用户是否被封禁',
    groupid int  COMMENT '0普通用户组，1达人组',
    uuid STRING ,
    channel STRING ,
    province STRING  COMMENT '省份',
    city STRING  COMMENT '城市',
    lon STRING  COMMENT '经度',
    lat STRING  COMMENT '纬度',
    signature STRING  COMMENT '个性签名',
    level tinyint  COMMENT '级别',
    xinge STRING  COMMENT '信鸽token',
    device STRING  COMMENT '机型',
    dance_role tinyint  COMMENT '我的角色 1领队 2队员 3未入队 0未选择',
    dance_level tinyint  COMMENT '舞蹈水平 1初级 2熟练',
    age_range tinyint  COMMENT '我的年龄 1小于30岁 2 30-55岁 3 大于55岁',
    last_upSTRING STRING  COMMENT '最后一次更新信息时间',
    birthdate int  COMMENT '用户录入生日',
    diu STRING  COMMENT '用户设备号',
    diu2 STRING  COMMENT '广告ID',
    diu3 STRING  COMMENT 'GUID',
    gender tinyint  COMMENT '性别',
    idcard int  COMMENT '身份证号码',
    category_id STRING COMMENT '兴趣大分类id，多个用逗号分割',
    space_pic STRING  COMMENT '空间背景'
    )
    COMMENT'用户字典表'
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY'\001'
    STORED AS TEXTFILE
    LOCATION '/olap/db/user/';
    ```

- b、后续导入hive表所在的hdfs，直接在语句中写死delete-target-dir，不在使用hue中prepare delete dir，以防误删灾难。

    ```shell 
    import --connect jdbc:mysql://10.10.43.15:3306/tduser?tinyInt1isBit=false --username root --password tangdouapp#123 --table user --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir  --target-dir /olap/db/user/ -m 1
    ```

## 五、follow_user表

>- import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table follow_user --fields-terminated-by \001 --hive-delims-replacement ,  --append --target-dir /olap/db/follow_user/ -m 1 

- a、首次需要创建hive表

    ```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS follow_user
    (
    id int COMMENT '主键自增',
    uid int COMMENT '观注用户',
    reuid int COMMENT '被观注用户',
    time string COMMENT '观注时间'
    )
    COMMENT'用户关注字典表'
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY'\001'
    STORED AS TEXTFILE
    LOCATION '/olap/db/follow_user/';
    ```

- b、后续导入hive表所在的hdfs，直接在语句中写死delete-target-dir，不在使用hue中prepare delete dir，以防误删灾难。

    ```shell 
    import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table follow_user --fields-terminated-by \001 --hive-delims-replacement ,  --delete-target-dir  --target-dir /olap/db/follow_user/ -m 1 
    ```

## 六、comment表

>- import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table comment --fields-terminated-by \001 --hive-delims-replacement ,   --target-dir /user/hadoop/db/comment/  --append -m 1

- a、首次需要创建hive表

    ```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS comment(
      id int COMMENT 'ID自增',
      uid int  COMMENT '评论用户ID',
      content string COMMENT '评论的内容',
      time string COMMENT '评论的时间',
      vid int COMMENT '内容ID',
      reply string COMMENT '回复内容(已弃用)',
      retime string COMMENT '回复时间',
      up int COMMENT '置顶',
      reuid int COMMENT '回复id',
      hot int COMMENT '热度',
      praise INT COMMENT '总赞数',
      upid int COMMENT '评论id',
      recontent string COMMENT '引用内容',
      is_ad int COMMENT '是否广告 1 是 0 否'
    )
    COMMENT '评论字典表'
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY '\001'
    STORED AS TEXTFILE
    LOCATION '/olap/db/comment/';
    ```
- b、后续导入hive表所在的hdfs，直接在语句中写死delete-target-dir，不在使用hue中prepare delete dir，以防误删灾难。

```shell 
import --connect jdbc:mysql://10.10.120.205:3306/tangdouapp?tinyInt1isBit=false --username root --password tangdouapp#123 --table comment --fields-terminated-by \001 --hive-delims-replacement , --delete-target-dir  --target-dir /olap/db/comment/ -m 1
```

