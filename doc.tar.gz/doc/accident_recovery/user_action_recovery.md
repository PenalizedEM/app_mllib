# user_action 相关业务恢复

## 1. 恢复user_action表

```sql 
    use dw;
    CREATE EXTERNAL TABLE IF NOT EXISTS user_action(
        u_timestamp TIMESTAMP COMMENT '东八区时间',
        u_backtime FLOAT COMMENT 'php层响应时间',
        u_responsetime FLOAT COMMENT '完整服务响应时间',
        u_host STRING COMMENT '服务器内网ip',
        u_xff STRING COMMENT '客户端ip',
        u_status STRING COMMENT 'http状态',
        u_size INT COMMENT 'http返回大小',
        u_div STRING COMMENT '客户端版本号,用于标志客户端产品的不同软件版本',
        u_dic STRING COMMENT '客户端渠道代码',
        u_diu STRING COMMENT '设备唯一号,android--imei, ios--IDFV',
        u_diu2 STRING COMMENT '广告ID,android--mac, ios--IDFA',
        u_diu3 STRING COMMENT 'GUID,android--guid, ios--guid',
        u_uid STRING COMMENT '注册用户id',
        u_startid STRING COMMENT '启动标识号(距离2016年1月1号0点0分0秒这时刻有多少秒）',
        u_stepid INT COMMENT '客户端的操作步骤',
        u_time STRING COMMENT '客户端时间戳',
        u_mod STRING COMMENT '服务端接口模块',
        u_ac STRING COMMENT '服务端具体接口',
        u_client STRING COMMENT '客户端类型',
        u_ver STRING COMMENT '服务端版本',
        u_uuid STRING COMMENT '用户设备号(md5)',
        u_hash STRING COMMENT '加密验证串',
        u_xinge STRING COMMENT '信鸽token',
        u_token STRING COMMENT '用户单点登录token',
        u_agent STRING COMMENT '客户端agent',
        u_method STRING COMMENT 'http方法',
        u_new_activity STRING COMMENT '跳转到页面名称(当前页)',
        u_old_activity STRING COMMENT '跳转过来页面名称',
        u_key STRING COMMENT '搜索关键词',
        u_client_module STRING COMMENT '用户客户端搜索模块',
        u_source STRING COMMENT '用户搜索调用的接口',
        u_page INT COMMENT '用户点击第几页的搜索结果',
        u_position INT COMMENT '用户点击第几条的搜索结果',
        u_vid STRING COMMENT '视频的id',
        u_type STRING COMMENT '搜索排序类型',
        u_percent INT COMMENT '页面停留时间/视频播放时间',
        u_rate INT COMMENT '视频播放进度（百分比)',
        u_user_role STRING COMMENT '用户在舞队内的角色',
        u_isnew_user STRING COMMENT '当天注册为新用户',
        u_isdownload STRING COMMENT '是否点击了播放页的下载按钮',
        u_isonline STRING COMMENT '是否在线播放',
        u_buffertime FLOAT COMMENT '进入播放页到视频开始播放的时间',
        u_action STRING COMMENT '操作播放器行为',
        u_ishigh STRING COMMENT '是否高清视频',
        u_cdn_source STRING COMMENT 'cdn名称',
        u_download_start TIMESTAMP COMMENT '下载开始',
        u_download_stop TIMESTAMP COMMENT '下载结束',
        u_fail_cdn_source STRING COMMENT '失败cdn源',
        u_new_cdn_source STRING COMMENT '切换cdn源',
        u_width INT COMMENT '屏幕尺寸——宽',
        u_height INT COMMENT '屏幕尺寸——高',
        u_lon STRING COMMENT '用户位置——经度',
        u_lat STRING COMMENT '用户位置——纬度',
        u_province STRING COMMENT '用户省份',
        u_city STRING COMMENT '用户城市',
        u_netop STRING COMMENT '网络运营商',
        u_nettype STRING COMMENT '网络类型',
        u_sdkversion STRING COMMENT 'android 系统版本号',
        u_model STRING COMMENT 'ios:固件版本, android:手机模型',
        u_device STRING COMMENT 'ios:设备型号, android:设备',
        u_manufacture STRING COMMENT '厂商',
        u_reverse0 STRING COMMENT '保留字段',
        u_reverse1 STRING COMMENT '保留字段',
        u_reverse2 STRING COMMENT '保留字段',
        u_reverse3 STRING COMMENT '保留字段',
        u_reverse4 STRING COMMENT '保留字段',
        u_reverse5 STRING COMMENT '保留字段',
        u_reverse6 STRING COMMENT '保留字段',
        u_reverse7 STRING COMMENT '保留字段',
        u_reverse8 STRING COMMENT '保留字段',
        u_reverse9 STRING COMMENT '保留字段',
        u_bigger_json STRING COMMENT '最后的大json'
    )
    COMMENT '糖豆用户行为表'
    PARTITIONED BY(dt STRING)
    ROW FORMAT DELIMITED
    FIELDS TERMINATED BY '\001'
    STORED AS TEXTFILE
    LOCATION '/olap/dw/ua/';
```

## 2、添加历史分区

```sql 
    alter table dw.user_action drop if EXISTS partition(dt='2016-09-20') ;
    alter table dw.user_action add if not EXISTS 
    partition(dt='2016-09-19') LOCATION '/olap/dw/ua/2016-09-19'
    partition(dt='2016-09-18') LOCATION '/olap/dw/ua/2016-09-18'
    partition(dt='2016-09-17') LOCATION '/olap/dw/ua/2016-09-17'
    partition(dt='2016-09-16') LOCATION '/olap/dw/ua/2016-09-16'
    partition(dt='2016-09-15') LOCATION '/olap/dw/ua/2016-09-15'
    partition(dt='2016-09-14') LOCATION '/olap/dw/ua/2016-09-14'
    partition(dt='2016-09-13') LOCATION '/olap/dw/ua/2016-09-13'
    partition(dt='2016-09-12') LOCATION '/olap/dw/ua/2016-09-12'
    partition(dt='2016-09-11') LOCATION '/olap/dw/ua/2016-09-11'
    partition(dt='2016-09-10') LOCATION '/olap/dw/ua/2016-09-10'
    partition(dt='2016-09-09') LOCATION '/olap/dw/ua/2016-09-09'
    partition(dt='2016-09-08') LOCATION '/olap/dw/ua/2016-09-08'
    partition(dt='2016-09-07') LOCATION '/olap/dw/ua/2016-09-07'
    partition(dt='2016-09-06') LOCATION '/olap/dw/ua/2016-09-06'
    partition(dt='2016-09-05') LOCATION '/olap/dw/ua/2016-09-05'
    partition(dt='2016-09-04') LOCATION '/olap/dw/ua/2016-09-04'
    partition(dt='2016-09-03') LOCATION '/olap/dw/ua/2016-09-03'
    ;
```


## 3、验证数据-查看最近几天DAU量级

```sql 
    select dt, count(distinct u_diu) dau from dw.user_action group by dt;
```

