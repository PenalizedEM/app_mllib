# 搜索大搜提示恢复

## 0、关键词累计搜索次数恢复

- 从db同步 search_sug 到/olap/da/search_top_keywords/dt=2016-09-21

```shell
sqoop import --connect jdbc:mysql://10.10.243.51:3306/search --username root --password tangdouapp#123 --query 'SELECT '2016-09-21',keyword,pv FROM  search_sug WHERE \$CONDITIONS '  --fields-terminated-by '\001' --hive-delims-replacement ','  --target-dir /olap/da/search_top_keywords/dt=2016-09-21  -m 1
``` 

## 1、大搜提示search_sug建表

```sql
use da;
drop table search_top_keywords;
CREATE EXTERNAL TABLE IF NOT EXISTS search_top_keywords(
d_datebufer STRING  COMMENT '最新一次出现的业务日期',
d_keyword  STRING  COMMENT '搜索关键词',
m_pv  int  COMMENT '累计搜索次数'
)
COMMENT '搜索-框搜—关键词'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/search_top_keywords/';

-- 添加元分区2016-09-21 
alter table da.search_top_keywords add if not EXISTS partition(dt='2016-09-21') LOCATION '/olap/da/search_top_keywords/dt=2016-09-21'

INSERT OVERWRITE table da.search_top_keywords partition(dt='${datebuf}') 
select 
if(b.dt is null, a.dt,b.dt) d_datebuf,
if(a.d_keyword is null, b.u_key, a.d_keyword) d_keyword,
case when a.m_pv is null and b.pv is not null then b.pv 
when a.m_pv is not null and b.pv is null then a.m_pv 
when a.m_pv is not null and b.pv is not null then a.m_pv+b.pv
else 0 
end as m_pv
from 
(
select * from da.search_top_keywords where dt='${datebuf_before}' 
) a  
full outer join 
(
select 
dt,
u_key, 
count(1) pv 
from dw.user_action 
where dt='${datebuf}' 
and concat(u_mod,'-',u_ac)='emptylog-search_onclick' 
and u_client_module='top' 
group by 
dt,
u_key 
) b 
on(a.d_keyword=b.u_key)
order by m_pv desc 
;

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS search_sug
(
keyword string COMMENT '专辑/空间关键词',
type string COMMENT '1舞曲，0搜索词',
pv int COMMENT 'pv'
)
COMMENT'视频提示-搜索用'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/da/search_sug/';

insert overwrite table da.search_sug
select
if(m.d_keyword is NULL,n.keyword,m.d_keyword) key ,
nvl(type,0) song ,
nvl(m.m_pv,0) pv
from
(select
d_keyword,m_pv
from da.search_top_keywords
where
dt='${datebuf}'
and m_pv>100
-- and d_keyword rlike '^[\\w-一()（）《》，,：:。·\\s\\.\\u4E00-\\u9FA5]{1,255}$'
)m
full outer join
(
select
keyword,type
from dw.playlist
where type=1
and is_prompt=0
and keyword<>'' and keyword is not null
-- and keyword rlike '^[\\w-一()（）《》，,：:。·\\s\\.\\u4E00-\\u9FA5]{1,255}$'
group by
keyword,type
) n
on m.d_keyword = n.keyword
;
```

## 2、Mysql search_sug建表

```sql
CREATE TABLE `search_sug` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID主键自增',
 `keyword` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '专辑/空间关键词',
 `type` int(11) DEFAULT NULL COMMENT '1舞曲,0关键词',
 `pv` int(11) DEFAULT NULL COMMENT 'pv',
 PRIMARY KEY (`id`),
 UNIQUE KEY `keyword` (`keyword`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4
```

## 3、Sqoop同步语句

```shell
export --connect jdbc:mysql://10.10.243.51:3306/search --username root --password tangdouapp#123 --table search_sug --columns id,keyword,type,pv --update-key keyword --update-mode allowinsert --export-dir /olap/da/search_sug/ --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N  -m 1
```

## 4、搜索测试服务器定时同步到es

```shell
ssh data@10.19.126.209 -p 12306 
38 11 * * * cd /data/newsugsync/ && java -jar geosearch.jar >> allsug.log 2>&1 
```

