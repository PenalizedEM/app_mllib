# 老集群数据恢复与迁移

> ## 误删数据的物理恢复
> 目前物理磁盘恢复操作做完了，最高的恢复到17%，平均在10%左右，数据在每个机器挂载的对应的
>  /data*back/dfs_back 下面，其中core12前2个盘数据在 挂载的 /data1recover 下
> 
> ## 剩余有价值HDFS数据的迁移
> - 注意hadoop防火墙要开启8020端口
> `distcp <srcurl> <desturl>`
> 

## 老集群uelrcx hosts列表

```shell

10.10.118.78    uhadoop-uelrcx-core1        
10.10.144.44    uhadoop-uelrcx-core2        
10.10.120.42    uhadoop-uelrcx-core3        
10.10.115.142   uhadoop-uelrcx-core4        
10.10.124.242   uhadoop-uelrcx-core5        
10.10.115.38    uhadoop-uelrcx-core6        
10.10.222.161   uhadoop-uelrcx-core10       
10.10.235.69    uhadoop-uelrcx-core11       
10.10.235.234   uhadoop-uelrcx-core12       
10.10.238.15    uhadoop-uelrcx-core9        
10.10.126.2 uhadoop-uelrcx-master1  外网ip    123.59.87.5
10.10.126.74    uhadoop-uelrcx-master2      

```



## 剩余有价值老集群HDFS数据的迁移

#### uelrcx集群HDFS文件向jhr2pf集群转移

```shell

# uelrcx集群文件分布

hadoop fs -du -h hdfs://123.59.87.5:8020/

# /user
# 135.6 G  406.8 G  hdfs://123.59.87.5:8020/user/hive
# 269.2 G  807.7 G  hdfs://123.59.87.5:8020/user/data
#2.7 G    8.0 G    hdfs://123.59.87.5:8020/user/hadoop

# 269.2 G  807.7 G  hdfs://123.59.87.5:8020/user/data/
hadoop distcp -m 50 -i -update  hdfs://uhadoop-uelrcx-master1:8020/user/data/logstash/ hdfs://10.10.171.218:8020/old/user/data/logstash/ 

# 135.6 G  406.8 G  hdfs://123.59.87.5:8020/user/hive/
hadoop distcp -m 50 -i -update  hdfs://uhadoop-uelrcx-master1:8020/user/hive/warehouse/da.db/ hdfs://10.10.171.218:8020/old/hive/warehouse/da.db

# 2.7 G    8.0 G    hdfs://123.59.87.5:8020/user/hadoop
hadoop distcp -m 50 -i -update  hdfs://uhadoop-uelrcx-master1:8020/user/hadoop/ hdfs://10.10.171.218:8020/old/user/hadoop/



```

## 恢复数据copy

### ucloud技术支持给的迁移shell

```shell

#!/bin/env bash
for i in {1..10}
do
  host="hadoop-uelrcx-core"$i
  echo "Now copying data from: "$host
  for j in {1..4}
  do
    if [ $j = 1 ];then
      cmd_hadoop_mkdir=$(echo "ssh root@"$host" hadoop fs -mkdir -p" "/backupdata/core"$i"/data")
      dir_source="/data/dfs_bak"
      dir_backup=$(echo "/backupdata/core"$i"/data")
    else
      let j=$j-1
      cmd_hadoop_mkdir=$(echo "ssh root@"$host" hadoop fs -mkdir -p" "/backupdata/core"$i"/data"$j)
      dir_source="/data"$j"/dfs_bak"
      dir_backup=$(echo "/backupdata/core"$i"/data"$j)
    fi
  echo -e 'mkdir command is:\t'$cmd_hadoop_mkdir
  cmd_hadoop_put="ssh root@"$host" hadoop fs -put $dir_source $dir_backup"
  echo -e 'copy command is:\t'$cmd_hadoop_put
  done
  echo "    "
  echo "    "
done

```


### 实际物理恢复文件的位置

>实际物理恢复的文件，需要每台机器单独验证

恢复的数据文件路径举例：

```shell 

/data*back/dfs_back/dn/current/BP-450393600-10.10.126.2-1461727771130/current/finalized/subdir12/subdir0/blk_xxx

```

