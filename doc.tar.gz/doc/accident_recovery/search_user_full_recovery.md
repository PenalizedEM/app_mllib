# 搜索用户搜索同步恢复

## 1、用户搜索数据表user_full

```sql

use da;
CREATE EXTERNAL TABLE IF NOT EXISTS user_full
(
id string COMMENT 'userid',
keyword string COMMENT '专辑/空间关键词',
name string COMMENT '用户昵称',
avatar string COMMENT '用户头像',
regtime string COMMENT '注册时间',
fan int COMMENT '粉丝个数',
level int COMMENT '级别'
)
COMMENT'用户表-搜索用'
ROW FORMAT DELIMITED
FIELDS TERMINATED BY'\001'
STORED AS TEXTFILE
LOCATION '/olap/da/user_full/';

insert overwrite table da.user_full
select
n.id,
m.keyword,
n.name,
avatar,
regtime,
nvl(q.fans_cnt,0) fan,
level
from
(SELECT id,name,avatar,regtime,level FROM dw.user) n
left outer join
(SELECT userid,keyword FROM dw.playlist WHERE type=2 and userid<>0 group by userid, keyword) m
on n.id=m.userid
left outer join
(select reuid,count(1) fans_cnt from dw.follow_user group by reuid) q
on n.id=q.reuid
;

```


## 2、Mysql user_full 建表语句

```sql
CREATE TABLE `user_full` (
  `id` int(10) NOT NULL  COMMENT 'userid',
  `keyword` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '专辑/空间关键词',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户昵称',
  `avatar` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '用户头像',
  `regtime` datetime DEFAULT NULL COMMENT '注册时间',
  `fan` int(11) DEFAULT NULL COMMENT '粉丝个数',
  `level` int(5) DEFAULT NULL COMMENT '级别',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

## 3、Sqoop 同步语句

```shell
export --connect jdbc:mysql://10.10.243.51:3306/search --username root --password tangdouapp#123 --table user_full --update-key id --update-mode allowinsert --export-dir /olap/da/user_full/ --input-fields-terminated-by \001 --input-null-string \\N --input-null-non-string \\N  -m 10

```

## 4、搜索测试服务器每隔12小时同步到es

```shell
ssh data@10.19.126.209 -p 12306 
* */12  * * * cd /home/data/jdbces/userinsh/ && ./tse-online-user-full.sh >> inuser.log 2>&1
```
