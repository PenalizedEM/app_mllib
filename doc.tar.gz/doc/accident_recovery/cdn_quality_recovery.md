# CDN质量日报监控

## 1、视频下载错误率

```sql

-- 视频下载错误率
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS vdq_cdn_errate(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_error_uv  int  COMMENT '下载错误人数',
m_error_pv  int  COMMENT '下载错误次数',
m_down_uv  int  COMMENT '总下载人数',
m_down_pv  int  COMMENT '总下载次数',
m_errate_uv float COMMENT '下载错误率（uv）'
)
COMMENT '视频下载质量——不同cdn下载错误率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vdq_cdn_errate/';

-- 以下注释不能放文件头，否则在hue中执行会因为hivejob名过长而直接跳过，返回执行成功。
-- 视频错误下载评估接口 在安卓v4.6.2以上版本有（2016-06-29）
-- 下载失败由于有重试机制，pv量会爆多于下载次数
-- 视频下载评估接口添加cdn源埋点——在安卓v4.7.1以上版本有（2016-07-14）

-- 安卓v4.7.1以上版本各CDN源视频下载错误率
insert overwrite table da.vdq_cdn_errate partition (dt='${datebuf}')
select
dt,
u_cdn_source,
download_fail_uv,
download_fail_pv,
download_uv,
download_pv,
download_fail_uv/if(download_uv=0,1,download_uv)
from
(
select
dt,
u_cdn_source,
sum(if(ac='emptylog-download_fail',1,0)) download_fail_uv,
sum(if(ac='emptylog-download_fail',pv,0)) download_fail_pv,
sum(if(ac='emptylog-download_onclick',1,0)) download_uv,
sum(if(ac='emptylog-download_onclick',pv,0)) download_pv
from
(
select
dt,
u_cdn_source,
concat(u_mod,'-',u_ac) ac,
u_diu,
count(1) pv
from dw.user_action
where dt='${datebuf}'
and u_cdn_source in ('cc','ucloud','upyun') -- 过滤异常cdn source
and concat(u_mod,'-',u_ac) in ('emptylog-download_fail','emptylog-download_onclick')
and u_div is not null and u_div<>''
and u_client=2
and substr(u_div,0,5)>='4.7.1'
group by
dt,
u_cdn_source,
concat(u_mod,'-',u_ac),
u_diu
) a
group by
dt,
u_cdn_source
) b ;

-- 视频下载错误率
CREATE EXTERNAL TABLE IF NOT EXISTS vdq_errate(
d_datebufer STRING  COMMENT '业务日期',
m_error_uv  int  COMMENT '下载错误人数',
m_error_pv  int  COMMENT '下载错误次数',
m_down_uv  int  COMMENT '总下载人数',
m_down_pv  int  COMMENT '总下载次数',
m_errate_uv float COMMENT '下载错误率（uv）'
)
COMMENT '视频下载质量——整体下载错误率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vdq_errate/';

-- 安卓v4.6.2以上版本视频下载错误率
insert overwrite table da.vdq_errate partition (dt='${datebuf}')
select
dt,
download_fail_uv,
download_fail_pv,
download_uv,
download_pv,
download_fail_uv/download_uv
from
(
select
dt,
sum(if(ac='emptylog-download_fail',1,0)) download_fail_uv,
sum(if(ac='emptylog-download_fail',pv,0)) download_fail_pv,
sum(if(ac='video-count_video',1,0)) download_uv,
sum(if(ac='video-count_video',pv,0)) download_pv
from
(
select
dt,
concat(u_mod,'-',u_ac) ac,
u_diu,
count(1) pv
from dw.user_action
where dt>='${datebuf}'
and concat(u_mod,'-',u_ac) in ('emptylog-download_fail','video-count_video')
and u_div is not null and u_div<>''
and u_client=2
and substr(u_div,0,5)>='4.6.2'
group by
dt,
concat(u_mod,'-',u_ac),
u_diu
) a
group by
dt
) b ;

```

## 2、视频播放质量

```sql
-- 安卓>=V4.6.8 top-hits(APP内视频播放量)接口添加u_cdn_source
-- 安卓>=V4.8.2 emptylog-video_buffer接口 (由于卡顿p可能远大于播放pv,统计播放卡顿比(uv))
-- 首播时间分布
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_quantile(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_min  float  COMMENT '最小值',
m_first_quartile  float  COMMENT '四分一分位数',
m_median  float  COMMENT '中位数',
m_lower_quartile  float  COMMENT '四分之三分位数',
m_avg float COMMENT '均值',
m_max float COMMENT '最大值',
m_var float COMMENT '方差',
m_ninety float COMMENT '90分位数',
m_ninetyfive float COMMENT '95分位数',
m_ninetynine float COMMENT '99分位数'
)
COMMENT '视频播放质量——首播时间分布'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_quantile/';

insert overwrite table da.vpq_quantile partition (dt='${datebuf}')
select
dt,
u_cdn_source,
min(u_buffertime)/1000 min_bt,
percentile(cast(u_buffertime as bigint),0.25)/1000 quater_bt,
percentile(cast(u_buffertime as bigint),0.5)/1000 median_bt,
percentile(cast(u_buffertime as bigint),0.75)/1000 threequater_bt,
avg(u_buffertime)/1000 avg_bt,
max(u_buffertime)/1000 max_bt,
variance(u_buffertime)/1000 var_bt,
percentile(cast(u_buffertime as bigint),0.90)/1000 threequater_bt,
percentile(cast(u_buffertime as bigint),0.95)/1000 threequater_bt,
percentile(cast(u_buffertime as bigint),0.99)/1000 threequater_bt
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_buffertime is not null and u_buffertime>0
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.5.7'
and u_client=2
group by
dt, u_cdn_source
;

-- 首播时间区间分布
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_interval(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_0to5s  int  COMMENT '0~5秒',
m_5to10s  int  COMMENT '5~10秒',
m_10to15s  int  COMMENT '10~15秒',
m_15to20s  int  COMMENT '15~20秒',
m_20to30s int COMMENT '20~30秒',
m_30to40s int COMMENT '30~40秒',
m_40to50s int COMMENT '40~50秒',
m_50to80s int COMMENT '50~80秒',
m_80to100s int COMMENT '80~100秒',
m_100to200s int COMMENT '100~200秒',
m_gt200s int COMMENT '200秒',
m_pv int COMMENT '总播放次数'
)
COMMENT '视频播放质量——首播时间区间分布'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_interval/';

insert overwrite table vpq_interval partition (dt='${datebuf}')
select
dt,
u_cdn_source,
sum(if(u_buffertime<5000,pv,0)) as 0to5s,
sum(if(u_buffertime>=5000 and u_buffertime<10000,pv,0)) as 5to10s,
sum(if(u_buffertime>=10000 and u_buffertime<15000,pv,0)) as 10to15s,
sum(if(u_buffertime>=15000 and u_buffertime<20000,pv,0)) as 15to20s,
sum(if(u_buffertime>=20000 and u_buffertime<30000,pv,0)) as 20to30s,
sum(if(u_buffertime>=30000 and u_buffertime<40000,pv,0)) as 30to40s,
sum(if(u_buffertime>=40000 and u_buffertime<50000,pv,0)) as 40to50s,
sum(if(u_buffertime>=50000 and u_buffertime<80000,pv,0)) as 50to80s,
sum(if(u_buffertime>=80000 and u_buffertime<100000,pv,0)) as 80to100s,
sum(if(u_buffertime>=100000 and u_buffertime<200000,pv,0)) as 100to200s,
sum(if(u_buffertime>=200000,pv,0)) as gt200s,
sum(pv) pv
from
(
select
dt, u_cdn_source,u_buffertime, count(1) pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_buffertime is not null and u_buffertime>0
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.5.7'
and u_client=2
group by
dt, u_cdn_source,u_buffertime
) a
group by
dt,
u_cdn_source
;

-- 播放错误率
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_errate(
d_datebufer STRING  COMMENT '业务日期',
d_cdn_source  STRING  COMMENT 'CDN源',
m_error_uv  int  COMMENT '播放错误人数',
m_error_pv  int  COMMENT '播放次数',
m_play_uv  int  COMMENT '总播放人数',
m_play_pv  int  COMMENT '总播放次数',
m_errate_uv float COMMENT '播放错误率（uv）',
m_errate_pv float COMMENT '播放错误率（pv）'
)
COMMENT '视频播放质量——播放错误率'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_errate/';

insert overwrite table da.vpq_errate partition (dt='${datebuf}')
select
c.dt,
c.u_cdn_source,
error_uv,
error_pv,
play_uv,
play_pv,
error_uv/play_uv errate_uv,
error_pv/play_pv errate_pv
from
(
select
dt,
u_cdn_source,
count(1) error_uv,
sum(pv) error_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='play_error'
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.5.7'
and u_client=2
group by
dt, u_cdn_source , u_diu
) a
group by
dt,
u_cdn_source
) c
join
(
select
dt,
u_cdn_source,
count(1) play_uv,
sum(pv) play_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.5.7'
and u_client=2
group by
dt, u_cdn_source , u_diu
) b
group by
dt,
u_cdn_source
) d
on (c.dt=d.dt and c.u_cdn_source=d.u_cdn_source)
;

-- 视频播放卡顿率
insert overwrite table da.vpq_lagrate partition (dt='${datebuf}')
select
c.dt,
c.u_cdn_source,
lag_uv,
lag_pv,
play_uv,
play_pv,
lag_uv/play_uv lagrate_uv,
lag_pv/play_pv lagrate_pv
from
(
select
dt,
u_cdn_source,
count(1) lag_uv,
sum(pv) lag_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_buffer'
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.8.2'
and u_client=2
group by
dt, u_cdn_source , u_diu
) a
group by
dt,
u_cdn_source
) c
join
(
select
dt,
u_cdn_source,
count(1) play_uv,
sum(pv) play_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
-- and u_mod='top'and u_ac='hits'
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.8.2'
and u_client=2
group by
dt, u_cdn_source , u_diu
) b
group by
dt,
u_cdn_source
) d
on (c.dt=d.dt and c.u_cdn_source=d.u_cdn_source)
;


-- 视频播放失败切换CDN源统计
use da;
CREATE EXTERNAL TABLE IF NOT EXISTS vpq_switch(
d_datebufer STRING  COMMENT '业务日期',
d_fail_cdn_source  STRING  COMMENT '播放失败的CDN源',
 m_switch_uv  int  COMMENT '切换cdn源人数',
 m_switch_pv  int  COMMENT '切换cdn源次数',
 m_play_uv  int  COMMENT '总播放人数',
 m_play_pv  int  COMMENT '总播放次数',
 m_swrate_uv float COMMENT '切换率（uv）',
 m_swrate_pv float COMMENT '切换率（pv）'
)
COMMENT '视频播放质量——播放失败切源统计'
PARTITIONED BY(dt STRING)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY '\001'
STORED AS TEXTFILE
LOCATION '/olap/da/vpq_switch/';

insert overwrite table da.vpq_switch partition (dt='${datebuf}')
select
c.dt,
c.u_fail_cdn_source,
switch_uv,
switch_pv,
play_uv,
play_pv,
switch_uv/play_uv switchrate_uv,
switch_pv/play_pv switchrate_pv
from
(
select
dt,
u_fail_cdn_source,
count(distinct u_diu) switch_uv,
count(1) switch_pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='cdn_switch'
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.5.7'
and u_client=2
group by
dt,
u_fail_cdn_source
) c
right outer join
(
select
dt,
u_cdn_source,
count(1) play_uv,
sum(pv) play_pv
from
(
select dt, u_cdn_source, u_diu, count(1) pv
from dw.user_action
where dt>='${datebuf}' and dt<='${datebuf}'
and u_mod='emptylog'and u_ac='video_play_speed'
and u_div<>'' and u_div is not null
and substr(u_div,0,5)>='4.5.7'
and u_client=2
group by
dt, u_cdn_source , u_diu
) b
group by
dt,
u_cdn_source
) d
on (c.dt=d.dt and c.u_fail_cdn_source=d.u_cdn_source)
where c.u_fail_cdn_source is not null
;

dfs -touchz /olap/da/vpq_switch/dt=${datebuf}/_SUCCESS;

```

## 3、9月1日~9月21日数据恢复

>根据邮件中已发送的历史数据，将9月1日~21日的数据汇总入9月1日的分区。

```sql
-- 一：视频播放错误率：

LOAD DATA INPATH '/temp/vpq_errate_0901.txt'
OVERWRITE INTO TABLE da.vpq_errate partition (dt='2016-09-01');

-- 二：视频播放切源率：
LOAD DATA INPATH '/temp/vpq_switch_0901.txt'
OVERWRITE INTO TABLE da.vpq_switch partition (dt='2016-09-01');

-- 三：首播时间区间分布：
LOAD DATA INPATH '/temp/vpq_interval_0901.txt'
OVERWRITE INTO TABLE da.vpq_interval partition (dt='2016-09-01');

-- 四：首播时间分位数分布：
LOAD DATA INPATH '/temp/vpq_quantile_0901.txt'
OVERWRITE INTO TABLE da.vpq_quantile partition (dt='2016-09-01');

-- 五：不同CDN的视频下载错误率：
LOAD DATA INPATH '/temp/vdq_cdn_errate_0901.txt'
OVERWRITE INTO TABLE da.vdq_cdn_errate partition (dt='2016-09-01');

-- 六：整体视频下载错误率：
LOAD DATA INPATH '/temp/vdq_errate_0901.txt'
OVERWRITE INTO TABLE da.vdq_errate partition (dt='2016-09-01');

-- 七：视频播放卡顿率：
LOAD DATA INPATH '/temp/vpq_lagrate_0901.txt'
OVERWRITE INTO TABLE da.vpq_lagrate partition (dt='2016-09-01');

-- 验证
select * from vpq_errate where dt='2016-09-01';
select * from vpq_switch where dt='2016-09-01';
select * from vpq_interval where dt='2016-09-01';
select * from vpq_quantile where dt='2016-09-01';
select * from vdq_cdn_errate where dt='2016-09-01';
select * from vdq_errate where dt='2016-09-01';
select * from vpq_lagrate where dt='2016-09-01';

```
