增长指数
===
## 1.分享日志规范
### 1.1 分享点击评估
* 模块(mod)：emptylog
* 接口(ac)：share_onclick
* 触发时间：在用户点击分享

#### 注意: 必填参数一定要带

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :--------: |:--------: |  :------: | :------: | :------: |
| utm_campaign |分享名称，以标识具体的推广活动	 | STRING | 是 | client_share,web_share |
| utm_source | 分享来源，用于确定具体的来源 | STRING | 是 | tangdou_ios,tangdou_webshare |
| utm_medium | 分享媒介，用于分享的广告等媒介| STRING | 是 | mobile_qq,qq_zone,wx_chat,wx_moment,message,share |
| utm_type |  分享类型，用于区分视频，活动页	 | STRING | 是 | 0 视频 1 活动页 2 空间页 3 app本身 4.舞队|
| vid |  视频id	 | STRING | 否 | 55525888 |

### 1.2 分享失败
* 模块(mod)：emptylog
* 接口(ac)：share_fail
* 触发时间：在用户点击分享，然后点击取消。客户端返回分享失败。

#### 注意: 必填参数一定要带

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :--------: |:--------: |  :------: | :------: | :------: |
| utm_campaign |分享名称，以标识具体的推广活动	 | STRING | 是 | client_share |
| utm_source | 分享来源，用于确定具体的来源 | STRING | 是 | tangdou_ios |
| utm_medium | 分享媒介，用于分享的广告等媒介| STRING | 是 | mobile_qq,qq_zone,wx_chat,wx_moment,message |
| utm_type |  分享类型，用于区分视频，活动页	 | STRING | 是 | 0 视频 1 活动页 2 空间页 3 app本身 4.舞队|
| vid |  视频id	 | STRING | 否 | 55525888 |

### 1.3 分享成功
* 模块(mod): user
* 接口(ac)：share
* 触发时间：用户分享成功，并点击返回糖豆

#### 注意: 必填参数一定要带

| 名称      | 含义       | hive字段类型 | 必传参数   |  取值举例  |
| :--------: |:--------: |  :------: | :------: | :------: |
| utm_campaign |分享名称，以标识具体的推广活动	 | STRING | 是 | client_share |
| utm_source | 分享来源，用于确定具体的来源 | STRING | 是 | tangdou_ios |
| utm_medium | 分享媒介，用于分享的广告等媒介	| STRING | 是 |mobile_qq,qq_zone,wx_chat,wx_moment,message |
| utm_type |  分享类型，用于区分视频，活动页	 | STRING | 是 | 0 视频 1 活动页 2 空间页  3 app本身 4.舞队|
| vid |  视频id	 | STRING | 否 | 55525888 |

## 2. 分享链接实例

头条链接：
微信出来
http://m.toutiao.com/i6305244398611333633/?tt_from=weixin&utm_campaign=client_share&from=groupmessage&app=news_article&utm_source=weixin&isappinstalled=1&iid=4718472751&utm_medium=toutiao_ios&wxshare_count=1

### from 和 isappinstalled 是微信带的

网页出来
http://toutiao.com/a6304855958027764225/?app=news_article#6649976-qzone-1-7224-3c8d8e8bb11b3fb9a4fd89478693d6c1

app 出来
http://toutiao.com/group/6308964388184637697/?iid=4891830685&app=news_article&tt_from=mobile_qq&utm_source=mobile_qq&utm_medium=toutiao_ios&utm_campaign=client_share


开眼链接：
http://www.wandoujia.com/eyepetizer/detail.html?vid=8210&utm_campaign=routine&utm_medium=share&utm_source=qq

开眼专题链接
http://www.wandoujia.com/eyepetizer/collection.html?name=childrensday
